#!/bin/bash
# Dusk 1.0: KDE Plasma and KWin underneath, Dusk's look on top.
#
#   ./build.sh install      install Dusk (or update it, or move from the old Dusk)
#   ./build.sh install -y   without asking first
#
# Called by dusk-update, and by the updater in the old Dusk's Settings: it
# follows the same rules (DUSK_PROGRESS for its step list, SUDO_ASKPASS for
# the password, -y / DUSK_YES).
set -euo pipefail
cd "$(dirname "$0")"
DUSK_VERSION=$(sed -n "s/^[[:space:]]*version: '\([^']*\)'.*/\1/p" meson.build | head -1)

if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
	B=$'\e[1m'; R=$'\e[0m'; ACC=$'\e[38;5;75m'; GOOD=$'\e[38;5;114m'; BAD=$'\e[38;5;203m'; GREY=$'\e[38;5;244m'
else
	B=; R=; ACC=; GOOD=; BAD=; GREY=
fi
STEP=0; STEPS=5
step() {
	STEP=$((STEP + 1))
	[[ -n "${DUSK_PROGRESS:-}" ]] && printf '@@step %s %s %s\n' "$STEP" "$STEPS" "$*"
	printf '\n%s%s%s/%s  %s%s\n' "$ACC" "$B" "$STEP" "$STEPS" "$*" "$R"
}
ok() { printf '  %s✓%s %s\n' "$GOOD" "$R" "$*"; }
note() { printf '  %s%s%s\n' "$GREY" "$*" "$R"; }
fail() {
	[[ -n "${DUSK_PROGRESS:-}" ]] && printf '@@failed %s\n' "$*"
	printf '\n  %s✕ %s%s\n' "$BAD" "$*" "$R" >&2
	exit 1
}
# Asked for the password by a window (no terminal): sudo asks through it.
if [[ -n "${SUDO_ASKPASS:-}" && ! -t 0 ]]; then
	sudo() { command sudo -A "$@"; }
fi

YES="${DUSK_YES:-}"
for a in "$@"; do [[ "$a" == -y || "$a" == --yes ]] && YES=1; done
MODE="${1:-install}"
[[ "$MODE" == -y || "$MODE" == --yes ]] && MODE=install
[[ "$MODE" == install ]] || fail "Use: ./build.sh install"

OLD=""
[[ -x /usr/local/bin/dusk ]] && OLD=$(head -1 /usr/local/share/dusk/version 2>/dev/null || echo 0.x)

printf '\n  %s%sDusk %s%s\n' "$ACC" "$B" "$DUSK_VERSION" "$R"
note "KDE Plasma and KWin underneath, Dusk's panel, Control Centre, icons and colours on top."
if [[ -n "$OLD" ]]; then
	note "Moves you over from Dusk $OLD (your look, wallpaper, shortcuts and pinned apps come along)."
fi
if [[ -z "$YES" && -t 0 && -z "${DUSK_PROGRESS:-}" ]]; then
	read -r -p "  ${B}Install Dusk $DUSK_VERSION?${R} [Y/n] " answer
	[[ "$answer" == [nN]* ]] && exit 0
fi

# ---- 1. KDE Plasma and the tools the Control Centre uses ---------------------------------
step "Getting KDE Plasma and the tools Dusk uses"
need=()
command -v startplasma-wayland >/dev/null || need+=("@kde-desktop-environment")
for t in plasmashell:plasma-workspace kpackagetool6:kf6-kpackage kwriteconfig6:kf6-kconfig playerctl:playerctl \
		brightnessctl:brightnessctl wpctl:wireplumber nmcli:NetworkManager spectacle:spectacle \
		powerprofilesctl:power-profiles-daemon rfkill:util-linux bluetoothctl:bluez python3:python3; do
	command -v "${t%%:*}" >/dev/null || need+=("${t#*:}")
done
if (( ${#need[@]} )); then
	note "Installing: ${need[*]} (KDE Plasma is about 1 GB the first time)"
	sudo dnf install -y "${need[@]}" || fail "Couldn't install ${need[*]}."
fi
ok "KDE Plasma and the tools are here"

# ---- 2. The old Dusk ----------------------------------------------------------------------
step "Moving over from the old Dusk"
python3 ./dusk-migrate || note "(nothing to bring over)"
if [[ -n "$OLD" ]]; then
	# Its own compositor and helpers go; its settings file stays in ~/.config/dusk.
	sudo rm -f /usr/local/bin/dusk /usr/local/bin/dusk-settings /usr/local/bin/dusk-xembed \
		/usr/local/bin/dusk-session /usr/local/bin/dusk-apply-theme /usr/local/bin/dusk-lyrics \
		/usr/local/bin/dusk-record /usr/local/bin/dusk-audio-outputs /usr/local/bin/dusk-doctor \
		/usr/local/share/applications/org.dusk.Settings.desktop /usr/lib/systemd/user/dusk-session.target \
		/usr/share/xdg-desktop-portal/dusk-portals.conf /etc/pam.d/dusk-lock \
		/usr/local/share/dusk/whatsnew.txt
	sudo rm -rf /usr/local/share/dusk-login
	ok "the old Dusk $OLD is gone; your settings came along"
else
	ok "nothing to move"
fi

# ---- 3. Dusk's parts ----------------------------------------------------------------------
step "Installing Dusk's panel, Control Centre, icons and colours"
mkdir -p "$HOME/.local/share/icons" "$HOME/.local/share/color-schemes" "$HOME/.local/bin" \
	"$HOME/.config/autostart" "$HOME/.local/share/dusk"
rm -rf "$HOME/.local/share/icons/Dusk"
cp -r icons/Dusk "$HOME/.local/share/icons/Dusk"
install -m755 dusk-icons-fill "$HOME/.local/bin/dusk-icons-fill"
"$HOME/.local/bin/dusk-icons-fill" || true
cat > "$HOME/.config/autostart/dusk-icons-fill.desktop" <<EOD
[Desktop Entry]
Type=Application
Name=Dusk icons for new apps
Exec=$HOME/.local/bin/dusk-icons-fill
NoDisplay=true
X-KDE-autostart-phase=2
EOD
cp color-schemes/*.colors "$HOME/.local/share/color-schemes/"
for pkg in "Plasma/Applet:plasmoids/org.dusk.controlcentre" "Plasma/LookAndFeel:lookandfeel/org.dusk.desktop"; do
	kpackagetool6 -t "${pkg%%:*}" -u "${pkg#*:}" >/dev/null 2>&1 || kpackagetool6 -t "${pkg%%:*}" -i "${pkg#*:}" >/dev/null ||
		fail "Couldn't install ${pkg#*:}."
done
# Title bars: centred titles, small soft shadows.
kwriteconfig6 --file breezerc --group Windeco --key TitleAlignment AlignCenterFullWidth
kwriteconfig6 --file breezerc --group Common --key ShadowSize ShadowSmall
kwriteconfig6 --file breezerc --group Common --key ShadowStrength 90
kwriteconfig6 --file breezerc --group Common --key OutlineCloseButton false
kwriteconfig6 --file kdeglobals --group Icons --key Theme Dusk
ok "icons (and one for every app that had none), Dusk Dark and Light, the Control Centre, the Dusk look"

# ---- 4. "Dusk" on the login screen ---------------------------------------------------------
step "Putting Dusk on the login screen"
exec_line=/usr/bin/startplasma-wayland
[[ -x /usr/libexec/plasma-dbus-run-session-if-needed ]] && exec_line="/usr/libexec/plasma-dbus-run-session-if-needed $exec_line"
sed "s|^Exec=.*|Exec=$exec_line|" data/dusk.desktop | sudo install -Dm644 /dev/stdin /usr/share/wayland-sessions/dusk.desktop
sudo install -Dm755 data/dusk-update /usr/local/bin/dusk-update
sudo install -Dm755 data/dusk-uninstall /usr/local/bin/dusk-uninstall
sudo install -Dm644 icons/Dusk/scalable/apps/dusk.svg /usr/local/share/icons/hicolor/scalable/apps/dusk.svg
printf '%s\n' "$DUSK_VERSION" | sudo install -Dm644 /dev/stdin /usr/local/share/dusk/version
mkdir -p "$HOME/.local/state/dusk" && printf '%s\n%s\n' "$DUSK_VERSION" "$(pwd)" > "$HOME/.local/state/dusk/installed"
ok "\"Dusk\" is on the login screen (it starts Plasma with Dusk's look)"

# ---- 5. Switching on ---------------------------------------------------------------------
step "Switching on Dusk's look"
if pgrep -u "$(id -u)" -x plasmashell >/dev/null; then
	sh "$HOME/.local/share/dusk/apply.sh" >/dev/null 2>&1 || true
	ok "done: Dusk's panel and Control Centre are on screen"
else
	# At the first login to Dusk (Plasma), once.
	cat > "$HOME/.config/autostart/dusk-apply-once.desktop" <<EOD
[Desktop Entry]
Type=Application
Name=Switch to Dusk's look
Exec=sh -c 'sleep 4; sh "$HOME/.local/share/dusk/apply.sh"; rm -f "$HOME/.config/autostart/dusk-apply-once.desktop"'
OnlyShowIn=KDE;
NoDisplay=true
X-KDE-autostart-phase=2
EOD
	ok "it switches on when you log in to Dusk"
fi

[[ -n "${DUSK_PROGRESS:-}" ]] && printf '@@installed %s\n' "$DUSK_VERSION"
printf '\n  %s%sDusk %s is installed.%s\n' "$GOOD" "$B" "$DUSK_VERSION" "$R"
if ! pgrep -u "$(id -u)" -x plasmashell >/dev/null; then
	note "Log out, then pick \"Dusk\" from the gear on the login screen."
fi
