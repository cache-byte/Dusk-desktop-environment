#!/usr/bin/env bash
# Dusk's installer and build script.
#
#   ./build.sh            install missing build packages, then build
#   ./build.sh run        build, then run Dusk in a window on your current desktop
#   ./build.sh install    build, then install Dusk as a login session
#   ./build.sh update     get the newest Dusk from GitHub and install it (dusk-update)
#   ./build.sh uninstall  remove the installed session
#   ./build.sh fonts      (re)download Dusk's fonts: Google Sans and Google Sans Code
#
# Fedora is what Dusk is made on. Debian / Ubuntu and Arch are supported on a
# best-effort basis: UNTESTED. Add -y (or DUSK_YES=1) to skip the question.
set -euo pipefail
cd "$(dirname "$0")"

# ---- Looks ----------------------------------------------------------------------------
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
	B=$'\e[1m'; D=$'\e[2m'; R=$'\e[0m'
	PURPLE=$'\e[38;5;141m'; DEEP=$'\e[38;5;97m'; SUN=$'\e[38;5;215m'; CORAL=$'\e[38;5;209m'
	STAR=$'\e[38;5;229m'; CYAN=$'\e[38;5;116m'; GREEN=$'\e[38;5;114m'; YELLOW=$'\e[38;5;221m'; RED=$'\e[38;5;203m'
else
	B=; D=; R=; PURPLE=; DEEP=; SUN=; CORAL=; STAR=; CYAN=; GREEN=; YELLOW=; RED=
fi
say()  { printf '%s›%s %s\n' "$CYAN" "$R" "$*"; }
good() { printf '%s✓%s %s\n' "$GREEN" "$R" "$*"; }
warn() { printf '%s!%s %s\n' "$YELLOW" "$R" "$*" >&2; }
fail() { printf '%s✗ %s%s\n' "$RED" "$*" "$R" >&2; exit 1; }

DUSK_VERSION=$(sed -n "s/^[[:space:]]*version: '\([^']*\)'.*/\1/p" meson.build | head -1)

banner() {
	printf '\n'
	printf '  %s✦%s %sD U S K%s  %s%s%s\n' "$STAR" "$R" "$B$PURPLE" "$R" "$D" "$DUSK_VERSION" "$R"
	printf '  %s─────────────────────────%s\n' "$CORAL" "$R"
	printf '  %sa desktop for the evening%s\n' "$D" "$R"
	printf '\n'
}

warning() {
	local line="${YELLOW}${B}"
	printf '%s╭──────────────────────────────────────────────────────────────────╮%s\n' "$line" "$R"
	printf '%s│  ⚠  DUSK IS WRITTEN BY AN AI (Claude, by Anthropic).             │%s\n' "$line" "$R"
	printf '%s│     IT MAY HAVE BUGS, CRASH, OR BREAK THINGS ON YOUR COMPUTER.   │%s\n' "$line" "$R"
	printf '%s│     USE IT AT YOUR OWN RISK. KEEP ANOTHER DESKTOP INSTALLED.     │%s\n' "$line" "$R"
	printf '%s╰──────────────────────────────────────────────────────────────────╯%s\n' "$line" "$R"
	case "$DISTRO" in
	fedora) printf '  %sFedora:%s the system Dusk is made and tested on.\n' "$B" "$R" ;;
	*) printf '  %s%s%s: %sUNTESTED.%s Package names are a best guess, and Dusk needs wlroots 0.20,\n  which your system may not have yet. Fedora is the only tested system.\n' \
		"$B" "$DISTRO_NAME" "$R" "$B$RED" "$R" ;;
	esac
	printf '\n'
}

confirm() {
	[[ "${DUSK_YES:-}" == 1 ]] && return 0
	[[ -t 0 ]] || return 0
	local answer
	read -r -p "${B}Carry on?${R} [y/N] " answer
	[[ "$answer" == [yY]* ]] || { say "Nothing was changed."; exit 0; }
}

# ---- Which system ---------------------------------------------------------------------
DISTRO=unknown
DISTRO_NAME="This system"
if [[ -r /etc/os-release ]]; then
	# shellcheck disable=SC1091
	. /etc/os-release
	DISTRO_NAME="${NAME:-$DISTRO_NAME}"
	case " ${ID:-} ${ID_LIKE:-} " in
	*" fedora "*|*" rhel "*) DISTRO=fedora ;;
	*" arch "*) DISTRO=arch ;;
	*" debian "*|*" ubuntu "*) DISTRO=debian ;;
	esac
fi

case "$DISTRO" in
fedora)
	PACKAGES=(gcc-c++ meson ninja-build pkgconf-pkg-config
		wlroots-devel wayland-devel wayland-protocols-devel libxkbcommon-devel
		pixman-devel libdrm-devel libinput-devel cairo-devel pango-devel
		gdk-pixbuf2-devel git pam-devel file curl
		libglvnd-devel mesa-libEGL-devel mesa-libgbm-devel   # scenefx (rounded corners)
		libxcb-devel xcb-util-wm-devel xorg-x11-server-Xwayland   # X11 apps
		systemd-devel                                             # notifications (sd-bus)
		qt6-qtbase-devel qt6-qtwayland qt6-qtsvg   # Dusk Settings
		brightnessctl wireplumber playerctl                       # brightness, volume, media
		bluez pulseaudio-utils python3 wf-recorder                # Bluetooth, media wave, lyrics, recording
		xdg-desktop-portal-gtk qt6-qtbase-gui)                    # apps follow light/dark
	OPTIONAL=(gnome-keyring polkit-gnome adw-gtk3-theme qt6ct grim wl-clipboard libnotify
		wayvnc android-tools scrcpy papirus-icon-theme bibata-cursor-themes)
	;;
arch)
	PACKAGES=(base-devel meson ninja pkgconf
		wlroots0.20 wayland wayland-protocols libxkbcommon
		pixman libdrm libinput cairo pango gdk-pixbuf2 git pam file curl
		libglvnd mesa libxcb xcb-util-wm xorg-xwayland systemd-libs
		qt6-base qt6-wayland qt6-svg
		brightnessctl wireplumber playerctl xdg-desktop-portal-gtk
		bluez bluez-utils libpulse python wf-recorder)
	OPTIONAL=(gnome-keyring polkit-gnome qt6ct grim wl-clipboard libnotify
		wayvnc android-tools scrcpy papirus-icon-theme)
	;;
debian)
	PACKAGES=(build-essential meson ninja-build pkg-config
		libwlroots-0.20-dev libwayland-dev wayland-protocols libxkbcommon-dev
		libpixman-1-dev libdrm-dev libinput-dev libcairo2-dev libpango1.0-dev
		libgdk-pixbuf-2.0-dev git libpam0g-dev file curl
		libegl-dev libgbm-dev libgles-dev libxcb1-dev libxcb-icccm4-dev xwayland libsystemd-dev
		qt6-base-dev qt6-wayland libqt6svg6-dev
		brightnessctl wireplumber playerctl xdg-desktop-portal-gtk
		bluez pulseaudio-utils python3 wf-recorder)
	OPTIONAL=(gnome-keyring policykit-1-gnome mate-polkit qt6ct grim wl-clipboard libnotify-bin
		wayvnc adb scrcpy papirus-icon-theme)
	;;
*)
	PACKAGES=(); OPTIONAL=()
	;;
esac

have_pkg() {
	case "$DISTRO" in
	fedora) rpm -q "$1" >/dev/null 2>&1 ;;
	arch) pacman -Q "$1" >/dev/null 2>&1 ;;
	debian) dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed" ;;
	*) return 0 ;;
	esac
}
pkg_install() {   # must-haves: stop if they can't be installed
	case "$DISTRO" in
	fedora) sudo dnf install -y "$@" ;;
	arch) sudo pacman -S --needed --noconfirm "$@" ;;
	debian) sudo apt-get update -qq && sudo apt-get install -y "$@" ;;
	esac
}
pkg_try() {   # nice to have: whatever exists
	case "$DISTRO" in
	fedora) sudo dnf install -y --skip-unavailable "$@" >/dev/null 2>&1 || true ;;
	arch) for p in "$@"; do sudo pacman -S --needed --noconfirm "$p" >/dev/null 2>&1 || true; done ;;
	debian) for p in "$@"; do sudo apt-get install -y "$p" >/dev/null 2>&1 || true; done ;;
	esac
}

install_deps() {
	if [[ "$DISTRO" == unknown ]]; then
		warn "Don't know how to install packages on $DISTRO_NAME: install Dusk's build packages yourself (see build.sh)."
	else
		local missing=()
		for p in "${PACKAGES[@]}"; do have_pkg "$p" || missing+=("$p"); done
		if ((${#missing[@]})); then
			say "Installing build packages: ${D}${missing[*]}${R}"
			pkg_install "${missing[@]}" || fail "Couldn't install the build packages above."
		fi
		local want=()
		for p in "${OPTIONAL[@]}"; do have_pkg "$p" || want+=("$p"); done
		# One polkit agent is enough.
		if have_pkg polkit-gnome || have_pkg mate-polkit || have_pkg policykit-1-gnome; then
			local keep=()
			for p in "${want[@]+"${want[@]}"}"; do
				[[ "$p" == polkit-gnome || "$p" == mate-polkit || "$p" == policykit-1-gnome ]] || keep+=("$p")
			done
			want=("${keep[@]+"${keep[@]}"}")
		fi
		if ((${#want[@]})) && [[ ! -f "$HOME/.cache/dusk-optional-asked" ]]; then
			say "Installing optional packages (skipped if not available): ${D}${want[*]}${R}"
			pkg_try "${want[@]}"
			mkdir -p "$HOME/.cache" && touch "$HOME/.cache/dusk-optional-asked"
		fi
	fi
	install_themes
	install_fonts
	install_songrec
}

# SongRec (a Shazam client): lyrics for songs whose name finds nothing are
# found by listening. From the system's packages if it has it, else Flathub.
install_songrec() {
	command -v songrec >/dev/null 2>&1 && return
	flatpak info com.github.marinm.songrec >/dev/null 2>&1 && return
	if [[ "$DISTRO" == arch ]] && pkg_try songrec 2>/dev/null && command -v songrec >/dev/null 2>&1; then return; fi
	if command -v flatpak >/dev/null 2>&1; then
		say "Installing SongRec from Flathub (recognises songs for lyrics)"
		flatpak remote-add --user --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo 2>/dev/null || true
		flatpak install --user -y --noninteractive flathub com.github.marinm.songrec >/dev/null 2>&1 \
			|| warn "Couldn't install SongRec (lyrics still work for songs found by name)."
	fi
}

# Dusk's default icons and cursor: Papirus and Bibata Modern Classic. From
# the system's packages when it has them; otherwise downloaded into your own
# icons folder.
install_themes() {
	local icons="$HOME/.local/share/icons"
	if ! ls -d /usr/share/icons/Papirus "$icons/Papirus" >/dev/null 2>&1; then
		pkg_try papirus-icon-theme
		if ! ls -d /usr/share/icons/Papirus >/dev/null 2>&1; then
			say "Downloading the Papirus icon theme"
			curl -fsSL https://raw.githubusercontent.com/PapirusDevelopmentTeam/papirus-icon-theme/master/install.sh |
				DESTDIR="$icons" sh >/dev/null 2>&1 || warn "Couldn't get Papirus (Dusk uses GNOME's icons meanwhile)"
		fi
	fi
	if ! ls -d /usr/share/icons/Bibata-Modern-Classic "$icons/Bibata-Modern-Classic" >/dev/null 2>&1; then
		[[ "$DISTRO" == fedora ]] && pkg_try bibata-cursor-themes
		if ! ls -d /usr/share/icons/Bibata-Modern-Classic >/dev/null 2>&1; then
			say "Downloading the Bibata Modern Classic cursor"
			mkdir -p "$icons"
			curl -fsSL https://github.com/ful1e5/Bibata_Cursor/releases/latest/download/Bibata-Modern-Classic.tar.xz |
				tar -xJ -C "$icons" || warn "Couldn't get Bibata (Dusk uses GNOME's cursor meanwhile)"
		fi
	fi
	# X11 apps with older libraries (Steam) only look in ~/.icons.
	if [[ -d "$icons/Bibata-Modern-Classic" && ! -e "$HOME/.icons/Bibata-Modern-Classic" ]]; then
		mkdir -p "$HOME/.icons" && ln -s "$icons/Bibata-Modern-Classic" "$HOME/.icons/Bibata-Modern-Classic" || true
	fi
}

# Dusk's default fonts: Google Sans for the interface and Google Sans Code
# for terminals (both free, OFL, from Google Fonts), into your own fonts folder.
# Without them everything uses Noto Sans / the system monospace instead.
install_fonts() {
	local dir="$HOME/.local/share/fonts/dusk" base="https://github.com/google/fonts/raw/main/ofl" got=0
	local want=("googlesans/GoogleSans%5BGRAD%2Copsz%2Cwght%5D.ttf:GoogleSans.ttf"
		"googlesans/GoogleSans-Italic%5BGRAD%2Copsz%2Cwght%5D.ttf:GoogleSans-Italic.ttf"
		"googlesanscode/GoogleSansCode%5Bwght%5D.ttf:GoogleSansCode.ttf"
		"googlesanscode/GoogleSansCode-Italic%5Bwght%5D.ttf:GoogleSansCode-Italic.ttf")
	local fams; fams=$(fc-list : family 2>/dev/null || true)
	mkdir -p "$dir"
	rm -f "$dir/GoogleSansFlex.ttf"   # Dusk 0.21.0-0.21.1 used Google Sans Flex
	for w in "${want[@]}"; do
		local src="${w%%:*}" name="${w##*:}"
		if [[ "${1:-}" != again ]]; then
			[[ -s "$dir/$name" ]] && continue
			case "$name" in
				GoogleSans.ttf|GoogleSans-Italic.ttf) grep -qxF "Google Sans" <<<"$fams" && continue ;;
				GoogleSansCode*) grep -qxF "Google Sans Code" <<<"$fams" && continue ;;
			esac
		fi
		say "Downloading the font $name"
		if curl -fsSL --retry 2 -o "$dir/$name.part" "$base/$src"; then
			mv "$dir/$name.part" "$dir/$name"; got=1
		else
			rm -f "$dir/$name.part"; warn "Couldn't download $name (Dusk uses Noto Sans / monospace meanwhile)"
		fi
	done
	if ((got)); then fc-cache -f "$dir" >/dev/null 2>&1 || true; fi
}

# Dusk once had its own login screen (greetd). It's gone: put GNOME's (GDM)
# back if it was in use, and remove what it installed.
remove_login_screen() {
	if grep -q dusk-greeter /etc/greetd/config.toml 2>/dev/null; then
		say "Putting GNOME's login screen (GDM) back"
		sudo systemctl disable greetd.service 2>/dev/null || true
		sudo systemctl enable gdm.service 2>/dev/null || sudo systemctl enable gdm3.service 2>/dev/null || true
		if [[ -f /etc/greetd/config.toml.before-dusk ]]; then
			sudo mv /etc/greetd/config.toml.before-dusk /etc/greetd/config.toml
		else
			sudo rm -f /etc/greetd/config.toml
		fi
		if [[ -f /etc/pam.d/greetd.before-dusk ]]; then sudo mv /etc/pam.d/greetd.before-dusk /etc/pam.d/greetd; fi
		good "GDM is back after a restart."
	fi
	sudo rm -rf /usr/local/bin/dusk-greeter /usr/local/bin/dusk-login-sync \
		/usr/share/polkit-1/actions/org.dusk.login-sync.policy /etc/dusk/greeter.conf \
		/usr/local/share/dusk-login /var/cache/dusk-greeter /var/lib/dusk-greeter \
		/var/log/dusk-login-sync.log
	sudo rmdir /etc/dusk 2>/dev/null || true
}

build() {
	install_deps
	if [[ ! -d build ]]; then
		meson setup build || fail "meson couldn't set up the build (a missing package? see above)."
	else
		# Look for packages again (one installed since, like Qt Quick, is found).
		meson setup --reconfigure build >/dev/null || fail "meson couldn't set up the build (a missing package? see above)."
	fi
	ninja -C build || fail "The build failed (see above)."
	good "Built: $(pwd)/build/dusk and $(pwd)/build/dusk-settings"
}

ARGS=()
for a in "$@"; do
	if [[ "$a" == -y || "$a" == --yes ]]; then DUSK_YES=1; else ARGS+=("$a"); fi
done
set -- "${ARGS[@]+"${ARGS[@]}"}"

case "${1:-build}" in
build)
	banner
	warning
	confirm
	build
	;;
run)
	build
	# Inside an existing Wayland desktop, Dusk opens as a window.
	# DUSK_TERMINAL=kitty ./build.sh run  also starts a terminal in it.
	if [[ -n "${DUSK_TERMINAL:-}" ]]; then
		exec ./build/dusk -s "$DUSK_TERMINAL" "${@:2}"
	fi
	exec ./build/dusk "${@:2}"
	;;
install)
	banner
	warning
	confirm
	build
	say "Installing (your password may be asked for)"
	sudo install -Dm755 build/dusk /usr/local/bin/dusk
	sudo install -Dm755 build/dusk-settings /usr/local/bin/dusk-settings
	sudo rm -f /usr/local/bin/dusk-settings-classic   # from 0.24 (the QML Settings, now gone)
	sudo install -Dm755 data/dusk-session /usr/local/bin/dusk-session
	sudo install -Dm755 data/dusk-update /usr/local/bin/dusk-update
	sudo install -Dm755 data/dusk-uninstall /usr/local/bin/dusk-uninstall
	# The lock screen's password check.
	sudo install -Dm644 data/pam-dusk-lock /etc/pam.d/dusk-lock
	remove_login_screen
	sudo install -Dm644 data/icons/dusk.svg /usr/local/share/icons/hicolor/scalable/apps/dusk.svg
	sudo install -Dm644 data/icons/org.dusk.Settings.svg /usr/local/share/icons/hicolor/scalable/apps/org.dusk.Settings.svg
	sudo gtk-update-icon-cache -qtf /usr/local/share/icons/hicolor 2>/dev/null || true
	sed 's|^Exec=.*|Exec=/usr/local/bin/dusk-session|' data/dusk.desktop |
		sudo install -Dm644 /dev/stdin /usr/share/wayland-sessions/dusk.desktop
	sudo install -Dm755 data/dusk-apply-theme /usr/local/bin/dusk-apply-theme
	sudo install -Dm755 data/dusk-doctor /usr/local/bin/dusk-doctor
	sudo install -Dm755 data/dusk-lyrics /usr/local/bin/dusk-lyrics
	sudo install -Dm755 data/dusk-record /usr/local/bin/dusk-record
	# Bluetooth: many systems install its service switched off. With an
	# adapter there, start it now and at every start-up.
	if ls /sys/class/bluetooth 2>/dev/null | grep -q '^hci' && ! systemctl is-active --quiet bluetooth.service 2>/dev/null; then
		sudo systemctl enable --now bluetooth.service 2>/dev/null || warn "Couldn't start the Bluetooth service."
	fi
	sudo install -Dm644 data/dusk-session.target /usr/lib/systemd/user/dusk-session.target
	# Lets apps (libadwaita, Firefox, Electron...) see Dusk's light/dark setting.
	sudo install -Dm644 data/dusk-portals.conf /usr/share/xdg-desktop-portal/dusk-portals.conf
	sed 's|^Exec=.*|Exec=/usr/local/bin/dusk-settings|' data/org.dusk.Settings.desktop |
		sudo install -Dm644 /dev/stdin /usr/local/share/applications/org.dusk.Settings.desktop
	# Floe was this desktop's old name: take the old session off the login screen.
	sudo rm -f /usr/local/bin/floe /usr/local/bin/floe-settings \
		/usr/share/wayland-sessions/floe.desktop \
		/usr/local/share/applications/floe-settings.desktop \
		/usr/local/share/applications/org.floe.Settings.desktop
	# Built from ~/src (the zips): keep that folder out of sight in Files
	# (the file manager hides what's listed in a folder's .hidden file).
	if [[ "$(pwd)" == "$HOME/src/"* ]] && ! grep -qxF src "$HOME/.hidden" 2>/dev/null; then
		echo src >> "$HOME/.hidden"
	fi
	# Which version, from where (Settings › About › Updates).
	mkdir -p "$HOME/.local/state/dusk" && printf '%s\n%s\n' "$DUSK_VERSION" "$(pwd)" > "$HOME/.local/state/dusk/installed"
	printf '\n'
	good "${B}Dusk $DUSK_VERSION is installed.${R}"
	if pgrep -u "$(id -u)" -x dusk >/dev/null 2>&1; then
		# Running Dusk now: the new version starts when you log in again.
		printf '\n'
		answer=n
		if [[ -t 0 && "${DUSK_YES:-}" != 1 ]]; then
			read -r -p "${B}Log out now to start the new version?${R} Save your work first. [y/N] " answer
		fi
		if [[ "$answer" == [yY]* ]]; then
			say "Logging out…"
			sleep 1
			pkill -TERM -u "$(id -u)" -x dusk || true
		else
			say "The new version starts the next time you log in."
			command -v notify-send >/dev/null &&
				notify-send -a Dusk -i dusk "Dusk $DUSK_VERSION is installed" "Log out and back in to start it." 2>/dev/null || true
		fi
	else
		say "Log out, then pick \"Dusk\" from the gear menu on the login screen."
	fi
	;;
update)
	exec bash data/dusk-update "${@:2}"
	;;
uninstall)
	# Everything, and what Dusk changed for other desktops put back.
	exec bash data/dusk-uninstall "${@:2}"
	;;
fonts)
	install_fonts again
	good "Fonts ready. Pick them in Settings › Appearance › Fonts."
	;;
*)
	echo "Usage: $0 [build|run|install|update|uninstall|fonts] [-y]"
	exit 1
	;;
esac
