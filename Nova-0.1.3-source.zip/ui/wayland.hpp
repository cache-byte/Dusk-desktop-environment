// Wayland backend for novaui: connection, outputs, seat (pointer / keyboard / clipboard),
// shared-memory buffers and the three kinds of window Nova needs:
//   LayerWindow    – panel, pop-ups, OSDs, wallpaper (wlr-layer-shell)
//   ToplevelWindow – ordinary app window (Settings)
//   LockWindow     – lock screen (ext-session-lock)
#pragma once
#include "window.hpp"

#include <list>

struct wl_display;
struct wl_registry;
struct wl_compositor;
struct wl_shm;
struct wl_seat;
struct wl_pointer;
struct wl_keyboard;
struct wl_surface;
struct wl_output;
struct wl_buffer;
struct wl_callback;
struct wl_data_device_manager;
struct wl_data_device;
struct wl_data_source;
struct wl_data_offer;
struct wl_subcompositor;
struct xdg_wm_base;
struct xdg_surface;
struct xdg_toplevel;
struct zwlr_layer_shell_v1;
struct zwlr_layer_surface_v1;
struct ext_session_lock_manager_v1;
struct ext_session_lock_v1;
struct ext_session_lock_surface_v1;
struct wp_cursor_shape_manager_v1;
struct wp_cursor_shape_device_v1;
struct wp_viewporter;
struct wp_viewport;
struct wp_fractional_scale_manager_v1;
struct wp_fractional_scale_v1;
struct ext_background_effect_manager_v1;
struct ext_background_effect_surface_v1;
struct xkb_context;
struct xkb_keymap;
struct xkb_state;

namespace ui {

class WaylandWindow;

struct Output {
    wl_output *wl = nullptr;
    uint32_t globalName = 0;
    std::string name, description;
    int width = 0, height = 0;      // mode, pixels
    int scale = 1;
    int x = 0, y = 0;
    Size logical() const { return {(double)width / scale, (double)height / scale}; }
    bool done = false;
};

class Wayland {
public:
    static Wayland &get();
    bool connect();                         // false when there is no compositor
    wl_display *display() const { return display_; }
    void roundtrip();
    void flush();

    // globals
    wl_compositor *compositor = nullptr;
    wl_subcompositor *subcompositor = nullptr;
    wl_shm *shm = nullptr;
    wl_seat *seat = nullptr;
    xdg_wm_base *wmBase = nullptr;
    zwlr_layer_shell_v1 *layerShell = nullptr;
    ext_session_lock_manager_v1 *lockManager = nullptr;
    wp_cursor_shape_manager_v1 *cursorShape = nullptr;
    wp_viewporter *viewporter = nullptr;
    wp_fractional_scale_manager_v1 *fractionalScale = nullptr;
    ext_background_effect_manager_v1 *backgroundEffect = nullptr;
    wl_data_device_manager *dataDeviceManager = nullptr;
    // other modules (toplevels, idle) bind their own globals from this list
    struct Global { uint32_t name; std::string interface; uint32_t version; };
    std::vector<Global> globals;
    void *bind(const Global &g, const void *interface, uint32_t version);

    // outputs
    std::vector<std::unique_ptr<Output>> outputs;
    Output *outputFor(wl_output *o);
    Output *outputNamed(const std::string &name);
    Signal<Output *> outputAdded;
    Signal<Output *> outputRemoved;

    // input
    WaylandWindow *pointerFocus = nullptr, *keyboardFocus = nullptr;
    uint32_t lastSerial = 0, pointerSerial = 0;
    Point pointerPos;
    void setCursor(Cursor c);
    // clipboard
    void setClipboard(const std::string &text);
    void readClipboard(std::function<void(const std::string &)> cb);
    // keyboard state, readable by anyone (Caps Lock hint on the lock screen)
    bool capsLock = false, numLock = false;
    Signal<> locksChanged;

    // internals (used by the C callbacks)
    void registryGlobal(wl_registry *r, uint32_t name, const char *iface, uint32_t version);
    void registryRemove(uint32_t name);
    void seatCaps(uint32_t caps);
    void keymap(int fd, uint32_t size);
    void key(uint32_t serial, uint32_t time, uint32_t key, uint32_t state);
    void modifiers(uint32_t dep, uint32_t lat, uint32_t lock, uint32_t group);
    void repeatInfo(int32_t rate, int32_t delay) { repeatRate_ = rate; repeatDelay_ = delay; }
    void stopRepeat();
    std::vector<WaylandWindow *> windows;
    wl_pointer *pointer = nullptr;
    wl_keyboard *keyboard = nullptr;
    wp_cursor_shape_device_v1 *cursorDevice = nullptr;
    wl_data_device *dataDevice = nullptr;
    wl_data_source *selectionSource = nullptr;
    std::string selectionText;
    wl_data_offer *selectionOffer = nullptr;
    std::vector<std::string> offerMimes;
    Cursor currentCursor = Cursor::Default;
    // pointer frame accumulation
    double axisX = 0, axisY = 0;
    int axis120X = 0, axis120Y = 0;
    bool axisDiscrete = false;
private:
    wl_display *display_ = nullptr;
    wl_registry *registry_ = nullptr;
    xkb_context *xkbCtx_ = nullptr;
    xkb_keymap *xkbKeymap_ = nullptr;
    xkb_state *xkbState_ = nullptr;
    int repeatRate_ = 30, repeatDelay_ = 400;
    int repeatTimer_ = 0;
    uint32_t repeatKey_ = 0;
    KeyEvent repeatEvent_;
    void sendKey(uint32_t key, bool pressed, bool repeat);
};

// A window on a wl_surface, drawn with Cairo into shm buffers
class WaylandWindow : public Window {
public:
    WaylandWindow();
    ~WaylandWindow() override;
    wl_surface *surface() const { return surface_; }
    bool configured() const { return configured_; }
    // input region: by default the whole window; empty rect list = click-through
    void setInputRegion(const std::vector<Rect> &rects);
    void setInputAll();
    void setOpaqueAll(bool opaque) { opaque_ = opaque; }
    void setCursor(Cursor c) override;
    void setClipboard(const std::string &t) override { Wayland::get().setClipboard(t); }
    void readClipboard(std::function<void(const std::string &)> cb) override { Wayland::get().readClipboard(std::move(cb)); }
    // blur behind cards (compositor real blur); updated after every paint
    bool wantBlur = true;
    bool tiny = false;      // one-pixel buffer stretched by the viewport (click catchers, solid fills)
    void hide();      // destroy the surface; show() recreates it
    void show();
    bool shown() const { return surface_ != nullptr; }
    // from the C callbacks
    void configureSize(int w, int h);
    void frameDone();
    void preferredScale(double s);
    void enter(wl_output *o);
    Output *output() const { return output_; }
protected:
    virtual void createRole() = 0;       // layer / xdg / lock role on surface_
    virtual void destroyRole() = 0;
    void scheduleRedraw() override;
    void ackConfigure() {}
    void commitFrame();
    wl_surface *surface_ = nullptr;
    bool configured_ = false;
    bool frameRequested_ = false, framePending_ = false;
    bool opaque_ = false;
    bool inputAll_ = true, inputDirty_ = false;
    std::vector<Rect> input_;
    void applyInput();
    double prefScale_ = 1;
    wp_viewport *viewport_ = nullptr;
    wp_fractional_scale_v1 *fracScale_ = nullptr;
    ext_background_effect_surface_v1 *blurEffect_ = nullptr;
    std::vector<std::pair<Rect, double>> lastBlur_;
    Output *output_ = nullptr;
    struct Buffer {
        wl_buffer *wl = nullptr;
        void *data = nullptr;
        size_t size = 0;
        int w = 0, h = 0;
        bool busy = false;
    };
    std::list<Buffer> buffers_;     // stable addresses: release callbacks point into it
    Buffer *nextBuffer(int w, int h);
    void freeBuffers();
    void createSurface();
    void destroySurface();
    void updateBlur();
    friend class Wayland;
};

enum class Layer { Background = 0, Bottom = 1, Top = 2, Overlay = 3 };
enum Anchor : uint32_t { AnchorTop = 1, AnchorBottom = 2, AnchorLeft = 4, AnchorRight = 8 };
enum class KeyboardMode { None = 0, Exclusive = 1, OnDemand = 2 };

class LayerWindow : public WaylandWindow {
public:
    LayerWindow(const std::string &ns, Layer layer, Output *out = nullptr);
    ~LayerWindow() override;
    void setAnchors(uint32_t a);
    void setMargins(int top, int right, int bottom, int left);
    void setExclusiveZone(int z);
    void setKeyboard(KeyboardMode m);
    void setLayer(Layer l);
    void setRequestedSize(int w, int h);    // 0 = stretch along anchored edges
    std::function<void()> onClosed;         // compositor dropped the surface (output went away)
    void closedByCompositor();
    Output *targetOutput() const { return target_; }
protected:
    void createRole() override;
    void destroyRole() override;
    std::string ns_;
    Layer layer_;
    Output *target_;
    zwlr_layer_surface_v1 *ls_ = nullptr;
    uint32_t anchors_ = 0;
    int mt_ = 0, mr_ = 0, mb_ = 0, ml_ = 0, excl_ = 0, reqW_ = 0, reqH_ = 0;
    KeyboardMode kb_ = KeyboardMode::None;
    void applyState();
};

class ToplevelWindow : public WaylandWindow {
public:
    ToplevelWindow(const std::string &title, const std::string &appId, Size initial);
    ~ToplevelWindow() override;
    void setTitle(const std::string &t);
    void setMinSize(int w, int h);
    void startMove();
    void startResize(uint32_t edges);   // xdg_toplevel resize edges
    void setMaximized(bool m);
    void minimize();
    bool maximized() const { return maximized_; }
    std::function<void()> onCloseRequest;   // default: quit the loop
    void close() override;
    // from callbacks
    void toplevelConfigure(int w, int h, bool maximized, bool fullscreen, bool tiled);
    void toplevelClose();
    Size pendingSize() const { return pending_; }
protected:
    void createRole() override;
    void destroyRole() override;
    xdg_surface *xs_ = nullptr;
    xdg_toplevel *top_ = nullptr;
    std::string title_, appId_;
    Size initial_;
    int minW_ = 0, minH_ = 0;
    bool maximized_ = false;
    Size pending_;
};

class SessionLock {
public:
    static SessionLock &get();
    bool lock();                      // asks the compositor; locked() fires when granted
    void unlock();
    bool isLocked() const { return lock_ != nullptr; }
    ext_session_lock_v1 *handle() const { return lock_; }
    Signal<> locked, finished;        // finished: the compositor refused or ended it
    void lockedCb() { locked.emit(); }
    void finishedCb();
private:
    ext_session_lock_v1 *lock_ = nullptr;
};

class LockWindow : public WaylandWindow {
public:
    explicit LockWindow(Output *out);
    ~LockWindow() override;
    void lockConfigure(uint32_t serial, int w, int h);
    Output *lockOutput() const { return out_; }
protected:
    void createRole() override;
    void destroyRole() override;
    Output *out_;
    ext_session_lock_surface_v1 *ls_ = nullptr;
};

}  // namespace ui
