#include "wayland.hpp"

#include <cairo.h>
#include <wayland-client.h>
#include <xkbcommon/xkbcommon.h>

#include "cursor-shape-v1-client-protocol.h"
#include "ext-background-effect-v1-client-protocol.h"
#include "ext-session-lock-v1-client-protocol.h"
#include "fractional-scale-v1-client-protocol.h"
#include "viewporter-client-protocol.h"
// the layer-shell header names a parameter "namespace", a C++ keyword
#define namespace namespace_
#include "wlr-layer-shell-unstable-v1-client-protocol.h"
#undef namespace
#include "xdg-shell-client-protocol.h"

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <linux/input-event-codes.h>
#include <poll.h>
#include <sys/mman.h>
#include <unistd.h>

namespace ui {

// =================================================================== helpers ==
static int makeShmFile(size_t size) {
    int fd = memfd_create("nova-ui", MFD_CLOEXEC | MFD_ALLOW_SEALING);
    if (fd < 0) return -1;
    if (ftruncate(fd, (off_t)size) < 0) { close(fd); return -1; }
    return fd;
}

// ================================================================== listeners ==
// ---- registry ----
static void reg_global(void *d, wl_registry *r, uint32_t name, const char *iface, uint32_t v) {
    static_cast<Wayland *>(d)->registryGlobal(r, name, iface, v);
}
static void reg_remove(void *d, wl_registry *, uint32_t name) { static_cast<Wayland *>(d)->registryRemove(name); }
static const wl_registry_listener registryListener = {reg_global, reg_remove};

// ---- outputs ----
static void out_geometry(void *d, wl_output *, int32_t x, int32_t y, int32_t, int32_t, int32_t, const char *, const char *, int32_t) {
    auto *o = static_cast<Output *>(d);
    o->x = x; o->y = y;
}
static void out_mode(void *d, wl_output *, uint32_t flags, int32_t w, int32_t h, int32_t) {
    auto *o = static_cast<Output *>(d);
    if (flags & WL_OUTPUT_MODE_CURRENT) { o->width = w; o->height = h; }
}
static void out_done(void *d, wl_output *) {
    auto *o = static_cast<Output *>(d);
    bool first = !o->done;
    o->done = true;
    if (first) Wayland::get().outputAdded.emit(o);
}
static void out_scale(void *d, wl_output *, int32_t s) { static_cast<Output *>(d)->scale = std::max(1, s); }
static void out_name(void *d, wl_output *, const char *n) { static_cast<Output *>(d)->name = n ? n : ""; }
static void out_desc(void *d, wl_output *, const char *n) { static_cast<Output *>(d)->description = n ? n : ""; }
static const wl_output_listener outputListener = {out_geometry, out_mode, out_done, out_scale, out_name, out_desc};

// ---- shell pings ----
static void wm_ping(void *, xdg_wm_base *b, uint32_t serial) { xdg_wm_base_pong(b, serial); }
static const xdg_wm_base_listener wmBaseListener = {wm_ping};

// ---- seat ----
static void seat_caps(void *d, wl_seat *, uint32_t caps) { static_cast<Wayland *>(d)->seatCaps(caps); }
static void seat_name(void *, wl_seat *, const char *) {}
static const wl_seat_listener seatListener = {seat_caps, seat_name};

static WaylandWindow *windowFor(wl_surface *s) {
    if (!s) return nullptr;
    for (auto *w : Wayland::get().windows) if (w->surface() == s) return w;
    return nullptr;
}

// ---- pointer ----
static void ptr_enter(void *, wl_pointer *, uint32_t serial, wl_surface *s, wl_fixed_t x, wl_fixed_t y) {
    auto &wl = Wayland::get();
    wl.pointerSerial = wl.lastSerial = serial;
    wl.pointerFocus = windowFor(s);
    wl.pointerPos = {wl_fixed_to_double(x), wl_fixed_to_double(y)};
    wl.currentCursor = Cursor::NotAllowed;   // force the shape to be sent
    wl.setCursor(Cursor::Default);
    if (wl.pointerFocus) wl.pointerFocus->pointerMotion(wl.pointerPos);
}
static void ptr_leave(void *, wl_pointer *, uint32_t serial, wl_surface *) {
    auto &wl = Wayland::get();
    wl.lastSerial = serial;
    if (wl.pointerFocus) wl.pointerFocus->pointerLeft();
    wl.pointerFocus = nullptr;
}
static void ptr_motion(void *, wl_pointer *, uint32_t, wl_fixed_t x, wl_fixed_t y) {
    auto &wl = Wayland::get();
    wl.pointerPos = {wl_fixed_to_double(x), wl_fixed_to_double(y)};
    if (wl.pointerFocus) wl.pointerFocus->pointerMotion(wl.pointerPos);
}
static void ptr_button(void *, wl_pointer *, uint32_t serial, uint32_t, uint32_t button, uint32_t state) {
    auto &wl = Wayland::get();
    wl.pointerSerial = wl.lastSerial = serial;
    int b = button == BTN_LEFT ? 1 : button == BTN_MIDDLE ? 2 : button == BTN_RIGHT ? 3 : 0;
    if (b && wl.pointerFocus) wl.pointerFocus->pointerButton(b, state == WL_POINTER_BUTTON_STATE_PRESSED);
}
static void ptr_axis(void *, wl_pointer *, uint32_t, uint32_t axis, wl_fixed_t value) {
    auto &wl = Wayland::get();
    (axis == WL_POINTER_AXIS_VERTICAL_SCROLL ? wl.axisY : wl.axisX) += wl_fixed_to_double(value);
}
static void ptr_frame(void *, wl_pointer *) {
    auto &wl = Wayland::get();
    if (wl.pointerFocus && (wl.axisX != 0 || wl.axisY != 0 || wl.axis120X || wl.axis120Y)) {
        if (wl.axisDiscrete) wl.pointerFocus->pointerAxis(wl.axis120X / 120.0, wl.axis120Y / 120.0, true);
        else wl.pointerFocus->pointerAxis(wl.axisX, wl.axisY, false);
    }
    wl.axisX = wl.axisY = 0;
    wl.axis120X = wl.axis120Y = 0;
    wl.axisDiscrete = false;
}
static void ptr_axis_source(void *, wl_pointer *, uint32_t src) {
    Wayland::get().axisDiscrete = src == WL_POINTER_AXIS_SOURCE_WHEEL;
}
static void ptr_axis_stop(void *, wl_pointer *, uint32_t, uint32_t) {}
static void ptr_axis_discrete(void *, wl_pointer *, uint32_t axis, int32_t d) {
    auto &wl = Wayland::get();
    (axis == WL_POINTER_AXIS_VERTICAL_SCROLL ? wl.axis120Y : wl.axis120X) += d * 120;
    wl.axisDiscrete = true;
}
static void ptr_axis120(void *, wl_pointer *, uint32_t axis, int32_t v) {
    auto &wl = Wayland::get();
    (axis == WL_POINTER_AXIS_VERTICAL_SCROLL ? wl.axis120Y : wl.axis120X) += v;
    wl.axisDiscrete = true;
}
static void ptr_axis_dir(void *, wl_pointer *, uint32_t, uint32_t) {}
static const wl_pointer_listener pointerListener = {ptr_enter, ptr_leave, ptr_motion, ptr_button, ptr_axis, ptr_frame,
                                                    ptr_axis_source, ptr_axis_stop, ptr_axis_discrete, ptr_axis120, ptr_axis_dir};

// ---- keyboard ----
static void kb_keymap(void *, wl_keyboard *, uint32_t format, int fd, uint32_t size) {
    if (format != WL_KEYBOARD_KEYMAP_FORMAT_XKB_V1) { close(fd); return; }
    Wayland::get().keymap(fd, size);
}
static void kb_enter(void *, wl_keyboard *, uint32_t serial, wl_surface *s, wl_array *) {
    auto &wl = Wayland::get();
    wl.lastSerial = serial;
    wl.keyboardFocus = windowFor(s);
}
static void kb_leave(void *, wl_keyboard *, uint32_t serial, wl_surface *) {
    auto &wl = Wayland::get();
    wl.lastSerial = serial;
    wl.stopRepeat();
    if (wl.keyboardFocus) wl.keyboardFocus->keyboardLeft();
    wl.keyboardFocus = nullptr;
}
static void kb_key(void *, wl_keyboard *, uint32_t serial, uint32_t time, uint32_t key, uint32_t state) {
    Wayland::get().key(serial, time, key, state);
}
static void kb_mods(void *, wl_keyboard *, uint32_t serial, uint32_t dep, uint32_t lat, uint32_t lock, uint32_t group) {
    Wayland::get().lastSerial = serial;
    Wayland::get().modifiers(dep, lat, lock, group);
}
static void kb_repeat(void *, wl_keyboard *, int32_t rate, int32_t delay) { Wayland::get().repeatInfo(rate, delay); }
static const wl_keyboard_listener keyboardListener = {kb_keymap, kb_enter, kb_leave, kb_key, kb_mods, kb_repeat};

// ---- clipboard ----
static void offer_offer(void *, wl_data_offer *, const char *mime) { Wayland::get().offerMimes.push_back(mime); }
static void offer_actions(void *, wl_data_offer *, uint32_t) {}
static void offer_action(void *, wl_data_offer *, uint32_t) {}
static const wl_data_offer_listener offerListener = {offer_offer, offer_actions, offer_action};

static void dd_offer(void *, wl_data_device *, wl_data_offer *o) {
    Wayland::get().offerMimes.clear();
    wl_data_offer_add_listener(o, &offerListener, nullptr);
}
static void dd_enter(void *, wl_data_device *, uint32_t, wl_surface *, wl_fixed_t, wl_fixed_t, wl_data_offer *) {}
static void dd_leave(void *, wl_data_device *) {}
static void dd_motion(void *, wl_data_device *, uint32_t, wl_fixed_t, wl_fixed_t) {}
static void dd_drop(void *, wl_data_device *) {}
static void dd_selection(void *, wl_data_device *, wl_data_offer *o) {
    auto &wl = Wayland::get();
    if (wl.selectionOffer && wl.selectionOffer != o) wl_data_offer_destroy(wl.selectionOffer);
    wl.selectionOffer = o;
}
static const wl_data_device_listener dataDeviceListener = {dd_offer, dd_enter, dd_leave, dd_motion, dd_drop, dd_selection};

static void src_target(void *, wl_data_source *, const char *) {}
static void src_send(void *, wl_data_source *, const char *, int fd) {
    const std::string &t = Wayland::get().selectionText;
    size_t off = 0;
    while (off < t.size()) {
        ssize_t n = write(fd, t.data() + off, t.size() - off);
        if (n <= 0) break;
        off += n;
    }
    close(fd);
}
static void src_cancelled(void *, wl_data_source *s) {
    auto &wl = Wayland::get();
    if (wl.selectionSource == s) wl.selectionSource = nullptr;
    wl_data_source_destroy(s);
}
static void src_dnd_drop(void *, wl_data_source *) {}
static void src_dnd_finished(void *, wl_data_source *) {}
static void src_action(void *, wl_data_source *, uint32_t) {}
static const wl_data_source_listener dataSourceListener = {src_target, src_send, src_cancelled, src_dnd_drop, src_dnd_finished, src_action};

// ---- surfaces ----
static void surf_enter(void *d, wl_surface *, wl_output *o) { static_cast<WaylandWindow *>(d)->enter(o); }
static void surf_leave(void *, wl_surface *, wl_output *) {}
static void surf_pref_scale(void *d, wl_surface *, int32_t s) {
    auto *w = static_cast<WaylandWindow *>(d);
    if (!Wayland::get().fractionalScale) w->preferredScale(s);
}
static void surf_pref_transform(void *, wl_surface *, uint32_t) {}
static const wl_surface_listener surfaceListener = {surf_enter, surf_leave, surf_pref_scale, surf_pref_transform};

static void frac_preferred(void *d, wp_fractional_scale_v1 *, uint32_t scale120) {
    static_cast<WaylandWindow *>(d)->preferredScale(scale120 / 120.0);
}
static const wp_fractional_scale_v1_listener fracListener = {frac_preferred};

static void frame_done(void *d, wl_callback *cb, uint32_t) {
    wl_callback_destroy(cb);
    static_cast<WaylandWindow *>(d)->frameDone();
}
static const wl_callback_listener frameListener = {frame_done};

struct BufferRelease { bool *busy; };
static void buffer_release(void *d, wl_buffer *) { *static_cast<bool *>(d) = false; }
static const wl_buffer_listener bufferListener = {buffer_release};

// ---- layer surfaces ----
static void layer_configure(void *d, zwlr_layer_surface_v1 *ls, uint32_t serial, uint32_t w, uint32_t h) {
    zwlr_layer_surface_v1_ack_configure(ls, serial);
    static_cast<WaylandWindow *>(d)->configureSize((int)w, (int)h);
}
static void layer_closed(void *d, zwlr_layer_surface_v1 *) { static_cast<LayerWindow *>(d)->closedByCompositor(); }
static const zwlr_layer_surface_v1_listener layerListener = {layer_configure, layer_closed};

// ---- xdg toplevel ----
static void xdgs_configure(void *d, xdg_surface *xs, uint32_t serial) {
    xdg_surface_ack_configure(xs, serial);
    auto *w = static_cast<ToplevelWindow *>(d);
    w->configureSize((int)w->pendingSize().w, (int)w->pendingSize().h);   // the size the toplevel configure asked for
}
static const xdg_surface_listener xdgSurfaceListener = {xdgs_configure};
static void top_configure(void *d, xdg_toplevel *, int32_t w, int32_t h, wl_array *states) {
    bool maxd = false, fs = false, tiled = false;
    uint32_t *s;
    for (s = (uint32_t *)states->data; (char *)s < (char *)states->data + states->size; s++) {
        if (*s == XDG_TOPLEVEL_STATE_MAXIMIZED) maxd = true;
        else if (*s == XDG_TOPLEVEL_STATE_FULLSCREEN) fs = true;
        else if (*s >= XDG_TOPLEVEL_STATE_TILED_LEFT && *s <= XDG_TOPLEVEL_STATE_TILED_BOTTOM) tiled = true;
    }
    static_cast<ToplevelWindow *>(d)->toplevelConfigure(w, h, maxd, fs, tiled);
}
static void top_close(void *d, xdg_toplevel *) { static_cast<ToplevelWindow *>(d)->toplevelClose(); }
static void top_bounds(void *, xdg_toplevel *, int32_t, int32_t) {}
static void top_caps(void *, xdg_toplevel *, wl_array *) {}
static const xdg_toplevel_listener toplevelListener = {top_configure, top_close, top_bounds, top_caps};

// ---- session lock ----
static void lock_locked(void *, ext_session_lock_v1 *) { SessionLock::get().lockedCb(); }
static void lock_finished(void *, ext_session_lock_v1 *) { SessionLock::get().finishedCb(); }
static const ext_session_lock_v1_listener lockListener = {lock_locked, lock_finished};
static void locksurf_configure(void *d, ext_session_lock_surface_v1 *, uint32_t serial, uint32_t w, uint32_t h) {
    static_cast<LockWindow *>(d)->lockConfigure(serial, (int)w, (int)h);
}
static const ext_session_lock_surface_v1_listener lockSurfaceListener = {locksurf_configure};

// =================================================================== Wayland ==
Wayland &Wayland::get() {
    static Wayland w;
    return w;
}
bool Wayland::connect() {
    display_ = wl_display_connect(nullptr);
    if (!display_) return false;
    registry_ = wl_display_get_registry(display_);
    wl_registry_add_listener(registry_, &registryListener, this);
    wl_display_roundtrip(display_);   // globals
    wl_display_roundtrip(display_);   // outputs, seat capabilities
    // events from the compositor are read whenever the socket has data
    Loop::get().addFd(wl_display_get_fd(display_), POLLIN, [this](int, short ev) {
        if (ev & (POLLERR | POLLHUP)) { fprintf(stderr, "nova-ui: the compositor went away\n"); Loop::get().quit(); return; }
        if (wl_display_dispatch(display_) < 0) { fprintf(stderr, "nova-ui: Wayland connection error\n"); Loop::get().quit(); }
    });
    Loop::get().addPrePoll([this] {
        wl_display_dispatch_pending(display_);
        wl_display_flush(display_);
    });
    return true;
}
void Wayland::roundtrip() { wl_display_roundtrip(display_); }
void Wayland::flush() { wl_display_flush(display_); }
void *Wayland::bind(const Global &g, const void *iface, uint32_t version) {
    return wl_registry_bind(registry_, g.name, (const wl_interface *)iface, std::min(version, g.version));
}

void Wayland::registryGlobal(wl_registry *r, uint32_t name, const char *iface, uint32_t v) {
    std::string i = iface;
    globals.push_back({name, i, v});
    if (i == wl_compositor_interface.name) compositor = (wl_compositor *)wl_registry_bind(r, name, &wl_compositor_interface, std::min(v, 6u));
    else if (i == wl_subcompositor_interface.name) subcompositor = (wl_subcompositor *)wl_registry_bind(r, name, &wl_subcompositor_interface, 1);
    else if (i == wl_shm_interface.name) shm = (wl_shm *)wl_registry_bind(r, name, &wl_shm_interface, 1);
    else if (i == wl_seat_interface.name && !seat) {
        seat = (wl_seat *)wl_registry_bind(r, name, &wl_seat_interface, std::min(v, 8u));
        wl_seat_add_listener(seat, &seatListener, this);
    } else if (i == xdg_wm_base_interface.name) {
        wmBase = (xdg_wm_base *)wl_registry_bind(r, name, &xdg_wm_base_interface, std::min(v, 5u));
        xdg_wm_base_add_listener(wmBase, &wmBaseListener, nullptr);
    } else if (i == zwlr_layer_shell_v1_interface.name) layerShell = (zwlr_layer_shell_v1 *)wl_registry_bind(r, name, &zwlr_layer_shell_v1_interface, std::min(v, 4u));
    else if (i == ext_session_lock_manager_v1_interface.name) lockManager = (ext_session_lock_manager_v1 *)wl_registry_bind(r, name, &ext_session_lock_manager_v1_interface, 1);
    else if (i == wp_cursor_shape_manager_v1_interface.name) cursorShape = (wp_cursor_shape_manager_v1 *)wl_registry_bind(r, name, &wp_cursor_shape_manager_v1_interface, 1);
    else if (i == wp_viewporter_interface.name) viewporter = (wp_viewporter *)wl_registry_bind(r, name, &wp_viewporter_interface, 1);
    else if (i == wp_fractional_scale_manager_v1_interface.name) fractionalScale = (wp_fractional_scale_manager_v1 *)wl_registry_bind(r, name, &wp_fractional_scale_manager_v1_interface, 1);
    else if (i == ext_background_effect_manager_v1_interface.name) backgroundEffect = (ext_background_effect_manager_v1 *)wl_registry_bind(r, name, &ext_background_effect_manager_v1_interface, 1);
    else if (i == wl_data_device_manager_interface.name) dataDeviceManager = (wl_data_device_manager *)wl_registry_bind(r, name, &wl_data_device_manager_interface, std::min(v, 3u));
    else if (i == wl_output_interface.name) {
        auto o = std::make_unique<Output>();
        o->globalName = name;
        o->wl = (wl_output *)wl_registry_bind(r, name, &wl_output_interface, std::min(v, 4u));
        wl_output_add_listener(o->wl, &outputListener, o.get());
        outputs.push_back(std::move(o));
    }
    if (seat && dataDeviceManager && !dataDevice) {
        dataDevice = wl_data_device_manager_get_data_device(dataDeviceManager, seat);
        wl_data_device_add_listener(dataDevice, &dataDeviceListener, nullptr);
    }
}
void Wayland::registryRemove(uint32_t name) {
    std::erase_if(globals, [name](const Global &g) { return g.name == name; });
    for (auto it = outputs.begin(); it != outputs.end(); ++it) {
        if ((*it)->globalName != name) continue;
        Output *o = it->get();
        outputRemoved.emit(o);
        wl_output_release(o->wl);
        outputs.erase(it);
        return;
    }
}
Output *Wayland::outputFor(wl_output *o) {
    for (auto &x : outputs) if (x->wl == o) return x.get();
    return nullptr;
}
Output *Wayland::outputNamed(const std::string &name) {
    for (auto &x : outputs) if (x->name == name) return x.get();
    return nullptr;
}

void Wayland::seatCaps(uint32_t caps) {
    if ((caps & WL_SEAT_CAPABILITY_POINTER) && !pointer) {
        pointer = wl_seat_get_pointer(seat);
        wl_pointer_add_listener(pointer, &pointerListener, nullptr);
        if (cursorShape) cursorDevice = wp_cursor_shape_manager_v1_get_pointer(cursorShape, pointer);
    }
    if ((caps & WL_SEAT_CAPABILITY_KEYBOARD) && !keyboard) {
        keyboard = wl_seat_get_keyboard(seat);
        wl_keyboard_add_listener(keyboard, &keyboardListener, nullptr);
    }
}
void Wayland::setCursor(Cursor c) {
    if (!cursorDevice || c == currentCursor) return;
    currentCursor = c;
    uint32_t shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_DEFAULT;
    switch (c) {
    case Cursor::Default: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_DEFAULT; break;
    case Cursor::Pointer: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_POINTER; break;
    case Cursor::Text: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_TEXT; break;
    case Cursor::Move: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_MOVE; break;
    case Cursor::ResizeNWSE: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_NWSE_RESIZE; break;
    case Cursor::ResizeNS: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_NS_RESIZE; break;
    case Cursor::ResizeEW: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_EW_RESIZE; break;
    case Cursor::Grab: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_GRAB; break;
    case Cursor::Grabbing: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_GRABBING; break;
    case Cursor::NotAllowed: shape = WP_CURSOR_SHAPE_DEVICE_V1_SHAPE_NOT_ALLOWED; break;
    }
    wp_cursor_shape_device_v1_set_shape(cursorDevice, pointerSerial, shape);
}

// ---- keyboard ----
void Wayland::keymap(int fd, uint32_t size) {
    char *map = (char *)mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (map == MAP_FAILED) return;
    if (!xkbCtx_) xkbCtx_ = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
    xkb_keymap *km = xkb_keymap_new_from_string(xkbCtx_, map, XKB_KEYMAP_FORMAT_TEXT_V1, XKB_KEYMAP_COMPILE_NO_FLAGS);
    munmap(map, size);
    if (!km) return;
    if (xkbState_) xkb_state_unref(xkbState_);
    if (xkbKeymap_) xkb_keymap_unref(xkbKeymap_);
    xkbKeymap_ = km;
    xkbState_ = xkb_state_new(km);
}
void Wayland::modifiers(uint32_t dep, uint32_t lat, uint32_t lock, uint32_t group) {
    if (!xkbState_) return;
    xkb_state_update_mask(xkbState_, dep, lat, lock, 0, 0, group);
    bool caps = xkb_state_led_name_is_active(xkbState_, XKB_LED_NAME_CAPS) > 0;
    bool num = xkb_state_led_name_is_active(xkbState_, XKB_LED_NAME_NUM) > 0;
    if (caps != capsLock || num != numLock) {
        capsLock = caps;
        numLock = num;
        locksChanged.emit();
    }
}
void Wayland::sendKey(uint32_t key, bool pressed, bool repeat) {
    if (!xkbState_ || !keyboardFocus) return;
    uint32_t code = key + 8;
    KeyEvent e;
    e.sym = xkb_state_key_get_one_sym(xkbState_, code);
    e.pressed = pressed;
    e.repeat = repeat;
    e.ctrl = xkb_state_mod_name_is_active(xkbState_, XKB_MOD_NAME_CTRL, XKB_STATE_MODS_EFFECTIVE) > 0;
    e.shift = xkb_state_mod_name_is_active(xkbState_, XKB_MOD_NAME_SHIFT, XKB_STATE_MODS_EFFECTIVE) > 0;
    e.alt = xkb_state_mod_name_is_active(xkbState_, XKB_MOD_NAME_ALT, XKB_STATE_MODS_EFFECTIVE) > 0;
    e.super = xkb_state_mod_name_is_active(xkbState_, XKB_MOD_NAME_LOGO, XKB_STATE_MODS_EFFECTIVE) > 0;
    if (pressed) {
        char buf[64];
        int n = xkb_state_key_get_utf8(xkbState_, code, buf, sizeof buf);
        if (n > 0) e.text.assign(buf, std::min<int>(n, sizeof buf - 1));
    }
    keyboardFocus->keyEvent(e);
}
void Wayland::key(uint32_t serial, uint32_t, uint32_t k, uint32_t state) {
    lastSerial = serial;
    bool pressed = state == WL_KEYBOARD_KEY_STATE_PRESSED;
    sendKey(k, pressed, false);
    if (pressed && xkbKeymap_ && xkb_keymap_key_repeats(xkbKeymap_, k + 8) && repeatRate_ > 0) {
        stopRepeat();
        repeatKey_ = k;
        repeatTimer_ = Loop::get().addTimer(repeatDelay_, [this] {
            sendKey(repeatKey_, true, true);
            repeatTimer_ = Loop::get().addTimer(1000 / std::max(1, repeatRate_), [this] { sendKey(repeatKey_, true, true); }, true);
        });
    } else if (!pressed && k == repeatKey_) stopRepeat();
}
void Wayland::stopRepeat() {
    if (repeatTimer_) Loop::get().removeTimer(repeatTimer_);
    repeatTimer_ = 0;
    repeatKey_ = 0;
}

// ---- clipboard ----
void Wayland::setClipboard(const std::string &text) {
    if (!dataDeviceManager || !dataDevice) return;
    selectionText = text;
    wl_data_source *s = wl_data_device_manager_create_data_source(dataDeviceManager);
    wl_data_source_add_listener(s, &dataSourceListener, nullptr);
    for (const char *m : {"text/plain;charset=utf-8", "text/plain", "UTF8_STRING", "STRING", "TEXT"}) wl_data_source_offer(s, m);
    wl_data_device_set_selection(dataDevice, s, lastSerial);
    selectionSource = s;
}
void Wayland::readClipboard(std::function<void(const std::string &)> cb) {
    if (selectionSource) { cb(selectionText); return; }
    if (!selectionOffer) { cb(""); return; }
    int fds[2];
    if (pipe2(fds, O_CLOEXEC | O_NONBLOCK) < 0) { cb(""); return; }
    wl_data_offer_receive(selectionOffer, "text/plain;charset=utf-8", fds[1]);
    close(fds[1]);
    wl_display_flush(display_);
    auto buf = std::make_shared<std::string>();
    auto id = std::make_shared<int>(0);
    *id = Loop::get().addFd(fds[0], POLLIN, [buf, id, cb](int fd, short) {
        char tmp[4096];
        ssize_t n = read(fd, tmp, sizeof tmp);
        if (n > 0) { buf->append(tmp, n); return; }
        if (n < 0 && errno == EAGAIN) return;
        Loop::get().removeFd(*id);
        close(fd);
        cb(*buf);
    });
}

// ============================================================ WaylandWindow ==
WaylandWindow::WaylandWindow() { Wayland::get().windows.push_back(this); }
WaylandWindow::~WaylandWindow() {
    auto &wl = Wayland::get();
    std::erase(wl.windows, this);
    if (wl.pointerFocus == this) wl.pointerFocus = nullptr;
    if (wl.keyboardFocus == this) wl.keyboardFocus = nullptr;
    // subclasses destroy their role first; the surface goes last
    destroySurface();
}
void WaylandWindow::createSurface() {
    auto &wl = Wayland::get();
    surface_ = wl_compositor_create_surface(wl.compositor);
    wl_surface_add_listener(surface_, &surfaceListener, this);
    if (wl.viewporter) viewport_ = wp_viewporter_get_viewport(wl.viewporter, surface_);
    if (wl.fractionalScale) {
        fracScale_ = wp_fractional_scale_manager_v1_get_fractional_scale(wl.fractionalScale, surface_);
        wp_fractional_scale_v1_add_listener(fracScale_, &fracListener, this);
    }
    if (wl.backgroundEffect && wantBlur)
        blurEffect_ = ext_background_effect_manager_v1_get_background_effect(wl.backgroundEffect, surface_);
    inputDirty_ = !inputAll_;
    lastBlur_.clear();
}
void WaylandWindow::destroySurface() {
    freeBuffers();
    if (blurEffect_) { ext_background_effect_surface_v1_destroy(blurEffect_); blurEffect_ = nullptr; }
    if (fracScale_) { wp_fractional_scale_v1_destroy(fracScale_); fracScale_ = nullptr; }
    if (viewport_) { wp_viewport_destroy(viewport_); viewport_ = nullptr; }
    if (surface_) { wl_surface_destroy(surface_); surface_ = nullptr; }
    configured_ = false;
    framePending_ = false;
    lastBlur_.clear();
}
void WaylandWindow::show() {
    if (surface_) return;
    createSurface();
    createRole();
}
void WaylandWindow::hide() {
    if (!surface_) return;
    auto &wl = Wayland::get();
    if (wl.pointerFocus == this) { wl.pointerFocus = nullptr; pointerLeft(); }
    if (wl.keyboardFocus == this) wl.keyboardFocus = nullptr;
    destroyRole();
    destroySurface();
}
void WaylandWindow::freeBuffers() {
    for (auto &b : buffers_) {
        if (b.wl) wl_buffer_destroy(b.wl);
        if (b.data) munmap(b.data, b.size);
    }
    buffers_.clear();
}
WaylandWindow::Buffer *WaylandWindow::nextBuffer(int w, int h) {
    for (auto &b : buffers_)
        if (!b.busy && b.w == w && b.h == h) return &b;
    // drop idle buffers of the wrong size, keep at most 3
    for (auto it = buffers_.begin(); it != buffers_.end();) {
        if (!it->busy && (it->w != w || it->h != h)) {
            if (it->wl) wl_buffer_destroy(it->wl);
            if (it->data) munmap(it->data, it->size);
            it = buffers_.erase(it);
        } else ++it;
    }
    if (buffers_.size() >= 3) return nullptr;
    int stride = w * 4;
    size_t size = (size_t)stride * h;
    int fd = makeShmFile(size);
    if (fd < 0) return nullptr;
    void *data = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (data == MAP_FAILED) { ::close(fd); return nullptr; }
    wl_shm_pool *pool = wl_shm_create_pool(Wayland::get().shm, fd, (int)size);
    wl_buffer *buf = wl_shm_pool_create_buffer(pool, 0, w, h, stride, WL_SHM_FORMAT_ARGB8888);
    wl_shm_pool_destroy(pool);
    ::close(fd);
    buffers_.push_back({buf, data, size, w, h, false});
    Buffer *b = &buffers_.back();
    wl_buffer_add_listener(buf, &bufferListener, &b->busy);
    return b;
}
void WaylandWindow::configureSize(int w, int h) {
    configured_ = true;
    if (w > 0 && h > 0) setSize({(double)w, (double)h}, prefScale_);
    commitFrame();
}
void WaylandWindow::preferredScale(double s) {
    if (s <= 0 || s == prefScale_) return;
    prefScale_ = s;
    setSize(size_, s);
    update();
}
void WaylandWindow::enter(wl_output *o) {
    output_ = Wayland::get().outputFor(o);
    if (!Wayland::get().fractionalScale && output_ && output_->scale != (int)prefScale_) preferredScale(output_->scale);
}
void WaylandWindow::scheduleRedraw() {
    if (!configured_ || !surface_) return;
    if (framePending_) { frameRequested_ = true; return; }   // painted when the frame callback comes
    if (frameRequested_) return;
    frameRequested_ = true;
    Loop::get().defer([this] {
        if (frameRequested_ && !framePending_) commitFrame();
    });
}
void WaylandWindow::frameDone() {
    framePending_ = false;
    bool more = tickAnimations(nowMs());
    if (more || frameRequested_ || needPaint_) commitFrame();
}
void WaylandWindow::setInputRegion(const std::vector<Rect> &rects) {
    inputAll_ = false;
    input_ = rects;
    inputDirty_ = true;
    if (surface_ && configured_) scheduleRedraw();
}
void WaylandWindow::setInputAll() {
    if (inputAll_) return;
    inputAll_ = true;
    inputDirty_ = true;
    if (surface_ && configured_) scheduleRedraw();
}
// input regions are double-buffered state: sent right before each commit (and again for a new surface)
void WaylandWindow::applyInput() {
    if (!surface_ || !inputDirty_) return;
    inputDirty_ = false;
    if (inputAll_) { wl_surface_set_input_region(surface_, nullptr); return; }
    wl_region *r = wl_compositor_create_region(Wayland::get().compositor);
    for (auto &x : input_) wl_region_add(r, (int)x.x, (int)x.y, (int)std::ceil(x.w), (int)std::ceil(x.h));
    wl_surface_set_input_region(surface_, r);
    wl_region_destroy(r);
}
void WaylandWindow::setCursor(Cursor c) {
    if (Wayland::get().pointerFocus == this) Wayland::get().setCursor(c);
}
void WaylandWindow::updateBlur() {
    if (!blurEffect_) return;
    auto regions = theme().realBlur ? blurRegions() : std::vector<std::pair<Rect, double>>{};
    if (regions.size() == lastBlur_.size()) {
        bool same = true;
        for (size_t i = 0; i < regions.size() && same; i++) {
            const auto &a = regions[i].first, &b = lastBlur_[i].first;
            same = std::lround(a.x) == std::lround(b.x) && std::lround(a.y) == std::lround(b.y) && std::lround(a.w) == std::lround(b.w) &&
                   std::lround(a.h) == std::lround(b.h) && regions[i].second == lastBlur_[i].second;
        }
        if (same) return;
    }
    lastBlur_ = regions;
    wl_region *r = wl_compositor_create_region(Wayland::get().compositor);
    for (auto &[rc, rad] : regions) {
        int x = (int)std::lround(rc.x), y = (int)std::lround(rc.y), w = (int)std::lround(rc.w), h = (int)std::lround(rc.h);
        int rr = (int)std::min<double>(rad, std::min(w, h) / 2.0);
        // rounded corners as 1 px slices: the compositor turns them back into a radius
        for (int i = 0; i < rr; i++) {
            double dy = rr - i - 0.5;
            int inset = (int)std::lround(rr - std::sqrt(std::max(0.0, (double)rr * rr - dy * dy)));
            wl_region_add(r, x + inset, y + i, w - 2 * inset, 1);
            wl_region_add(r, x + inset, y + h - 1 - i, w - 2 * inset, 1);
        }
        wl_region_add(r, x, y + rr, w, h - 2 * rr);
    }
    ext_background_effect_surface_v1_set_blur_region(blurEffect_, regions.empty() ? nullptr : r);
    wl_region_destroy(r);
}
void WaylandWindow::commitFrame() {
    frameRequested_ = false;
    if (!configured_ || !surface_ || size_.w <= 0 || size_.h <= 0) return;
    if (tiny && viewport_) {
        Buffer *b = nextBuffer(1, 1);
        if (!b) { frameRequested_ = true; return; }
        Color c = clearColor;
        uint32_t px = ((uint32_t)std::lround(c.a * 255) << 24) | ((uint32_t)std::lround(c.r * c.a * 255) << 16) |
                      ((uint32_t)std::lround(c.g * c.a * 255) << 8) | (uint32_t)std::lround(c.b * c.a * 255);
        *(uint32_t *)b->data = px;
        wl_surface_set_buffer_scale(surface_, 1);
        wp_viewport_set_destination(viewport_, (int)std::lround(size_.w), (int)std::lround(size_.h));
        applyInput();
        wl_surface_attach(surface_, b->wl, 0, 0);
        wl_surface_damage_buffer(surface_, 0, 0, 1, 1);
        b->busy = true;
        wl_surface_commit(surface_);
        return;
    }
    tickAnimations(nowMs());
    double s = Wayland::get().fractionalScale && viewport_ ? prefScale_ : std::max(1.0, std::round(prefScale_));
    int pw = (int)std::ceil(size_.w * s), ph = (int)std::ceil(size_.h * s);
    if (s != scale_) setSize(size_, s);
    Buffer *b = nextBuffer(pw, ph);
    if (!b) { frameRequested_ = true; return; }   // all buffers busy: try again on the next frame
    cairo_surface_t *cs = cairo_image_surface_create_for_data((unsigned char *)b->data, CAIRO_FORMAT_ARGB32, pw, ph, pw * 4);
    cairo_t *cr = cairo_create(cs);
    paintTo(cr);
    cairo_destroy(cr);
    cairo_surface_destroy(cs);
    if (viewport_) {
        wl_surface_set_buffer_scale(surface_, 1);
        wp_viewport_set_destination(viewport_, (int)std::lround(size_.w), (int)std::lround(size_.h));
    } else {
        wl_surface_set_buffer_scale(surface_, (int)s);
    }
    updateBlur();
    applyInput();
    wl_surface_attach(surface_, b->wl, 0, 0);
    wl_surface_damage_buffer(surface_, 0, 0, pw, ph);
    b->busy = true;
    wl_callback *cb = wl_surface_frame(surface_);
    wl_callback_add_listener(cb, &frameListener, this);
    framePending_ = true;
    wl_surface_commit(surface_);
}

// ================================================================ LayerWindow ==
LayerWindow::LayerWindow(const std::string &ns, Layer layer, Output *out) : ns_(ns), layer_(layer), target_(out) {}
LayerWindow::~LayerWindow() {
    destroyRole();
}
void LayerWindow::createRole() {
    auto &wl = Wayland::get();
    ls_ = zwlr_layer_shell_v1_get_layer_surface(wl.layerShell, surface_, target_ ? target_->wl : nullptr, (uint32_t)layer_, ns_.c_str());
    zwlr_layer_surface_v1_add_listener(ls_, &layerListener, this);
    applyState();
    wl_surface_commit(surface_);
}
void LayerWindow::destroyRole() {
    if (ls_) { zwlr_layer_surface_v1_destroy(ls_); ls_ = nullptr; }
}
void LayerWindow::applyState() {
    if (!ls_) return;
    zwlr_layer_surface_v1_set_size(ls_, reqW_, reqH_);
    zwlr_layer_surface_v1_set_anchor(ls_, anchors_);
    zwlr_layer_surface_v1_set_margin(ls_, mt_, mr_, mb_, ml_);
    zwlr_layer_surface_v1_set_exclusive_zone(ls_, excl_);
    zwlr_layer_surface_v1_set_keyboard_interactivity(ls_, (uint32_t)kb_);
}
void LayerWindow::setAnchors(uint32_t a) { anchors_ = a; applyState(); if (surface_ && configured_) wl_surface_commit(surface_); }
void LayerWindow::setMargins(int t, int r, int b, int l) {
    mt_ = t; mr_ = r; mb_ = b; ml_ = l;
    applyState();
    if (surface_ && configured_) wl_surface_commit(surface_);
}
void LayerWindow::setExclusiveZone(int z) { excl_ = z; applyState(); if (surface_ && configured_) wl_surface_commit(surface_); }
void LayerWindow::setKeyboard(KeyboardMode m) { kb_ = m; applyState(); if (surface_ && configured_) wl_surface_commit(surface_); }
void LayerWindow::setLayer(Layer l) {
    layer_ = l;
    if (ls_) zwlr_layer_surface_v1_set_layer(ls_, (uint32_t)l);
    if (surface_ && configured_) wl_surface_commit(surface_);
}
void LayerWindow::setRequestedSize(int w, int h) {
    if (w == reqW_ && h == reqH_) return;
    reqW_ = w; reqH_ = h;
    applyState();
    if (surface_ && configured_) wl_surface_commit(surface_);
}
void LayerWindow::closedByCompositor() {
    // the output went away: drop the surface; the owner decides what to do
    Loop::get().defer([this] {
        hide();
        if (onClosed) onClosed();
    });
}

// ============================================================= ToplevelWindow ==
ToplevelWindow::ToplevelWindow(const std::string &title, const std::string &appId, Size initial)
    : title_(title), appId_(appId), initial_(initial) {
    pending_ = initial;
}
ToplevelWindow::~ToplevelWindow() { destroyRole(); }
void ToplevelWindow::createRole() {
    auto &wl = Wayland::get();
    xs_ = xdg_wm_base_get_xdg_surface(wl.wmBase, surface_);
    xdg_surface_add_listener(xs_, &xdgSurfaceListener, this);
    top_ = xdg_surface_get_toplevel(xs_);
    xdg_toplevel_add_listener(top_, &toplevelListener, this);
    xdg_toplevel_set_title(top_, title_.c_str());
    xdg_toplevel_set_app_id(top_, appId_.c_str());
    if (minW_ || minH_) xdg_toplevel_set_min_size(top_, minW_, minH_);
    wl_surface_commit(surface_);
}
void ToplevelWindow::destroyRole() {
    if (top_) { xdg_toplevel_destroy(top_); top_ = nullptr; }
    if (xs_) { xdg_surface_destroy(xs_); xs_ = nullptr; }
}
void ToplevelWindow::setTitle(const std::string &t) {
    title_ = t;
    if (top_) xdg_toplevel_set_title(top_, t.c_str());
}
void ToplevelWindow::setMinSize(int w, int h) {
    minW_ = w; minH_ = h;
    if (top_) xdg_toplevel_set_min_size(top_, w, h);
}
void ToplevelWindow::startMove() {
    if (top_) xdg_toplevel_move(top_, Wayland::get().seat, Wayland::get().pointerSerial);
}
void ToplevelWindow::startResize(uint32_t edges) {
    if (top_) xdg_toplevel_resize(top_, Wayland::get().seat, Wayland::get().pointerSerial, edges);
}
void ToplevelWindow::setMaximized(bool m) {
    if (!top_) return;
    if (m) xdg_toplevel_set_maximized(top_);
    else xdg_toplevel_unset_maximized(top_);
}
void ToplevelWindow::minimize() {
    if (top_) xdg_toplevel_set_minimized(top_);
}
void ToplevelWindow::close() {
    if (onCloseRequest) onCloseRequest();
    else Loop::get().quit();
}
void ToplevelWindow::toplevelConfigure(int w, int h, bool maxd, bool, bool) {
    maximized_ = maxd;
    if (w > 0 && h > 0) pending_ = {(double)w, (double)h};
    else if (pending_.w <= 0) pending_ = initial_;
}
void ToplevelWindow::toplevelClose() { close(); }

// =============================================================== session lock ==
SessionLock &SessionLock::get() {
    static SessionLock l;
    return l;
}
bool SessionLock::lock() {
    auto &wl = Wayland::get();
    if (!wl.lockManager || lock_) return false;
    lock_ = ext_session_lock_manager_v1_lock(wl.lockManager);
    ext_session_lock_v1_add_listener(lock_, &lockListener, nullptr);
    wl.flush();
    return true;
}
void SessionLock::unlock() {
    if (!lock_) return;
    ext_session_lock_v1_unlock_and_destroy(lock_);
    lock_ = nullptr;
    Wayland::get().roundtrip();
}
void SessionLock::finishedCb() {
    if (lock_) { ext_session_lock_v1_destroy(lock_); lock_ = nullptr; }
    finished.emit();
}

LockWindow::LockWindow(Output *out) : out_(out) { wantBlur = false; }
LockWindow::~LockWindow() { destroyRole(); }
void LockWindow::createRole() {
    ext_session_lock_v1 *lock = SessionLock::get().handle();
    if (!lock || !out_) return;
    ls_ = ext_session_lock_v1_get_lock_surface(lock, surface_, out_->wl);
    ext_session_lock_surface_v1_add_listener(ls_, &lockSurfaceListener, this);
}
void LockWindow::destroyRole() {
    if (ls_) { ext_session_lock_surface_v1_destroy(ls_); ls_ = nullptr; }
}
void LockWindow::lockConfigure(uint32_t serial, int w, int h) {
    ext_session_lock_surface_v1_ack_configure(ls_, serial);
    configureSize(w, h);
}

}  // namespace ui
