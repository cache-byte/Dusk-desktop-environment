#include "window.hpp"

#include <cairo.h>

namespace ui {

Window::Window() {
    themeConn_ = theme().changed.connect([this] { update(); });
}
Window::~Window() {
    theme().changed.disconnect(themeConn_);
    // the widgets are destroyed before the window bookkeeping goes away
    overlay_.reset();
    root_.reset();
}

void Window::setRootWidget(std::unique_ptr<Widget> w) {
    hover_ = press_ = focus_ = nullptr;
    animating_.clear();
    root_ = std::move(w);
    root_->window_ = this;
    relayout();
}
void Window::setSize(Size s, double scale) {
    bool changed = s.w != size_.w || s.h != size_.h || scale != scale_;
    size_ = s;
    scale_ = scale;
    if (changed) {
        resized.emit(s);
        relayout();
    }
}
void Window::layoutNow() {
    needLayout_ = false;
    bumpLayoutGeneration();
    beforeLayout();
    if (root_) root_->setGeometry({0, 0, size_.w, size_.h});
    if (overlay_) overlay_->arrange();
}
void Window::paintTo(cairo_t *cr) {
    if (needLayout_) layoutNow();
    cairo_save(cr);
    cairo_set_operator(cr, CAIRO_OPERATOR_SOURCE);
    cairo_set_source_rgba(cr, clearColor.r, clearColor.g, clearColor.b, clearColor.a);
    cairo_paint(cr);
    cairo_restore(cr);
    cairo_save(cr);
    cairo_scale(cr, scale_, scale_);
    Painter p(cr);
    if (root_) root_->render(p);
    if (overlay_) overlay_->render(p);
    cairo_restore(cr);
    needPaint_ = false;
    painted.emit();
}

void Window::update() {
    needPaint_ = true;
    scheduleRedraw();
}
void Window::relayout() {
    needLayout_ = true;
    update();
}
void Window::requestFrames(Widget *w) {
    if (std::find(animating_.begin(), animating_.end(), w) == animating_.end()) animating_.push_back(w);
    update();
}
bool Window::tickAnimations(int64_t now) {
    if (animating_.empty()) return false;
    auto list = animating_;
    for (Widget *w : list)
        if (!w->tickAnims(now)) std::erase(animating_, w);
    needPaint_ = true;
    return !animating_.empty();
}
void Window::forget(Widget *w) {
    if (hover_ == w) hover_ = nullptr;
    if (press_ == w) press_ = nullptr;
    if (focus_ == w) focus_ = nullptr;
    std::erase(animating_, w);
}

void Window::setFocus(Widget *w) {
    if (w == focus_) return;
    Widget *old = focus_;
    focus_ = w;
    if (old) old->focusOut();
    if (w) w->focusIn();
}

void Window::showOverlay(std::unique_ptr<Widget> w, std::function<void()> onDismiss) {
    dismissOverlay();
    overlay_ = std::move(w);
    overlay_->window_ = this;
    overlayDismiss_ = std::move(onDismiss);
    overlay_->opacity.set(0);
    overlay_->startAnim(overlay_->opacity, 1, theme().ms(120));
    update();
}
void Window::dismissOverlay() {
    if (!overlay_) return;
    // forget pointers into the overlay before it goes
    auto inside = [&](Widget *x) {
        for (Widget *p = x; p; p = p->parent()) if (p == overlay_.get()) return true;
        return false;
    };
    if (hover_ && inside(hover_)) hover_ = nullptr;
    if (press_ && inside(press_)) press_ = nullptr;
    if (focus_ && inside(focus_)) focus_ = nullptr;
    std::erase_if(animating_, inside);
    overlay_.reset();
    if (overlayDismiss_) { auto f = std::move(overlayDismiss_); overlayDismiss_ = nullptr; f(); }
    update();
}

// ---------------------------------------------------------------- input --
void Window::updateHover() {
    Widget *h = nullptr;
    if (overlay_) h = overlay_->hitTest(pointer_);
    if (!h && root_ && !(overlay_ && overlay_->geom.contains(pointer_))) h = root_->hitTest(pointer_);
    if (h != hover_) {
        Widget *old = hover_;
        hover_ = h;
        // leave the old chain, enter the new (only the deepest widget gets the events)
        if (old) old->pointerLeave();
        if (h) h->pointerEnter();
    }
    setCursor(hover_ ? hover_->cursor : Cursor::Default);
}
void Window::pointerMotion(Point p) {
    if (!pointerInside_) { pointerInside_ = true; pointerInside.emit(true); }
    pointer_ = p;
    if (press_) {
        press_->pointerMove(p);   // drags stay with the widget that was pressed
        return;
    }
    updateHover();
    if (hover_) hover_->pointerMove(p);
}
void Window::pointerButton(int button, bool pressedDown) {
    if (pressedDown) {
        if (overlay_ && !overlay_->geom.contains(pointer_)) {   // click outside a popup closes it
            dismissOverlay();
            return;
        }
        updateHover();
        // the deepest widget that wants the press, walking up
        Widget *t = hover_;
        while (t && !t->pointerPress(pointer_, button)) t = t->parent();
        press_ = t;
        pressButton_ = button;
        // focus follows clicks: the nearest focusable widget, or nothing
        Widget *f = hover_;
        while (f && !f->focusable) f = f->parent();
        setFocus(f);
        return;
    }
    if (press_ && button == pressButton_) {
        Widget *t = press_;
        press_ = nullptr;
        t->pointerRelease(pointer_, button);
        updateHover();
    }
}
void Window::pointerAxis(double dx, double dy, bool discrete) {
    Widget *t = hover_;
    if (!t && root_) t = root_->hitTest(pointer_);
    // non-interactive widgets can still scroll (scroll views): search from the deepest hit
    if (!t && root_) t = root_.get();
    while (t && !t->scroll(dx, dy, discrete)) t = t->parent();
}
void Window::pointerLeft() {
    if (hover_) { Widget *h = hover_; hover_ = nullptr; h->pointerLeave(); }
    pointer_ = {-1, -1};
    if (pointerInside_) { pointerInside_ = false; pointerInside.emit(false); }
}
void Window::keyEvent(const KeyEvent &e) {
    if (e.pressed && e.sym == key::Escape && overlay_) { dismissOverlay(); return; }
    for (Widget *w = focus_; w; w = w->parent())
        if (w->key(e)) return;
    if (onKey) onKey(e);
}
void Window::keyboardLeft() {
    // keep focus (text fields keep their caret when the pointer wanders), stop key repeat
}

std::vector<std::pair<Rect, double>> Window::blurRegions() const {
    std::vector<std::pair<Rect, double>> out;
    std::function<void(Widget *)> walk = [&](Widget *w) {
        if (!w->visible || w->opacity.target() <= 0.01) return;
        if (auto *c = dynamic_cast<Card *>(w); c && c->blurBehind)
            out.push_back({{c->geom.x + c->tx.value(), c->geom.y + c->ty.value(), c->geom.w, c->geom.h}, c->radius});
        for (auto &ch : w->children()) walk(ch.get());
    };
    if (blurProvider) for (auto &r : blurProvider()) out.push_back(r);
    if (root_) walk(root_.get());
    if (overlay_) walk(overlay_.get());
    return out;
}

// -------------------------------------------------------------- offscreen --
bool OffscreenWindow::savePng(const std::string &path, int settleMs) {
    // let entrance animations finish
    int64_t t0 = nowMs();
    while (!animating_.empty() && nowMs() - t0 < settleMs) {
        tickAnimations(nowMs());
        Loop::get().iterate(16);
    }
    int w = (int)std::ceil(size_.w * scale_), h = (int)std::ceil(size_.h * scale_);
    cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, w, h);
    cairo_t *cr = cairo_create(s);
    paintTo(cr);
    cairo_destroy(cr);
    bool ok = cairo_surface_write_to_png(s, path.c_str()) == CAIRO_STATUS_SUCCESS;
    cairo_surface_destroy(s);
    return ok;
}

}  // namespace ui
