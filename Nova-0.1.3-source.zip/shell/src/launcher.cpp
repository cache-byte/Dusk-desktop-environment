// Launcher: search (apps by name first, files, run a command, settings pages), favourites,
// calculator answers via qalc, and the user / lock / power footer. Fills the 8×10 pop-up grid.
#include "apps.hpp"
#include "ui/sys.hpp"
#include "windows.hpp"

#include <filesystem>

namespace nova {

using namespace ui;

static const std::vector<std::string> kSettingsPages = {
    "For you", "Appearance", "Connections", "Display", "Sound", "Power", "Notifications", "Popups & indicators",
    "Music & lyrics", "Gaming", "Windows & tiling", "Keyboard", "Mouse & touchpad", "Panel & launcher", "Users", "Updates", "About"};

static std::string urlEncode(const std::string &s) {
    std::string o;
    char b[4];
    for (unsigned char c : s) {
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
        else { snprintf(b, sizeof b, "%%%02X", c); o += b; }
    }
    return o;
}

static void sectionTitle(Widget *parent, const std::string &s) {
    auto *l = parent->add<Label>(s, 12, Weight::DemiBold, Role::Text3);
    l->font.letterSpacing = 0.7;
}

static std::string uptimeText() {
    double s = atof(readFile("/proc/uptime").c_str());
    int h = (int)(s / 3600), m = (int)(fmod(s, 3600) / 60);
    return "up " + (h ? std::to_string(h) + " h " : std::string()) + std::to_string(m) + " min";
}

class Launcher : public Card {
public:
    explicit Launcher(Screen *s) : Card(Dir::Column, 16), screen(s) {
        const Theme &t = theme();
        fixedW = t.gridWidth();
        fixedH = t.gridHeight(t.gridRows);
        padding(t.gridPad);
        radius = t.radius;
        interactive = true;   // clicks on the card don't reach the catcher anyway; keeps hover sane

        // ---- search field ----
        search = add<TextInput>();
        search->leadingIcon = "search";
        search->placeholder = "Search apps, files, settings…";
        search->fontSize = 15;
        search->fixedH = 50;
        search->onChanged = [this](const std::string &q) {
            query = q;
            current = 0;
            calc.clear();
            fileTimer.start();
            calcTimer.start();
            conns.later([this] { rebuild(); });
        };
        search->onSubmit = [this](const std::string &) { activate(current); };
        search->onKeyFirst = [this](const KeyEvent &e) {
            if (!e.pressed) return false;
            if (e.sym == key::Down) { move(cols()); return true; }
            if (e.sym == key::Up) { move(-cols()); return true; }
            if (e.sym == key::Right && cols() > 1 && search->text().empty()) { move(1); return true; }
            if (e.sym == key::Left && cols() > 1 && search->text().empty()) { move(-1); return true; }
            if (e.sym == key::Tab || e.sym == key::ISO_Left_Tab) {
                static const std::vector<std::string> tabs = {"apps", "files", "run", "settings"};
                int i = (int)(std::find(tabs.begin(), tabs.end(), tab) - tabs.begin());
                setTab(tabs[(i + (e.shift ? 3 : 1)) % 4]);
                return true;
            }
            if (e.sym == key::Escape) { shell().close(); return true; }
            return false;
        };

        // ---- tabs ----
        tabsRow = row(this, 6);
        body = col(this, 12);
        body->grow = 1;
        body->clip = true;
        add<Separator>();
        buildFooter();

        fileTimer.setup(220, [this] { searchFiles(); });
        calcTimer.setup(160, [this] { runCalc(); });
        conns.on(Apps::get().changed, [this] { conns.later([this] { rebuild(); }); });
        rebuild();
        conns.later([this] { if (window()) window()->setFocus(search); });
    }

    Screen *screen;
    std::string tab = "apps", query, calc;
    int current = 0;
    bool powerMenu = false;
    std::vector<std::string> files;
    TextInput *search;
    Box *tabsRow, *body, *footer = nullptr, *powerRow = nullptr;
    ScrollView *results = nullptr;
    std::vector<Widget *> items;
    Timer fileTimer, calcTimer;
    std::shared_ptr<Process> fileProc, calcProc;
    Connections conns;

    int cols() const { return tab == "apps" && cfg().s("launcherView", "list") == "grid" ? 4 : 1; }

    void setTab(const std::string &t) {
        tab = t;
        current = 0;
        search->placeholder = tab == "run" ? "Type a command and press Enter" : "Search apps, files, settings…";
        if (tab == "files") fileTimer.start();
        conns.later([this] { rebuild(); });
    }

    std::vector<const App *> appResults() const {
        std::string q = lower(trim(query));
        std::vector<const App *> out;
        if (q.empty()) {
            for (auto &a : Apps::get().all()) if (!a.noDisplay) out.push_back(&a);
            std::sort(out.begin(), out.end(), [](const App *a, const App *b) { return lower(a->name) < lower(b->name); });
            return out;
        }
        return Apps::get().search(q);   // name first, then generic name, keywords, description
    }

    int count() const {
        if (tab == "apps") return (int)std::min<size_t>(appResults().size(), 120);
        if (tab == "files") return (int)files.size();
        if (tab == "settings") return (int)settingsPages().size();
        return 0;
    }
    std::vector<std::string> settingsPages() const {
        std::vector<std::string> o;
        for (auto &p : kSettingsPages) if (lower(p).find(lower(query)) != std::string::npos) o.push_back(p);
        return o;
    }

    void move(int d) {
        int n = count();
        if (!n) return;
        current = std::clamp(current + d, 0, n - 1);
        for (size_t i = 0; i < items.size(); i++) {
            if (auto *b = dynamic_cast<Button *>(items[i])) { b->active = (int)i == current; b->update(); }
        }
        if (current < (int)items.size() && results) results->ensureVisible(items[current]->geom);
        refreshHot();
    }
    void refreshHot() {
        for (size_t i = 0; i < items.size(); i++) items[i]->update();
    }

    void launch(const App *a) {
        if (!a) return;
        Apps::get().launch(*a, cfg().b("gamesOnDedicatedGpu", true) && a->isGame());
    }

    void activate(int i) {
        if (tab == "apps") {
            auto r = appResults();
            if (r.empty() && !query.empty()) spawn({"xdg-open", "https://duckduckgo.com/?q=" + urlEncode(query)});
            else if (i >= 0 && i < (int)r.size()) launch(r[i]);
        } else if (tab == "files") {
            if (i >= 0 && i < (int)files.size()) spawn({"xdg-open", files[i]});
        } else if (tab == "run") {
            if (!trim(query).empty()) spawnShell(query);
        } else if (tab == "settings") {
            auto p = settingsPages();
            if (i >= 0 && i < (int)p.size()) spawn({"nova-settings", "--page", p[i]});
        }
        shell().close();
    }

    void searchFiles() {
        if (tab != "files" || query.size() < 2) { files.clear(); return; }
        std::string q = query;
        if (fileProc) fileProc->kill();
        fileProc = Process::run({"sh", "-c",
            "command -v fd >/dev/null && fd -i -d 5 --max-results 40 -- \"$1\" \"$HOME\" || "
            "find \"$HOME\" -maxdepth 5 -iname \"*$1*\" -not -path '*/.*' 2>/dev/null | head -40", "sh", q},
            [this, q, alive = conns.token()](int, const std::string &out) {
                if (!*alive || q != query) return;
                files.clear();
                for (auto &l : split(out, '\n')) if (!trim(l).empty()) files.push_back(trim(l));
                conns.later([this] { rebuild(); });
            });
    }

    void runCalc() {
        if (tab != "apps" || query.find_first_of("0123456789") == std::string::npos || !haveProgram("qalc")) return;
        std::string q = query;
        if (calcProc) calcProc->kill();
        calcProc = Process::run({"qalc", "-t", "-e", q}, [this, q, alive = conns.token()](int, const std::string &out) {
            if (!*alive || q != query) return;
            std::string r = trim(out), lr = lower(r);
            calc = (!r.empty() && r != trim(q) && lr.find("error") == std::string::npos && lr.find("warning") == std::string::npos) ? r : "";
            conns.later([this] { rebuild(); });
        });
    }

    // one list row (icon, title, subtitle, arrow when hot)
    Button *listRow(Widget *parent, const std::string &icon, bool appIcon, const std::string &title, const std::string &sub, int idx) {
        auto *b = parent->add<Button>(Dir::Row, 14);
        b->fixedH = 56;
        b->radius = 13;
        b->padding(12, 0);
        b->activeBg = theme().accentSoft;
        b->activeBorder = theme().accentLine;
        b->hoverBg = theme().accentSoft;
        b->active = idx == current;
        if (appIcon) b->add<AppIconW>(icon, 34);
        else b->add<IconW>(icon, 22, Role::Text2)->ml = 6;
        auto *tc = col(b, 2);
        tc->grow = 1;
        tc->justify = Justify::Center;
        tc->add<Label>(title, 15, Weight::Medium);
        if (!sub.empty()) {
            auto *s = tc->add<Label>(sub, 12, Weight::Normal, Role::Text3);
            if (tab == "files") s->elide = Elide::Middle;   // paths: keep the file name
        }
        b->onClick = [this, idx] { activate(idx); };
        b->onHover = [this, idx](bool h) { if (h) { current = idx; for (size_t i = 0; i < items.size(); i++) if (auto *x = dynamic_cast<Button *>(items[i])) { x->active = (int)i == idx; x->update(); } } };
        return b;
    }

    void rebuild() {
        const Theme &t = theme();
        // tabs
        tabsRow->clear();
        for (auto [id, icon, label] : std::vector<std::tuple<std::string, std::string, std::string>>{
                 {"apps", "grid", "Apps"}, {"files", "file", "Files"}, {"run", "terminal", "Run"}, {"settings", "settings", "Settings"}}) {
            bool on = tab == id;
            auto *b = tabsRow->add<Button>(Dir::Row, 7);
            b->fixedH = 30;
            b->radius = 15;
            b->padding(10, 0);
            b->bg = on ? t.accent : t.surface2;
            b->hoverBg = on ? t.accentBright : t.surface3;
            b->fill = false;
            b->add<IconW>(icon, 14, on ? Role::OnAccent : Role::Text2);
            b->add<Label>(label, 13, on ? Weight::DemiBold : Weight::Normal, on ? Role::OnAccent : Role::Text2)->fill = false;
            std::string idc = id;
            b->onClick = [this, idc] { setTab(idc); };
        }

        body->clear();
        items.clear();
        results = nullptr;
        if (tab == "apps" && query.empty()) {
            // favourites: first row of pinned apps
            auto pinned = cfg().j("pinned");
            if (pinned.is_array() && !pinned.empty()) {
                sectionTitle(body, "FAVOURITES");
                auto *fav = row(body, t.gridGap);
                int n = 0;
                for (auto &p : pinned) {
                    if (!p.is_string() || n++ >= t.gridCols) continue;
                    std::string id = p.get<std::string>();
                    const App *a = Apps::get().lookup(id);
                    auto *c = fav->add<Button>(Dir::Column, 8);
                    c->fixedW = t.gridCell;
                    c->radius = 12;
                    c->pt = c->pb = 6;
                    c->crossAlign = Align::Center;
                    auto *ic = c->add<AppIconW>(a && !a->icon.empty() ? a->icon : id, 40);
                    ic->fill = false;
                    auto *l = c->add<Label>(a ? a->name : id, 11, Weight::Normal, Role::Text2);
                    l->hAlign = Align::Center;
                    c->onClick = [this, a] { launch(a); shell().close(); };
                }
            }
        }
        // section header + list / grid switch
        auto *hdr = row(body, 2);
        std::string title = tab == "apps" ? (query.empty() ? "ALL APPS" : "RESULTS") : upper(tab);
        auto *ht = hdr->add<Label>(title, 12, Weight::DemiBold, Role::Text3);
        ht->font.letterSpacing = 0.7;
        ht->grow = 1;
        if (tab == "apps") {
            for (std::string v : {"list", "grid"}) {
                bool on = cfg().s("launcherView", "list") == v;
                auto *b = hdr->add<IconButton>(v, 30, 15);
                b->fixedH = 24;
                b->radius = 7;
                b->bg = on ? t.surface3 : Color{0, 0, 0, 0};
                b->icon->role = on ? Role::Text : Role::Text3;
                b->onClick = [this, v] { cfg().set("launcherView", v); conns.later([this] { rebuild(); }); };
            }
        }
        // calculator / conversion: click copies the answer
        if (tab == "apps" && !calc.empty()) {
            auto *c = body->add<Button>(Dir::Row, 12);
            c->fixedH = 52;
            c->radius = 14;
            c->padding(16, 0);
            c->bg = t.accentSoft;
            c->hoverBg = t.accentLine;
            c->add<IconW>("calc", 20, Role::Accent);
            c->add<Label>(calc, 16, Weight::DemiBold)->grow = 1;
            c->add<Label>("Copy", 13, Weight::Normal, Role::Accent)->fill = false;
            std::string ans = calc;
            if (auto p = ans.rfind("= "); p != std::string::npos) ans = ans.substr(p + 2);
            c->onClick = [ans] { spawn({"wl-copy", ans}); shell().close(); };
        }

        results = body->add<ScrollView>();
        results->grow = 1;
        auto *list = results->add<Box>(Dir::Column, 2);
        if (tab == "apps") {
            auto r = appResults();
            if (r.empty() && !query.empty()) {
                auto *nf = row(list, 8);
                for (auto [icon, label, kind] : std::vector<std::tuple<std::string, std::string, std::string>>{
                         {"globe", "Search the web", "web"}, {"pkg", "Find in Software", "sw"}}) {
                    auto *b = nf->add<Button>(Dir::Row, 8);
                    b->grow = 1;
                    b->fixedH = 46;
                    b->radius = 13;
                    b->bg = t.surface2;
                    b->justify = Justify::Center;
                    b->add<IconW>(icon, 16, Role::Text2);
                    b->add<Label>(label + " for “" + query + "”", 13)->fill = false;
                    std::string k = kind, q = query;
                    b->onClick = [k, q] {
                        if (k == "web") spawn({"xdg-open", "https://duckduckgo.com/?q=" + urlEncode(q)});
                        else spawn({"gnome-software", "--search", q});
                        shell().close();
                    };
                }
            }
            size_t n = std::min<size_t>(r.size(), 120);
            if (cols() == 1) {
                for (size_t i = 0; i < n; i++) {
                    const App *a = r[i];
                    items.push_back(listRow(list, a->icon.empty() ? a->id : a->icon, true, a->name,
                                            !a->comment.empty() ? a->comment : a->genericName, (int)i));
                }
            } else {
                Box *line = nullptr;
                for (size_t i = 0; i < n; i++) {
                    if (i % 4 == 0) { line = row(list, 0); }
                    const App *a = r[i];
                    auto *b = line->add<Button>(Dir::Column, 8);
                    b->grow = 1;
                    b->fixedH = 96;
                    b->radius = 13;
                    b->justify = Justify::Center;
                    b->crossAlign = Align::Center;
                    b->activeBg = t.accentSoft;
                    b->activeBorder = t.accentLine;
                    b->hoverBg = t.accentSoft;
                    b->active = (int)i == current;
                    b->add<AppIconW>(a->icon.empty() ? a->id : a->icon, 44)->fill = false;
                    auto *l = b->add<Label>(a->name, 12, Weight::Normal, Role::Text2);
                    l->hAlign = Align::Center;
                    l->maxW = (t.gridWidth() - 2 * t.gridPad) / 4 - 10;
                    int idx = (int)i;
                    b->onClick = [this, idx] { activate(idx); };
                    items.push_back(b);
                }
                if (line) while (line->children().size() < 4) line->add<Spacer>()->grow = 1;
            }
        } else if (tab == "files") {
            std::string home = homeDir();
            for (size_t i = 0; i < files.size(); i++) {
                std::string f = files[i];
                std::string shownPath = startsWith(f, home) ? "~" + f.substr(home.size()) : f;
                bool dir = std::filesystem::is_directory(f);
                items.push_back(listRow(list, dir ? "folder" : "text-x-generic", true, std::filesystem::path(f).filename().string(), shownPath, (int)i));
            }
            if (files.empty()) {
                auto *l = list->add<Label>(query.size() < 2 ? "Type to search your home folder" : "No files found", 13, Weight::Normal, Role::Text3);
                l->hAlign = Align::Center;
                l->mt = 30;
            }
        } else if (tab == "run") {
            auto *l = list->add<Label>(query.empty() ? "Runs in a shell: commands, scripts, URLs with xdg-open…" : "Enter runs:  " + query, 13, Weight::Normal, Role::Text3);
            l->mt = 10;
        } else if (tab == "settings") {
            auto p = settingsPages();
            for (size_t i = 0; i < p.size(); i++) items.push_back(listRow(list, "preferences-system", true, p[i], "Settings", (int)i));
        }
        relayout();
    }

    static std::string upper(std::string s) { for (auto &c : s) c = (char)toupper(c); return s; }

    void buildFooter() {
        const Theme &t = theme();
        footer = row(this, 12);
        class SmallAvatar : public Widget {
        public:
            std::shared_ptr<Image> face;
            Size sizeHint(double, double) override { return {40, 40}; }
            void paint(Painter &p) override {
                p.save();
                p.clip(geom, 20);
                p.gradient(geom, Color::hex("#d9925a"), Color::hex("#7d3f6b"));
                if (face && face->valid()) p.image(*face, geom, 20);
                p.restore();
            }
        };
        auto *av = footer->add<SmallAvatar>();
        std::string face = homeDir() + "/.face";
        if (std::filesystem::exists(face)) av->face = std::make_shared<Image>(face, 80, 80);
        auto *who = col(footer, 2);
        who->grow = 1;
        const char *u = getenv("USER");
        who->add<Label>(u ? u : "", 14, Weight::DemiBold);
        auto *up = row(who, 5);
        up->add<IconW>("clock", 12, Role::Text3);
        up->add<Label>(uptimeText(), 12, Weight::Normal, Role::Text3)->fill = false;
        auto *set = footer->add<IconButton>("settings");
        set->onClick = [] { spawn({"nova-settings"}); shell().close(); };
        auto *lock = footer->add<IconButton>("lock");
        lock->onClick = [] { shell().close(); LockScreen::get().lock(); };
        auto *pw = footer->add<IconButton>("power");
        pw->icon->role = Role::Custom;
        pw->icon->color = Color::hex("#ff8a7a");
        pw->onClick = [this] { powerMenu = !powerMenu; powerRow->visible = powerMenu; relayout(); };

        powerRow = row(this, 8);
        powerRow->visible = false;
        std::vector<std::pair<std::string, std::vector<std::string>>> acts = {
            {"Log out", {"novactl", "dispatch", "exit"}}, {"Suspend", {"systemctl", "suspend"}},
            {"Restart", {"systemctl", "reboot"}}, {"Shut down", {"systemctl", "poweroff"}}};
        for (size_t i = 0; i < acts.size(); i++) {
            bool danger = i == 3;
            auto *b = powerRow->add<TextButton>(acts[i].first);
            b->grow = 1;
            b->fixedH = 36;
            b->radius = 11;
            b->bg = danger ? Color{0.91, 0.38, 0.3, 0.2} : t.surface3;
            if (danger) { b->label->role = Role::Custom; b->label->color = Color::hex("#ff8a7a"); }
            auto cmd = acts[i].second;
            b->onClick = [cmd] { spawn(cmd); };
        }
    }
};

std::unique_ptr<Widget> makeLauncher(Screen *s) { return std::make_unique<Launcher>(s); }

}  // namespace nova
