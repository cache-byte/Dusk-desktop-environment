// Super+Tab: blurred wallpaper, workspaces along the top (x to close, + to add),
// a window search, and every window on the current workspace as a card
// (app icon bottom-left, close button top-right). Minimised windows on the right.
#include "apps.hpp"
#include "novaipc.hpp"
#include "windows.hpp"

namespace nova {

using namespace ui;

// rows that wrap, centred (window cards)
class Flow : public Widget {
public:
    double spacing = 48;
    Size sizeHint(double aw, double) override {
        double x = 0, y = 0, rowH = 0, maxW = 0;
        for (auto &c : children_) {
            if (!c->visible) continue;
            Size s = c->hint(aw, kInf);
            if (x > 0 && x + s.w > aw) { y += rowH + spacing; x = 0; rowH = 0; }
            x += s.w + spacing;
            maxW = std::max(maxW, x - spacing);
            rowH = std::max(rowH, s.h);
        }
        return {std::min(aw, maxW), y + rowH};
    }
    void arrange() override {
        // gather rows, then centre each
        std::vector<std::vector<std::pair<Widget *, Size>>> rows(1);
        double x = 0;
        for (auto &c : children_) {
            if (!c->visible) continue;
            Size s = c->hint(geom.w, kInf);
            if (x > 0 && x + s.w > geom.w) { rows.emplace_back(); x = 0; }
            rows.back().push_back({c.get(), s});
            x += s.w + spacing;
        }
        double total = 0;
        std::vector<double> heights;
        for (auto &r : rows) {
            double h = 0;
            for (auto &[w, s] : r) h = std::max(h, s.h);
            heights.push_back(h);
            total += h + spacing;
        }
        total -= spacing;
        double y = geom.y + std::max(0.0, (geom.h - total) / 2);
        for (size_t i = 0; i < rows.size(); i++) {
            double rw = -spacing;
            for (auto &[w, s] : rows[i]) rw += s.w + spacing;
            double xx = geom.x + (geom.w - rw) / 2;
            for (auto &[w, s] : rows[i]) { w->setGeometry({xx, y, s.w, s.h}); xx += s.w + spacing; }
            y += heights[i] + spacing;
        }
    }
};

// full-screen blurred, darkened wallpaper
class OverviewBg : public Stack {
public:
    std::shared_ptr<Image> img;
    void paint(Painter &p) override {
        p.fill(geom, Color{0.05, 0.05, 0.07, 1});
        if (img && img->valid()) p.image(*img, geom);
        p.fill(geom, Color{0, 0, 0, 0.28});
    }
};

static int wsOf(const json &w) {
    if (w.contains("index") && w["index"].is_number()) return w["index"].get<int>();
    return w.value("workspace", 1);
}

OverviewWindow::OverviewWindow(Screen *s) : LayerWindow("nova-overview", Layer::Overlay, s->output), screen(s) {
    setAnchors(AnchorTop | AnchorBottom | AnchorLeft | AnchorRight);
    setMargins(0, 0, (int)theme().panelHeight, 0);
    setExclusiveZone(-1);
    setKeyboard(KeyboardMode::Exclusive);
    wantBlur = false;
    onKey = [](const KeyEvent &e) {
        if (e.pressed && e.sym == key::Escape) { shell().close(); return true; }
        return false;
    };
    conns_.on(ipc().workspacesChanged, [this] { reload(); });
    build();
    show();
    reload();
}
OverviewWindow::~OverviewWindow() = default;

void OverviewWindow::reload() {
    ipc().request("get windows", [this, alive = conns_.token()](const json &r) {
        if (!*alive) return;
        windows_ = r.is_object() && r.contains("windows") ? r["windows"] : json::array();
        conns_.later([this] { build(); });
    });
}

void OverviewWindow::build() {
    std::string query;
    if (auto *in = dynamic_cast<TextInput *>(focus())) query = in->text();
    const Theme &t = theme();
    Size scr = screen->output ? screen->output->logical() : Size{1920, 1080};
    auto *bg = setRoot<OverviewBg>();
    bg->img = blurredWallpaper(scr);
    bg->interactive = true;
    bg->onClick = [] { shell().close(); };

    std::string me = screen->name();
    OutputWs ws = ipc().wsFor(me);
    json mine = json::array(), wins = json::array(), minimized = json::array();
    for (auto &w : windows_) {
        std::string o = w.value("output", std::string());
        if (o.empty() || o == me) mine.push_back(w);
    }
    std::string q = lower(query);
    for (auto &w : q.empty() ? mine : windows_) {
        if (w.value("minimized", false)) continue;
        std::string hay = lower(w.value("title", std::string()) + " " + w.value("app_id", std::string()));
        if (q.empty() ? wsOf(w) == ws.active : hay.find(q) != std::string::npos) wins.push_back(w);
    }
    for (auto &w : mine) if (w.value("minimized", false)) minimized.push_back(w);
    int n = std::max(1, ws.active);
    for (int o : ws.occupied) n = std::max(n, o);

    auto *page = bg->add<Box>(Dir::Column, 10);
    page->pt = 34;
    page->pb = 30;

    // ---- workspaces ----
    auto *wsRow = row(page, 16);
    wsRow->fill = false;
    wsRow->alignSelf = Align::Center;
    wsRow->crossAlign = Align::Start;
    auto wp = wallpaperImage(scr);
    for (int i = 1; i <= n; i++) {
        auto *c = col(wsRow, 8);
        c->crossAlign = Align::Center;
        auto *thumb = c->add<Stack>();
        thumb->fixedW = 220;
        thumb->fixedH = 124;
        auto *frame = thumb->add<Box>(Dir::Column);
        frame->radius = 14;
        frame->bg = t.surface;
        frame->border = i == ws.active ? t.accent : Color{1, 1, 1, 0.12};
        frame->borderWidth = i == ws.active ? 2.5 : 1;
        frame->justify = Justify::Center;
        frame->padding(2);
        frame->interactive = true;
        frame->cursor = Cursor::Pointer;
        frame->onClick = [i] { ipc().dispatch("workspace " + std::to_string(i)); };
        auto *im = frame->add<ImageW>();
        im->image = wp;
        im->radius = 12;
        im->grow = 1;
        im->opacity.set(0.85);
        int count = 0;
        for (auto &w : mine) if (wsOf(w) == i) count++;
        auto *cnt = thumb->add<Label>(std::to_string(count) + (count == 1 ? " window" : " windows"), 12);
        cnt->role = Role::Custom;
        cnt->color = Color{1, 1, 1, 1};
        cnt->fill = false;
        cnt->alignSelf = Align::Center;
        cnt->hAlign = Align::Center;
        if (n > 1) {
            auto *x = thumb->add<IconButton>("x", 22, 12);
            x->bg = t.danger;
            x->hoverBg = t.danger.lighter(0.1);
            x->icon->role = Role::Custom;
            x->icon->color = Color{1, 1, 1, 1};
            x->fill = false;
            x->alignSelf = Align::End;
            x->mt = 6;
            x->mr = 6;
            int base = ws.base;
            x->onClick = [this, i, base] {
                ipc().dispatch("close-workspace " + std::to_string(base + i - 1));
                conns_.after(150, [this] { reload(); });
            };
        }
        auto *lbl = c->add<Label>("Workspace " + std::to_string(i), 13, i == ws.active ? Weight::DemiBold : Weight::Normal,
                                  i == ws.active ? Role::AccentBright : Role::Text2);
        lbl->fill = false;
    }
    if (n < 9) {
        auto *add = wsRow->add<Button>(Dir::Row, 0);
        add->fixedW = 64;
        add->fixedH = 124;
        add->radius = 14;
        add->border = t.accentLine;
        add->borderWidth = 1.5;
        add->justify = Justify::Center;
        add->add<IconW>("plus", 20, Role::AccentBright)->fill = false;
        add->onClick = [n] { ipc().dispatch("workspace " + std::to_string(n + 1)); };
    }

    // ---- search ----
    auto *sb = page->add<Card>(Dir::Row, 12);
    sb->fill = false;
    sb->alignSelf = Align::Center;
    sb->fixedW = 440;
    sb->fixedH = 46;
    sb->radius = 23;
    sb->padding(18, 0);
    sb->shadow = false;
    auto *in = sb->add<TextInput>();
    in->framed = false;
    in->leadingIcon = "search";
    in->placeholder = "Search windows";
    in->fontSize = 15;
    in->grow = 1;
    in->setText(query);
    in->onChanged = [this](const std::string &) { conns_.later([this] { build(); }); };
    in->onSubmit = [wins](const std::string &) {
        if (wins.empty()) return;
        ipc().dispatch("focus-window " + std::to_string(wins[0].value("id", 0)));
        shell().close();
    };

    // ---- windows + minimised ----
    auto *body = row(page, 40);
    body->grow = 1;
    body->crossAlign = Align::Start;
    body->mt = 30;
    body->pl = 150;
    body->pr = 52;
    auto *stage = body->add<Box>(Dir::Column);
    stage->grow = 1;
    stage->radius = 28;
    stage->bg = Color{1, 1, 1, 0.035};
    stage->border = Color{1, 1, 1, 0.06};
    stage->padding(40);
    stage->justify = Justify::Center;
    if (wins.empty()) {
        auto *l = stage->add<Label>(query.empty() ? "No windows on this workspace" : "No matching windows", 14, Weight::Normal, Role::Text3);
        l->hAlign = Align::Center;
    } else {
        auto *flow = stage->add<Flow>();
        for (auto &w : wins) {
            std::string app = w.value("app_id", std::string()), title = w.value("title", std::string());
            int id = w.value("id", 0);
            const App *a = Apps::get().lookup(app);
            std::string icon = a && !a->icon.empty() ? a->icon : app;
            auto *wc = flow->add<Box>(Dir::Column, 14);
            wc->fixedW = 320;
            auto *cardS = wc->add<Stack>();
            cardS->fixedH = 210;
            auto *card = cardS->add<Button>(Dir::Column, 0);
            card->radius = 14;
            card->bg = Color{0.08, 0.075, 0.105, 0.95};
            card->hoverBg = card->bg;
            card->border = Color{1, 1, 1, 0.08};
            card->activeBorder = t.accent;
            card->justify = Justify::Center;
            card->add<AppIconW>(icon, 72)->fill = false;
            card->children().back()->alignSelf = Align::Center;
            card->onHover = [card](bool h) { card->border = h ? theme().accent : Color{1, 1, 1, 0.08}; card->borderWidth = h ? 2 : 1; };
            card->onClick = [id] { ipc().dispatch("focus-window " + std::to_string(id)); shell().close(); };
            auto *x = cardS->add<IconButton>("x", 28, 14);
            x->bg = t.danger;
            x->hoverBg = t.danger.lighter(0.1);
            x->icon->role = Role::Custom;
            x->icon->color = Color{1, 1, 1, 1};
            x->fill = false;
            x->alignSelf = Align::End;
            x->mt = 6;
            x->mr = 6;
            x->onClick = [this, id] {
                ipc().dispatch("close-window " + std::to_string(id));
                conns_.after(150, [this] { reload(); });
            };
            auto *badge = cardS->add<AppIconW>(icon, 46);
            badge->fill = false;
            badge->alignSelf = Align::End;
            badge->ml = 8;
            badge->mt = 210 - 46 - 8;
            badge->fixedW = 46;
            auto *tl = wc->add<Label>(title.empty() ? app : title, 13, Weight::Normal, Role::Text2);
            tl->hAlign = Align::Center;
        }
    }
    if (!minimized.empty()) {
        auto *mc = col(body, 12);
        mc->fixedW = 190;
        auto *h = mc->add<Label>("MINIMIZED", 12, Weight::DemiBold, Role::Text3);
        h->font.letterSpacing = 0.7;
        for (auto &w : minimized) {
            std::string app = w.value("app_id", std::string());
            int id = w.value("id", 0);
            const App *a = Apps::get().lookup(app);
            auto *b = mc->add<Button>(Dir::Column, 0);
            b->fixedH = 118;
            b->radius = 14;
            b->bg = t.surface;
            b->justify = Justify::Center;
            auto *ic = b->add<AppIconW>(a && !a->icon.empty() ? a->icon : app, 48);
            ic->fill = false;
            ic->alignSelf = Align::Center;
            b->onClick = [id] { ipc().dispatch("focus-window " + std::to_string(id)); shell().close(); };
            mc->add<Label>(w.value("title", std::string()), 12, Weight::Normal, Role::Text3);
        }
    }
    setFocus(in);
    relayout();
}

}  // namespace nova
