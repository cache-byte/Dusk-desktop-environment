#include "config.hpp"
#include "ui/paint.hpp"
#include "ui/sys.hpp"

#include <filesystem>

namespace nova {

Config &Config::get() {
    static Config c;
    return c;
}
std::string Config::dir() { return ui::configDir() + "/nova"; }

void Config::load() {
    static bool watching = false;
    for (const char *p : {"/usr/share/nova/defaults.json", "/usr/local/share/nova/defaults.json"}) {
        bool ok = false;
        std::string t = ui::readFile(p, &ok);
        if (!ok) continue;
        try {
            json d = json::parse(t);
            defaults_ = d.contains("values") ? d["values"] : d;
            break;
        } catch (...) {}
    }
    bool ok = false;
    std::string t = ui::readFile(dir() + "/settings.json", &ok);
    user_ = json::object();
    if (ok) {
        try { user_ = json::parse(t); } catch (...) { fprintf(stderr, "nova-shell: settings.json is not valid JSON, using defaults\n"); }
    }
    if (!user_.is_object()) user_ = json::object();
    merged_ = defaults_.is_object() ? defaults_ : json::object();
    for (auto &[k, v] : user_.items()) merged_[k] = v;
    // control-centre layout: reset when the grid changed shape (ccVersion)
    if (value<int>("ccVersion", 1) < 3 && defaults_.contains("ccLayout")) {
        merged_["ccLayout"] = defaults_["ccLayout"];
        merged_["ccVersion"] = 3;
        // save it, so a layout made afterwards isn't reset again on the next start
        user_.erase("ccLayout");
        user_["ccVersion"] = 3;
        ownWrite_ = ui::nowMs();
        ui::writeFile(dir() + "/settings.json", user_.dump(2));
    }
    applyTheme();
    if (!watching) {
        watching = true;
        std::filesystem::create_directories(dir());
        ui::FileWatch::watch(dir() + "/settings.json", [this] {
            if (ui::nowMs() - ownWrite_ < 400) return;    // our own write
            load();
            changed.emit();
        });
    }
}

void Config::set(const std::string &key, const json &v) {
    if (merged_.contains(key) && merged_[key] == v) return;
    // re-read first: the Settings app may have changed other keys meanwhile
    bool ok = false;
    std::string t = ui::readFile(dir() + "/settings.json", &ok);
    json cur = json::object();
    if (ok) { try { cur = json::parse(t); } catch (...) {} }
    if (!cur.is_object()) cur = json::object();
    cur[key] = v;
    user_ = cur;
    merged_[key] = v;
    std::filesystem::create_directories(dir());
    ownWrite_ = ui::nowMs();
    ui::writeFile(dir() + "/settings.json", cur.dump(2));
    applyTheme();
    changed.emit();
}

json Config::osd(const std::string &kind) const {
    static const json defs = json::parse(R"({
        "slider": { "pos": 5, "dir": "up", "dx": 0, "dy": 0 },
        "lock": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 },
        "power": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 },
        "notifications": { "pos": 8, "dir": "up", "dx": 0, "dy": 0 },
        "message": { "pos": 1, "dir": "across", "dx": 0, "dy": 0 },
        "nowplaying": { "pos": 8, "dir": "clock", "dx": 0, "dy": 0 },
        "lyrics": { "pos": 7, "dir": "centre", "dx": 0, "dy": 40 },
        "visualizer": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 }
    })");
    json o = defs.contains(kind) ? defs[kind] : json::object();
    json user = j("osd");
    if (user.is_object() && user.contains(kind) && user[kind].is_object())
        for (auto &[k, v] : user[kind].items()) o[k] = v;
    return o;
}

void Config::applyTheme() {
    ui::Theme &t = ui::theme();
    t.dark = s("mode", "dark") != "light";
    t.accent = ui::Color::hex(s("accent", "#c8b64a"), ui::Color::hex("#c8b64a"));
    t.font = s("font", "Inter");
    t.mono = s("monoFont", "JetBrains Mono");
    t.fontSize = d("fontSize", 14);
    t.transparencyUi = d("transparencyUi", 0.8);
    t.transparencyPanel = d("transparencyPanel", 0.8);
    t.transparencyApps = d("transparencyApps", 0.8);
    t.blurUi = d("blurUi", 0.8);
    t.blurPanel = d("blurPanel", 0.8);
    t.blurApps = d("blurApps", 0.8);
    t.animationSpeed = d("animationSpeed", 1.0);
    t.realBlur = getenv("NOVA_REAL_BLUR") && std::string(getenv("NOVA_REAL_BLUR")) == "1";
    ui::setIconTheme(s("iconTheme", t.dark ? "Papirus-Dark" : "Papirus"));
    t.rebuild();
}

}  // namespace nova
