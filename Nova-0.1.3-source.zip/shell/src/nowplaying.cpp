// Pops up right above the clock after hovering it for 1.5 s (when something is playing).
// It stays open while the pointer moves onto it, so its buttons can be pressed.
#include "services.hpp"
#include "windows.hpp"

namespace nova {

using namespace ui;

// seek bar: click anywhere to jump there
class SeekBar : public Widget {
public:
    SeekBar() { interactive = true; cursor = Cursor::Pointer; fixedH = 10; }
    double frac = 0;
    void paint(Painter &p) override {
        p.fill(geom, theme().dark ? Color{1, 1, 1, 0.07} : Color{0, 0, 0, 0.08}, geom.h / 2);
        if (frac > 0) p.fill({geom.x, geom.y, std::max(geom.h, geom.w * std::clamp(frac, 0.0, 1.0)), geom.h}, theme().accent, geom.h / 2);
    }
    bool pointerPress(Point pt, int button) override {
        Player *pl = Media::get().player();
        if (button == 1 && pl && pl->canSeek && pl->length > 0) Media::get().seek(pl->length * std::clamp((pt.x - geom.x) / geom.w, 0.0, 1.0));
        return true;
    }
};

// small rounded tab / chip
static Button *chip(Widget *parent, const std::string &text, bool on, bool filled) {
    auto *b = parent->add<Button>(Dir::Row, 0);
    b->fixedH = filled ? 26 : 24;
    b->radius = b->fixedH / 2;
    b->padding(filled ? 10 : 9, 0);
    b->bg = on ? (filled ? theme().accent : theme().surface3) : (filled ? theme().surface2 : Color{0, 0, 0, 0});
    if (!filled) b->border = theme().border;
    b->fill = false;
    auto *l = b->add<Label>(text, 12, on && filled ? Weight::DemiBold : Weight::Normal,
                            on ? (filled ? Role::OnAccent : Role::Text) : (filled ? Role::Text2 : Role::Text3));
    l->fill = false;
    return b;
}

struct NowPlayingWindow::Parts {
    std::string tab = "player";
    SeekBar *seek = nullptr;
    Label *pos = nullptr, *left = nullptr;
    Timer tick;
    bool shownOnce = false;
};

NowPlayingWindow::NowPlayingWindow(Screen *s) : FitWindow("nova-nowplaying", Layer::Overlay, s->output), screen(s), p_(std::make_unique<Parts>()) {
    pointerInside.connect([](bool in) { shell().setCardHovered(in); });
    conns_.on(Media::get().changed, [this] { if (shown()) build(); });
    conns_.on(cfg().changed, [this] { if (shown()) build(); });
    conns_.on(Lyrics::get().changed, [this] { if (shown() && p_->tab == "lyrics") fit(); });
    p_->tick.setup(1000, [this] { refresh(); }, true);
    resized.connect([this](Size sz) {
        Size scr = screen->output ? screen->output->logical() : Size{};
        setBackdrop(*this, scr, {scr.w - sz.w - (shell().clockRightGap - margin), scr.h - sz.h - (theme().panelHeight + 6 - margin), sz.w, sz.h});
    });
}
NowPlayingWindow::~NowPlayingWindow() { shell().setCardHovered(false); }

void NowPlayingWindow::sync() {
    auto &sh = shell();
    bool want = sh.npOpen && sh.npOutput == screen->name() && Media::get().player();
    if (want && !shown()) {
        build();
        json o = cfg().osd("nowplaying");
        if (o.value("dir", std::string("clock")) == "clock") {
            place(AnchorBottom | AnchorRight, 0, (int)sh.clockRightGap, (int)theme().panelHeight + 6, 0);
        } else {
            Placement pl = placementFor(o, theme().panelHeight);
            place(pl.anchors, pl.mt, pl.mr, pl.mb, pl.ml);
        }
        show();
        p_->tick.start();
        // rises out of the clock
        if (Widget *c = root()->children().empty() ? nullptr : root()->children()[0].get()) {
            c->opacity.set(0);
            c->ty.set(14);
            c->startAnim(c->opacity, 1, theme().ms(160));
            c->startAnim(c->ty, 0, theme().ms(200));
        }
    } else if (!want && shown()) {
        p_->tick.stop();
        hide();
    }
}

void NowPlayingWindow::refresh() {
    Player *pl = Media::get().player();
    if (!pl || !p_->seek) return;
    double pos = pl->positionNow();
    p_->seek->frac = pl->length > 0 ? pos / pl->length : 0;
    p_->seek->update();
    p_->pos->setText(Media::fmt(pos));
    p_->left->setText("-" + Media::fmt(std::max(0.0, pl->length - pos)));
}

void NowPlayingWindow::build() {
    Player *pl = Media::get().player();
    root()->clear();
    p_->seek = nullptr;
    if (!pl) return;
    const Theme &t = theme();
    auto &M = Media::get();
    bool lyricsOn = cfg().b("lyricsNowPlaying", true);
    if (!lyricsOn) p_->tab = "player";

    auto *card = root()->add<Card>(Dir::Column, 14);
    card->fixedW = t.gridWidth();
    card->radius = 22;
    card->padding(16);

    // header: bars, "Now playing · App", Player / Lyrics tabs
    auto *head = row(card, 8);
    if (pl->playing) { auto *b = head->add<MusicBars>(); b->setActive(true); }
    auto *ht = head->add<Label>("Now playing" + (pl->identity.empty() ? "" : " · " + pl->identity), 12, Weight::Normal, Role::Text2);
    ht->grow = 1;
    if (lyricsOn) {
        for (auto [id, label] : std::vector<std::pair<std::string, std::string>>{{"player", "Player"}, {"lyrics", "Lyrics"}}) {
            auto *c = chip(head, label, p_->tab == id, true);
            std::string idc = id;
            c->onClick = [this, idc] { p_->tab = idc; conns_.later([this] { build(); }); };
        }
    }
    // more than one player: pick which one the controls drive
    if (M.players.size() > 1) {
        auto *flow = row(card, 6);
        for (auto &x : M.players) {
            auto *c = chip(flow, x.identity.empty() ? x.bus : x.identity, x.bus == pl->bus, false);
            std::string bus = x.bus;
            c->onClick = [bus] { Loop::get().defer([bus] { Media::get().choose(bus); }); };
        }
    }

    if (p_->tab == "lyrics") {
        auto *lv = card->add<LyricsView>();
        lv->scaleK = 0.8;
        lv->fixedH = 210;
        if (!Lyrics::get().source.empty()) {
            auto *src = card->add<Label>("Synced lyrics · " + Lyrics::get().source, 11, Weight::Normal, Role::Text3);
            src->fill = false;
            src->alignSelf = Align::End;
        }
    } else {
        auto *info = row(card, 14);
        auto *art = info->add<ImageW>();
        art->fixedW = art->fixedH = 68;
        art->radius = 14;
        art->image = M.art;
        art->placeholder = t.surface3;
        art->placeholderIcon = "music";
        auto *txt = col(info, 3);
        txt->grow = 1;
        txt->add<Label>(pl->title, 16, Weight::DemiBold);
        std::string sub = pl->artist;
        if (!pl->album.empty()) sub += (sub.empty() ? "" : " · ") + pl->album;
        txt->add<Label>(sub, 13, Weight::Normal, Role::Text2);
        auto places = cfg().j("vizPlaces");
        if (places.is_array() && std::find(places.begin(), places.end(), "nowplaying") != places.end()) {
            auto *v = card->add<Visualizer>();
            v->fixedH = 54;
        }
    }

    if (pl->length > 0) {
        auto *pc = col(card, 7);
        p_->seek = pc->add<SeekBar>();
        auto *times = row(pc, 0);
        p_->pos = times->add<Label>("", 12, Weight::Normal, Role::Text3);
        p_->pos->fill = false;
        stretch(times);
        p_->left = times->add<Label>("", 12, Weight::Normal, Role::Text3);
        p_->left->fill = false;
        refresh();
    }

    auto *ctl = row(card, 26);
    ctl->justify = Justify::Center;
    auto *prev = ctl->add<IconButton>("prev", 40, 20);
    prev->bg = Color{0, 0, 0, 0};
    prev->onClick = [] { Media::get().previous(); };
    auto *play = ctl->add<IconButton>(pl->playing ? "pause" : "play", 46, 20);
    play->radius = 23;
    play->bg = t.accent;
    play->hoverBg = t.accentBright;
    play->icon->role = Role::OnAccent;
    play->onClick = [] { Media::get().playPause(); };
    auto *next = ctl->add<IconButton>("next", 40, 20);
    next->bg = Color{0, 0, 0, 0};
    next->onClick = [] { Media::get().next(); };
    fit();
    relayout();
}

}  // namespace nova
