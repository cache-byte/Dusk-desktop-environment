// Notification pop-ups (toasts), the notification card, and the calendar + notification centre.
#include "notifications.hpp"
#include "windows.hpp"

#include <ctime>
#include <set>

namespace nova {

using namespace ui;

// Notification bodies use a small HTML subset; Pango markup understands b / i / u only.
static std::string bodyMarkup(const std::string &in) {
    std::string out;
    for (size_t i = 0; i < in.size(); i++) {
        char c = in[i];
        if (c == '<') {
            size_t e = in.find('>', i);
            if (e == std::string::npos) { out += "&lt;"; continue; }
            std::string tag = lower(in.substr(i + 1, e - i - 1));
            std::string bare = tag;
            if (!bare.empty() && bare[0] == '/') bare = bare.substr(1);
            if (bare == "b" || bare == "i" || bare == "u") out += "<" + tag + ">";
            else if (bare == "br" || bare == "br/") out += "\n";
            i = e;
        } else if (c == '&') {
            // keep entities, escape bare ampersands
            size_t semi = in.find(';', i);
            bool entity = semi != std::string::npos && semi - i < 8 && in.find(' ', i) > semi;
            out += entity ? "&" : "&amp;";
        } else if (c == '>') out += "&gt;";
        else out += c;
    }
    return out;
}

static std::string hhmm(int64_t ms) {
    time_t t = (time_t)(ms / 1000);
    tm lt;
    localtime_r(&t, &lt);
    char b[16];
    strftime(b, sizeof b, cfg().b("clock24", true) ? "%H:%M" : "%l:%M %p", &lt);
    return trim(b);
}

Widget *notificationCard(Widget *parent, const Notification &n, bool toast) {
    const Theme &t = theme();
    Box *card;
    if (toast) {
        auto *c = parent->add<Card>(Dir::Column, 10);
        c->radius = t.radius;
        card = c;
    } else {
        card = parent->add<Box>(Dir::Column, 10);
        card->bg = t.surface2;
        card->radius = t.radius;
        card->border = t.border;
    }
    if (n.urgency == 2) card->border = t.danger;
    card->padding(16);
    uint32_t id = n.id;
    // a click on the card runs the default action (or just dismisses the toast)
    card->interactive = true;
    bool hasDefault = std::any_of(n.actions.begin(), n.actions.end(), [](auto &a) { return a.first == "default"; });
    card->cursor = hasDefault ? Cursor::Pointer : Cursor::Default;
    card->onClick = [id, hasDefault, toast] {
        Loop::get().defer([id, hasDefault, toast] {
            if (hasDefault) Notifications::get().invoke(id, "default");
            else if (toast) Notifications::get().dismissPopup(id);
        });
    };

    auto *head = row(card, 10);
    head->add<AppIconW>(n.appIcon.empty() ? (n.desktopEntry.empty() ? "dialog-information" : n.desktopEntry) : n.appIcon, 22);
    auto *app = head->add<Label>(n.app.empty() ? "Notification" : n.app, 13, Weight::Normal, Role::Text2);
    app->fill = false;
    head->add<Label>("· " + hhmm(n.time), 13, Weight::Normal, Role::Text3)->fill = false;
    stretch(head);
    auto *x = head->add<IconButton>("x", 26, 16);
    x->bg = Color{0, 0, 0, 0};
    x->icon->role = Role::Text3;
    x->onClick = [id] { Loop::get().defer([id] { Notifications::get().dismiss(id); }); };

    auto *bodyRow = row(card, 14);
    bodyRow->crossAlign = Align::Start;
    auto *txt = col(bodyRow, 4);
    txt->grow = 1;
    auto *sum = txt->add<Label>(n.summary, 15, Weight::DemiBold);
    sum->maxLines = 2;
    if (!n.body.empty()) {
        auto *b = txt->add<Label>(bodyMarkup(n.body), 13, Weight::Normal, Role::Text2);
        b->markup = true;
        b->maxLines = 4;
    }
    if (n.image && n.image->valid()) {
        auto *im = bodyRow->add<ImageW>();
        im->image = n.image;
        im->fixedW = 84;
        im->fixedH = 54;
        im->radius = 10;
        im->fill = false;
        im->alignSelf = Align::Start;
    }
    std::vector<std::pair<std::string, std::string>> acts;
    for (auto &a : n.actions) if (a.first != "default") acts.push_back(a);
    if (!acts.empty()) {
        auto *ar = row(card, 8);
        for (size_t i = 0; i < acts.size(); i++) {
            bool last = i == acts.size() - 1;
            auto *b = ar->add<TextButton>(acts[i].second, "", last);
            b->grow = 1;
            b->fixedH = 34;
            b->radius = 11;
            if (!last) b->bg = t.surface3;
            std::string key = acts[i].first;
            b->onClick = [id, key] { Loop::get().defer([id, key] { Notifications::get().invoke(id, key); }); };
        }
    }
    return card;
}

// ================================================================ toasts ==
NotificationsWindow::NotificationsWindow(Screen *s) : FitWindow("nova-notifications", Layer::Overlay, s->output, 30), screen(s) {
    conns_.on(Notifications::get().changed, [this] { sync(); });
    conns_.on(cfg().changed, [this] { sync(); });
    pointerInside.connect([](bool in) { Notifications::get().holdPopups(in); });
    resized.connect([this](Size sz) {
        Size scr = screen->output ? screen->output->logical() : Size{};
        Placement pl = placementFor(cfg().osd("notifications"), theme().panelHeight);
        double x = (pl.anchors & AnchorLeft) ? pl.ml - margin : (pl.anchors & AnchorRight) ? scr.w - sz.w - (pl.mr - margin) : (scr.w - sz.w) / 2;
        double y = (pl.anchors & AnchorTop) ? pl.mt - margin : (pl.anchors & AnchorBottom) ? scr.h - sz.h - (pl.mb - margin) : (scr.h - sz.h) / 2;
        setBackdrop(*this, scr, {x, y, sz.w, sz.h});
    });
}
NotificationsWindow::~NotificationsWindow() { Notifications::get().holdPopups(false); }

void NotificationsWindow::sync() {
    auto &N = Notifications::get();
    auto &sh = shell();
    bool want = !N.popups.empty() && sh.popout != "notifications" && !sh.npOpen && indicatorOnScreen(screen->name());
    if (!want) {
        if (shown()) { hide(); Notifications::get().holdPopups(false); }
        return;
    }
    rebuild();
    if (!shown()) {
        Placement pl = placementFor(cfg().osd("notifications"), theme().panelHeight);
        place(pl.anchors, pl.mt, pl.mr, pl.mb, pl.ml);
        show();
    }
}

void NotificationsWindow::rebuild() {
    auto &N = Notifications::get();
    root()->clear();
    json o = cfg().osd("notifications");
    int pos = o.value("pos", 8);
    std::string dir = o.value("dir", std::string("up"));
    // "up" stacks the newest nearest the edge going upward; "down" the other way
    bool newestAtBottom = pos / 3 == 2 ? dir != "down" : dir == "up";
    auto *stack = root()->add<Box>(Dir::Column, 10);
    stack->fixedW = 400;
    std::vector<uint32_t> ids = N.popups;
    if (newestAtBottom) std::reverse(ids.begin(), ids.end());
    for (uint32_t id : ids)
        if (const Notification *n = N.find(id)) {
            Widget *c = notificationCard(stack, *n, true);
            (void)c;
        }
    fit();
    relayout();
}

// ================================================== calendar + notifications ==
class NotificationCentre : public Card {
public:
    explicit NotificationCentre(Screen *s) : Card(Dir::Column, 14), screen(s) {
        const Theme &t = theme();
        fixedW = t.gridWidth();
        padding(t.gridPad);
        radius = t.radius;
        time_t now = time(nullptr);
        tm lt;
        localtime_r(&now, &lt);
        year = lt.tm_year + 1900;
        month = lt.tm_mon;
        conns.on(Notifications::get().changed, [this] { conns.later([this] { build(); }); });
        conns.on(cfg().changed, [this] { conns.later([this] { build(); }); });
        build();
    }
    Screen *screen;
    int year, month;
    std::set<std::string> open;     // expanded groups
    Connections conns;
    Size sizeHint(double aw, double ah) override {
        // whole cells of the pop-up grid, like the control centre
        Size s = Card::sizeHint(aw, ah);
        const Theme &t = theme();
        return {s.w, t.gridHeight(t.gridRowsFor(s.h))};
    }
    void build() {
        clear();
        const Theme &t = theme();
        auto &N = Notifications::get();
        // ---- month header ----
        auto *head = row(this, 4);
        tm first{};
        first.tm_year = year - 1900;
        first.tm_mon = month;
        first.tm_mday = 1;
        first.tm_hour = 12;
        mktime(&first);
        char mb[64];
        strftime(mb, sizeof mb, "%B %Y", &first);
        head->add<Label>(mb, 18, Weight::DemiBold)->grow = 1;
        auto *prev = head->add<IconButton>("chevr", 32, 16);
        prev->icon->rotation.set(180);
        prev->onClick = [this] { if (--month < 0) { month = 11; year--; } conns.later([this] { build(); }); };
        auto *next = head->add<IconButton>("chevr", 32, 16);
        next->onClick = [this] { if (++month > 11) { month = 0; year++; } conns.later([this] { build(); }); };

        // ---- days ----
        auto *grid = col(this, 2);
        auto *names = row(grid, 2);
        for (const char *d : {"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"}) {
            auto *l = names->add<Label>(d, 12, Weight::Normal, Role::Text3);
            l->grow = 1;
            l->hAlign = Align::Center;
        }
        int lead = (first.tm_wday + 6) % 7;
        time_t now = time(nullptr);
        tm today;
        localtime_r(&now, &today);
        for (int r = 0; r < 6; r++) {
            auto *wk = row(grid, 2);
            for (int c = 0; c < 7; c++) {
                tm d = first;
                d.tm_mday = 1 - lead + r * 7 + c;
                mktime(&d);
                bool isToday = d.tm_year == today.tm_year && d.tm_yday == today.tm_yday;
                bool inMonth = d.tm_mon == month;
                auto *cell = wk->add<Box>(Dir::Row);
                cell->grow = 1;
                cell->fixedH = 34;
                cell->radius = 10;
                cell->justify = Justify::Center;
                if (isToday) cell->bg = t.accent;
                auto *l = cell->add<Label>(std::to_string(d.tm_mday), 13, isToday ? Weight::Bold : Weight::Normal,
                                           isToday ? Role::OnAccent : inMonth ? Role::Text : Role::Text3);
                l->fill = false;
            }
        }
        add<Separator>();

        // ---- notifications ----
        auto *nh = row(this, 10);
        nh->add<Label>("Notifications", 15, Weight::DemiBold)->grow = 1;
        nh->add<Label>("Do not disturb", 13, Weight::Normal, Role::Text2)->fill = false;
        auto *dnd = nh->add<Toggle>(cfg().b("dnd", false));
        dnd->onToggled = [](bool v) { cfg().set("dnd", v); };

        auto groups = N.groups();
        if (groups.empty()) {
            auto *l = add<Label>("You're all caught up", 13, Weight::Normal, Role::Text3);
            l->hAlign = Align::Center;
            l->mt = l->mb = 24;
        } else {
            auto *sv = add<ScrollView>();
            sv->maxH = 360;
            auto *list = sv->add<Box>(Dir::Column, 8);
            bool grouping = cfg().b("groupNotifications", true);
            for (auto &g : groups) {
                bool many = grouping && g.items.size() > 1;
                bool isOpen = g.items.size() <= 2 || open.count(g.key);
                auto *gb = col(list, 6);
                if (many) {
                    auto *gh = row(gb, 6);
                    gh->add<Label>(g.name, 12, Weight::DemiBold, Role::Text2)->grow = 1;
                    auto *more = gh->add<Label>(isOpen ? "Show less" : std::to_string(g.items.size() - 1) + " more", 12, Weight::Normal, Role::Accent);
                    more->fill = false;
                    more->interactive = true;
                    more->cursor = Cursor::Pointer;
                    std::string key = g.key;
                    more->onClick = [this, key] {
                        if (open.count(key)) open.erase(key); else open.insert(key);
                        conns.later([this] { build(); });
                    };
                }
                size_t shownN = isOpen ? g.items.size() : 1;
                for (size_t i = 0; i < shownN; i++) notificationCard(gb, *g.items[i], false);
            }
            auto *clr = add<TextButton>("Clear all");
            clr->fill = false;
            clr->alignSelf = Align::End;
            clr->fixedH = 32;
            clr->radius = 11;
            clr->bg = t.surface3;
            clr->onClick = [] { Loop::get().defer([] { Notifications::get().clearAll(); }); };
        }
        relayout();
    }
};

std::unique_ptr<Widget> makeNotificationCentre(Screen *s) {
    return std::make_unique<NotificationCentre>(s);
}

}  // namespace nova
