// Bottom panel: launcher, pinned + running apps, then capture countdown, clipboard,
// lock keys, tray, status (network, volume, battery) and the clock.
#pragma once
#include "common.hpp"
#include "shell.hpp"

namespace nova {

class Panel : public ui::LayerWindow {
public:
    explicit Panel(Screen *s);
    ~Panel() override;
    Screen *screen;
    ui::Rect clockRect() const;          // window coordinates
private:
    ui::Box *apps_ = nullptr, *right_ = nullptr;
    PanelButton *launcherBtn_ = nullptr, *clipBtn_ = nullptr;
    Pill *countdown_ = nullptr, *locks_ = nullptr, *tray_ = nullptr, *status_ = nullptr, *clock_ = nullptr;
    ui::Label *countdownL_ = nullptr, *time_ = nullptr, *date_ = nullptr, *badgeL_ = nullptr;
    ui::IconW *capsI_ = nullptr, *numI_ = nullptr, *netI_ = nullptr, *volI_ = nullptr;
    BatteryW *battery_ = nullptr;
    ui::Box *badge_ = nullptr, *rec_ = nullptr;
    MusicBars *bars_ = nullptr;
    Visualizer *viz_ = nullptr;
    Connections conns_;
    std::string appsKey_;      // what the app buttons show (skip rebuilding when nothing changed)
    int clockTimer_ = 0;
    void build();
    void rebuildApps();
    void rebuildTray();
    void refresh();
    void refreshClock();
};

}  // namespace nova
