#!/usr/bin/env bash
# Nova installer for Fedora 43+.
#
# Normal use (one line, finds the newest Nova-*-source.zip on GitHub):
#   command -v unzip >/dev/null || sudo dnf install -y unzip; z=$(curl -fsSL https://api.github.com/repos/cache-byte/Nova-desktop-environment/contents | grep -oE 'Nova-[0-9.]+-source\.zip' | sort -uV | tail -1); d=$(mktemp -d); curl -fL -o "$d/nova.zip" "https://raw.githubusercontent.com/cache-byte/Nova-desktop-environment/main/$z" && unzip -q "$d/nova.zip" -d "$d/src" && bash "$d/src/install.sh"
#
# From an unzipped source folder:
#   ./install.sh              install or reinstall everything
#   ./install.sh --deps       only install packages
#   ./install.sh --yes        don't ask questions (used by nova-update)
#   ./install.sh --ci         packages + build only, no system changes (GitHub Actions)
#   ./install.sh --as-user U  run as root on behalf of user U (Settings' updater, via pkexec)
#
# Everything this script adds or changes is written to /var/lib/nova/manifest
# so nova-uninstall can put the system back exactly as it was.
# The full output of every step goes to a log file (shown at the end).
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
HERE=$PWD

PREFIX=/usr
STATE=/var/lib/nova
MANIFEST=$STATE/manifest
BACKUPS=$STATE/backup
VERSION=$(cat VERSION 2>/dev/null || echo 0.0.0)

DEPS_ONLY=0; NO_SDDM=0; YES=0; CI=0; FOR_USER=""
while [ $# -gt 0 ]; do
    case "$1" in
        --deps) DEPS_ONLY=1 ;;
        --yes|-y|--update) YES=1 ;;
        --ci) CI=1; YES=1; NO_SDDM=1 ;;
        --as-user) FOR_USER="${2:?}"; YES=1; shift ;;
        -h|--help) sed -n '2,18p' "$0"; exit 0 ;;
        *) echo "unknown option: $1" >&2; exit 2 ;;
    esac
    shift
done

# shellcheck source=session/nova-ui.sh
. "$HERE/session/nova-ui.sh"

# --------------------------------------------------------------- helpers --
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo"; fi
if [ "$(id -u)" -eq 0 ] && [ "$CI" -eq 0 ] && [ -z "$FOR_USER" ]; then
    echo "Run install.sh as your normal user (it asks for your password when needed)." >&2
    exit 1
fi
# run something as the person Nova is for (flatpak --user etc.)
as_user() { if [ -n "$FOR_USER" ]; then runuser -u "$FOR_USER" -- env HOME="$(getent passwd "$FOR_USER" | cut -d: -f6)" "$@"; else "$@"; fi; }

ask() { # ask "question" -> 0 for yes
    [ "$YES" -eq 1 ] && return 0
    local r; printf '\n   %s?%s %s %s[Y/n]%s ' "$C_ACC" "$C_R" "$1" "$C_DIM" "$C_R"
    read -r r </dev/tty || true
    [[ -z "$r" || "$r" =~ ^[Yy] ]]
}
have_pkg() { rpm -q "$1" >/dev/null 2>&1; }
need() { "$@" || { ui_box "Nova couldn't be installed" "A required step failed (see above)." "Full log: $NOVA_LOG" "Fix the problem and run the installer again."; exit 1; }; }

# Manifest lines:  file <path> | backup <orig> <copy> | dm <unit> | pkg <name> | copr <repo> | flatpak <id> | version <v>
mf_has() { [ -f "$MANIFEST" ] && grep -qxF -- "$*" "$MANIFEST"; }
mf_add() {
    [ "$CI" -eq 1 ] && return 0
    mf_has "$*" || echo "$*" | $SUDO tee -a "$MANIFEST" >/dev/null
}
backup_once() { # keep the true original from the first install
    local f="$1"
    [ "$CI" -eq 1 ] && return 0
    grep -q "^backup $f " "$MANIFEST" 2>/dev/null && return 0
    if [ -e "$f" ]; then
        $SUDO install -D -m 600 "$f" "$BACKUPS$f"
        mf_add "backup $f $BACKUPS$f"
    else
        mf_add "file $f"
    fi
}
put() { $SUDO install -Dm"$1" "$2" "$3"; mf_add "file $3"; }
put_tree() {
    local src="$1" dest="$2" f rel
    while IFS= read -r -d '' f; do
        rel="${f#"$src"/}"
        $SUDO install -Dm644 "$f" "$dest/$rel"
        mf_add "file $dest/$rel"
    done < <(find "$src" -type f -print0)
}
dnf_install() { # install, recording packages that weren't there before
    local new=() p
    for p in "$@"; do have_pkg "$p" || new+=("$p"); done
    [ ${#new[@]} -eq 0 ] && return 0
    $SUDO dnf install -y "${new[@]}" || return 1
    for p in "${new[@]}"; do have_pkg "$p" && mf_add "pkg $p"; done
    return 0
}
dnf_optional() { # install what exists, skip what doesn't
    local missing=() p
    for p in "$@"; do have_pkg "$p" || missing+=("$p"); done
    [ ${#missing[@]} -eq 0 ] && return 0
    if ! $SUDO dnf install -y --skip-unavailable "${missing[@]}"; then
        # one bad package (a conflict, say) fails the whole batch: try them one by one
        echo "-- batch failed; installing one at a time"
        for p in "${missing[@]}"; do $SUDO dnf install -y --skip-unavailable "$p" || echo "-- skipped $p"; done
    fi
    for p in "${missing[@]}"; do have_pkg "$p" && mf_add "pkg $p"; done
    return 0
}
in_repos() { have_pkg "$1" || dnf -q list --available "$1" >/dev/null 2>&1; }
# ffmpeg from RPM Fusion conflicts with Fedora's ffmpeg-free: use whichever is there
ffmpeg_pkg() { if have_pkg ffmpeg || command -v ffmpeg >/dev/null; then :; else echo ffmpeg-free; fi; }
wlroots_pkg() {
    local p; for p in wlroots0.19-devel wlroots-devel wlroots0.20-devel wlroots0.18-devel; do
        in_repos "$p" && dnf_install "$p" && return 0
    done; return 1
}
dnf_plugins() { $SUDO dnf install -y dnf5-plugins || $SUDO dnf install -y dnf-plugins-core || true; }

# ------------------------------------------------------------------ start --
if [ "$DEPS_ONLY" -eq 1 ]; then ui_steps 3; elif [ "$CI" -eq 1 ]; then ui_steps 4; else ui_steps 8; fi
ui_banner "installer" "$VERSION"

ui_step "Checking your system"
. /etc/os-release 2>/dev/null || true
if [ "${ID:-}" = fedora ]; then ui_ok "${PRETTY_NAME:-Fedora}"; else ui_warn "Written for Fedora (found ${PRETTY_NAME:-unknown}); continuing anyway"; fi
if [ "${VERSION_ID:-0}" != rawhide ] && [ "${VERSION_ID:-0}" -lt 43 ] 2>/dev/null; then
    ui_warn "Fedora ${VERSION_ID} is older than 43; some packages may be missing"
fi
if lspci 2>/dev/null | grep -qi nvidia; then
    if lsmod | grep -q '^nvidia'; then
        ui_ok "NVIDIA driver loaded"
        [ "$(cat /sys/module/nvidia_drm/parameters/modeset 2>/dev/null)" = Y ] \
            || ui_warn "NVIDIA modesetting is off — run: sudo grubby --update-kernel=ALL --args=nvidia-drm.modeset=1"
    elif lsmod | grep -q '^nouveau'; then
        ui_ok "NVIDIA GPU on the open nouveau/NVK driver"
    fi
    dnf repolist 2>/dev/null | grep -qi rpmfusion || ui_info "RPM Fusion isn't enabled (needed for the NVIDIA driver): rpmfusion.org/Howto/NVIDIA"
fi

if [ "$CI" -eq 0 ]; then
    if [ -n "$SUDO" ]; then ui_info "Your password is needed to install system files"; need ui_sudo_keepalive; fi
    $SUDO install -d -m 755 "$STATE" "$BACKUPS"
    $SUDO touch "$MANIFEST"
fi
# ---- leftovers from a different desktop that was also called Nova ----
# Its config would be read by this Nova (no shell = black screen) and its programs in
# /usr/local/bin would run instead of ours. Nothing is deleted: it is moved aside.
if [ "$CI" -eq 0 ]; then
    UHOME=$(as_user sh -c 'echo "$HOME"'); STAMP=$(date +%Y%m%d-%H%M%S); OLD=/var/lib/nova/old-$STAMP
    moved=()
    if [ -f "$UHOME/.config/nova/nova.conf" ] && ! head -1 "$UHOME/.config/nova/nova.conf" | grep -q '^# Nova compositor configuration'; then
        as_user mv "$UHOME/.config/nova" "$UHOME/.config/nova.old-$STAMP" && moved+=("~/.config/nova → ~/.config/nova.old-$STAMP")
    fi
    if [ -e "$UHOME/.config/quickshell/nova" ]; then
        as_user mv "$UHOME/.config/quickshell/nova" "$UHOME/.config/quickshell/nova.old-$STAMP" && moved+=("~/.config/quickshell/nova → nova.old-$STAMP")
    fi
    for f in /usr/local/bin/nova /usr/local/bin/novactl /usr/local/bin/nova-* /usr/local/share/wayland-sessions/nova*.desktop \
             /usr/share/xsessions/nova*.desktop /usr/local/share/applications/nova*.desktop; do
        [ -e "$f" ] || continue
        $SUDO mkdir -p "$OLD" && $SUDO mv "$f" "$OLD/" && moved+=("$f → $OLD/")
    done
    for f in /usr/share/wayland-sessions/*.desktop; do   # another session file that also says Nova
        [ -f "$f" ] && [ "$(basename "$f")" != nova.desktop ] && grep -qiE '^Name=Nova\s*$' "$f" || continue
        $SUDO mkdir -p "$OLD" && $SUDO mv "$f" "$OLD/" && moved+=("$f → $OLD/")
    done
    if [ ${#moved[@]} -gt 0 ]; then
        ui_warn "Moved aside leftovers from an older Nova:"
        for m in "${moved[@]}"; do ui_info "  $m"; done
    fi
fi
ui_info "Log: $NOVA_LOG"

# ------------------------------------------------------------- packages --
ui_step "Installing packages"
ui_task "Package manager plugins" dnf_plugins
need ui_task "Build tools and libraries" dnf_install \
    gcc-c++ meson ninja-build cmake pkgconf-pkg-config unzip curl git python3 \
    wayland-devel wayland-protocols-devel libxkbcommon-devel libinput-devel pixman-devel libdrm-devel \
    libxcb-devel xcb-util-wm-devel qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtsvg
need ui_task "wlroots" wlroots_pkg
need ui_task "Desktop services" dnf_install \
    xorg-x11-server-Xwayland xdg-desktop-portal xdg-desktop-portal-wlr xdg-desktop-portal-gtk \
    grim slurp wl-clipboard brightnessctl playerctl wireplumber \
    NetworkManager bluez upower swayidle wlr-randr libnotify gnome-keyring
ui_task "Themes, fonts and extras" dnf_optional \
    qt6-qtmultimedia pipewire-utils cliphist gammastep polkit-gnome switcheroo-control \
    adw-gtk3-theme qt6ct qadwaitadecorations-qt6 papirus-icon-theme rsms-inter-fonts jetbrains-mono-fonts-all \
    fd-find plocate libqalculate cava gamemode mangohud gnome-software pavucontrol satty $(ffmpeg_pkg)
have_pkg polkit-gnome || ui_task "Password prompts (polkit agent)" dnf_optional polkit-kde
have_pkg power-profiles-daemon || ui_task "Power profiles (tuned-ppd)" dnf_optional tuned-ppd

if [ "$CI" -eq 0 ]; then
    ui_step "Shell, recorder and extras"
    copr() { $SUDO dnf copr enable -y "$1" && mf_add "copr $1"; }
    if ! { in_repos quickshell && ui_task "Quickshell (Fedora)" dnf_install quickshell; }; then
        ui_task "Quickshell repository (COPR)" copr errornointernet/quickshell || true
        need ui_task "Quickshell (COPR)" dnf_install quickshell
    fi
    if ! { in_repos gpu-screen-recorder && ui_task "Screen recorder (Fedora)" dnf_install gpu-screen-recorder; }; then
        ui_task "Screen recorder repository (COPR)" copr brycensranch/gpu-screen-recorder-git \
            && { ui_task "Screen recorder (COPR)" dnf_install gpu-screen-recorder || true; }
        have_pkg gpu-screen-recorder || { ui_warn "gpu-screen-recorder unavailable — using wf-recorder (no instant replay)"; ui_task "wf-recorder" dnf_optional wf-recorder; }
    fi
    songrec_flatpak() {
        command -v flatpak >/dev/null || return 1
        as_user flatpak remote-add --user --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo \
            && as_user flatpak install --user -y flathub com.github.marinm.songrec
    }
    if ! { in_repos songrec && ui_task "SongRec (Fedora)" dnf_install songrec; }; then
        if ui_task "SongRec (Flathub)" songrec_flatpak; then mf_add "flatpak com.github.marinm.songrec"
        else ui_warn "SongRec not installed — lyrics are still found by title"; fi
    fi
    if [ ! -d /usr/share/icons/Bibata-Modern-Classic ]; then
        get_bibata() {
            local t rc; t=$(mktemp -d)
            curl -fsSL -o "$t/b.tar.xz" https://github.com/ful1e5/Bibata_Cursor/releases/latest/download/Bibata-Modern-Classic.tar.xz \
                && $SUDO tar -xJf "$t/b.tar.xz" -C /usr/share/icons; rc=$?; rm -rf "$t"; return $rc
        }
        if ui_task "Bibata Modern Classic cursor" get_bibata; then mf_add "dir /usr/share/icons/Bibata-Modern-Classic"
        else ui_warn "Couldn't download the Bibata cursor; pick another one in Settings"; fi
    else
        ui_ok "Bibata Modern Classic cursor"
    fi
fi
if [ "$DEPS_ONLY" -eq 1 ]; then ui_box "Packages are installed" "Full log: $NOVA_LOG"; exit 0; fi

# ---------------------------------------------------------------- build --
ui_step "Building the compositor"
$SUDO rm -rf build
need ui_task "Configuring" meson setup build/compositor compositor --prefix=$PREFIX --buildtype=release
need ui_task "Compiling" ninja -C build/compositor
ui_step "Building Settings"
need ui_task "Configuring" cmake -S settings -B build/settings -G Ninja -DCMAKE_INSTALL_PREFIX=$PREFIX -DCMAKE_BUILD_TYPE=Release
need ui_task "Compiling" ninja -C build/settings
if [ "$CI" -eq 1 ]; then ui_box "Build finished" "Compositor and Settings compiled on ${PRETTY_NAME:-Fedora}"; exit 0; fi

# -------------------------------------------------------------- install --
ui_step "Installing Nova"
need ui_task "Compositor" $SUDO meson install -C build/compositor --no-rebuild --quiet
need ui_task "Settings app" $SUDO cmake --install build/settings
for f in $(sed -n 's/^\(\/.*\)$/\1/p' build/compositor/meson-logs/install-log.txt 2>/dev/null) \
         $(cat build/settings/install_manifest.txt 2>/dev/null); do
    mf_add "file $f"
done
install_shell() {
    $SUDO rm -rf $PREFIX/share/nova/shell
    put_tree shell        $PREFIX/share/nova/shell
    put_tree assets/qt6ct $PREFIX/share/nova/qt6ct
    put 644 VERSION       $PREFIX/share/nova/VERSION
    put 644 CHANGELOG.md  $PREFIX/share/nova/CHANGELOG.md
    put 644 session/nova-ui.sh $PREFIX/share/nova/ui.sh
    local s
    for s in nova-session nova-shell nova-power nova-polkit-agent nova-doctor nova-theme nova-gpu nova-update nova-uninstall nova-lyrics nova-record; do
        [ -f "session/$s" ] && put 755 "session/$s" "$PREFIX/bin/$s"
    done
    put 644 session/nova.desktop        $PREFIX/share/wayland-sessions/nova.desktop
    put 644 session/nova-portals.conf   $PREFIX/share/xdg-desktop-portal/nova-portals.conf
    put 644 session/nova-update.desktop $PREFIX/share/applications/nova-update.desktop
    put 755 session/nova-install-root   $PREFIX/libexec/nova/nova-install-root
    put 644 assets/polkit/org.nova.update.policy $PREFIX/share/polkit-1/actions/org.nova.update.policy
    backup_once /etc/pam.d/nova-lock
    $SUDO install -Dm644 shell/pam/nova-lock /etc/pam.d/nova-lock
}
need ui_task "Shell, tools and wallpapers" install_shell

# ------------------------------------------------------------ login screen --
# Nova uses the login screen you already have (GDM, SDDM, LightDM...): it only adds
# "Nova" to its session list. Older Nova versions switched to SDDM; that is undone here.
ui_step "Login screen"
undo_sddm() {
    local prev f copy
    prev=$(sed -n 's/^dm //p' "$MANIFEST" | head -1)
    if [ -n "$prev" ]; then
        $SUDO systemctl disable sddm.service 2>/dev/null || true
        $SUDO systemctl enable --force "$prev" || return 1
        $SUDO sed -i '/^dm /d' "$MANIFEST"
    fi
    for f in /etc/sddm.conf.d/10-nova.conf /etc/pam.d/sddm; do
        copy=$(sed -n "s#^backup $f ##p" "$MANIFEST" | head -1)
        if [ -n "$copy" ] && [ -f "$copy" ]; then $SUDO install -m 644 "$copy" "$f"
        elif grep -qx "file $f" "$MANIFEST"; then $SUDO rm -f "$f"; fi
        $SUDO sed -i "\#^backup $f #d; \#^file $f\$#d" "$MANIFEST"
    done
    $SUDO rm -f /etc/sddm.conf.d/10-nova.conf
    $SUDO rm -rf $PREFIX/share/sddm/themes/nova
    $SUDO sed -i '\#^file '"$PREFIX"'/share/sddm/themes/nova/#d' "$MANIFEST"
    return 0
}
LOGIN_NOTE="Log out and pick \"Nova\" in your login screen's session menu."
if [ "$CI" -eq 0 ]; then
    if grep -q '^dm ' "$MANIFEST" 2>/dev/null || [ -d $PREFIX/share/sddm/themes/nova ]; then
        prev=$(sed -n 's/^dm //p' "$MANIFEST" | head -1)
        if ui_task "Putting your previous login screen back${prev:+ (${prev%.service})}" undo_sddm; then
            LOGIN_NOTE="Reboot to get your previous login screen back, then pick Nova in its session menu."
        else
            ui_warn "Couldn't switch back; run: sudo systemctl enable --force ${prev:-gdm.service}"
        fi
    fi
    dm=$(readlink -e /etc/systemd/system/display-manager.service 2>/dev/null); dm=$(basename "${dm:-unknown}" .service)
    ui_ok "Login screen: $dm (Nova is in its session list)"
fi

# ----------------------------------------------------------------- finish --
ui_step "Finishing"
ui_task "Hybrid graphics helper" sh -c "${SUDO:+sudo }systemctl enable --now switcheroo-control.service || true"
ui_task "File search index" sh -c "${SUDO:+sudo }systemctl enable plocate-updatedb.timer || true"
# a wallpaper that was bundled before but is gone now: fall back to the default
fix_wallpaper() {
    local f; f="$(as_user sh -c 'echo $HOME')/.config/nova/settings.json"
    [ -f "$f" ] || return 0
    as_user python3 - "$f" <<'PY'
import json, os, sys
p = sys.argv[1]
try: s = json.load(open(p))
except Exception: sys.exit(0)
w = s.get("wallpaper") or ""
if w.startswith("/usr/share/nova/shell/assets/wallpapers/") and not os.path.exists(w):
    s["wallpaper"] = ""
    json.dump(s, open(p, "w"), indent=2)
PY
}
ui_task "Wallpaper" fix_wallpaper || true
$SUDO sed -i '/^version /d' "$MANIFEST"
echo "version $VERSION" | $SUDO tee -a "$MANIFEST" >/dev/null

ui_box "Nova $VERSION is installed" \
    "$LOGIN_NOTE" \
    "Try it inside this desktop first:   nova -s nova-shell" \
    "Check everything inside Nova:       nova-doctor" \
    "Update: nova-update      Remove: nova-uninstall" \
    "Full log: $NOVA_LOG"
