# Dusk

A calm, practical desktop for Linux. Since 1.0, Dusk runs on KDE Plasma and
KWin (window handling, games, sleep, screens, the tray, notifications) with
Dusk's own panel, Control Centre, icons and colours on top.

## What's new in 1.0.2

- **Updating from the old Dusk's Settings finishes:** 1.0.1 removed the old Dusk Settings halfway through, and it was the window asking for your password, so step 4 stopped. The old Dusk is now removed at the very end, and running the install again finishes a move that stopped halfway.

## What's new in 1.0.1

- **The install no longer stops at the first step:** Dusk asked for power-profiles-daemon, which can't be installed next to Fedora's tuned-ppd, so dnf refused everything. Dusk now uses whichever one you have, through its standard interface.
- **Much smaller:** only KWin and the Plasma parts Dusk uses (the panel engine, power, Wi-Fi and Bluetooth prompts, sound, screens, the lock screen, portals, password prompts and System Settings) instead of the whole KDE desktop and its apps.
- **Clearer errors:** if a package can't be installed, the message says why.

## What's new in 1.0.0

- **Dusk is built on KDE Plasma and KWin:** KDE's tested window handling replaces Dusk's own compositor. Full-screen games, focus, controllers, sleep, NVIDIA, HDR and variable refresh rate behave as they do on KDE, and the tray, notifications, volume keys and Wi-Fi password prompts are KDE's.
- **The Dusk Control Centre:** a status pill in the panel (scroll it for volume, middle-click to mute) opens Wi-Fi and Bluetooth, airplane mode, dark mode, night light, Do not disturb, stay awake and screenshot, tall sliders for brightness, volume and the microphone, the battery with the three power modes, and what's playing.
- **Dusk icons for every app:** rounded, coloured icons with a symbol for what each app does; apps without one get a fitting icon made for them (games a gamepad, browsers a globe…), and new apps get one at the next login. Games keep their own art.
- **Dusk Dark and Dusk Light:** GNOME's greys, the accent from the wallpaper.
- **One floating panel:** the app menu, show desktop, your apps, the workspaces, the tray, the Control Centre and the clock.
- **Moving over from the old Dusk:** light or dark, the accent, the wallpaper, your keyboard shortcuts and the apps pinned to your panel come along; the old compositor and its helpers are removed. "Dusk" on the login screen now starts the new one.

## Install or update

From the old Dusk: Settings › About › Updates › "Install from a zip…", or

    cd /tmp && rm -rf dusk && unzip -oq ~/Downloads/Dusk-1.0.2-source.zip && ./dusk/build.sh install

Then log out and pick **Dusk** on the login screen. Later updates:
`dusk-update` (or `dusk-update --zip ~/Downloads/Dusk-X-source.zip`).
To remove Dusk: `dusk-uninstall` (Plasma stays).

## Credits

Dusk is made by **cache-byte** — design, ideas and testing — with code
written alongside Claude (Anthropic).

It stands on these projects; thank you:

- **KDE Plasma, KWin, Kirigami, Breeze and KDE Frameworks** (KDE e.V., GPL/LGPL) — the desktop underneath: window management, the panel engine, System Settings, the screen locker, KDE Connect. <https://kde.org>
- **Lucide** (ISC licence) — the line icons in the Control Centre and the symbols in Dusk's icons. <https://lucide.dev>
- **GNOME and libadwaita** — the grey palette and ideas from the GNOME Human Interface Guidelines. <https://developer.gnome.org/hig/>
- **Papirus** (GPL-3.0) — icons for everything Dusk's own set doesn't cover. <https://github.com/PapirusDevelopmentTeam/papirus-icon-theme>
- **PipeWire and WirePlumber**, **NetworkManager**, **BlueZ**, **power-profiles-daemon**, **playerctl**, **brightnessctl**, **systemd** — sound, networks, Bluetooth, power modes, media and brightness.
- **Fedora** — the system it's made and tested on.
- **wlroots and SceneFX** — the old Dusk (0.x) compositor was built on them.
- Ideas from **Samsung One UI** (the Control Centre), **Windows 11** and **macOS**.

Dusk is free software under the GPL-2.0-or-later.
