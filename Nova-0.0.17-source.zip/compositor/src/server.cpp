// Server setup, outputs, layer-shell, session lock and the "plug and play"
// protocols the shell and apps rely on.
#include <algorithm>
#include <cmath>
#include "ipc.hpp"
#include "server.hpp"

void create_xdg_view(Server *s, wlr_xdg_toplevel *t);
void create_popup(Server *s, wlr_xdg_popup *popup);
#ifdef NOVA_XWAYLAND
void create_xwayland_view(Server *s, wlr_xwayland_surface *xs);
#endif
void setup_input(Server *s);

static const float kSnapColor[4] = {0.78f * 0.22f, 0.71f * 0.22f, 0.29f * 0.22f, 0.22f};   // accent, premultiplied
static const float kBlack[4] = {0, 0, 0, 1};

wlr_box output_box(Server *s, Output *o) {
    wlr_box b{};
    wlr_output_layout_get_box(s->output_layout, o->output, &b);
    return b;
}

Output *Server::output_at(double lx, double ly) {
    wlr_output *o = wlr_output_layout_output_at(output_layout, lx, ly);
    if (!o) return nullptr;
    for (auto &out : outputs)
        if (out->output == o) return out.get();
    return nullptr;
}

Output *Server::focused_output() {
    Output *o = output_at(cursor->x, cursor->y);
    if (!o && !outputs.empty()) o = outputs.front().get();
    return o;
}

// ------------------------------------------------------------- layer shell --
void Server::arrange_layers(Output *out) {
    out->full = output_box(this, out);
    wlr_box usable = out->full;

    // Exclusive-zone surfaces first (panels), top-most layer first; then the rest.
    for (int pass = 0; pass < 2; pass++) {
        for (int layer = 3; layer >= 0; layer--) {
            for (LayerSurface *ls : layers) {
                if (ls->output != out || !ls->layer->initialized) continue;
                if ((int)ls->layer->current.layer != layer) continue;
                bool excl = ls->layer->current.exclusive_zone > 0;
                if ((pass == 0) != excl) continue;
                wlr_scene_layer_surface_v1_configure(ls->scene, &out->full, &usable);
                int px, py;
                wlr_scene_node_coords(&ls->scene->tree->node, &px, &py);
                wlr_scene_node_set_position(&ls->popups->node, px, py);
            }
        }
    }
    bool changed = memcmp(&usable, &out->usable, sizeof usable) != 0;
    out->usable = usable;

    if (out->lock_backdrop) {
        wlr_scene_rect_set_size(out->lock_backdrop, out->full.width, out->full.height);
        wlr_scene_node_set_position(&out->lock_backdrop->node, out->full.x, out->full.y);
    }

    if (changed) {
        for (View *v : views) {
            if (!v->mapped) continue;
            wlr_box g = v->geometry();
            if (output_at(v->x + g.width / 2.0, v->y + g.height / 2.0) != out) continue;
            if (v->maximized) v->set_maximized(true);
            else if (v->tile != View::Tile::None) v->set_tile(v->tile);
        }
    }

    // Keyboard: the top-most mapped exclusive surface on top/overlay grabs it.
    wlr_layer_surface_v1 *topmost = nullptr;
    for (int layer = 3; layer >= 2 && !topmost; layer--) {
        for (LayerSurface *ls : layers) {
            wlr_layer_surface_v1 *l = ls->layer;
            if ((int)l->current.layer == layer && l->surface->mapped &&
                l->current.keyboard_interactive == ZWLR_LAYER_SURFACE_V1_KEYBOARD_INTERACTIVITY_EXCLUSIVE) {
                topmost = l;
                break;
            }
        }
    }
    if (topmost && !locked) {
        if (exclusive_layer != topmost) {
            if (View *f = focused_view()) f->set_activated(false);
            exclusive_layer = topmost;
            focused_layer = topmost->surface;
            focus_surface(topmost->surface);
        }
    } else if (exclusive_layer) {
        exclusive_layer = nullptr;
        focused_layer = nullptr;
        focus_top_view();
    }
}

void Server::arrange_all() {
    for (auto &o : outputs) arrange_layers(o.get());
}

static void create_layer_surface(Server *s, wlr_layer_surface_v1 *l) {
    if (!l->output) {
        Output *o = s->focused_output();
        if (!o) {
            wlr_layer_surface_v1_destroy(l);
            return;
        }
        l->output = o->output;
    }
    auto *ls = new LayerSurface{};
    ls->server = s;
    ls->layer = l;
    for (auto &o : s->outputs)
        if (o->output == l->output) ls->output = o.get();
    ls->scene = wlr_scene_layer_surface_v1_create(s->layer_trees[l->pending.layer], l);
    ls->scene->tree->node.data = &ls->tag;
    ls->popups = wlr_scene_tree_create(s->popup_tree);
    ls->popups->node.data = &ls->tag;
    l->data = ls;
    s->layers.push_back(ls);

    ls->commit.connect(&l->surface->events.commit, [ls](void *) {
        wlr_layer_surface_v1 *l = ls->layer;
        Server *s = ls->server;
        if (!ls->output) return;
        if (ls->configured && l->current.committed == 0) return;
        ls->configured = true;
        // Layer changed (e.g. bottom -> top)?
        wlr_scene_tree *want = s->layer_trees[l->current.layer];
        if (ls->scene->tree->node.parent != want) wlr_scene_node_reparent(&ls->scene->tree->node, want);
        s->arrange_layers(ls->output);
    });
    ls->new_popup.connect(&l->events.new_popup,
                          [s](void *d) { create_popup(s, static_cast<wlr_xdg_popup *>(d)); });
    ls->map.connect(&l->surface->events.map, [ls](void *) {
        if (ls->output) ls->server->arrange_layers(ls->output);
    });
    ls->unmap.connect(&l->surface->events.unmap, [ls](void *) {
        Server *s = ls->server;
        if (s->focused_layer == ls->layer->surface) s->focused_layer = nullptr;
        if (s->exclusive_layer == ls->layer) s->exclusive_layer = nullptr;
        if (s->seat->keyboard_state.focused_surface == ls->layer->surface) s->focus_top_view();
        if (ls->output) s->arrange_layers(ls->output);
    });
    ls->destroy.connect(&l->events.destroy, [ls](void *) {
        Server *s = ls->server;
        Output *o = ls->output;
        s->layers.remove(ls);
        if (s->exclusive_layer == ls->layer) s->exclusive_layer = nullptr;
        wlr_scene_node_destroy(&ls->popups->node);
        delete ls;
        if (o) s->arrange_layers(o);
    });
}

// ------------------------------------------------------------------ output --
void Server::add_output(wlr_output *wo) {
    wlr_output_init_render(wo, allocator, renderer);

    // Mode, scale and rotation: what Settings > Display saved, else the screen's preferred
    // mode and 100 % unless the screen is very high resolution.
    const OutputCfg *oc = config.output_cfg(wo->name);
    wlr_output_state st;
    wlr_output_state_init(&st);
    wlr_output_state_set_enabled(&st, true);
    wlr_output_mode *mode = wlr_output_preferred_mode(wo);
    if (oc && oc->width > 0) {
        wlr_output_mode *m, *best = nullptr;
        wl_list_for_each(m, &wo->modes, link) {
            if (m->width != oc->width || m->height != oc->height) continue;
            if (!best || std::abs(m->refresh / 1000.0 - oc->refresh) < std::abs(best->refresh / 1000.0 - oc->refresh)) best = m;
        }
        if (best) mode = best;
    }
    if (mode) wlr_output_state_set_mode(&st, mode);
    double scale = 1.0;
    if (oc && oc->scale > 0) scale = oc->scale;
    else if (mode && wo->phys_width > 0) {
        double dpi = mode->width / (wo->phys_width / 25.4);
        // only real HiDPI panels are scaled; ordinary 1080p laptops (~140 dpi) stay at 100 %
        scale = dpi >= 230 ? 2.0 : dpi >= 190 ? 1.5 : dpi >= 165 ? 1.25 : 1.0;
    }
    wlr_output_state_set_scale(&st, (float)scale);
    if (oc && !oc->transform.empty()) {
        static const std::pair<const char *, wl_output_transform> tr[] = {
            {"normal", WL_OUTPUT_TRANSFORM_NORMAL}, {"90", WL_OUTPUT_TRANSFORM_90}, {"180", WL_OUTPUT_TRANSFORM_180},
            {"270", WL_OUTPUT_TRANSFORM_270}, {"flipped", WL_OUTPUT_TRANSFORM_FLIPPED},
            {"flipped-90", WL_OUTPUT_TRANSFORM_FLIPPED_90}, {"flipped-180", WL_OUTPUT_TRANSFORM_FLIPPED_180},
            {"flipped-270", WL_OUTPUT_TRANSFORM_FLIPPED_270}};
        for (auto &t : tr) if (oc->transform == t.first) wlr_output_state_set_transform(&st, t.second);
    }
    if (!wlr_output_commit_state(wo, &st)) {
        // saved mode not accepted (new cable, different monitor): fall back to defaults
        wlr_output_state_finish(&st);
        wlr_output_state_init(&st);
        wlr_output_state_set_enabled(&st, true);
        if (wlr_output_mode *m = wlr_output_preferred_mode(wo)) wlr_output_state_set_mode(&st, m);
        wlr_output_commit_state(wo, &st);
    }
    wlr_output_state_finish(&st);

    auto out = std::make_unique<Output>();
    Output *o = out.get();
    o->server = this;
    o->output = wo;
    // take the lowest free workspace slot; its first workspace is shown
    for (int sl = 0; sl < kMaxOutputs; sl++) {
        bool used = false;
        for (auto &x : outputs) used |= x->slot == sl;
        if (!used) { o->slot = sl; break; }
    }
    o->active = o->slot * kWsPerOutput;
    wlr_scene_node_set_enabled(&ws_trees[o->active]->node, true);

    o->frame.connect(&wo->events.frame, [this, o](void *) {
        wlr_scene_output *so = o->scene_output;
        if (o->gamma_dirty) {
            o->gamma_dirty = false;
            wlr_output_state st;
            wlr_output_state_init(&st);
            wlr_gamma_control_v1 *ctl = wlr_gamma_control_manager_v1_get_control(gamma, o->output);
            if (wlr_gamma_control_v1_apply(ctl, &st) && wlr_scene_output_build_state(so, &st, nullptr)) {
                if (!wlr_output_commit_state(o->output, &st) && ctl)
                    wlr_gamma_control_v1_send_failed_and_destroy(ctl);
            }
            wlr_output_state_finish(&st);
        } else {
            // Fullscreen games get VRR and, if allowed, tearing page flips.
            View *fs = o->server->fullscreen_view_on(o);
            bool want_vrr = config.vrr && fs && o->output->adaptive_sync_supported;
            bool tear = false;
            if (fs && config.tearing != "never") {
                tear = config.tearing == "always";
                if (tearing && wlr_tearing_control_manager_v1_surface_hint_from_surface(tearing, fs->surface()) ==
                                   WP_TEARING_CONTROL_V1_PRESENTATION_HINT_ASYNC)
                    tear = true;
#ifdef NOVA_XWAYLAND
                if (config.tearing == "auto" && fs->kind == View::Kind::XWayland) tear = true;   // Proton / Wine games
#endif
            }
            if (want_vrr == o->vrr_on && !tear) {
                wlr_scene_output_commit(so, nullptr);
            } else {
                wlr_output_state st;
                wlr_output_state_init(&st);
                if (want_vrr != o->vrr_on) wlr_output_state_set_adaptive_sync_enabled(&st, want_vrr);
                if (wlr_scene_output_build_state(so, &st, nullptr)) {
                    st.tearing_page_flip = tear;
                    bool ok = wlr_output_commit_state(o->output, &st);
                    if (!ok && tear) { st.tearing_page_flip = false; ok = wlr_output_commit_state(o->output, &st); }
                    if (ok) o->vrr_on = want_vrr;
                    else o->vrr_on = o->output->adaptive_sync_status == WLR_OUTPUT_ADAPTIVE_SYNC_ENABLED;
                }
                wlr_output_state_finish(&st);
            }
        }
        timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        wlr_scene_output_send_frame_done(so, &now);
    });
    o->request_state.connect(&wo->events.request_state, [o](void *data) {
        auto *e = static_cast<wlr_output_event_request_state *>(data);
        wlr_output_commit_state(o->output, e->state);
        o->server->arrange_layers(o);
    });
    o->destroy.connect(&wo->events.destroy, [this, o](void *) {
        // Layer surfaces on this output have nowhere to go.
        std::vector<LayerSurface *> doomed;
        for (LayerSurface *ls : layers)
            if (ls->output == o) doomed.push_back(ls);
        for (LayerSurface *ls : doomed) {
            ls->output = nullptr;
            wlr_layer_surface_v1_destroy(ls->layer);
        }
        if (o->lock_backdrop) wlr_scene_node_destroy(&o->lock_backdrop->node);
        // Windows on the unplugged monitor move to the remaining one (nothing gets lost).
        for (int i = 0; i < kWsPerOutput; i++) wlr_scene_node_set_enabled(&ws_trees[o->slot * kWsPerOutput + i]->node, false);
        Output *dest = nullptr;
        for (auto &x : outputs) if (x.get() != o) { dest = x.get(); break; }
        if (dest) {
            std::vector<View *> orphans;
            for (View *v : views) if (v->workspace / kWsPerOutput == o->slot) orphans.push_back(v);
            for (View *v : orphans) {
                int to = dest->slot * kWsPerOutput + ws_index(v->workspace);
                move_to_workspace(v, to);
            }
        }
        Server *srv = this;
        Output *victim = o;
        srv->outputs.remove_if([victim](const std::unique_ptr<Output> &x) { return x.get() == victim; });
        srv->update_output_manager();
    });

    wlr_output_layout_output *lo = oc && oc->has_pos ? wlr_output_layout_add(output_layout, wo, oc->x, oc->y)
                                                     : wlr_output_layout_add_auto(output_layout, wo);
    o->scene_output = wlr_scene_output_create(scene, wo);
    wlr_scene_output_layout_add_output(scene_layout, lo, o->scene_output);

    o->lock_backdrop = wlr_scene_rect_create(lock_tree, 1, 1, kBlack);
    wlr_scene_node_lower_to_bottom(&o->lock_backdrop->node);
    wlr_scene_node_set_enabled(&o->lock_backdrop->node, locked);

    outputs.push_back(std::move(out));
    arrange_layers(o);
    update_output_manager();
}

void Server::update_output_manager() {
    wlr_output_configuration_v1 *cfg = wlr_output_configuration_v1_create();
    for (auto &o : outputs) {
        wlr_output_configuration_head_v1 *head = wlr_output_configuration_head_v1_create(cfg, o->output);
        wlr_box b = output_box(this, o.get());
        head->state.x = b.x;
        head->state.y = b.y;
    }
    wlr_output_manager_v1_set_configuration(output_manager, cfg);
}

void Server::apply_output_config(wlr_output_configuration_v1 *cfg, bool test_only) {
    bool ok = true;
    wlr_output_configuration_head_v1 *head;
    wl_list_for_each(head, &cfg->heads, link) {
        wlr_output *wo = head->state.output;
        wlr_output_state st;
        wlr_output_state_init(&st);
        wlr_output_state_set_enabled(&st, head->state.enabled);
        if (head->state.enabled) {
            if (head->state.mode) wlr_output_state_set_mode(&st, head->state.mode);
            else
                wlr_output_state_set_custom_mode(&st, head->state.custom_mode.width, head->state.custom_mode.height,
                                                 head->state.custom_mode.refresh);
            wlr_output_state_set_scale(&st, std::clamp(head->state.scale, 1.0f, 2.0f));   // 100–200 %
            wlr_output_state_set_transform(&st, head->state.transform);
            wlr_output_state_set_adaptive_sync_enabled(&st, head->state.adaptive_sync_enabled);
        }
        ok &= test_only ? wlr_output_test_state(wo, &st) : wlr_output_commit_state(wo, &st);
        wlr_output_state_finish(&st);
        if (!test_only && ok) {
            if (head->state.enabled) wlr_output_layout_add(output_layout, wo, head->state.x, head->state.y);
            else wlr_output_layout_remove(output_layout, wo);   // the pointer can't wander onto a switched-off screen
        }
    }
    if (ok) wlr_output_configuration_v1_send_succeeded(cfg);
    else wlr_output_configuration_v1_send_failed(cfg);
    wlr_output_configuration_v1_destroy(cfg);
    if (!test_only) {
        arrange_all();
        update_output_manager();
    }
}

// ------------------------------------------------------------ session lock --
void Server::refresh_lock_backdrops() {
    for (auto &o : outputs)
        if (o->lock_backdrop) wlr_scene_node_set_enabled(&o->lock_backdrop->node, locked);
}

void Server::on_new_lock(wlr_session_lock_v1 *l) {
    if (lock) {   // already locked by another client
        wlr_session_lock_v1_destroy(l);
        return;
    }
    lock = l;
    locked = true;
    grab = Grab::None;
    if (View *f = focused_view()) f->set_activated(false);
    wlr_seat_keyboard_notify_clear_focus(seat);
    wlr_seat_pointer_notify_clear_focus(seat);
    exclusive_layer = nullptr;
    refresh_lock_backdrops();

    lock_new_surface.connect(&l->events.new_surface, [this](void *data) {
        auto *surf = static_cast<wlr_session_lock_surface_v1 *>(data);
        auto *ls = new LockSurface{};
        ls->surf = surf;
        ls->tree = wlr_scene_subsurface_tree_create(lock_tree, surf->surface);
        ls->tree->node.data = &ls->tag;
        wlr_box b{};
        wlr_output_layout_get_box(output_layout, surf->output, &b);
        wlr_scene_node_set_position(&ls->tree->node, b.x, b.y);
        wlr_session_lock_surface_v1_configure(surf, b.width, b.height);

        ls->map.connect(&surf->surface->events.map, [this, ls](void *) {
            Output *fo = focused_output();
            if (!seat->keyboard_state.focused_surface || (fo && fo->output == ls->surf->output))
                focus_surface(ls->surf->surface);
        });
        ls->destroy.connect(&surf->events.destroy, [ls](void *) { delete ls; });
    });
    lock_unlock.connect(&l->events.unlock, [this](void *) {
        locked = false;
        refresh_lock_backdrops();
        focus_top_view();
        arrange_all();
    });
    lock_destroy.connect(&l->events.destroy, [this](void *) {
        // If the locker crashed without unlocking we stay locked (black screen)
        // until a new locker connects: never fail open.
        lock = nullptr;
        lock_new_surface.disconnect();
        lock_unlock.disconnect();
        lock_destroy.disconnect();
    });

    wlr_session_lock_v1_send_locked(l);
}

// -------------------------------------------------------------------- init --
bool Server::init() {
    config.load();

    display = wl_display_create();
    loop = wl_display_get_event_loop(display);
    backend = wlr_backend_autocreate(loop, &session);
    if (!backend) {
        wlr_log(WLR_ERROR, "failed to create wlr_backend");
        return false;
    }
    renderer = wlr_renderer_autocreate(backend);
    if (!renderer) return false;
    wlr_renderer_init_wl_display(renderer, display);
    allocator = wlr_allocator_autocreate(backend, renderer);
    if (!allocator) return false;

    compositor = wlr_compositor_create(display, 5, renderer);
    wlr_subcompositor_create(display);
    wlr_data_device_manager_create(display);
    wlr_primary_selection_v1_device_manager_create(display);
    wlr_data_control_manager_v1_create(display);    // clipboard history (cliphist / shell)
    wlr_export_dmabuf_manager_v1_create(display);
    wlr_screencopy_manager_v1_create(display);      // screenshots, screen sharing via xdp-wlr
    wlr_viewporter_create(display);
    wlr_single_pixel_buffer_manager_v1_create(display);
    wlr_fractional_scale_manager_v1_create(display, 1);
#if NOVA_WLR_AT_LEAST(0, 19)
    wlr_presentation_create(display, backend, 2);
#else
    wlr_presentation_create(display, backend);
#endif

    output_layout = wlr_output_layout_create(display);
    wlr_xdg_output_manager_v1_create(display, output_layout);

    // Scene graph, bottom to top.
    scene = wlr_scene_create();
    scene_layout = wlr_scene_attach_output_layout(scene, output_layout);
    layer_trees[0] = wlr_scene_tree_create(&scene->tree);   // background (wallpaper, desktop icons)
    layer_trees[1] = wlr_scene_tree_create(&scene->tree);   // bottom
    views_root = wlr_scene_tree_create(&scene->tree);
    for (int i = 0; i < kWorkspaces; i++) {
        ws_trees[i] = wlr_scene_tree_create(views_root);
        wlr_scene_node_set_enabled(&ws_trees[i]->node, false);   // each output enables its own
    }
    snap_preview = wlr_scene_rect_create(views_root, 0, 0, kSnapColor);
    wlr_scene_node_set_enabled(&snap_preview->node, false);
    layer_trees[2] = wlr_scene_tree_create(&scene->tree);   // top (panel)
    layer_trees[3] = wlr_scene_tree_create(&scene->tree);   // overlay (launcher, OSD, notifications)
    popup_tree = wlr_scene_tree_create(&scene->tree);
    drag_tree = wlr_scene_tree_create(&scene->tree);
    lock_tree = wlr_scene_tree_create(&scene->tree);

    // Shells.
    xdg_shell = wlr_xdg_shell_create(display, 3);
    new_xdg_toplevel.connect(&xdg_shell->events.new_toplevel,
                             [this](void *d) { create_xdg_view(this, static_cast<wlr_xdg_toplevel *>(d)); });
    new_xdg_popup.connect(&xdg_shell->events.new_popup,
                          [this](void *d) { create_popup(this, static_cast<wlr_xdg_popup *>(d)); });

    layer_shell = wlr_layer_shell_v1_create(display, 4);
    new_layer_surface.connect(&layer_shell->events.new_surface, [this](void *d) {
        create_layer_surface(this, static_cast<wlr_layer_surface_v1 *>(d));
    });

    // Decorations: Nova apps draw their own (CSD); tell everyone so.
    wlr_server_decoration_manager_set_default_mode(wlr_server_decoration_manager_create(display),
                                                   WLR_SERVER_DECORATION_MANAGER_MODE_CLIENT);
    xdg_deco = wlr_xdg_decoration_manager_v1_create(display);
    new_deco.connect(&xdg_deco->events.new_toplevel_decoration, [](void *data) {
        auto *d = static_cast<wlr_xdg_toplevel_decoration_v1 *>(data);
        struct Deco {
            wlr_xdg_toplevel_decoration_v1 *d;
            Listener request, destroy, commit;
        };
        auto *deco = new Deco{d, {}, {}, {}};
        auto apply = [deco](void *) {
            if (deco->d->toplevel->base->initialized)
                wlr_xdg_toplevel_decoration_v1_set_mode(deco->d,
                                                        WLR_XDG_TOPLEVEL_DECORATION_V1_MODE_CLIENT_SIDE);
        };
        deco->request.connect(&d->events.request_mode, apply);
        deco->commit.connect(&d->toplevel->base->surface->events.commit, [deco, apply](void *p) {
            if (deco->d->toplevel->base->initialized) {
                apply(p);
                deco->commit.disconnect();
            }
        });
        deco->destroy.connect(&d->events.destroy, [deco](void *) { delete deco; });
        apply(nullptr);
    });

    // Taskbar + session lock.
    ftl_manager = wlr_foreign_toplevel_manager_v1_create(display);
    lock_manager = wlr_session_lock_manager_v1_create(display);
    new_lock.connect(&lock_manager->events.new_lock,
                     [this](void *d) { on_new_lock(static_cast<wlr_session_lock_v1 *>(d)); });

    // Idle (swayidle / hypridle) and inhibit (video players, games).
    idle_notifier = wlr_idle_notifier_v1_create(display);
    idle_inhibit = wlr_idle_inhibit_v1_create(display);
    new_inhibitor.connect(&idle_inhibit->events.new_inhibitor, [this](void *data) {
        auto *inh = static_cast<wlr_idle_inhibitor_v1 *>(data);
        struct Watch {
            Listener destroy;
        };
        auto *w = new Watch;
        inhibitors_active++;
        update_idle_inhibit();
        w->destroy.connect(&inh->events.destroy, [this, w](void *) {
            Server *srv = this;      // copy first: deleting w destroys this closure
            delete w;
            srv->inhibitors_active--;
            srv->update_idle_inhibit();
        });
    });

    tearing = wlr_tearing_control_manager_v1_create(display, 1);
    relative_pointer = wlr_relative_pointer_manager_v1_create(display);
    pointer_constraints = wlr_pointer_constraints_v1_create(display);

    gamma = wlr_gamma_control_manager_v1_create(display);   // night light (gammastep / wlsunset)
    set_gamma.connect(&gamma->events.set_gamma, [this](void *data) {
        auto *e = static_cast<wlr_gamma_control_manager_v1_set_gamma_event *>(data);
        for (auto &o : outputs)
            if (o->output == e->output) {
                o->gamma_dirty = true;
                wlr_output_schedule_frame(o->output);
            }
    });

    activation = wlr_xdg_activation_v1_create(display);
    activation_request.connect(&activation->events.request_activate, [this](void *data) {
        auto *e = static_cast<wlr_xdg_activation_v1_request_activate_event *>(data);
        View *v = view_for_surface(e->surface);
        if (!v || !v->mapped || locked) return;
        if (!ws_shown(v->workspace)) switch_workspace(v->workspace);
        focus_view(v);
    });

    output_manager = wlr_output_manager_v1_create(display);
    om_apply.connect(&output_manager->events.apply,
                     [this](void *d) { apply_output_config(static_cast<wlr_output_configuration_v1 *>(d), false); });
    om_test.connect(&output_manager->events.test,
                    [this](void *d) { apply_output_config(static_cast<wlr_output_configuration_v1 *>(d), true); });
    layout_change.connect(&output_layout->events.change, [this](void *) {
        arrange_all();
        update_output_manager();
    });

    new_output.connect(&backend->events.new_output, [this](void *d) { add_output(static_cast<wlr_output *>(d)); });

    // Cursor & seat.
    cursor = wlr_cursor_create();
    wlr_cursor_attach_output_layout(cursor, output_layout);
    cursor_shape = wlr_cursor_shape_manager_v1_create(display, 1);
    seat = wlr_seat_create(display, "seat0");
    set_cursor_theme(config.cursor_theme, config.cursor_size);
    setup_input(this);

    // Wayland socket.
    const char *sock = wl_display_add_socket_auto(display);
    if (!sock) {
        wlr_backend_destroy(backend);
        return false;
    }
    socket_name = sock;

#ifdef NOVA_XWAYLAND
    xwayland = wlr_xwayland_create(display, compositor, true);
    if (xwayland) {
        xw_ready.connect(&xwayland->events.ready, [this](void *) { wlr_xwayland_set_seat(xwayland, seat); });
        xw_new_surface.connect(&xwayland->events.new_surface, [this](void *d) {
            create_xwayland_view(this, static_cast<wlr_xwayland_surface *>(d));
        });
        setenv("DISPLAY", xwayland->display_name, 1);
    } else {
        wlr_log(WLR_ERROR, "XWayland failed to start; X11 apps will not work");
    }
#endif

    if (!wlr_backend_start(backend)) {
        wlr_backend_destroy(backend);
        wl_display_destroy(display);
        return false;
    }

    setenv("WAYLAND_DISPLAY", sock, 1);
    setenv("XDG_CURRENT_DESKTOP", "Nova", 1);
    setenv("XDG_SESSION_DESKTOP", "nova", 1);
    setenv("XDG_SESSION_TYPE", "wayland", 1);
    setenv("MOZ_ENABLE_WAYLAND", "1", 1);
    setenv("QT_QPA_PLATFORM", "wayland;xcb", 1);
    setenv("ELECTRON_OZONE_PLATFORM_HINT", "auto", 1);

    ipc = std::make_unique<Ipc>(this);
    ipc->start();

    wlr_log(WLR_INFO, "Nova running on WAYLAND_DISPLAY=%s", sock);

    // Make the session environment visible to D-Bus activated services
    // (portals, notification daemons, etc.).
    spawn("dbus-update-activation-environment --systemd WAYLAND_DISPLAY DISPLAY XDG_CURRENT_DESKTOP "
          "XDG_SESSION_TYPE NOVA_SOCK XCURSOR_THEME XCURSOR_SIZE QT_QPA_PLATFORMTHEME SSH_AUTH_SOCK");
    bool shell = false;
    for (const std::string &cmd : config.autostart) shell |= cmd.find("nova-shell") != std::string::npos;
    if (!shell) spawn("nova-shell");   // a config without it would leave a black screen
    // password prompts for admin apps and the updater: the first polkit agent installed
    spawn("pgrep -f 'authentication-agent|policykit|lxpolkit' >/dev/null || for a in "
          "/usr/libexec/polkit-gnome-authentication-agent-1 /usr/libexec/kf6/polkit-kde-authentication-agent-1 "
          "/usr/libexec/polkit-mate-authentication-agent-1 /usr/bin/lxqt-policykit-agent; do "
          "[ -x \"$a\" ] && exec \"$a\"; done");
    for (const std::string &cmd : config.autostart) spawn(cmd);
    return true;
}

void Server::run() { wl_display_run(display); }

void Server::shutdown() {
    ipc.reset();
    wl_display_destroy_clients(display);
#ifdef NOVA_XWAYLAND
    if (xwayland) wlr_xwayland_destroy(xwayland);
#endif
    wlr_scene_node_destroy(&scene->tree.node);
    wlr_xcursor_manager_destroy(xcursor);
    wlr_cursor_destroy(cursor);
    wlr_allocator_destroy(allocator);
    wlr_renderer_destroy(renderer);
    wlr_backend_destroy(backend);
    wl_display_destroy(display);
}
