#include "ccentre.hpp"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <fstream>
#include <map>
#include <pwd.h>
#include <unistd.h>
#include <linux/input-event-codes.h>

#include "apps.hpp"
#include "draw.hpp"
#include "glyphs.hpp"
#include "launcher.hpp"
#include "notify.hpp"
#include "panel.hpp"
#include "popover.hpp"
#include "system.hpp"

namespace dusk {

namespace {

constexpr int kWidth = 392;
constexpr int kPad = 16;
constexpr int kMargin = 10;      // from the screen edge / panel
constexpr int kCols = 6;         // the tile grid
constexpr int kGap = 8;
constexpr int kMaxRows = 14;

bool inside(const wlr_box &b, double x, double y) {
	return x >= b.x && y >= b.y && x < b.x + b.width && y < b.y + b.height;
}

std::string ago(std::time_t when) {
	const long d = static_cast<long>(std::time(nullptr) - when);
	if (d < 60) return "now";
	if (d < 3600) return std::to_string(d / 60) + " min ago";
	if (d < 86400) return std::to_string(d / 3600) + " h ago";
	return std::to_string(d / 86400) + " d ago";
}

// An on/off switch; `t` goes 0 -> 1 as it turns on. Half way the knob
// stretches into a pill, so it looks like it's being pulled across.
void draw_switch(cairo_t *cr, double x, double y, double t) {
	t = std::clamp(t, 0.0, 1.0);
	fill_rounded(cr, x, y, 44, 24, 12, mix(theme::tile_off, theme::accent, t));
	const double stretch = 9 * std::sin(M_PI * t);
	const double kx = x + 3 + t * 20 - stretch * t;
	fill_rounded(cr, kx, y + 3, 18 + stretch, 18, 9, mix(rgb(0xffffff), theme::on_accent, t));
}

// ---- what can be a tile ------------------------------------------------------

struct TileDef {
	const char *id, *name, *kind;   // kind: toggle, slider, info, action
	int w, h;                        // size when added
};
const TileDef kTiles[] = {
	{"wifi", "Wi-Fi", "toggle", 3, 1},
	{"bluetooth", "Bluetooth", "toggle", 3, 1},
	{"sound", "Sound", "toggle", 1, 1},
	{"dnd", "Do not disturb", "toggle", 1, 1},
	{"dark", "Dark mode", "toggle", 1, 1},
	{"nightlight", "Night light", "toggle", 1, 1},
	{"screenshot", "Screenshot", "action", 1, 1},
	{"airplane", "Airplane mode", "toggle", 1, 1},
	{"caffeine", "Caffeine", "toggle", 2, 1},
	{"power", "Power mode", "toggle", 1, 1},
	{"brightness", "Brightness", "slider", 1, 3},
	{"volume", "Volume", "slider", 1, 3},
	{"mic", "Microphone", "slider", 1, 3},
	{"battery", "Battery", "info", 3, 1},
	{"media", "Now playing", "info", 3, 1},
};

const TileDef *tile_def(const std::string &id) {
	for (const TileDef &d : kTiles) {
		if (id == d.id) return &d;
	}
	return nullptr;
}

// Tiles that make no sense on this computer are left out.
bool tile_available(Server *server, const std::string &id) {
	const SystemStatus &st = *server->status;
	if (id == "brightness") return st.has_brightness;
	if (id == "battery") return st.has_battery;
	if (id == "mic") return st.has_audio;
	// With a battery, its tile is the power mode tile too (one tile, not two).
	if (id == "power") return !st.power_profile.empty() && !st.has_battery;
	return tile_def(id) != nullptr;
}

// Like Arqen's: Wi-Fi and Bluetooth across the top; brightness, volume and
// the microphone stand on the left like a phone's; toggles fill the nine
// cells beside them; battery and what's playing along the bottom.
std::vector<CcTile> default_layout(Server *server) {
	const bool battery = tile_available(server, "battery");
	const bool brightness = tile_available(server, "brightness");
	std::vector<CcTile> l = {
		{"wifi", 0, 0, 3, 1}, {"bluetooth", 3, 0, 3, 1},
		{brightness ? "brightness" : "power", 0, 1, 1, 3}, {"volume", 1, 1, 1, 3}, {"mic", 2, 1, 1, 3},
		{"sound", 3, 1, 1, 1}, {"dnd", 4, 1, 1, 1}, {"dark", 5, 1, 1, 1},
		{"nightlight", 3, 2, 1, 1}, {"screenshot", 4, 2, 1, 1}, {"airplane", 5, 2, 1, 1},
		{"caffeine", 3, 3, battery ? 3 : 2, 1}, {"power", 5, 3, 1, 1},
		{"battery", 0, 4, 3, 1}, {"media", battery ? 3 : 0, 4, battery ? 3 : 6, 1},
	};
	if (battery) {
		// The battery tile does the power mode too.
		l.erase(std::remove_if(l.begin() + 3, l.end(), [](const CcTile &t) { return t.id == "power"; }), l.end());
	}
	if (!brightness && !battery) {
		// The power tile went in brightness's place; drop its second copy
		// and stand it up as a 1x1 there.
		l.erase(std::remove_if(l.begin() + 3, l.end(), [](const CcTile &t) { return t.id == "power"; }),
			l.end());
		l[2].h = 1;
	}
	return l;
}

bool overlaps(const CcTile &a, const CcTile &b) {
	return a.c < b.c + b.w && b.c < a.c + a.w && a.r < b.r + b.h && b.r < a.r + a.h;
}

// Does `t` fit in `l` (not counting the tiles named)?
bool fits(const std::vector<CcTile> &l, const CcTile &t, const std::string &skip1,
		const std::string &skip2 = "") {
	if (t.c < 0 || t.r < 0 || t.w < 1 || t.h < 1 || t.c + t.w > kCols || t.r + t.h > kMaxRows) {
		return false;
	}
	for (const CcTile &o : l) {
		if (o.id != skip1 && o.id != skip2 && overlaps(o, t)) return false;
	}
	return true;
}

struct TileState {
	std::string icon, title, subtitle;
	bool on = false;
	bool usable = true;   // e.g. no Wi-Fi adapter
	int value = 0;        // sliders, 0..100
	bool muted = false;   // sliders
};

TileState tile_state(Server *server, const std::string &id) {
	const SystemStatus &st = *server->status;
	const Config &c = server->config;
	TileState i;
	if (id == "wifi") {
		i.title = "Wi-Fi";
		i.on = st.wifi_enabled && !st.airplane;
		i.usable = st.wifi_available;
		i.icon = !i.on ? "offline" : st.ssid.empty() ? "wifi-0" : wifi_icon(st.wifi_signal);
		i.subtitle = !i.usable ? "No adapter" : !i.on ? "Off"
			: st.net_kind == "ethernet" && st.ssid.empty() ? "Wired" : st.ssid.empty() ? "Not connected" : st.ssid;
	} else if (id == "bluetooth") {
		i.title = "Bluetooth";
		i.on = st.bt_powered;
		i.usable = st.bt_available;
		i.icon = i.on ? "bluetooth" : "bluetooth-off";
		i.subtitle = !i.usable ? "No adapter" : !i.on ? "Off" : st.bt_device.empty() ? "On" : st.bt_device;
	} else if (id == "sound") {
		i.title = "Sound";
		i.on = !st.muted;
		i.usable = st.has_audio;
		i.icon = speaker_icon(st.volume, st.muted);
		i.subtitle = st.muted ? "Muted" : std::to_string(st.volume) + "%";
	} else if (id == "dark") {
		i.title = "Dark mode";
		i.on = c.dark;
		i.icon = "moon";
		i.subtitle = c.dark ? "Dark" : "Light";
	} else if (id == "nightlight") {
		i.title = "Night light";
		i.on = c.night_light;
		i.icon = "nightlight";
		i.subtitle = c.night_light ? std::to_string(c.night_light_temp) + " K" : "Off";
	} else if (id == "dnd") {
		i.title = "Do not disturb";
		i.on = c.dnd;
		i.icon = c.dnd ? "bell-off" : "bell";
		i.subtitle = c.dnd ? "On" : "Off";
	} else if (id == "airplane") {
		i.title = "Airplane mode";
		i.on = st.airplane;
		i.icon = "airplane";
		i.subtitle = st.airplane ? "On" : "Off";
	} else if (id == "caffeine") {
		i.title = "Caffeine";
		i.on = st.caffeine;
		i.icon = "coffee";
		i.subtitle = st.caffeine ? "Staying awake" : "Off";
	} else if (id == "power") {
		i.title = "Power mode";
		i.usable = !st.power_profile.empty();
		i.on = i.usable && st.power_profile != "balanced";
		i.icon = "gauge-" + st.power_profile;
		i.subtitle = st.power_profile == "power-saver" ? "Power saver"
			: st.power_profile == "performance" ? "Performance" : i.usable ? "Balanced" : "Unavailable";
	} else if (id == "screenshot") {
		i.title = "Screenshot";
		i.icon = "screenshot";
		i.subtitle = "Area, window, screen";
	} else if (id == "brightness") {
		i.title = "Brightness";
		i.icon = "sun";
		i.value = st.brightness;
		i.usable = st.has_brightness;
	} else if (id == "volume") {
		i.title = "Volume";
		i.icon = speaker_icon(st.volume, st.muted);
		i.value = st.volume;
		i.muted = st.muted;
		i.usable = st.has_audio;
	} else if (id == "mic") {
		i.title = "Microphone";
		i.icon = st.mic_muted ? "mic-off" : "mic";
		i.value = st.mic_volume;
		i.muted = st.mic_muted;
		i.usable = st.has_audio;
	} else if (id == "battery") {
		// The battery and the power mode in one: click to change the mode.
		i.title = std::to_string(st.battery) + "%" + (st.battery_state == "Charging" ? " · charging" : "");
		i.icon = battery_icon(st.battery, st.charging);
		i.on = !st.power_profile.empty() && st.power_profile != "balanced";
		i.subtitle = st.power_profile.empty() ? "Battery"
			: std::string("Power mode: ") + (st.power_profile == "power-saver" ? "Power saver"
				: st.power_profile == "performance" ? "Performance" : "Balanced");
	} else if (id == "media") {
		i.title = st.media_available ? (st.media_title.empty() ? "Playing" : st.media_title) : "Nothing playing";
		i.subtitle = st.media_available ? st.media_artist : "";
		i.on = st.media_playing;
		i.icon = st.media_playing ? "pause" : "play";
	}
	return i;
}

std::string serialise(const std::vector<CcTile> &l) {
	std::string out;
	for (const CcTile &t : l) {
		out += (out.empty() ? "" : ",") + t.id + ":" + std::to_string(t.c) + ":" + std::to_string(t.r) + ":" +
			std::to_string(t.w) + ":" + std::to_string(t.h);
	}
	return out;
}

std::string uptime_text() {
	std::ifstream f("/proc/uptime");
	double s = 0;
	f >> s;
	const long sec = static_cast<long>(s);
	const long d = sec / 86400, h = sec % 86400 / 3600, m = sec % 3600 / 60;
	if (d > 0) return std::to_string(d) + "d " + std::to_string(h) + "h";
	if (h > 0) return std::to_string(h) + "h " + std::to_string(m) + "m";
	return std::to_string(m) + "m";
}

} // namespace

ControlCentre::ControlCentre(Server *server)
		: server_(server), layer_(server->layer_menu, &tag),
		fx_(server->anim.get(), [this] { if (open_ || alpha_ > 0) redraw(); }),
		hl_(layer_, server->anim.get()) {
	layer_.set_enabled(false);
	timer_ = wl_event_loop_add_timer(server->loop, &ControlCentre::handle_timer, this);
	// Your name: the full name from your account, else the login name.
	if (const passwd *pw = getpwuid(getuid())) {
		std::string gecos = pw->pw_gecos ? pw->pw_gecos : "";
		gecos = gecos.substr(0, gecos.find(','));
		user_name_ = gecos.empty() ? pw->pw_name : gecos;
		if (!user_name_.empty()) user_name_[0] = static_cast<char>(std::toupper(user_name_[0]));
	}
}

ControlCentre::~ControlCentre() {
	server_->anim->cancel(anim_);
	wl_event_source_remove(timer_);
	if (art_) cairo_surface_destroy(art_);
	if (avatar_) cairo_surface_destroy(avatar_);
}

int ControlCentre::handle_timer(void *data) {
	auto *self = static_cast<ControlCentre *>(data);
	if (!self->open_) {
		return 0;
	}
	self->server_->status->refresh_media();
	wl_event_source_timer_update(self->timer_, 3000);
	return 0;
}

// ---- opening and closing ----------------------------------------------------

void ControlCentre::open(Output *output, wlr_box anchor, const std::string &edge) {
	// Seen now: the panel's bell goes.
	if (server_->notifications && server_->notifications->unseen) {
		server_->notifications->unseen = 0;
		server_->redraw_panels();
	}
	if (!output) {
		return;
	}
	output_ = output;
	const std::string &side = server_->config.cc_side;
	if (side == "left") {
		left_side_ = true;
	} else if (side == "right") {
		left_side_ = false;
	} else if (edge == "left" || edge == "right") {
		left_side_ = edge == "left";
	} else {
		// Follow the button: whichever half of the screen it is on.
		const wlr_box o = output->box();
		left_side_ = anchor.width > 0 && anchor.x + anchor.width / 2 < o.x + o.width / 2;
	}
	open_ = true;
	page_ = Page::Tiles;
	editing_ = false;
	typing_ = false;
	notes_scroll_ = 0;
	open_groups_.clear();
	server_->status->refresh();
	server_->status->refresh_media();
	fx_.snap("notes", 0);
	redraw();
	place();
	layer_.set_enabled(true);
	layer_.raise();
	wl_event_source_timer_update(timer_, 3000);

	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 1.0, c.animate(c.anim_menu) ? c.ms(280) : 0,
		[this] { place(); }, [this] { anim_ = 0; });
	server_->redraw_panels();
}

void ControlCentre::close() {
	if (!open_) {
		return;
	}
	open_ = false;
	typing_ = false;
	editing_ = false;
	edit_tile_.clear();
	dragging_.clear();
	server_->cc_grab = false;
	wl_event_source_timer_update(timer_, 0);
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 0.0, c.animate(c.anim_menu) ? c.ms(200) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!open_) {
				layer_.set_enabled(false);
			}
		});
	server_->redraw_panels();
}

void ControlCentre::toggle(Output *output, wlr_box anchor, const std::string &edge) {
	if (open_ && output_ == output) {
		close();
	} else {
		open(output, anchor, edge);
	}
}

void ControlCentre::toggle(Output *output) {
	if (open_ || !output) {
		close();
		return;
	}
	for (const auto &panel : output->panels) {
		const auto &w = panel->config().widgets;
		if (std::find(w.begin(), w.end(), "status") != w.end()) {
			open(output, panel->anchor("status"), panel->config().edge);
			return;
		}
	}
	open(output, wlr_box{}, "right");
}

void ControlCentre::output_gone(Output *output) {
	if (output_ == output) {
		open_ = false;
		server_->anim->cancel(anim_);
		anim_ = 0;
		alpha_ = 0;
		layer_.set_enabled(false);
		output_ = nullptr;
	}
}

void ControlCentre::refresh() {
	if (open_ || alpha_ > 0) {
		redraw();
	}
}

// A tall card along the side of the screen; slides in from that side, with
// a small spring at the end (like Arqen's).
void ControlCentre::place() {
	if (!output_) {
		return;
	}
	const wlr_box u = output_->usable();
	const int x = left_side_ ? u.x + kMargin : u.x + u.width - kWidth - kMargin;
	const double t = std::clamp(alpha_, 0.0, 1.1);
	// From off the screen's edge, unless another screen is on that side (it
	// would show there): then a short slide while it fades.
	const wlr_box ob = output_->box();
	const double edge_x = left_side_ ? ob.x - 1.0 : ob.x + ob.width + 1.0;
	const bool neighbour = wlr_output_layout_output_at(server_->layout, edge_x, ob.y + ob.height / 2.0) != nullptr;
	const int reach = neighbour ? std::min(48, std::max(0, left_side_ ? x - ob.x : ob.x + ob.width - x - kWidth))
		: kWidth + kMargin;
	const int slide = static_cast<int>(std::lround((1.0 - t) * reach));
	box_.x = x;
	// Sliding off the screen it can stay a little visible (it's gone past the
	// edge by the end); with the short slide it fades out completely, or
	// it would be left standing faintly and then vanish.
	const double alpha = neighbour ? std::min(1.0, t * t * (3 - 2 * std::min(1.0, t))) : std::min(1.0, 0.25 + t);
	layer_.show(left_side_ ? x - slide : x + slide, box_.y, alpha, 1.0, 0, 0);
}

// Hover is drawn by the GPU highlight (no redraws while the mouse moves).
double ControlCentre::hv(const std::string &) {
	return 0.0;
}

// Cards inside follow the sidebar's corners: outer radius = inner + padding.
int ControlCentre::card_radius() const {
	return std::max(10, theme::ui_radius - 4);
}

bool ControlCentre::contains(double lx, double ly) const {
	return open_ && inside(box_, lx, ly);
}

// ---- drawing ------------------------------------------------------------------

void ControlCentre::add_hot(const std::string &id, double x, double y, double w, double h,
		double radius, wlr_box vis) {
	const wlr_box box{static_cast<int>(x), static_cast<int>(y), static_cast<int>(w),
		static_cast<int>(h)};
	hots_.push_back(Hot{id, box, vis.width > 0 ? vis : box,
		radius == -1 ? static_cast<double>(card_radius()) : radius});
}

void ControlCentre::update_highlight() {
	for (const Hot &h : hots_) {
		if (h.id == hover_ && h.radius >= 0) {
			hl_.show(h.vis, h.radius, with_alpha(theme::text, theme::dark ? 0.09 : 0.07));
			return;
		}
	}
	hl_.hide();
}

std::string ControlCentre::hot_at(double px, double py) const {
	for (auto it = hots_.rbegin(); it != hots_.rend(); ++it) {
		if (inside(it->box, px, py)) {
			return it->id;
		}
	}
	return "";
}

wlr_box ControlCentre::tile_box(const CcTile &t) const {
	const double step = cell_ + kGap;
	return wlr_box{static_cast<int>(std::lround(kPad + t.c * step)),
		static_cast<int>(std::lround(grid_top_ + t.r * step)),
		static_cast<int>(std::lround(t.w * cell_ + (t.w - 1) * kGap)),
		static_cast<int>(std::lround(t.h * cell_ + (t.h - 1) * kGap))};
}

void ControlCentre::redraw() {
	if (!output_ || drawing_) {
		return;
	}
	drawing_ = true;
	const wlr_box u = output_->usable();
	box_.width = kWidth;
	box_.height = std::max(300, u.height - 2 * kMargin);
	box_.y = u.y + kMargin;
	box_.x = left_side_ ? u.x + kMargin : u.x + u.width - kWidth - kMargin;

	// The layout: saved, or the default; only tiles that work here.
	if (edit_tile_.empty()) {
		const auto &saved = server_->config.cc_layout;
		layout_.clear();
		for (const CcTile &t : saved.empty() ? default_layout(server_) : saved) {
			if (tile_available(server_, t.id) && fits(layout_, t, "")) {
				layout_.push_back(t);
			}
		}
	}

	const float scale = output_->output->scale;
	Canvas canvas(kWidth, box_.height, scale);
	cairo_t *cr = canvas.cr();
	hots_.clear();
	const double outer = card_radius() + kPad;
	ui_card(cr, 0, 0, kWidth, box_.height, outer, with_alpha(theme::bg_alt, theme::ui_opacity));

	int y = kPad;
	draw_header(cr, y, scale);
	const int bottom = box_.height - kPad;

	// Changing page: the new one slides in and fades up.
	const double slide = fx_.get("page");
	cairo_save(cr);
	cairo_rectangle(cr, 0, y - 4, kWidth, bottom - y + 4 + kPad);
	cairo_clip(cr);
	const double dx = slide * 60 * (page_ == Page::Tiles ? -1 : 1);
	cairo_translate(cr, dx, 0);
	cairo_push_group(cr);
	const size_t hots_before = hots_.size();
	if (page_ == Page::Tiles) {
		draw_grid(cr, y, scale);
		if (editing_) {
			draw_edit_tray(cr, y, scale);
		} else if (server_->config.cc_notifications) {
			draw_notifications(cr, y, bottom, scale);
		}
	} else {
		draw_detail(cr, y, bottom, scale);
	}
	cairo_pop_group_to_source(cr);
	cairo_paint_with_alpha(cr, 1.0 - 0.8 * std::fabs(slide));
	cairo_restore(cr);
	for (size_t i = hots_before; i < hots_.size(); i++) {
		hots_[i].box.x += static_cast<int>(std::lround(dx));
		hots_[i].vis.x += static_cast<int>(std::lround(dx));
	}
	layer_.present(canvas, wlr_box{0, 0, kWidth, box_.height}, outer);
	drawing_ = false;
	place();
	update_highlight();
}

// You (picture, name, how long the computer has been on) and round buttons:
// edit the tiles, Settings, power.
void ControlCentre::draw_header(cairo_t *cr, int &y, float scale) {
	const int h = 52;
	const int buttons = 3, bsize = 40, bgap = 6;
	const int me_w = kWidth - 2 * kPad - buttons * (bsize + bgap);
	fill_rounded(cr, kPad, y, me_w, h, h / 2.0, theme::card_bg);
	add_hot("me", kPad, y, me_w, h, h / 2.0);

	// Your picture: ~/.face, or the one from your account, else your initial.
	if (!avatar_tried_) {
		avatar_tried_ = true;
		const char *home = getenv("HOME");
		const passwd *pw = getpwuid(getuid());
		for (const std::string &p : {std::string(home ? home : "") + "/.face",
				std::string("/var/lib/AccountsService/icons/") + (pw ? pw->pw_name : "")}) {
			if (access(p.c_str(), R_OK) == 0) {
				avatar_ = load_image_sized(p, static_cast<int>(40 * scale), static_cast<int>(40 * scale));
				if (avatar_) break;
			}
		}
	}
	const double ax = kPad + 6, ay = y + 6, as = 40;
	cairo_save(cr);
	cairo_new_path(cr);
	cairo_arc(cr, ax + as / 2, ay + as / 2, as / 2, 0, 2 * M_PI);
	cairo_clip(cr);
	if (avatar_) {
		const double iw = cairo_image_surface_get_width(avatar_), ih = cairo_image_surface_get_height(avatar_);
		const double s = std::max(as / iw, as / ih);
		cairo_translate(cr, ax + (as - iw * s) / 2, ay + (as - ih * s) / 2);
		cairo_scale(cr, s, s);
		cairo_set_source_surface(cr, avatar_, 0, 0);
		cairo_paint(cr);
	} else {
		set_color(cr, theme::accent);
		cairo_paint(cr);
		draw_text(cr, user_name_.substr(0, 1), ax, ay, as, as, theme::font_large, theme::on_accent,
			Align::Center);
	}
	cairo_restore(cr);
	const int tx = kPad + 56, tw = me_w - 64;
	draw_text(cr, user_name_, tx, y + 7, tw, 20, theme::font_bold, theme::text);
	// A chip: how long the computer has been on.
	const std::string up = "Up " + uptime_text();
	const int cw = text_width(up, theme::font_small) + 14;
	fill_rounded(cr, tx, y + 29, cw, 17, 8.5, with_alpha(theme::text, 0.08));
	draw_text(cr, up, tx, y + 29, cw, 17, theme::font_small, theme::text_dim, Align::Center);

	const struct {
		const char *id, *icon;
	} kButtons[] = {{"edit", "edit"}, {"settings", "gear"}, {"power", "power"}};
	int bx = kPad + me_w + bgap;
	for (const auto &b : kButtons) {
		const bool lit = std::string(b.id) == "edit" && editing_;
		cairo_new_path(cr);
		cairo_arc(cr, bx + bsize / 2.0, y + h / 2.0, bsize / 2.0, 0, 2 * M_PI);
		set_color(cr, lit ? theme::accent : theme::card_bg);
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, b.icon, bx + bsize / 2.0 - 9, y + h / 2.0 - 9, 18,
			lit ? theme::on_accent : theme::text, scale);
		add_hot(b.id, bx, y + (h - bsize) / 2, bsize, bsize, bsize / 2.0);
		bx += bsize + bgap;
	}
	y += h + 14;
}

namespace {

// What the battery is doing, in words.
std::string battery_words(const SystemStatus &st) {
	if (st.battery_state == "Charging") return "Charging";
	if (st.battery_state == "Full") return "Full";
	if (st.battery_state == "Not charging") return "Plugged in, not charging";
	return "On battery";
}

// Each power mode has its colour, made from the accent: warmer for
// Performance, greener for Power saver, the accent itself for Balanced.
Color power_mode_color(const std::string &mode) {
	if (mode == "performance") return mix(theme::accent, rgb(0xf0883e), 0.6);
	if (mode == "power-saver") return mix(theme::accent, rgb(0x3fb950), 0.6);
	return theme::accent;
}

// Dark or white, whichever reads on `bg`.
Color readable_on(const Color &bg) {
	const double lum = 0.299 * bg.r + 0.587 * bg.g + 0.114 * bg.b;
	return lum > 0.62 ? rgb(0x1c1c1c) : rgb(0xffffff);
}

} // namespace

void ControlCentre::draw_tile(cairo_t *cr, const CcTile &t, const wlr_box &b, float scale,
		bool floating) {
	const TileDef *def = tile_def(t.id);
	if (!def) return;
	const TileState s = tile_state(server_, t.id);
	const std::string kind = def->kind;
	const double r = std::min<double>(card_radius(), std::min(b.width, b.height) / 2.0);
	const std::string id = t.id;
	const bool edit = editing_;

	if (kind == "slider") {
		// A bar that fills from the bottom (upright) or from the left.
		const bool vertical = b.height > b.width;
		const std::string vkey = "val:" + id;
		if (dragging_ == "sl:" + id) fx_.snap(vkey, s.value);
		else fx_.set(vkey, s.value, s.value);
		const double v = std::clamp(fx_.get(vkey), 0.0, 100.0) / 100.0;
		fill_rounded(cr, b.x, b.y, b.width, b.height, r, theme::tile_off);
		cairo_save(cr);
		rounded_rect(cr, b.x, b.y, b.width, b.height, r);
		cairo_clip(cr);
		const Color fill = s.muted ? theme::text_dim : theme::accent;
		set_color(cr, fill);
		if (vertical) {
			const double fh = b.height * v;
			cairo_rectangle(cr, b.x, b.y + b.height - fh, b.width, fh);
		} else {
			cairo_rectangle(cr, b.x, b.y, b.width * v, b.height);
		}
		cairo_fill(cr);
		cairo_restore(cr);
		const double isz = 20;
		double ix, iy;
		if (vertical) {
			ix = b.x + b.width / 2.0 - isz / 2;
			iy = b.y + b.height - isz - 12;
		} else {
			ix = b.x + 14;
			iy = b.y + b.height / 2.0 - isz / 2;
		}
		const bool icon_on_fill = vertical ? v > 0.18 : v > 0.12;
		draw_named_icon(cr, server_->icons, s.icon, ix, iy, isz,
			icon_on_fill ? theme::on_accent : theme::text, scale);
		if (vertical && dragging_ == "sl:" + id) {
			// The number only while you drag it: a calm tile otherwise.
			draw_text(cr, std::to_string(s.value), b.x, b.y + 10, b.width, 18, theme::font_bold,
				v > 0.88 ? theme::on_accent : theme::text, Align::Center);
		} else if (!vertical && b.width >= 3 * cell_) {
			draw_text(cr, std::to_string(s.value) + "%", b.x + b.width - 60, b.y, 48, b.height,
				theme::font_small, v > 0.85 ? theme::on_accent : theme::text_dim, Align::Right);
		}
		if (!edit && !floating) {
			add_hot("sl:" + id, b.x, b.y, b.width, b.height, -2);
			if (dragging_ == "sl:" + id) {
				drag_track_ = b;
				drag_vertical_ = vertical;
			}
		}
		return;
	}

	if (id == "media") {
		const SystemStatus &st = *server_->status;
		fill_rounded(cr, b.x, b.y, b.width, b.height, r, theme::card_bg);
		const int as = b.height - 12;
		const int ax = b.x + 6, ay = b.y + 6;
		if (st.media_art != art_path_) {
			art_path_ = st.media_art;
			if (art_) {
				cairo_surface_destroy(art_);
				art_ = nullptr;
			}
			if (!art_path_.empty()) {
				art_ = load_image_sized(art_path_, static_cast<int>(as * scale), static_cast<int>(as * scale));
			}
		}
		if (art_ && st.media_available) {
			cairo_save(cr);
			rounded_rect(cr, ax, ay, as, as, std::max(6.0, r - 6));
			cairo_clip(cr);
			const double iw = cairo_image_surface_get_width(art_), ih = cairo_image_surface_get_height(art_);
			const double sc = std::max(as / iw, as / ih);
			cairo_translate(cr, ax + (as - iw * sc) / 2, ay + (as - ih * sc) / 2);
			cairo_scale(cr, sc, sc);
			cairo_set_source_surface(cr, art_, 0, 0);
			cairo_paint(cr);
			cairo_restore(cr);
		} else {
			fill_rounded(cr, ax, ay, as, as, std::max(6.0, r - 6), theme::tile_off);
			draw_named_icon(cr, server_->icons, "speaker-on", ax + as / 2.0 - 9, ay + as / 2.0 - 9, 18,
				theme::text_dim, scale);
		}
		const int btn = std::min(36, b.height - 12);
		const bool wide = b.width >= 5 * cell_;
		const int controls_w = st.media_available ? (wide ? 3 * (btn + 4) : btn + 6) : 0;
		const int tx = ax + as + 10, tw = b.x + b.width - tx - controls_w - 6;
		draw_text(cr, s.title, tx, b.y + (s.subtitle.empty() ? 0 : 7), tw,
			s.subtitle.empty() ? b.height : 20, theme::font_bold, st.media_available ? theme::text : theme::text_dim);
		if (!s.subtitle.empty()) {
			draw_text(cr, s.subtitle, tx, b.y + 27, tw, 18, theme::font_small, theme::text_dim);
		}
		if (!edit && !floating) add_hot("tm:media", b.x, b.y, b.width - controls_w, b.height, r);
		if (st.media_available) {
			std::vector<std::pair<const char *, const char *>> ctl;
			if (wide) ctl.push_back({"mp:previous", "previous"});
			ctl.push_back({"mp:play-pause", st.media_playing ? "pause" : "play"});
			if (wide) ctl.push_back({"mp:next", "next"});
			int bx = b.x + b.width - 6 - static_cast<int>(ctl.size()) * (btn + 4) + 4;
			for (const auto &[cid, icon] : ctl) {
				const bool main = std::string(cid) == "mp:play-pause";
				cairo_new_path(cr);
				cairo_arc(cr, bx + btn / 2.0, b.y + b.height / 2.0, btn / 2.0, 0, 2 * M_PI);
				set_color(cr, main ? theme::accent : theme::tile_off);
				cairo_fill(cr);
				draw_named_icon(cr, server_->icons, icon, bx + btn / 2.0 - 8, b.y + b.height / 2.0 - 8, 16,
					main ? theme::on_accent : theme::text, scale);
				if (!edit && !floating) add_hot(cid, bx, b.y + (b.height - btn) / 2, btn, btn, btn / 2.0);
				bx += btn + 4;
			}
		}
		return;
	}

	if (id == "battery") {
		// The charge fills the tile like a gauge, in the power mode's colour
		// (red when it's running low); the three modes sit at the right end.
		const SystemStatus &st = *server_->status;
		const std::string &mode = st.power_profile;
		const bool low = st.battery <= 15 && st.battery_state == "Discharging";
		const Color mc = low ? rgb(0xe5534b) : power_mode_color(mode);
		// Smooth changes: the level, and the colour from one mode to the next.
		fx_.set("bat:level", st.battery, st.battery);
		const double level = std::clamp(fx_.get("bat:level"), 0.0, 100.0) / 100.0;
		// When the mode (or low battery) changes the colour, it eases across.
		const std::string ck = "bat:col";
		static Color from = mc, target = mc;
		if (mc.r != target.r || mc.g != target.g || mc.b != target.b) {
			from = mix(from, target, 1.0 - std::clamp(fx_.get(ck), 0.0, 1.0));
			target = mc;
			fx_.snap(ck, 1);
			fx_.set(ck, 0);
		}
		const Color col = mix(from, target, 1.0 - std::clamp(fx_.get(ck), 0.0, 1.0));
		fill_rounded(cr, b.x, b.y, b.width, b.height, r, with_alpha(col, theme::dark ? 0.20 : 0.16));
		cairo_save(cr);
		rounded_rect(cr, b.x, b.y, b.width, b.height, r);
		cairo_clip(cr);
		cairo_rectangle(cr, b.x, b.y, b.width * level, b.height);
		set_color(cr, with_alpha(col, theme::dark ? 0.55 : 0.45));
		cairo_fill(cr);
		cairo_restore(cr);

		const bool modes = !mode.empty();
		const int bs = std::min(26, b.height - 18);
		const int group_w = modes ? 3 * bs + 2 * 3 + 8 : 0;
		const double tx = b.x + 14, tw = b.width - 14 - group_w - 10;
		const std::string pct = std::to_string(st.battery) + "%";
		draw_text(cr, pct, tx, b.y + b.height / 2.0 - 20, tw, 22, theme::font_large, theme::text);
		if (st.battery_state == "Charging") {
			const double gx = tx + text_width(pct, theme::font_large) + 6;
			if (gx + 14 < tx + tw) {
				draw_named_icon(cr, server_->icons, "zap", gx, b.y + b.height / 2.0 - 17, 14, theme::text, scale);
			}
		}
		const std::string sub = !modes ? battery_words(st)
			: mode == "performance" ? "Performance" : mode == "power-saver" ? "Power saver" : "Balanced";
		draw_text(cr, sub, tx, b.y + b.height / 2.0 + 2, tw, 17, theme::font_small, with_alpha(theme::text, 0.75));
		if (!edit && !floating) add_hot("tm:battery", b.x, b.y, b.width, b.height, r);

		if (modes) {
			// Three round buttons on a soft pill: the chosen one in its colour.
			const double gx = b.x + b.width - group_w - 6, gy = b.y + (b.height - bs - 8) / 2.0;
			fill_rounded(cr, gx, gy, group_w, bs + 8, (bs + 8) / 2.0, with_alpha(theme::card_bg, 0.75));
			static const char *kModes[] = {"power-saver", "balanced", "performance"};
			for (int m = 0; m < 3; m++) {
				const std::string p = kModes[m];
				const double cx = gx + 4 + bs / 2.0 + m * (bs + 3), cy = gy + 4 + bs / 2.0;
				const bool chosen = p == mode;
				if (chosen) {
					const Color pc = power_mode_color(p);
					cairo_new_path(cr);
					cairo_arc(cr, cx, cy, bs / 2.0, 0, 2 * M_PI);
					set_color(cr, pc);
					cairo_fill(cr);
					draw_named_icon(cr, server_->icons, "gauge-" + p, cx - 8, cy - 8, 16, readable_on(pc), scale);
				} else {
					draw_named_icon(cr, server_->icons, "gauge-" + p, cx - 8, cy - 8, 16, theme::text_dim, scale);
				}
				if (!edit && !floating) {
					add_hot("pp:" + p, static_cast<int>(cx - bs / 2.0), static_cast<int>(cy - bs / 2.0), bs, bs, bs / 2.0);
				}
			}
		}
		return;
	}

	// Toggles, screenshot.
	const std::string on_key = "on:" + id;
	const bool on = s.on && s.usable;
	fx_.set(on_key, on ? 1.0 : 0.0, on ? 1.0 : 0.0);
	const double onv = std::clamp(fx_.get(on_key), 0.0, 1.0);
	const double press = fx_.get("press:" + id);
	const Color off_fill = !s.usable ? with_alpha(theme::tile_off, theme::tile_off.a * 0.5) : theme::tile_off;
	const Color fill = mix(off_fill, theme::accent, onv);
	const Color fg = !s.usable ? theme::text_dim : mix(theme::text, theme::on_accent, onv);
	cairo_save(cr);
	{
		const double cx = b.x + b.width / 2.0, cy = b.y + b.height / 2.0, k = 1.0 - 0.06 * press;
		cairo_translate(cr, cx, cy);
		cairo_scale(cr, k, k);
		cairo_translate(cr, -cx, -cy);
	}
	fill_rounded(cr, b.x, b.y, b.width, b.height, r, fill);
	if (t.w == 1 && t.h == 1) {
		draw_named_icon(cr, server_->icons, s.icon, b.x + b.width / 2.0 - 11, b.y + b.height / 2.0 - 11, 22,
			fg, scale);
		if (!edit && !floating) add_hot("ti:" + id, b.x, b.y, b.width, b.height, r);
	} else if (t.w <= 2 && t.h == 1) {
		// Two cells wide: no room for the round button, so a plain icon and
		// the title beside it (the icon's end still switches it).
		const double isz = 18, ix = b.x + 12, iy = b.y + b.height / 2.0 - isz / 2;
		draw_named_icon(cr, server_->icons, s.icon, ix, iy, isz, fg, scale);
		const double tx = ix + isz + 9, tw = b.x + b.width - tx - 8;
		draw_text(cr, s.title, tx, b.y + b.height / 2.0 - 18, tw, 19, theme::font_bold, fg);
		draw_text(cr, s.subtitle, tx, b.y + b.height / 2.0 + 1, tw, 17, theme::font_small, with_alpha(fg, 0.8));
		if (!edit && !floating) {
			add_hot("tm:" + id, b.x, b.y, b.width, b.height, r);
			add_hot("ti:" + id, b.x, b.y, static_cast<int>(isz + 20), b.height, r,
				wlr_box{b.x, b.y, b.width, b.height});
		}
	} else {
		// A round icon you click to switch it; the rest opens its list or options.
		const double d = std::min<double>(b.height, cell_) - 12;
		const double cx = b.x + 6 + d / 2, cy = t.h == 1 ? b.y + b.height / 2.0 : b.y + 6 + d / 2;
		cairo_new_path(cr);
		cairo_arc(cr, cx, cy, d / 2, 0, 2 * M_PI);
		set_color(cr, onv > 0.5 ? with_alpha(theme::on_accent, 0.22) : with_alpha(theme::text, 0.08));
		cairo_fill(cr);
		draw_named_icon(cr, server_->icons, s.icon, cx - 10, cy - 10, 20, fg, scale);
		double tx, ty, tw;
		if (t.h == 1) {
			tx = b.x + 12 + d;
			ty = b.y + b.height / 2.0 - 19;
			tw = b.x + b.width - tx - 10;
		} else {
			tx = b.x + 12;
			ty = b.y + b.height - 46;
			tw = b.width - 24;
		}
		draw_text(cr, s.title, tx, ty, tw, 20, theme::font_bold, fg);
		draw_text(cr, s.subtitle, tx, ty + 20, tw, 18, theme::font_small, with_alpha(fg, 0.8));
		if (!edit && !floating) {
			const int ir = static_cast<int>(d / 2);
			add_hot("tm:" + id, b.x, b.y, b.width, b.height, r);
			add_hot("ti:" + id, cx - ir - 2, cy - ir - 2, 2 * ir + 4, 2 * ir + 4, ir);
		}
	}
	cairo_restore(cr);
}

void ControlCentre::draw_grid(cairo_t *cr, int &y, float scale) {
	if (editing_) {
		// The edit bar: a hint, Reset and Done.
		draw_text(cr, "Drag tiles, pull a corner to resize", kPad + 4, y, kWidth - 2 * kPad - 150, 30,
			theme::font_small, theme::text_dim);
		const struct {
			const char *id, *label;
			int w;
			bool primary;
		} kButtons[] = {{"edit-reset", "Reset", 64, false}, {"edit-done", "Done", 64, true}};
		int bx = kWidth - kPad - 64 - 6 - 64;
		for (const auto &b : kButtons) {
			fill_rounded(cr, bx, y + 2, b.w, 26, 13, b.primary ? theme::accent : theme::tile_off);
			draw_text(cr, b.label, bx, y + 2, b.w, 26, b.primary ? theme::font_bold : theme::font_small,
				b.primary ? theme::on_accent : theme::text, Align::Center);
			add_hot(b.id, bx, y + 2, b.w, 26, 13);
			bx += b.w + 6;
		}
		y += 38;
	}
	cell_ = (kWidth - 2 * kPad - (kCols - 1) * kGap) / static_cast<double>(kCols);
	grid_top_ = y;
	int rows = 0;
	for (const CcTile &t : layout_) rows = std::max(rows, t.r + t.h);
	if (editing_) rows = std::min(kMaxRows, rows + 1);   // room to drop tiles below

	if (editing_) {
		// The free cells: faint filled squares (no outlines) where a tile can go.
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < kCols; c++) {
				const bool taken = std::any_of(layout_.begin(), layout_.end(), [&](const CcTile &t) {
					return t.id != edit_tile_ && c >= t.c && c < t.c + t.w && r >= t.r && r < t.r + t.h;
				});
				if (taken) continue;
				const wlr_box cb = tile_box(CcTile{"", c, r, 1, 1});
				fill_rounded(cr, cb.x + 3, cb.y + 3, cb.width - 6, cb.height - 6,
					std::min<double>(card_radius(), cb.width / 2.0) - 3, with_alpha(theme::text, 0.05));
			}
		}
	}
	for (const CcTile &t : layout_) {
		if (t.id == edit_tile_ && !edit_resize_) continue;   // drawn under the pointer below
		const wlr_box b = tile_box(t);
		draw_tile(cr, t, b, scale, false);
		if (editing_) {
			add_hot("mv:" + t.id, b.x, b.y, b.width, b.height, -2);
			// Hide: a small minus badge inside the top corner (OneUI-like).
			const double hx = b.x + b.width - 13, hy = b.y + 13;
			cairo_new_path(cr);
			cairo_arc(cr, hx, hy, 9, 0, 2 * M_PI);
			set_color(cr, theme::close_hover);
			cairo_fill(cr);
			set_color(cr, rgb(0xffffff));
			cairo_set_line_width(cr, 1.8);
			cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
			cairo_move_to(cr, hx - 3.5, hy);
			cairo_line_to(cr, hx + 3.5, hy);
			cairo_stroke(cr);
			add_hot("rm:" + t.id, hx - 12, hy - 12, 24, 24, 12);
			// Resize: a short rounded arc following the bottom corner.
			const double cr_r = std::min<double>(card_radius(), std::min(b.width, b.height) / 2.0);
			const double inset = 5, ar = std::max(6.0, cr_r - inset);
			const double rx = b.x + b.width - inset - ar, ry = b.y + b.height - inset - ar;
			set_color(cr, with_alpha(theme::text, 0.5));
			cairo_set_line_width(cr, 3);
			cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
			cairo_new_path(cr);
			cairo_arc(cr, rx, ry, ar, M_PI * 0.08, M_PI * 0.42);
			cairo_stroke(cr);
			const double rx2 = b.x + b.width - 5, ry2 = b.y + b.height - 5;
			add_hot("rs:" + t.id, rx2 - 22, ry2 - 22, 26, 26, -2);
		}
	}
	// A tile being moved: where it would land, and the tile under the pointer.
	if (editing_ && !edit_tile_.empty()) {
		const wlr_box tb = tile_box(edit_target_);
		rounded_rect(cr, tb.x + 1, tb.y + 1, tb.width - 2, tb.height - 2, card_radius());
		set_color(cr, with_alpha(edit_target_ok_ ? theme::accent : rgb(0xd7263d), 0.25));
		cairo_fill_preserve(cr);
		set_color(cr, edit_target_ok_ ? theme::accent : rgb(0xd7263d));
		cairo_set_line_width(cr, 2);
		cairo_stroke(cr);
		if (!edit_resize_) {
			for (const CcTile &t : layout_) {
				if (t.id != edit_tile_) continue;
				wlr_box b = tile_box(t);
				b.x = static_cast<int>(std::lround(edit_px_ - grab_dx_));
				b.y = static_cast<int>(std::lround(edit_py_ - grab_dy_));
				cairo_push_group(cr);
				draw_tile(cr, t, b, scale, true);
				cairo_pop_group_to_source(cr);
				cairo_paint_with_alpha(cr, 0.85);
			}
		}
	}
	y = grid_top_ + (rows > 0 ? static_cast<int>(std::lround(rows * cell_ + (rows - 1) * kGap)) : 0) + 16;
}

// In edit mode, under the grid: the tiles you hid, to add back.
void ControlCentre::draw_edit_tray(cairo_t *cr, int &y, float) {
	std::vector<const TileDef *> hidden;
	for (const TileDef &d : kTiles) {
		const bool shown = std::any_of(layout_.begin(), layout_.end(),
			[&d](const CcTile &t) { return t.id == d.id; });
		if (!shown && tile_available(server_, d.id)) hidden.push_back(&d);
	}
	draw_text(cr, hidden.empty() ? "Every tile is on the grid" : "Add a tile", kPad + 4, y, 300, 22,
		theme::font_small, theme::text_dim);
	y += 26;
	int x = kPad;
	for (const TileDef *d : hidden) {
		const std::string label = std::string("+  ") + d->name;
		const int w = text_width(label, theme::font_small) + 24;
		if (x + w > kWidth - kPad) {
			x = kPad;
			y += 36;
		}
		fill_rounded(cr, x, y, w, 30, 15, theme::tile_off);
		draw_text(cr, label, x, y, w, 30, theme::font_small, theme::text, Align::Center);
		add_hot(std::string("add:") + d->id, x, y, w, 30, 15);
		x += w + 8;
	}
	y += 40;
}

void ControlCentre::draw_detail(cairo_t *cr, int &y, int bottom, float scale) {
	SystemStatus &st = *server_->status;
	const bool wifi = page_ == Page::Wifi;

	// Header: back, title, rescan, on/off switch.
	if (const double h = hv("back"); h > 0.01) {
		cairo_new_path(cr);
		cairo_arc(cr, kPad + 18, y + 18, 18, 0, 2 * M_PI);
		set_color(cr, with_alpha(theme::text, 0.12 * h));
		cairo_fill(cr);
	}
	draw_named_icon(cr, server_->icons, "chevron-left", kPad + 9, y + 9, 18, theme::text, scale);
	add_hot("back", kPad, y, 36, 36, 18);
	draw_text(cr, wifi ? "Wi-Fi" : "Bluetooth", kPad + 44, y, 200, 36, theme::font_large, theme::text);
	const bool on = wifi ? st.wifi_enabled && !st.airplane : st.bt_powered;
	fx_.set("switch", on ? 1.0 : 0.0, on ? 1.0 : 0.0);
	draw_switch(cr, kWidth - kPad - 48, y + 6, fx_.get("switch"));
	add_hot("detail-switch", kWidth - kPad - 52, y, 52, 36, -2);
	const int rx = kWidth - kPad - 48 - 44;
	if (const double h = hv("rescan"); h > 0.01) {
		cairo_new_path(cr);
		cairo_arc(cr, rx + 16, y + 18, 16, 0, 2 * M_PI);
		set_color(cr, with_alpha(theme::text, 0.12 * h));
		cairo_fill(cr);
	}
	draw_named_icon(cr, server_->icons, "refresh", rx + 8, y + 10, 16,
		st.scanning ? theme::text_dim : theme::text, scale);
	add_hot("rescan", rx, y + 2, 32, 32, 16);
	y += 48;

	// Password entry for a new secured network.
	if (wifi && !password_for_.empty()) {
		const int w = kWidth - 2 * kPad;
		fill_rounded(cr, kPad, y, w, 104, 20, theme::card_bg);
		draw_text(cr, "Password for " + password_for_, kPad + 14, y + 8, w - 28, 22, theme::font_small,
			theme::text_dim);
		fill_rounded(cr, kPad + 12, y + 32, w - 24, 36, 18, theme::field_bg);
		std::string dots;
		for (size_t i = 0; i < password_.size(); i++) {
			dots += "•";
		}
		draw_text(cr, dots.empty() ? "Type the password" : dots, kPad + 26, y + 32, w - 120, 36,
			theme::font, dots.empty() ? theme::text_dim : theme::text);
		if (typing_) {
			const int cx = kPad + 26 + (dots.empty() ? 0 : text_width(dots, theme::font)) + 1;
			cairo_rectangle(cr, cx, y + 41, 2, 18);
			set_color(cr, theme::accent);
			cairo_fill(cr);
		}
		add_hot("password", kPad + 12, y + 32, w - 24, 36, -2);
		const int bw = 90;
		fill_rounded(cr, kPad + w - 12 - bw, y + 72, bw, 26, 13,
			connecting_ ? theme::tile_off : theme::accent);
		draw_text(cr, connecting_ ? "Connecting…" : "Connect", kPad + w - 12 - bw, y + 72, bw, 26,
			theme::font_small, connecting_ ? theme::text_dim : theme::on_accent, Align::Center);
		add_hot("connect", kPad + w - 12 - bw, y + 72, bw, 26, 13);
		if (!wifi_message_.empty()) {
			draw_text(cr, wifi_message_, kPad + 14, y + 72, w - bw - 36, 26, theme::font_small,
				rgb(0xe05a5a));
		}
		y += 116;
	} else if (!wifi_message_.empty()) {
		draw_text(cr, wifi_message_, kPad + 4, y, kWidth - 2 * kPad, 22, theme::font_small,
			theme::text_dim);
		y += 26;
	} else if (!wifi && !st.bt_message.empty()) {
		y += draw_paragraph(cr, st.bt_message, kPad + 4, y, kWidth - 2 * kPad, 2, theme::font_small,
			rgb(0xe05a5a)) + 8;
	}

	// The list.
	list_area_ = wlr_box{kPad, y, kWidth - 2 * kPad, bottom - y};
	const int row_h = 52;
	const int count = wifi ? static_cast<int>(st.networks.size()) : static_cast<int>(st.bt_devices.size());
	if (!on) {
		draw_text(cr, wifi ? "Wi-Fi is off" : "Bluetooth is off", kPad, y + 20, kWidth - 2 * kPad, 24,
			theme::font, theme::text_dim, Align::Center);
		return;
	}
	if (count == 0) {
		draw_text(cr, st.scanning ? "Searching…" : wifi ? "No networks found"
			: "No devices found. Put yours in pairing mode, then press refresh.",
			kPad, y + 20, kWidth - 2 * kPad, 40, theme::font_small, theme::text_dim, Align::Center);
		return;
	}
	cairo_save(cr);
	cairo_rectangle(cr, list_area_.x, list_area_.y, list_area_.width, list_area_.height);
	cairo_clip(cr);
	fx_.set("list", list_scroll_, 0);
	int ry = y - static_cast<int>(std::lround(fx_.get("list")));
	for (int i = 0; i < count; i++, ry += row_h + 6) {
		if (ry + row_h < list_area_.y || ry > list_area_.y + list_area_.height) {
			continue;
		}
		const std::string id = (wifi ? "net:" : "bt:") + std::to_string(i);
		std::string name, sub, icon;
		bool active = false;
		if (wifi) {
			const WifiNetwork &n = st.networks[static_cast<size_t>(i)];
			name = n.ssid;
			active = n.active;
			sub = n.active ? "Connected" : n.saved ? "Saved" : n.secure ? "Secured" : "Open";
			icon = wifi_icon(n.signal);
		} else {
			const BtDevice &d = st.bt_devices[static_cast<size_t>(i)];
			name = d.name;
			active = d.connected;
			const bool busy = st.bt_busy == d.address;
			sub = busy ? (d.paired ? (d.connected ? "Disconnecting…" : "Connecting…") : "Pairing…")
				: d.connected ? "Connected" : d.paired ? "Paired" : "Nearby · click to pair";
			icon = "bluetooth";
			// A line above the first nearby device.
			if (!d.paired && (i == 0 || st.bt_devices[static_cast<size_t>(i - 1)].paired)) {
				draw_text(cr, "NEARBY", kPad + 4, ry - 2, 200, 16, theme::font_small, theme::text_dim);
				ry += 18;
			}
		}
		fill_rounded(cr, kPad, ry, kWidth - 2 * kPad, row_h, card_radius(),
			active ? with_alpha(theme::accent, 0.22) : theme::card_bg);
		if (const double h = hv(id); h > 0.01) {
			fill_rounded(cr, kPad, ry, kWidth - 2 * kPad, row_h, card_radius(),
				with_alpha(theme::text, 0.06 * h));
		}
		draw_named_icon(cr, server_->icons, icon, kPad + 16, ry + row_h / 2.0 - 9, 18, theme::text, scale);
		draw_text(cr, name, kPad + 48, ry + 7, kWidth - 2 * kPad - 90, 20, theme::font, theme::text);
		draw_text(cr, sub, kPad + 48, ry + 27, kWidth - 2 * kPad - 90, 18, theme::font_small,
			active ? theme::accent : theme::text_dim);
		if (wifi && st.networks[static_cast<size_t>(i)].secure) {
			draw_named_icon(cr, server_->icons, "lock", kWidth - kPad - 34, ry + row_h / 2.0 - 7, 14,
				theme::text_dim, scale);
		}
		const int top = std::max(ry, list_area_.y);
		const int bot = std::min(ry + row_h, list_area_.y + list_area_.height);
		add_hot(id, kPad, top, kWidth - 2 * kPad, bot - top);
	}
	cairo_restore(cr);
	const bool nearby = !wifi && std::any_of(st.bt_devices.begin(), st.bt_devices.end(),
		[](const BtDevice &d) { return !d.paired; });
	list_max_scroll_ = std::max(0, count * (row_h + 6) - 6 + (nearby ? 18 : 0) - list_area_.height);
	list_scroll_ = std::clamp(list_scroll_, 0, list_max_scroll_);
}

// Notifications under the tiles, stacked by app like a phone (or one card
// each). Click a stack's count to open it up; hover a card for its ✕.
void ControlCentre::draw_notifications(cairo_t *cr, int y, int bottom, float scale) {
	if (bottom - y < 60) {
		return;
	}
	const Notifications *notes = server_->notifications.get();
	std::vector<const Notification *> items;
	if (notes) {
		for (const Notification &n : notes->list()) {
			if (!n.transient) items.push_back(&n);
		}
	}
	// Header: "Notifications · 3", then Settings and Clear.
	const std::string title = std::string("Notifications") +
		(items.empty() ? std::string() : "  ·  " + std::to_string(items.size()));
	draw_text(cr, title, kPad + 6, y, 220, 28, theme::font_bold, theme::text_dim);
	{
		int bx = kWidth - kPad;
		auto button = [&](const char *id, const char *label) {
			const int w = text_width(label, theme::font_small) + 22;
			bx -= w;
			fill_rounded(cr, bx, y + 1, w, 26, 13, theme::card_bg);
			draw_text(cr, label, bx, y + 1, w, 26, theme::font_small, theme::text, Align::Center);
			add_hot(id, bx, y + 1, w, 26, 13);
			bx -= 6;
		};
		if (!items.empty()) button("clear", "Clear");
		button("note-settings", "Settings");
	}
	y += 36;
	notes_area_ = wlr_box{kPad, y, kWidth - 2 * kPad, bottom - y};

	if (!notes || !notes->running()) {
		draw_text(cr, "Another app is showing notifications", kPad, y, kWidth - 2 * kPad, 40,
			theme::font_small, theme::text_dim, Align::Center);
		return;
	}
	if (items.empty()) {
		draw_named_icon(cr, server_->icons, "bell", kWidth / 2.0 - 14, y + 30, 28,
			with_alpha(theme::text_dim, 0.6), scale);
		draw_text(cr, "No notifications", kPad, y + 64, kWidth - 2 * kPad, 20, theme::font,
			theme::text_dim, Align::Center);
		return;
	}

	// Stacks: one per app, newest first.
	struct Group {
		std::string app;
		std::vector<const Notification *> notes;
	};
	std::vector<Group> groups;
	for (const Notification *n : items) {
		const std::string app = n->app.empty() ? "Notification" : n->app;
		auto it = std::find_if(groups.begin(), groups.end(), [&](const Group &g) { return g.app == app; });
		if (!server_->config.notif_group || it == groups.end()) {
			groups.push_back(Group{app, {n}});
		} else {
			it->notes.push_back(n);
		}
	}

	cairo_save(cr);
	cairo_rectangle(cr, notes_area_.x, notes_area_.y - 2, notes_area_.width, notes_area_.height + 2);
	cairo_clip(cr);
	const int w = kWidth - 2 * kPad;
	const int text_w = w - 24 - 40;
	fx_.set("notes", notes_scroll_, 0);
	int cy = y - static_cast<int>(std::lround(fx_.get("notes")));
	int total = 0;
	auto visible = [&](int top, int h) { return top + h > notes_area_.y && top < notes_area_.y + notes_area_.height; };
	auto hit = [&](const std::string &id, int top, int h, double radius) {
		const int t = std::max(top, notes_area_.y);
		const int b = std::min(top + h, notes_area_.y + notes_area_.height);
		if (b > t) add_hot(id, kPad, t, w, b - t, radius);
	};

	for (const Group &g : groups) {
		const bool stacked = g.notes.size() > 1;
		const bool opened = stacked && open_groups_.count(g.app);
		const size_t shown = opened ? g.notes.size() : 1;
		if (opened) {
			// The open stack's header: app, count, "Show less", ✕ all.
			if (visible(cy, 26)) {
				draw_text(cr, g.app + "  ·  " + std::to_string(g.notes.size()), kPad + 6, cy, w - 140, 26,
					theme::font_small, theme::text_dim);
				const int lw = 82;
				fill_rounded(cr, kPad + w - lw - 32, cy + 1, lw, 24, 12, theme::card_bg);
				draw_text(cr, "Show less", kPad + w - lw - 32, cy + 1, lw, 24, theme::font_small, theme::text,
					Align::Center);
				add_hot("grp:" + g.app, kPad + w - lw - 32, cy + 1, lw, 24, 12);
				cairo_new_path(cr);
				cairo_arc(cr, kPad + w - 12, cy + 13, 12, 0, 2 * M_PI);
				set_color(cr, theme::card_bg);
				cairo_fill(cr);
				draw_named_icon(cr, server_->icons, "close", kPad + w - 19, cy + 6, 14, theme::text, scale);
				add_hot("grpclose:" + g.app, kPad + w - 24, cy + 1, 24, 24, 12);
			}
			cy += 32;
			total += 32;
		}
		for (size_t i = 0; i < shown; i++) {
			const Notification *n = g.notes[i];
			const int sh = std::max(18, draw_paragraph(cr, n->summary, 0, 0, text_w, 2, theme::font_bold,
				theme::text, false));
			const int bh = draw_paragraph(cr, n->body, 0, 0, text_w, 3, theme::font, theme::text, false);
			const int h = 12 + 18 + 4 + sh + (bh ? 2 + bh : 0) + 12;
			const std::string id = "note:" + std::to_string(n->id);
			const std::string xid = "noteclose:" + std::to_string(n->id);
			const bool closed_stack = stacked && !opened;
			const int under = closed_stack ? std::min<int>(2, static_cast<int>(g.notes.size()) - 1) : 0;
			if (visible(cy, h + under * 6)) {
				// A closed stack shows the cards behind as edges peeking out.
				for (int k = under; k >= 1; k--) {
					fill_rounded(cr, kPad + 8 * k, cy + h - 20 + 6 * k, w - 16 * k, 20, card_radius() - 2,
						mix(theme::card_bg, theme::bg_alt, 0.35 * k));
				}
				fill_rounded(cr, kPad, cy, w, h, card_radius(), theme::card_bg);
				draw_notification_icon(cr, server_->icons, *n, kPad + 12, cy + 34, 30, scale);
				draw_text(cr, g.app + " · " + ago(n->time), kPad + 12, cy + 10, w - 100, 18, theme::font_small,
					theme::text_dim);
				draw_paragraph(cr, n->summary, kPad + 52, cy + 34, text_w, 2, theme::font_bold, theme::text);
				if (bh) {
					draw_paragraph(cr, n->body, kPad + 52, cy + 34 + sh + 2, text_w, 3, theme::font,
						theme::text_dim);
				}
				hit(id, cy, h, card_radius());
				int right = kPad + w - 10;
				if (closed_stack) {
					// The count: click to open the stack.
					const std::string count = "+" + std::to_string(g.notes.size() - 1);
					const int cw = text_width(count, theme::font_small) + 16;
					right -= cw;
					fill_rounded(cr, right, cy + 8, cw, 22, 11, with_alpha(theme::accent, 0.22));
					draw_text(cr, count, right, cy + 8, cw, 22, theme::font_small, theme::text, Align::Center);
					if (cy + 8 >= notes_area_.y) add_hot("grp:" + g.app, right, cy + 8, cw, 22, 11);
					right -= 6;
				}
				if (hover_ == id || hover_ == xid || hover_ == "grp:" + g.app) {
					const int bx = right - 24, by = cy + 7;
					cairo_new_path(cr);
					cairo_arc(cr, bx + 12, by + 12, 12, 0, 2 * M_PI);
					set_color(cr, theme::tile_off);
					cairo_fill(cr);
					draw_named_icon(cr, server_->icons, "close", bx + 5, by + 5, 14, theme::text, scale);
					// A closed stack's ✕ clears the whole stack.
					if (by >= notes_area_.y) {
						add_hot(closed_stack ? "grpclose:" + g.app : xid, bx, by, 24, 24, 12);
					}
				}
			}
			const int step = h + under * 6 + 8;
			cy += step;
			total += step;
		}
	}
	cairo_restore(cr);
	notes_max_scroll_ = std::max(0, total - 8 - notes_area_.height);
	notes_scroll_ = std::clamp(notes_scroll_, 0, notes_max_scroll_);
}

// ---- input ----------------------------------------------------------------------

void ControlCentre::motion(double lx, double ly) {
	if (!edit_tile_.empty()) {
		drag_edit(lx - box_.x, ly - box_.y);
		return;
	}
	if (!dragging_.empty()) {
		drag_slider(lx, ly);
		return;
	}
	const std::string now = hot_at(lx - box_.x, ly - box_.y);
	if (now != hover_) {
		// A notification shows its close button while pointed at; that needs
		// a redraw. Everything else is just the GPU highlight moving.
		auto noteish = [](const std::string &s) { return s.rfind("note", 0) == 0 || s.rfind("grp", 0) == 0; };
		const bool notes = noteish(now) || noteish(hover_);
		hover_ = now;
		if (notes) {
			redraw();
		} else {
			update_highlight();
		}
	}
}

void ControlCentre::leave() {
	if (!hover_.empty() && dragging_.empty() && edit_tile_.empty()) {
		const bool notes = hover_.rfind("note", 0) == 0 || hover_.rfind("grp", 0) == 0;
		hover_.clear();
		if (notes) {
			redraw();
		} else {
			update_highlight();
		}
	}
}

void ControlCentre::drag_slider(double lx, double ly) {
	const wlr_box &t = drag_track_;
	if (t.width <= 0 || t.height <= 0) {
		return;
	}
	const double px = lx - box_.x, py = ly - box_.y;
	const double f = drag_vertical_ ? 1.0 - (py - t.y) / t.height : (px - t.x) / t.width;
	const int value = static_cast<int>(std::lround(std::clamp(f, 0.0, 1.0) * 100));
	SystemStatus &st = *server_->status;
	if (dragging_ == "sl:volume") st.set_volume(value);
	else if (dragging_ == "sl:brightness") st.set_brightness(std::max(1, value));
	else if (dragging_ == "sl:mic") st.set_mic_volume(value);
}

// ---- edit mode: moving and resizing tiles ----

void ControlCentre::drag_edit(double px, double py) {
	edit_px_ = px;
	edit_py_ = py;
	auto self = std::find_if(layout_.begin(), layout_.end(), [this](const CcTile &t) { return t.id == edit_tile_; });
	if (self == layout_.end()) {
		return;
	}
	const double step = cell_ + kGap;
	CcTile target = *self;
	if (edit_resize_) {
		// The corner follows the pointer, as far as the free cells allow.
		const wlr_box b = tile_box(*self);
		target.w = std::clamp(static_cast<int>(std::lround((px - b.x + kGap) / step)), 1, kCols - self->c);
		target.h = std::clamp(static_cast<int>(std::lround((py - b.y + kGap) / step)), 1, 6);
		if (fits(layout_, target, self->id)) {
			self->w = target.w;
			self->h = target.h;
		}
		edit_target_ = *self;
		edit_target_ok_ = true;
	} else {
		target.c = std::clamp(static_cast<int>(std::lround((px - grab_dx_ - kPad) / step)), 0, kCols - self->w);
		target.r = std::clamp(static_cast<int>(std::lround((py - grab_dy_ - grid_top_) / step)), 0,
			kMaxRows - self->h);
		edit_target_ = target;
		edit_target_ok_ = fits(layout_, target, self->id);
		if (!edit_target_ok_) {
			// Onto one tile that can take this one's old place: they swap.
			const CcTile *other = nullptr;
			int count = 0;
			for (const CcTile &o : layout_) {
				if (o.id != self->id && overlaps(o, target)) {
					other = &o;
					count++;
				}
			}
			if (count == 1) {
				CcTile moved = *other;
				moved.c = self->c;
				moved.r = self->r;
				edit_target_ok_ = fits(layout_, moved, self->id, other->id) &&
					fits(layout_, target, self->id, other->id) && !overlaps(moved, target);
			}
		}
	}
	redraw();
}

void ControlCentre::end_edit_drag() {
	auto self = std::find_if(layout_.begin(), layout_.end(), [this](const CcTile &t) { return t.id == edit_tile_; });
	if (self != layout_.end() && !edit_resize_ && edit_target_ok_) {
		const CcTile target = edit_target_;
		for (CcTile &o : layout_) {
			if (o.id != self->id && overlaps(o, target)) {
				o.c = self->c;   // the swap
				o.r = self->r;
			}
		}
		self->c = target.c;
		self->r = target.r;
	}
	edit_tile_.clear();
	edit_resize_ = false;
	server_->cc_grab = false;
	save_layout();
	redraw();
}

void ControlCentre::save_layout() {
	server_->write_setting("cc_layout", serialise(layout_));
}

void ControlCentre::press(double lx, double ly, uint32_t button) {
	const double px = lx - box_.x, py = ly - box_.y;
	const std::string id = hot_at(px, py);
	auto starts = [&](const char *p) { return id.rfind(p, 0) == 0; };
	if (button == BTN_RIGHT) {
		if (starts("ti:") || starts("tm:") || starts("sl:")) {
			tile_more(id.substr(3), lx, ly);
		} else if (starts("bt:")) {
			// A paired device: connect or disconnect, or forget it.
			SystemStatus &st = *server_->status;
			const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 3));
			if (i < st.bt_devices.size() && st.bt_devices[i].paired) {
				const BtDevice d = st.bt_devices[i];
				Server *srv = server_;
				std::vector<MenuItem> items;
				items.push_back(MenuItem::header(d.name));
				items.push_back(MenuItem::action(d.connected ? "Disconnect" : "Connect",
					[srv, d] { srv->status->connect_bluetooth(d); }));
				MenuItem forget = MenuItem::action("Forget this device",
					[srv, d] { srv->status->forget_bluetooth(d); });
				forget.danger = true;
				items.push_back(forget);
				srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1},
					"point", std::move(items));
			}
		} else if (page_ == Page::Tiles) {
			show_menu(lx, ly);
		}
		return;
	}
	if (button != BTN_LEFT) {
		return;
	}
	if (starts("sl:")) {
		dragging_ = id;
		server_->cc_grab = true;
		for (const CcTile &t : layout_) {
			if ("sl:" + t.id == id) {
				drag_track_ = tile_box(t);
				drag_vertical_ = t.h > t.w;
			}
		}
		drag_slider(lx, ly);
		return;
	}
	if (starts("mv:") || starts("rs:")) {
		edit_tile_ = id.substr(3);
		edit_resize_ = starts("rs:");
		for (const CcTile &t : layout_) {
			if (t.id == edit_tile_) {
				const wlr_box b = tile_box(t);
				grab_dx_ = px - b.x;
				grab_dy_ = py - b.y;
				edit_target_ = t;
				edit_target_ok_ = true;
			}
		}
		server_->cc_grab = true;
		drag_edit(px, py);
		return;
	}
	if (id != "password" && typing_) {
		typing_ = false;
	}
	if (!id.empty()) {
		hl_.flash();
	}
	activate(id);
}

void ControlCentre::release() {
	if (!edit_tile_.empty()) {
		end_edit_drag();
		return;
	}
	dragging_.clear();
	server_->cc_grab = false;
	redraw();
}

void ControlCentre::scroll(double lx, double ly, double delta) {
	const double px = lx - box_.x, py = ly - box_.y;
	const int step = static_cast<int>(std::lround(delta * 3));
	if (page_ == Page::Tiles && inside(notes_area_, px, py)) {
		notes_scroll_ = std::clamp(notes_scroll_ + step, 0, notes_max_scroll_);
		redraw();
	} else if (page_ != Page::Tiles && inside(list_area_, px, py)) {
		list_scroll_ = std::clamp(list_scroll_ + step, 0, list_max_scroll_);
		redraw();
	} else {
		// Over a slider tile: the wheel changes it.
		const std::string id = hot_at(px, py);
		const int change = delta < 0 ? 5 : -5;
		SystemStatus &st = *server_->status;
		if (id == "sl:volume") st.set_volume(st.volume + change);
		else if (id == "sl:brightness") st.set_brightness(st.brightness + change);
		else if (id == "sl:mic") st.set_mic_volume(st.mic_volume + change);
	}
}

void ControlCentre::open_page(Page page) {
	SystemStatus &st = *server_->status;
	page_ = page;
	list_scroll_ = 0;
	fx_.snap("list", 0);
	fx_.snap("page", 1);
	fx_.set("page", 0);
	password_for_.clear();
	wifi_message_.clear();
	if (page_ == Page::Wifi) {
		st.scan_wifi();
	} else if (page_ == Page::Bluetooth) {
		st.scan_bluetooth();
	}
	redraw();
}

// A tile's main click: switch it, or do it.
void ControlCentre::tile_action(const std::string &t) {
	SystemStatus &st = *server_->status;
	const Config &c = server_->config;
	fx_.snap("press:" + t, 1);
	fx_.set("press:" + t, 0);
	if (t == "wifi") st.toggle_wifi();
	else if (t == "bluetooth") st.toggle_bluetooth();
	else if (t == "sound") st.toggle_mute();
	else if (t == "airplane") st.toggle_airplane();
	else if (t == "caffeine") st.toggle_caffeine();
	else if (t == "power") st.cycle_power_profile();
	else if (t == "battery") st.cycle_power_profile();
	else if (t == "dark") server_->write_setting("theme", c.dark ? "light" : "dark");
	else if (t == "nightlight") server_->write_setting("night_light", c.night_light ? "false" : "true");
	else if (t == "dnd") server_->write_setting("dnd", c.dnd ? "false" : "true");
	else if (t == "screenshot") {
		// After the control centre has slid away, so it isn't in the picture.
		close();
		Server *srv = server_;
		// The screenshot tool, once the control centre has gone.
		srv->run_then("sleep 0.3", [srv](bool) { srv->screenshot("tool"); });
		return;
	}
	redraw();
}

// The rest of a tile (or a right-click): Wi-Fi and Bluetooth open their
// lists; the others their options.
void ControlCentre::tile_more(const std::string &t, double lx, double ly) {
	if (t == "wifi" && server_->status->wifi_available) {
		open_page(Page::Wifi);
	} else if (t == "bluetooth" && server_->status->bt_available) {
		open_page(Page::Bluetooth);
	} else {
		show_tile_menu(t, lx, ly);
	}
}

void ControlCentre::show_tile_menu(const std::string &tile, double lx, double ly) {
	Server *srv = server_;
	const Config &c = srv->config;
	SystemStatus &st = *srv->status;
	std::vector<MenuItem> items;
	auto set = [srv](std::string key, std::string value) {
		return [srv, key, value] { srv->write_setting(key, value); };
	};
	if (tile == "dark") {
		items.push_back(MenuItem::radio("Dark", c.dark, set("theme", "dark")));
		items.push_back(MenuItem::radio("Light", !c.dark, set("theme", "light")));
	} else if (tile == "nightlight") {
		items.push_back(MenuItem::check("Night light", c.night_light,
			set("night_light", c.night_light ? "false" : "true")));
		items.push_back(MenuItem::header("Warmth"));
		for (const auto &[label, k] : std::vector<std::pair<std::string, int>>{
				{"A little", 5500}, {"Medium", 4300}, {"Warm", 3400}, {"Very warm", 2700}}) {
			items.push_back(MenuItem::radio(label, std::abs(c.night_light_temp - k) < 300, [srv, k = k] {
				Config::write_key("night_light", "true");
				srv->write_setting("night_light_temp", std::to_string(k));
			}));
		}
	} else if (tile == "dnd") {
		items.push_back(MenuItem::check("Do not disturb", c.dnd, set("dnd", c.dnd ? "false" : "true")));
		items.push_back(MenuItem::action("Clear notifications", [srv] {
			if (srv->notifications) srv->notifications->clear_all();
		}));
		items.push_back(MenuItem::action("Notification settings…", [srv] { srv->open_settings("notifications"); }));
	} else if (tile == "power" || tile == "battery") {
		if (tile == "battery") {
			items.push_back(MenuItem::header(std::to_string(st.battery) + "%, " + battery_words(st)));
		}
		for (const auto &[label, p] : std::vector<std::pair<std::string, std::string>>{
				{"Power saver", "power-saver"}, {"Balanced", "balanced"}, {"Performance", "performance"}}) {
			if (!st.power_profile.empty()) {
				items.push_back(MenuItem::radio(label, st.power_profile == p,
					[srv, p = p] { srv->status->set_power_profile(p); }));
			}
		}
		items.push_back(MenuItem::action("Power settings…", [srv] { srv->open_settings("power"); }));
	} else if (tile == "caffeine") {
		items.push_back(MenuItem::check("Keep the screen awake", st.caffeine, [srv] { srv->status->toggle_caffeine(); }));
	} else if (tile == "airplane") {
		items.push_back(MenuItem::check("Airplane mode", st.airplane, [srv] { srv->status->toggle_airplane(); }));
	} else if (tile == "sound" || tile == "volume") {
		items.push_back(MenuItem::check("Mute", st.muted, [srv] { srv->status->toggle_mute(); }));
	} else if (tile == "mic") {
		items.push_back(MenuItem::check("Mute microphone", st.mic_muted, [srv] { srv->status->toggle_mic(); }));
	} else if (tile == "screenshot") {
		items.push_back(MenuItem::action("Screenshot tool…", [this] { tile_action("screenshot"); }, "area"));
		items.push_back(MenuItem::action("This screen", [srv] {
			srv->control_centre->close();
			srv->run_then("sleep 0.35", [srv](bool) { srv->screenshot("screen"); });
		}, "display"));
		items.push_back(MenuItem::action("All screens", [srv] {
			srv->control_centre->close();
			srv->run_then("sleep 0.35", [srv](bool) { srv->screenshot("all"); });
		}));
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Screenshot settings…", [srv] { srv->open_settings("screenshots"); }, "gear"));
	} else if (tile == "media") {
		items.push_back(MenuItem::action("Play / pause", [srv] { srv->status->media("play-pause"); }));
		items.push_back(MenuItem::action("Next", [srv] { srv->status->media("next"); }));
		items.push_back(MenuItem::action("Previous", [srv] { srv->status->media("previous"); }));
	}
	if ((tile == "sound" || tile == "volume" || tile == "mic")) {
		for (const char *mixer : {"pwvucontrol", "pavucontrol"}) {
			if (access((std::string("/usr/bin/") + mixer).c_str(), X_OK) == 0) {
				items.push_back(MenuItem::action("Sound settings…", [srv, m = std::string(mixer)] { srv->spawn(m); }));
				break;
			}
		}
	}
	if (!items.empty()) items.push_back(MenuItem::separator());
	items.push_back(MenuItem::action("Edit tiles", [this] {
		editing_ = true;
		redraw();
	}, "edit"));
	MenuItem hide = MenuItem::action("Hide this tile", [this, tile] {
		layout_.erase(std::remove_if(layout_.begin(), layout_.end(),
			[&tile](const CcTile &t) { return t.id == tile; }), layout_.end());
		save_layout();
	});
	hide.danger = true;
	items.push_back(hide);
	srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point",
		std::move(items));
}

void ControlCentre::show_menu(double lx, double ly) {
	Server *srv = server_;
	const Config &c = srv->config;
	std::vector<MenuItem> items;
	items.push_back(MenuItem::action("Edit tiles", [this] {
		editing_ = true;
		redraw();
	}, "edit"));
	items.push_back(MenuItem::check("Notifications", c.cc_notifications,
		[srv, on = c.cc_notifications] { srv->write_setting("cc_notifications", on ? "false" : "true"); }));
	items.push_back(MenuItem::check("Stack notifications by app", c.notif_group,
		[srv, on = c.notif_group] { srv->write_setting("notif_group", on ? "false" : "true"); }));
	items.push_back(MenuItem::header("Opens on the"));
	for (const auto &[label, side] : std::vector<std::pair<std::string, std::string>>{
			{"Side of its button", "auto"}, {"Left", "left"}, {"Right", "right"}}) {
		items.push_back(MenuItem::radio(label, c.cc_side == side, [srv, s = side] { srv->write_setting("cc_side", s); }));
	}
	items.push_back(MenuItem::separator());
	items.push_back(MenuItem::action("Control centre settings…", [srv] { srv->open_settings("controlcentre"); }, "gear"));
	srv->menu->show(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point",
		std::move(items));
}

// Power: the same menu as the app menu's power button (power_actions).
void ControlCentre::show_power_menu(double lx, double ly) {
	server_->show_power_menu(output_, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point");
}

void ControlCentre::activate(const std::string &id) {
	SystemStatus &st = *server_->status;
	auto starts = [&](const char *p) { return id.rfind(p, 0) == 0; };
	if (id.empty()) {
		return;
	}
	if (id == "settings") {
		close();
		server_->open_settings();
		return;
	}
	if (id == "me") {
		close();
		server_->open_settings("about");
		return;
	}
	if (id == "power") {
		const wlr_box b = [&] {
			for (const Hot &h : hots_) if (h.id == "power") return h.box;
			return wlr_box{};
		}();
		show_power_menu(box_.x + b.x, box_.y + b.y + b.height);
		return;
	}
	if (id == "edit" || id == "edit-done") {
		editing_ = id == "edit" ? !editing_ : false;
	} else if (id == "edit-reset") {
		layout_ = default_layout(server_);
		server_->write_setting("cc_layout", "");
	} else if (starts("rm:")) {
		const std::string t = id.substr(3);
		layout_.erase(std::remove_if(layout_.begin(), layout_.end(),
			[&t](const CcTile &x) { return x.id == t; }), layout_.end());
		save_layout();
	} else if (starts("add:")) {
		// Into the first free place, row by row.
		const TileDef *d = tile_def(id.substr(4));
		if (d) {
			CcTile t{d->id, 0, 0, d->w, d->h};
			bool placed = false;
			for (int r = 0; r < kMaxRows && !placed; r++) {
				for (int c = 0; c + t.w <= kCols && !placed; c++) {
					t.c = c;
					t.r = r;
					placed = fits(layout_, t, "");
				}
			}
			if (!placed) {
				t.w = t.h = 1;
				for (int r = 0; r < kMaxRows && !placed; r++) {
					for (int c = 0; c < kCols && !placed; c++) {
						t.c = c;
						t.r = r;
						placed = fits(layout_, t, "");
					}
				}
			}
			if (placed) {
				layout_.push_back(t);
				save_layout();
			}
		}
	} else if (starts("ti:")) {
		tile_action(id.substr(3));
		return;
	} else if (starts("tm:")) {
		const Hot *h = nullptr;
		for (const Hot &x : hots_) if (x.id == id) h = &x;
		tile_more(id.substr(3), box_.x + (h ? h->box.x + h->box.width / 2 : 0),
			box_.y + (h ? h->box.y + h->box.height : 0));
		return;
	} else if (starts("pp:")) {
		// A power mode button on the battery tile.
		st.set_power_profile(id.substr(3));
	} else if (starts("mp:")) {
		st.media(id.substr(3).c_str());
	} else if (id == "back") {
		page_ = Page::Tiles;
		fx_.snap("page", 1);
		fx_.set("page", 0);
		typing_ = false;
		password_for_.clear();
	} else if (id == "detail-switch") {
		if (page_ == Page::Wifi) {
			if (st.airplane) st.toggle_airplane();
			else st.toggle_wifi();
		} else {
			st.toggle_bluetooth();
		}
	} else if (id == "rescan") {
		if (page_ == Page::Wifi) st.scan_wifi();
		else st.scan_bluetooth();
	} else if (id == "password") {
		typing_ = true;
	} else if (id == "connect") {
		handle_key(XKB_KEY_Return, "");
		return;
	} else if (starts("net:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 4));
		if (i < st.networks.size() && !connecting_) {
			const WifiNetwork n = st.networks[i];
			if (n.active) {
				return;
			}
			if (n.secure && !n.saved) {
				password_for_ = n.ssid;
				password_.clear();
				typing_ = true;
				wifi_message_.clear();
			} else {
				connecting_ = true;
				wifi_message_ = "Connecting to " + n.ssid + "…";
				st.connect_wifi(n, "", [this, n](bool ok, std::string reason) {
					connecting_ = false;
					if (ok) {
						wifi_message_.clear();
					} else if (reason == "password") {
						password_for_ = n.ssid;
						password_.clear();
						typing_ = true;
						wifi_message_ = "Wrong or missing password";
					} else {
						wifi_message_ = "Couldn't connect to " + n.ssid;
					}
					server_->status->scan_wifi();
					redraw();
				});
			}
		}
	} else if (starts("bt:")) {
		const size_t i = static_cast<size_t>(std::atoi(id.c_str() + 3));
		if (i < st.bt_devices.size()) {
			st.connect_bluetooth(st.bt_devices[i]);
		}
	} else if (id == "clear") {
		if (server_->notifications) server_->notifications->clear_all();
		notes_scroll_ = 0;
		open_groups_.clear();
	} else if (id == "note-settings") {
		close();
		server_->open_settings("notifications");
		return;
	} else if (starts("grpclose:")) {
		const std::string app = id.substr(9);
		if (Notifications *n = server_->notifications.get()) {
			std::vector<uint32_t> ids;
			for (const Notification &x : n->list()) {
				if ((x.app.empty() ? "Notification" : x.app) == app) ids.push_back(x.id);
			}
			for (uint32_t nid : ids) n->dismiss(nid);
		}
		open_groups_.erase(app);
	} else if (starts("grp:")) {
		const std::string app = id.substr(4);
		if (!open_groups_.erase(app)) open_groups_.insert(app);
	} else if (starts("noteclose:")) {
		if (server_->notifications) {
			server_->notifications->dismiss(static_cast<uint32_t>(std::strtoul(id.c_str() + 10, nullptr, 10)));
		}
	} else if (starts("note:")) {
		if (server_->notifications) {
			server_->notifications->activate(static_cast<uint32_t>(std::strtoul(id.c_str() + 5, nullptr, 10)));
		}
	}
	redraw();
}

bool ControlCentre::handle_key(xkb_keysym_t sym, const std::string &text) {
	if (sym == XKB_KEY_Escape) {
		if (typing_) {
			typing_ = false;
			password_for_.clear();
			redraw();
		} else {
			close();
		}
		return true;
	}
	if (!typing_) {
		return false;
	}
	if (sym == XKB_KEY_Return || sym == XKB_KEY_KP_Enter) {
		if (password_.empty() || connecting_) {
			return true;
		}
		WifiNetwork n;
		for (const WifiNetwork &w : server_->status->networks) {
			if (w.ssid == password_for_) {
				n = w;
			}
		}
		n.ssid = password_for_;
		connecting_ = true;
		wifi_message_.clear();
		const std::string password = password_;
		server_->status->connect_wifi(n, password, [this](bool ok, std::string) {
			connecting_ = false;
			if (ok) {
				password_for_.clear();
				password_.clear();
				typing_ = false;
				wifi_message_.clear();
			} else {
				wifi_message_ = "Couldn't connect";
			}
			server_->status->scan_wifi();
			redraw();
		});
		redraw();
		return true;
	}
	if (sym == XKB_KEY_BackSpace) {
		if (!password_.empty()) {
			size_t cut = password_.size() - 1;
			while (cut > 0 && (static_cast<unsigned char>(password_[cut]) & 0xc0) == 0x80) {
				cut--;
			}
			password_.erase(cut);
		}
	} else if (!text.empty() && static_cast<unsigned char>(text[0]) >= 0x20 && text[0] != 0x7f) {
		password_ += text;
	}
	redraw();
	return true;
}

} // namespace dusk
