#include "mediaview.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <unistd.h>

#include "anim.hpp"
#include "audiolevel.hpp"
#include "glyphs.hpp"
#include "lyrics.hpp"
#include "popover.hpp"
#include "server.hpp"
#include "system.hpp"

namespace dusk {

std::string media_clock(double seconds) {
	const long s = std::max(0L, static_cast<long>(seconds));
	char buf[24];
	if (s >= 3600) {
		std::snprintf(buf, sizeof buf, "%ld:%02ld:%02ld", s / 3600, s / 60 % 60, s % 60);
	} else {
		std::snprintf(buf, sizeof buf, "%ld:%02ld", s / 60, s % 60);
	}
	return buf;
}

namespace {

// "spotify" -> "Spotify"; browsers' instance names ("firefox.instance_2_31") cut short.
std::string player_label(const std::string &player) {
	if (player.empty()) return "This computer";
	std::string p = player.substr(0, player.find('.'));
	static const std::pair<const char *, const char *> kNames[] = {
		{"firefox", "Firefox"}, {"chromium", "Chromium"}, {"chrome", "Chrome"}, {"brave", "Brave"},
		{"spotify", "Spotify"}, {"vlc", "VLC"}, {"mpv", "mpv"}, {"rhythmbox", "Rhythmbox"},
		{"elisa", "Elisa"}, {"amberol", "Amberol"}, {"io", "Music"}, {"edge", "Edge"}, {"msedge", "Edge"},
	};
	for (const auto &[k, v] : kNames) {
		if (p == k) return v;
	}
	if (!p.empty()) p[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(p[0])));
	return p;
}

// The title: a step bigger than text, semibold (like Samsung's).
const char *title_font() {
	static std::string f;
	std::string fam = theme::font_store[0];
	const size_t sp = fam.rfind(' ');
	double size = 10;
	if (sp != std::string::npos) {
		size = std::atof(fam.c_str() + sp + 1);
		fam = fam.substr(0, sp);
	}
	char buf[32];
	std::snprintf(buf, sizeof buf, " Semibold %.1f", size + 2);
	f = fam + buf;
	return f.c_str();
}

void paint_cover(cairo_t *cr, cairo_surface_t *img, double x, double y, double w, double h) {
	const double iw = cairo_image_surface_get_width(img), ih = cairo_image_surface_get_height(img);
	const double s = std::max(w / iw, h / ih);
	cairo_save(cr);
	cairo_translate(cr, x + (w - iw * s) / 2, y + (h - ih * s) / 2);
	cairo_scale(cr, s, s);
	cairo_set_source_surface(cr, img, 0, 0);
	cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
	cairo_pattern_set_extend(cairo_get_source(cr), CAIRO_EXTEND_PAD);
	cairo_paint(cr);
	cairo_restore(cr);
}

// The art, or a quiet placeholder, in a rounded square.
void draw_thumb(cairo_t *cr, IconLoader &icons, cairo_surface_t *art, double x, double y, double s, double r,
		const Color &bg, const Color &fg, float scale) {
	cairo_save(cr);
	rounded_rect(cr, x, y, s, s, r);
	cairo_clip(cr);
	if (art) {
		paint_cover(cr, art, x, y, s, s);
	} else {
		set_color(cr, bg);
		cairo_paint(cr);
		const double is = s * 0.42;
		draw_named_icon(cr, icons, "disc-3", x + (s - is) / 2, y + (s - is) / 2, is, fg, scale);
	}
	cairo_restore(cr);
}

} // namespace

MediaView::MediaView(Server *server) : server_(server) {}

MediaView::~MediaView() {
	set_shown(false);
	if (art_bg_) cairo_surface_destroy(art_bg_);
	if (art_) cairo_surface_destroy(art_);
}

void MediaView::set_shown(bool shown) {
	shown_ = shown;
	const bool want = shown && server_->status && server_->status->media_playing &&
		server_->config.media_wave_beat && server_->audio_level;
	if (want != listening_) {
		listening_ = want;
		if (want) server_->audio_level->acquire();
		else if (server_->audio_level) server_->audio_level->release();
	}
}

void MediaView::load_art(float scale) {
	const SystemStatus &st = *server_->status;
	const int px = static_cast<int>(std::lround(120 * scale));
	if (st.media_art == art_path_ && art_px_ >= px) return;
	art_path_ = st.media_art;
	art_px_ = px;
	if (art_bg_) cairo_surface_destroy(art_bg_);
	if (art_) cairo_surface_destroy(art_);
	art_bg_ = art_ = nullptr;
	if (!art_path_.empty()) {
		art_ = load_image_sized(art_path_, px, px);
		art_bg_ = load_image_sized(art_path_, 40, 40);   // stretched over the card: soft
	}
}

double MediaView::position() const {
	const SystemStatus &st = *server_->status;
	if (drag_s_ >= 0) return drag_s_;
	double p = st.media_position;
	if (st.media_playing) p += (now_ms() - st.media_read_at) / 1000.0;
	return st.media_length > 0 ? std::clamp(p, 0.0, st.media_length) : std::max(0.0, p);
}

void MediaView::drag(double x) {
	const SystemStatus &st = *server_->status;
	if (st.media_length <= 0 || seek_.width <= 0) return;
	drag_s_ = std::clamp((x - seek_.x) / seek_.width, 0.0, 1.0) * st.media_length;
}

void MediaView::end_drag() {
	if (drag_s_ >= 0) server_->status->seek(drag_s_);
	drag_s_ = -1;
}

bool MediaView::moving() const {
	const SystemStatus &st = *server_->status;
	return shown_ && st.media_available && (st.media_playing || marquee_on_ || amp_ > 0.05);
}

bool MediaView::step(double dt) {
	const SystemStatus &st = *server_->status;
	set_shown(shown_);   // starts / stops listening as playback starts and stops
	if (!shown_ || !st.media_available) return false;
	dt = std::min(dt, 100.0);
	const bool anim = server_->config.animations;
	AudioLevel *al = server_->audio_level.get();
	const bool live = listening_ && al && al->live();
	const double target_level = live ? al->level() : 0;
	level_ += (target_level - level_) * std::min(1.0, dt / 60.0);
	double target_amp = 0;
	if (st.media_playing && anim) {
		target_amp = live ? 1.2 + 5.2 * level_ + 2.6 * al->beat() : 3.0;
	}
	amp_ += (target_amp - amp_) * std::min(1.0, dt / (target_amp > amp_ ? 45.0 : 120.0));
	if (st.media_playing && anim) phase_ += dt / 1000.0 * (1.1 + 2.4 * level_);

	if (marquee_on_ && anim) {
		if (marquee_wait_ > 0) {
			marquee_wait_ -= dt;
		} else {
			marquee_off_ += dt / 1000.0 * 34;
			if (marquee_off_ >= marquee_w_ + 48) {
				marquee_off_ = 0;
				marquee_wait_ = 2200;
			}
		}
	}
	return moving();
}

// The title: as it is when it fits; otherwise sliding along, faded at the ends.
void MediaView::draw_title(cairo_t *cr, const std::string &text, double x, double y, double w, double h,
		const char *font, const Color &color) {
	if (text != marquee_text_) {
		marquee_text_ = text;
		marquee_off_ = 0;
		marquee_wait_ = 2200;
	}
	const int tw = text_width(text, font);
	marquee_w_ = tw;
	marquee_on_ = server_->config.media_marquee && tw > w + 1;
	if (!marquee_on_) {
		draw_text(cr, text, x, y, w, h, font, color);
		return;
	}
	cairo_save(cr);
	cairo_rectangle(cr, x, y, w, h);
	cairo_clip(cr);
	cairo_push_group(cr);
	const double gap = 48;
	draw_text(cr, text, x - marquee_off_, y, tw + 4, h, font, color);
	draw_text(cr, text, x - marquee_off_ + tw + gap, y, tw + 4, h, font, color);
	cairo_pop_group_to_source(cr);
	// Soft edges: the text fades out at the right, and at the left while moving.
	cairo_pattern_t *mask = cairo_pattern_create_linear(x, 0, x + w, 0);
	const double edge = std::min(0.12, 18.0 / w);
	cairo_pattern_add_color_stop_rgba(mask, 0, 0, 0, 0, marquee_off_ > 0.5 ? 0 : 1);
	cairo_pattern_add_color_stop_rgba(mask, edge, 0, 0, 0, 1);
	cairo_pattern_add_color_stop_rgba(mask, 1 - edge, 0, 0, 0, 1);
	cairo_pattern_add_color_stop_rgba(mask, 1, 0, 0, 0, 0);
	cairo_mask(cr, mask);
	cairo_pattern_destroy(mask);
	cairo_restore(cr);
}

// The progress line: a wave for the part played (its height moves with the
// music), a plain line for the rest, and a knob where it is now.
void MediaView::draw_wave(cairo_t *cr, double x0, double y, double w, const Color &played, const Color &rest,
		std::vector<MediaHot> *hots) {
	const SystemStatus &st = *server_->status;
	seek_ = wlr_box{static_cast<int>(x0), static_cast<int>(y - 12), static_cast<int>(w), 24};
	const double frac = st.media_length > 0 ? std::clamp(position() / st.media_length, 0.0, 1.0) : 0;
	const double kx = x0 + w * frac;
	cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
	set_color(cr, rest);
	cairo_set_line_width(cr, 3);
	cairo_move_to(cr, std::min(kx + 7, x0 + w), y);
	cairo_line_to(cr, x0 + w, y);
	cairo_stroke(cr);
	if (kx > x0 + 1) {
		cairo_move_to(cr, x0, y);
		const double len = 26;   // one wave
		for (double x = x0; x <= kx - 4; x += 1.25) {
			// Calm right at both ends, so it starts and meets the knob smoothly.
			const double ends = std::min(1.0, std::min(x - x0, kx - x) / 10.0);
			cairo_line_to(cr, x, y + amp_ * ends * std::sin((x - x0) / len * 2 * M_PI - phase_ * 2 * M_PI));
		}
		cairo_line_to(cr, kx, y);
		set_color(cr, played);
		cairo_set_line_width(cr, 3.2);
		cairo_stroke(cr);
	}
	// Samsung's knob: a short upright pill.
	const double kh = dragging() ? 20 : 16;
	fill_rounded(cr, kx - 3, y - kh / 2, 6, kh, 3, played);
	if (hots && st.media_length > 0) {
		hots->push_back(MediaHot{"mp:seek", wlr_box{static_cast<int>(x0 - 8), static_cast<int>(y - 14),
			static_cast<int>(w + 16), 28}, -1});
	}
}

void MediaView::draw(cairo_t *cr, double x, double y, double w, double h, double radius, float scale, Look look,
		std::vector<MediaHot> *hots) {
	load_art(scale);
	if (look == Look::Samsung) {
		draw_samsung(cr, x, y, w, h, radius, scale, hots);
	} else {
		draw_plain(cr, x, y, w, h, radius, scale, look, hots);
	}
}

void MediaView::draw_samsung(cairo_t *cr, double x, double y, double w, double h, double r, float scale,
		std::vector<MediaHot> *hots) {
	const SystemStatus &st = *server_->status;
	IconLoader &icons = server_->icons;
	const Color white = rgb(0xffffff), soft = rgb(0xffffff, 0.72);

	// The art fills the card, softened and darkened so white reads on it.
	cairo_save(cr);
	rounded_rect(cr, x, y, w, h, r);
	cairo_clip(cr);
	if (art_bg_ && st.media_available) {
		paint_cover(cr, art_bg_, x - 6, y - 6, w + 12, h + 12);
	} else {
		const Color &a = theme::accent;
		cairo_pattern_t *g = cairo_pattern_create_linear(x, y, x + w, y + h);
		cairo_pattern_add_color_stop_rgb(g, 0, a.r * 0.62, a.g * 0.62, a.b * 0.66);
		cairo_pattern_add_color_stop_rgb(g, 1, a.r * 0.26, a.g * 0.26, a.b * 0.32);
		cairo_set_source(cr, g);
		cairo_paint(cr);
		cairo_pattern_destroy(g);
	}
	cairo_pattern_t *shade = cairo_pattern_create_linear(0, y, 0, y + h);
	cairo_pattern_add_color_stop_rgba(shade, 0, 0, 0, 0, 0.30);
	cairo_pattern_add_color_stop_rgba(shade, 1, 0, 0, 0, 0.58);
	cairo_set_source(cr, shade);
	cairo_paint(cr);
	cairo_pattern_destroy(shade);
	cairo_restore(cr);

	const bool lyrics = server_->lyrics && server_->config.lyrics && st.media_available;
	const bool found = lyrics && server_->lyrics->available();
	const std::string title = st.media_available ? (st.media_title.empty() ? "Playing" : st.media_title)
		: "Nothing playing";
	const double pad = h >= 140 ? 18 : 14;

	auto control_row = [&](double cx, double cy, double gap, double big, double small) {
		if (!st.media_available) return;
		const struct {
			const char *id, *icon;
			double dx, size;
		} kButtons[] = {
			{"mp:previous", "previous", -gap, small},
			{"mp:play-pause", st.media_playing ? "pause" : "play", 0, big},
			{"mp:next", "next", gap, small},
		};
		for (const auto &b : kButtons) {
			draw_named_icon(cr, icons, b.icon, cx + b.dx - b.size / 2, cy - b.size / 2, b.size, white, scale);
			if (hots) {
				const double hit = b.size + 18;
				hots->push_back(MediaHot{b.id, wlr_box{static_cast<int>(cx + b.dx - hit / 2),
					static_cast<int>(cy - hit / 2), static_cast<int>(hit), static_cast<int>(hit)}, hit / 2});
			}
		}
	};

	if (h >= 140) {
		// Full: app and output on top, title and artist, the wave and times,
		// the controls along the bottom.
		const double top = y + pad - 2;
		draw_named_icon(cr, icons, "play", x + pad, top + 4, 10, soft, scale);
		const std::string from = player_label(st.media_player);
		draw_text(cr, from, x + pad + 16, top, w / 2, 18, theme::font_small, soft);
		if (hots) {
			hots->push_back(MediaHot{"mp:open", wlr_box{static_cast<int>(x + pad - 4), static_cast<int>(top - 3),
				text_width(from, theme::font_small) + 28, 24}, 12});
		}
		const std::string out = "Media output";
		const int ow = text_width(out, theme::font_small) + 24;
		const double ox = x + w - pad - ow;
		fill_rounded(cr, ox, top - 4, ow, 26, 13, rgb(0xffffff, 0.16));
		draw_text(cr, out, ox, top - 4, ow, 26, theme::font_small, white, Align::Center);
		if (hots) hots->push_back(MediaHot{"mp:output", wlr_box{static_cast<int>(ox), static_cast<int>(top - 4), ow, 26}, 13});
		if (lyrics) {
			const double lx = ox - 32;
			cairo_new_path(cr);
			cairo_arc(cr, lx + 13, top + 9, 13, 0, 2 * M_PI);
			const bool lit = server_->config.lyrics_show && found;
			set_color(cr, lit ? rgb(0xffffff, 0.85) : rgb(0xffffff, 0.16));
			cairo_fill(cr);
			draw_named_icon(cr, icons, "mic-vocal", lx + 6, top + 2, 14,
				lit ? rgb(0x15141a) : found ? white : rgb(0xffffff, 0.45), scale);
			if (hots) hots->push_back(MediaHot{"mp:lyrics", wlr_box{static_cast<int>(lx), static_cast<int>(top - 4), 26, 26}, 13});
		}
		const double ty = top + 26;
		draw_title(cr, title, x + pad, ty, w - 2 * pad, 24, title_font(), white);
		draw_text(cr, st.media_artist, x + pad, ty + 24, w - 2 * pad, 18, theme::font_small, soft);
		const double wy = y + h - 64;
		if (st.media_available && st.media_length > 0) {
			draw_wave(cr, x + pad + 2, wy, w - 2 * pad - 4, white, rgb(0xffffff, 0.30), hots);
			draw_text(cr, media_clock(position()), x + pad, wy + 7, 60, 14, theme::font_small, soft);
			draw_text(cr, media_clock(st.media_length), x + w - pad - 60, wy + 7, 60, 14, theme::font_small, soft,
				Align::Right);
		} else if (st.media_available) {
			draw_wave(cr, x + pad + 2, wy, w - 2 * pad - 4, white, rgb(0xffffff, 0.30), nullptr);
		}
		control_row(x + w / 2, y + h - 24, 64, 26, 22);
	} else if (h >= 84) {
		// Medium: title and artist with the controls beside them, the wave under.
		const double ctl_w = st.media_available ? 120 : 0;
		draw_title(cr, title, x + pad, y + pad - 4, w - 2 * pad - ctl_w, 22, theme::font_bold, white);
		draw_text(cr, st.media_artist, x + pad, y + pad + 17, w - 2 * pad - ctl_w, 16, theme::font_small, soft);
		control_row(x + w - pad - ctl_w / 2, y + pad + 12, 38, 22, 18);
		if (st.media_available) {
			draw_wave(cr, x + pad + 2, y + h - pad - 4, w - 2 * pad - 4, white, rgb(0xffffff, 0.30),
				st.media_length > 0 ? hots : nullptr);
		}
	} else {
		// One row: the cover, title and artist, play/pause; a thin wave along the bottom.
		const double as = h - 16;
		draw_thumb(cr, icons, art_, x + 8, y + 8, as, std::max(6.0, r - 8), rgb(0xffffff, 0.14), soft, scale);
		const double tx = x + 8 + as + 10;
		const double ctl = st.media_available ? (w >= 220 ? 104 : 40) : 0;
		const double tw = x + w - tx - ctl - 6;
		draw_title(cr, title, tx, y + h / 2 - 18, tw, 20, theme::font_bold, white);
		draw_text(cr, st.media_artist, tx, y + h / 2 + 1, tw, 16, theme::font_small, soft);
		if (st.media_available) {
			if (w >= 220) control_row(x + w - 6 - ctl / 2, y + h / 2 - 2, 34, 20, 16);
			else control_row(x + w - 6 - ctl / 2, y + h / 2 - 2, 0, 20, 0);
			if (st.media_length > 0) {
				const double frac = std::clamp(position() / st.media_length, 0.0, 1.0);
				cairo_save(cr);
				rounded_rect(cr, x, y, w, h, r);
				cairo_clip(cr);
				cairo_rectangle(cr, x, y + h - 3, w * frac, 3);
				set_color(cr, rgb(0xffffff, 0.8));
				cairo_fill(cr);
				cairo_restore(cr);
			}
		}
	}
	if (hots && st.media_available) {
		// The rest of the card: right-click options, a click does nothing.
		hots->insert(hots->begin(), MediaHot{"mp:card", wlr_box{static_cast<int>(x), static_cast<int>(y),
			static_cast<int>(w), static_cast<int>(h)}, -2});
	}
}

// The other looks: on the card colours of their control centre.
void MediaView::draw_plain(cairo_t *cr, double x, double y, double w, double h, double r, float scale, Look look,
		std::vector<MediaHot> *hots) {
	const SystemStatus &st = *server_->status;
	IconLoader &icons = server_->icons;
	const std::string title = st.media_available ? (st.media_title.empty() ? "Playing" : st.media_title)
		: look == Look::Mac ? "Not Playing" : "Nothing playing";
	auto button = [&](const char *id, const char *icon, double cx, double cy, double size, bool round, const Color &fg) {
		if (round) {
			cairo_new_path(cr);
			cairo_arc(cr, cx, cy, size * 0.9, 0, 2 * M_PI);
			set_color(cr, theme::tile_off);
			cairo_fill(cr);
		}
		draw_named_icon(cr, icons, icon, cx - size / 2, cy - size / 2, size, fg, scale);
		if (hots) {
			const double hit = size + 16;
			hots->push_back(MediaHot{id, wlr_box{static_cast<int>(cx - hit / 2), static_cast<int>(cy - hit / 2),
				static_cast<int>(hit), static_cast<int>(hit)}, hit / 2});
		}
	};
	const char *play = st.media_playing ? "pause" : "play";
	fill_rounded(cr, x, y, w, h, r, theme::card_bg);
	if (look == Look::Windows) {
		// Windows 11: the app on top, title and artist, the cover at the right,
		// the controls centred underneath.
		const double pad = 16, as = std::min(64.0, h - 64);
		draw_text(cr, player_label(st.media_player), x + pad, y + 10, w / 2, 18, theme::font_small, theme::text_dim);
		draw_thumb(cr, icons, art_, x + w - pad - as, y + 14, as, 6, theme::tile_off, theme::text_dim, scale);
		draw_title(cr, title, x + pad, y + 32, w - 3 * pad - as, 22, theme::font_bold, theme::text);
		draw_text(cr, st.media_artist, x + pad, y + 54, w - 3 * pad - as, 18, theme::font_small, theme::text_dim);
		if (st.media_available) {
			const double cy = y + h - 24;
			button("mp:previous", "previous", x + w / 2 - 56, cy, 16, false, theme::text);
			button("mp:play-pause", play, x + w / 2, cy, 18, false, theme::text);
			button("mp:next", "next", x + w / 2 + 56, cy, 16, false, theme::text);
		}
	} else if (look == Look::Gnome) {
		// GNOME: one row: cover, title over artist, small controls at the end.
		const double as = std::min(44.0, h - 16);
		draw_thumb(cr, icons, art_, x + 10, y + (h - as) / 2, as, 8, theme::tile_off, theme::text_dim, scale);
		const double tx = x + 10 + as + 12, ctl = st.media_available ? 104 : 0;
		draw_title(cr, title, tx, y + h / 2 - 19, x + w - tx - ctl - 8, 20, theme::font_bold, theme::text);
		draw_text(cr, st.media_artist, tx, y + h / 2 + 1, x + w - tx - ctl - 8, 18, theme::font_small, theme::text_dim);
		if (st.media_available) {
			const double cx = x + w - 10 - ctl / 2, cy = y + h / 2;
			button("mp:previous", "previous", cx - 34, cy, 15, false, theme::text);
			button("mp:play-pause", play, cx, cy, 16, false, theme::text);
			button("mp:next", "next", cx + 34, cy, 15, false, theme::text);
		}
	} else {
		// macOS: the cover at the top left, title and artist, controls below.
		const double pad = 14, as = std::min(46.0, h * 0.34);
		draw_thumb(cr, icons, art_, x + pad, y + pad, as, 8, theme::tile_off, theme::text_dim, scale);
		draw_title(cr, title, x + pad, y + pad + as + 6, w - 2 * pad, 20, theme::font_bold, theme::text);
		draw_text(cr, st.media_artist, x + pad, y + pad + as + 25, w - 2 * pad, 17, theme::font_small, theme::text_dim);
		const double cy = y + h - 22;
		const Color fg = st.media_available ? theme::text : theme::text_dim;
		button("mp:previous", "previous", x + w / 2 - 38, cy, 16, false, fg);
		button("mp:play-pause", play, x + w / 2, cy, 20, false, fg);
		button("mp:next", "next", x + w / 2 + 38, cy, 16, false, fg);
	}
	if (hots && st.media_available) {
		hots->insert(hots->begin(), MediaHot{"mp:card", wlr_box{static_cast<int>(x), static_cast<int>(y),
			static_cast<int>(w), static_cast<int>(h)}, -2});
	}
}

// Where sound goes: the outputs PipeWire knows, the one in use ticked.
void sound_output_menu(Server *srv, Output *out, double lx, double ly) {
	srv->run_capture("wpctl status 2>/dev/null", [srv, out, lx, ly](const std::string &text) {
		std::vector<MenuItem> items;
		items.push_back(MenuItem::header("Play sound on"));
		bool audio = false, sinks = false;
		std::istringstream in(text);
		std::string line;
		while (std::getline(in, line)) {
			if (line == "Audio") audio = true;
			else if (line == "Video" || line == "Settings") audio = false;
			if (!audio) continue;
			if (line.find("Sinks:") != std::string::npos) {
				sinks = true;
				continue;
			}
			if (sinks && (line.find("├─") != std::string::npos || line.find("└─") != std::string::npos)) {
				sinks = false;
			}
			if (!sinks) continue;
			// " │  *   57. Built-in Audio Analog Stereo        [vol: 0.40]"
			const bool current = line.find('*') != std::string::npos;
			size_t i = 0;
			while (i < line.size() && !std::isdigit(static_cast<unsigned char>(line[i]))) i++;
			const size_t dot = line.find('.', i);
			if (i >= line.size() || dot == std::string::npos) continue;
			const std::string id = line.substr(i, dot - i);
			std::string name = line.substr(dot + 1);
			name = name.substr(0, name.find(" [vol"));
			while (!name.empty() && name.front() == ' ') name.erase(0, 1);
			while (!name.empty() && name.back() == ' ') name.pop_back();
			if (name.empty()) continue;
			items.push_back(MenuItem::radio(name, current, [srv, id] {
				srv->run_capture("wpctl set-default " + id + " >/dev/null 2>&1",
					[srv](const std::string &) { srv->status->refresh(); });
			}));
		}
		if (items.size() == 1) items.push_back(MenuItem::action("No sound outputs found", [] {}));
		items.push_back(MenuItem::separator());
		for (const char *mixer : {"pwvucontrol", "pavucontrol"}) {
			if (access((std::string("/usr/bin/") + mixer).c_str(), X_OK) == 0) {
				items.push_back(MenuItem::action("Sound settings…", [srv, m = std::string(mixer)] { srv->spawn(m); }, "gear"));
				break;
			}
		}
		srv->menu->show(out, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point", std::move(items));
	});
}

} // namespace dusk
