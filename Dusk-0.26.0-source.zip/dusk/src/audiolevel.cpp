#include "audiolevel.hpp"

#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <cmath>

#include "anim.hpp"
#include "server.hpp"

namespace dusk {

namespace {
constexpr int kRate = 8000;           // samples a second: plenty for loudness and beats
constexpr int kBlock = kRate / 100;   // 10 ms
}

AudioLevel::AudioLevel(Server *server) : server_(server) {}

AudioLevel::~AudioLevel() {
	stop();
}

void AudioLevel::acquire() {
	if (users_++ == 0) start();
}

void AudioLevel::release() {
	if (users_ <= 0) return;
	if (--users_ == 0) stop();
}

void AudioLevel::start() {
	if (pid_ > 0) return;
	int fds[2];
	if (pipe(fds) != 0) return;
	const pid_t pid = fork();
	if (pid == 0) {
		setsid();
		sigset_t set;
		sigemptyset(&set);
		sigprocmask(SIG_SETMASK, &set, nullptr);
		signal(SIGPIPE, SIG_DFL);
		close(fds[0]);
		dup2(fds[1], STDOUT_FILENO);
		close(fds[1]);
		const int null = open("/dev/null", O_WRONLY);
		if (null >= 0) dup2(null, STDERR_FILENO);
		// The sound going to the speakers, quietly, as small numbers. "dusk-levels"
		// is how the microphone indicator knows it isn't a recording.
		execl("/bin/sh", "/bin/sh", "-c",
			"if command -v parec >/dev/null; then "
			"exec parec --client-name=dusk-levels --stream-name=dusk-levels -d @DEFAULT_MONITOR@ --raw "
			"--format=s16le --rate=8000 --channels=1 --latency-msec=30; "
			"elif command -v pw-record >/dev/null; then "
			"exec pw-record -P '{ stream.capture.sink = true, application.name = \"dusk-levels\" }' "
			"--rate 8000 --channels 1 --format s16 -; fi",
			static_cast<char *>(nullptr));
		_exit(127);
	}
	close(fds[1]);
	if (pid < 0) {
		close(fds[0]);
		return;
	}
	pid_ = pid;
	fd_ = fds[0];
	fcntl(fd_, F_SETFL, fcntl(fd_, F_GETFL) | O_NONBLOCK);
	fcntl(fd_, F_SETFD, FD_CLOEXEC);
	source_ = wl_event_loop_add_fd(server_->loop, fd_, WL_EVENT_READABLE, &AudioLevel::handle_read, this);
	has_carry_ = false;
	block_sum_ = 0;
	block_n_ = 0;
}

void AudioLevel::stop() {
	if (source_) wl_event_source_remove(source_);
	source_ = nullptr;
	if (fd_ >= 0) close(fd_);
	fd_ = -1;
	if (pid_ > 0) {
		kill(-pid_, SIGTERM);
		kill(pid_, SIGTERM);
		waitpid(pid_, nullptr, 0);
	}
	pid_ = -1;
	env_ = 0;
	last_data_ = -1e9;
}

int AudioLevel::handle_read(int fd, uint32_t mask, void *data) {
	auto *self = static_cast<AudioLevel *>(data);
	unsigned char buf[4096];
	for (;;) {
		const ssize_t n = read(fd, buf, sizeof buf);
		if (n > 0) {
			self->feed(buf, static_cast<size_t>(n));
			continue;
		}
		if (n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR)) {
			// The reader ended (no sound server, or neither tool installed):
			// the wave sways on its own.
			const int users = self->users_;
			self->stop();
			self->users_ = users;
		}
		break;
	}
	(void)mask;
	return 0;
}

void AudioLevel::feed(const unsigned char *data, size_t n) {
	size_t i = 0;
	auto sample = [](unsigned char lo, unsigned char hi) {
		return static_cast<int16_t>(static_cast<uint16_t>(lo | (hi << 8))) / 32768.0;
	};
	const double now = now_ms();
	last_data_ = now;
	if (has_carry_ && n > 0) {
		const double s = sample(carry_, data[0]);
		block_sum_ += s * s;
		block_n_++;
		has_carry_ = false;
		i = 1;
	}
	for (; i + 1 < n; i += 2) {
		const double s = sample(data[i], data[i + 1]);
		block_sum_ += s * s;
		if (++block_n_ < kBlock) continue;
		const double rms = std::sqrt(block_sum_ / block_n_);
		block_sum_ = 0;
		block_n_ = 0;
		// Quick to rise, slower to fall: it moves with the music without jitter.
		env_ = rms > env_ ? env_ + (rms - env_) * 0.6 : env_ * 0.90 + rms * 0.10;
		avg_ += (rms - avg_) * 0.02;
		peak_ = std::max({env_, peak_ * 0.9985, 0.02});
		// A beat: clearly louder than lately, not too soon after the last.
		if (rms > avg_ * 1.45 && rms > 0.015 && now - last_beat_ > 180) {
			last_beat_ = now;
		}
	}
	if (i < n) {
		carry_ = data[i];
		has_carry_ = true;
	}
}

bool AudioLevel::live() const {
	return pid_ > 0 && now_ms() - last_data_ < 500;
}

double AudioLevel::level() const {
	if (!live()) return 0;
	return std::clamp(env_ / peak_, 0.0, 1.0);
}

double AudioLevel::beat() const {
	if (!live()) return 0;
	const double since = now_ms() - last_beat_;
	return since < 0 ? 0 : std::exp(-since / 140.0);
}

} // namespace dusk
