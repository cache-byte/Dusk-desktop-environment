// The app menu: lists installed apps (from .desktop files), type to search.
#pragma once

#include <string>
#include <vector>

#include "server.hpp"
#include "ui.hpp"

namespace dusk {

class Launcher {
public:
	explicit Launcher(Server *server);
	~Launcher();
	Launcher(const Launcher &) = delete;
	Launcher &operator=(const Launcher &) = delete;

	bool is_open() const { return open_; }
	bool is_open_on(const Output *output) const { return open_ && output_ == output; }
	// Opens next to `anchor` (the menu button) on a panel at `edge`.
	void open(Output *output, wlr_box anchor, const std::string &edge);
	void close();
	void toggle(Output *output, wlr_box anchor, const std::string &edge);
	// From the keyboard: next to the first menu button on that screen.
	void toggle(Output *output);
	void output_gone(Output *output);

	bool contains(double lx, double ly) const;
	void motion(double lx, double ly);
	void leave();
	void click(double lx, double ly, uint32_t button);
	void scroll(double delta, bool wheel = true);
	// The scroll bar: press on it and drag (or click the track to jump there).
	bool dragging_bar() const { return bar_drag_; }
	void drag_bar(double lx, double ly);
	void end_drag() { bar_drag_ = false; }
	// Returns true if the key was used by the menu.
	bool handle_key(xkb_keysym_t sym, const std::string &text);

	NodeTag tag{NodeTag::Kind::Launcher, this};

private:
	// The look (Settings › Panels › App menu): a list next to the button
	// (Dusk), Windows 11's Start, or a full-screen grid (GNOME, macOS).
	bool grid() const { return look_ != "dusk"; }
	bool full() const { return look_ == "gnome" || look_ == "macos"; }
	void measure();               // sizes and places of everything, for the look
	int item_at(double px, double py) const;   // grid looks: which app
	wlr_box item_box(int index, double scroll) const;
	int max_first() const;
	wlr_box power_box() const;
	wlr_box settings_box() const;
	void filter();
	void redraw();
	void redraw_grid();
	void place();
	void launch(int row);
	void keep_selection_visible();
	int visible_rows() const;
	int row_at(double px, double py) const;
	bool on_power(double px, double py) const;
	bool on_settings(double px, double py) const;

	Server *server_;
	UiLayer layer_;
	Fades fx_;
	Highlight sel_;    // the selected row (keyboard)
	Highlight hl_;     // under the pointer
	void update_highlights();
	bool drawing_ = false;
	Output *output_ = nullptr;
	bool open_ = false;
	wlr_box box_{};
	wlr_box anchor_{};
	std::string edge_ = "bottom";
	uint64_t anim_ = 0;
	double alpha_ = 0.0;

	std::string look_ = "dusk";
	int w_ = 420, h_ = 540;
	// Grid looks: the search field, the grid and its cells.
	wlr_box search_{};
	wlr_box grid_{};
	int cols_ = 1, cell_w_ = 100, cell_h_ = 100, icon_ = 48, grid_rows_ = 1;
	std::string user_name_;
	bool keyed_ = false;          // moved with the arrow keys: show which app is picked

	std::vector<int> shown_;   // indexes into server_->apps.apps()
	std::string query_;
	int selected_ = 0;
	int first_row_ = 0;
	int hover_row_ = -1;
	bool hover_power_ = false;
	bool hover_settings_ = false;
	double scroll_accum_ = 0;
	bool bar_drag_ = false;
	bool on_bar(double px, double py) const;
};

} // namespace dusk
