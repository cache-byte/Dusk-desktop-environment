#include "launcher.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <linux/input-event-codes.h>
#include <pwd.h>
#include <unistd.h>

#include "draw.hpp"
#include "glyphs.hpp"
#include "panel.hpp"

namespace dusk {

namespace {

constexpr int kWidth = 420;
constexpr int kHeight = 540;
constexpr int kPad = 14;
constexpr int kSearchHeight = 40;
constexpr int kListTop = kPad + kSearchHeight + 12;
constexpr int kRowHeight = 42;
constexpr int kFooterHeight = 52;

std::string lower(std::string s) {
	for (char &c : s) {
		c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
	}
	return s;
}

} // namespace

Launcher::Launcher(Server *server)
		: server_(server), layer_(server->layer_menu, &tag),
		fx_(server->anim.get(), [this] { if (open_ || alpha_ > 0) redraw(); }),
		sel_(layer_, server->anim.get()), hl_(layer_, server->anim.get()) {
	layer_.set_enabled(false);
	fx_.set_speed(55);
	if (const passwd *pw = getpwuid(getuid())) {
		std::string gecos = pw->pw_gecos ? pw->pw_gecos : "";
		gecos = gecos.substr(0, gecos.find(','));
		user_name_ = gecos.empty() ? pw->pw_name : gecos;
		if (!user_name_.empty()) user_name_[0] = static_cast<char>(std::toupper(user_name_[0]));
	}
}

// ---- The looks' measurements ----------------------------------------------------------------

void Launcher::measure() {
	look_ = server_->config.launcher_look;
	if (!output_) return;
	const wlr_box u = output_->usable();
	if (look_ == "dusk") {
		w_ = kWidth;
		h_ = kHeight;
		return;
	}
	if (look_ == "windows") {
		// Start: search on top, the apps six to a row, you and the power button along the bottom.
		w_ = std::min(640, u.width - 16);
		h_ = std::min(720, u.height - 16);
		const int pad = 28;
		search_ = wlr_box{pad, 24, w_ - 2 * pad, 38};
		grid_ = wlr_box{pad - 4, 24 + 38 + 52, w_ - 2 * pad + 8, 0};
		grid_.height = h_ - 64 - 12 - grid_.y;
		cols_ = std::max(3, std::min(6, grid_.width / 96));
		cell_w_ = grid_.width / cols_;
		cell_h_ = 88;
		icon_ = 34;
	} else {
		// GNOME's app grid / macOS's Launchpad: the whole screen (above and
		// below the panels), a search field at the top, big icons.
		const bool mac = look_ == "macos";
		w_ = u.width;
		h_ = u.height;
		const int sw = mac ? 260 : 340, sh = mac ? 30 : 40;
		search_ = wlr_box{(w_ - sw) / 2, mac ? 36 : 28, sw, sh};
		const int side = std::max(40, static_cast<int>(w_ * (mac ? 0.13 : 0.08)));
		cell_w_ = mac ? 150 : 140;
		cell_h_ = mac ? 140 : 128;
		icon_ = mac ? 76 : 64;
		cols_ = std::clamp((w_ - 2 * side) / cell_w_, 3, mac ? 7 : 8);
		const int gw = cols_ * cell_w_;
		grid_ = wlr_box{(w_ - gw) / 2, search_.y + sh + (mac ? 56 : 44), gw, 0};
		grid_.height = h_ - grid_.y - 40;
	}
	grid_rows_ = std::max(1, grid_.height / cell_h_);
}

int Launcher::max_first() const {
	if (!grid()) return std::max(0, static_cast<int>(shown_.size()) - visible_rows());
	const int rows = (static_cast<int>(shown_.size()) + cols_ - 1) / cols_;
	return std::max(0, rows - grid_rows_);
}

wlr_box Launcher::item_box(int index, double scroll) const {
	const int row = index / cols_, col = index % cols_;
	return wlr_box{grid_.x + col * cell_w_, static_cast<int>(std::lround(grid_.y + row * cell_h_ - scroll)), cell_w_,
		cell_h_};
}

int Launcher::item_at(double px, double py) const {
	if (px < grid_.x || px >= grid_.x + cols_ * cell_w_ || py < grid_.y || py >= grid_.y + grid_rows_ * cell_h_) {
		return -1;
	}
	const double scroll = const_cast<Fades &>(fx_).get("scroll", first_row_ * cell_h_);
	const int row = static_cast<int>(std::floor((py - grid_.y + scroll) / cell_h_));
	const int col = static_cast<int>((px - grid_.x) / cell_w_);
	const int i = row * cols_ + col;
	return i >= 0 && i < static_cast<int>(shown_.size()) ? i : -1;
}

wlr_box Launcher::power_box() const {
	if (!server_->config.menu_power || full()) return wlr_box{};
	if (look_ == "windows") return wlr_box{w_ - 28 - 40, h_ - 64 + 12, 40, 40};
	return wlr_box{w_ - kPad - 36, h_ - kFooterHeight + 8, 36, 36};
}

wlr_box Launcher::settings_box() const {
	if (full()) return wlr_box{};
	if (look_ == "windows") return wlr_box{w_ - 28 - 40 - 8 - 40, h_ - 64 + 12, 40, 40};
	return wlr_box{kPad, h_ - kFooterHeight + 8, 130, 36};
}

Launcher::~Launcher() {
	if (anim_) {
		server_->anim->cancel(anim_);
	}
}

void Launcher::filter() {
	const auto &apps = server_->apps.apps();
	shown_.clear();
	const std::string q = lower(query_);
	std::vector<int> starts, contains;
	for (int i = 0; i < static_cast<int>(apps.size()); i++) {
		const AppInfo &app = apps[static_cast<size_t>(i)];
		if (!app.visible) {
			continue;
		}
		const std::string name = lower(app.name);
		if (q.empty() || name.rfind(q, 0) == 0) {
			starts.push_back(i);
		} else if (name.find(q) != std::string::npos ||
				lower(app.comment).find(q) != std::string::npos ||
				lower(app.exec).find(q) != std::string::npos) {
			contains.push_back(i);
		}
	}
	shown_ = starts;
	shown_.insert(shown_.end(), contains.begin(), contains.end());
	selected_ = 0;
	first_row_ = 0;
	// A new list: no gliding from where the old one was.
	fx_.snap("scroll", 0);
}

int Launcher::visible_rows() const {
	return (kHeight - kListTop - kFooterHeight - 4) / kRowHeight;
}

// Next to the menu button, on the side away from its panel's screen edge
// (or in the middle of the screen when opened from the keyboard with no
// panel). Slides a little while fading in/out.
void Launcher::place() {
	if (!output_) {
		return;
	}
	const wlr_box o = output_->box();
	const wlr_box u = output_->usable();
	const int gap = 8;
	int x, y;
	if (full()) {
		x = u.x;
		y = u.y;
	} else if (anchor_.width <= 0) {
		x = o.x + (o.width - w_) / 2;
		y = o.y + (o.height - h_) / 2;
	} else if (edge_ == "top" || edge_ == "bottom") {
		// Windows 11's Start sits in the middle of the screen, over the taskbar.
		x = look_ == "windows" ? u.x + (u.width - w_) / 2 : anchor_.x;
		y = edge_ == "top" ? anchor_.y + anchor_.height + gap + 6 : anchor_.y - h_ - gap - 6;
	} else {
		y = anchor_.y;
		x = edge_ == "left" ? anchor_.x + anchor_.width + gap + 6 : anchor_.x - w_ - gap - 6;
	}
	x = std::clamp(x, u.x + (full() ? 0 : gap), std::max(u.x + gap, u.x + u.width - w_ - (full() ? 0 : gap)));
	y = std::clamp(y, u.y + (full() ? 0 : gap), std::max(u.y + gap, u.y + u.height - h_ - (full() ? 0 : gap)));
	box_ = wlr_box{x, y, w_, h_};
	// It grows out of the corner nearest the menu button (full screen: from the middle).
	double ox = w_ / 2.0, oy = h_ / 2.0;
	if (anchor_.width > 0 && !full()) {
		ox = std::clamp<double>(anchor_.x + anchor_.width / 2.0 - x, 0, w_);
		oy = std::clamp<double>(anchor_.y + anchor_.height / 2.0 - y, 0, h_);
		if (edge_ == "bottom") oy = h_;
		else if (edge_ == "top") oy = 0;
		else if (edge_ == "left") ox = 0;
		else ox = w_;
	}
	const double t = std::clamp(alpha_, 0.0, 1.1);
	layer_.show(x, y, std::min(1.0, t * 1.3), (full() ? 0.96 : 0.9) + (full() ? 0.04 : 0.1) * t, ox, oy);
}

void Launcher::open(Output *output, wlr_box anchor, const std::string &edge) {
	if (!output) {
		return;
	}
	output_ = output;
	anchor_ = anchor;
	edge_ = edge;
	open_ = true;
	query_.clear();
	hover_row_ = -1;
	keyed_ = false;
	measure();
	server_->apps.reload();   // picks up newly installed apps
	filter();
	redraw();
	place();
	layer_.set_enabled(true);
	layer_.raise();

	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 1.0, c.animate(c.anim_menu) ? c.ms(230) : 0,
		[this] { place(); }, [this] { anim_ = 0; });
	server_->redraw_panels();   // menu button shows as pressed
}

void Launcher::close() {
	if (!open_) {
		return;
	}
	open_ = false;
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 0.0, c.animate(c.anim_menu) ? c.ms(160) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!open_) {
				layer_.set_enabled(false);
			}
		});
	server_->redraw_panels();
}

void Launcher::toggle(Output *output, wlr_box anchor, const std::string &edge) {
	if (open_) {
		close();
	} else {
		open(output, anchor, edge);
	}
}

void Launcher::toggle(Output *output) {
	if (open_ || !output) {
		close();
		return;
	}
	for (const auto &panel : output->panels) {
		const auto &w = panel->config().widgets;
		if (std::find(w.begin(), w.end(), "menu") != w.end()) {
			open(output, panel->anchor("menu"), panel->config().edge);
			return;
		}
	}
	open(output, wlr_box{}, "bottom");
}

void Launcher::output_gone(Output *output) {
	if (output_ == output) {
		open_ = false;
		server_->anim->cancel(anim_);
		anim_ = 0;
		alpha_ = 0;
		layer_.set_enabled(false);
		output_ = nullptr;
	}
}

bool Launcher::contains(double lx, double ly) const {
	return open_ && lx >= box_.x && lx < box_.x + box_.width &&
		ly >= box_.y && ly < box_.y + box_.height;
}

int Launcher::row_at(double px, double py) const {
	if (grid()) return item_at(px, py);
	if (px < kPad || px >= w_ - kPad || py < kListTop) {
		return -1;
	}
	if (py >= kListTop + visible_rows() * kRowHeight) {
		return -1;
	}
	// Rows as drawn, while the list may still be gliding.
	const double scroll = const_cast<Fades &>(fx_).get("scroll", first_row_ * kRowHeight);
	const int row = static_cast<int>(std::floor((py - kListTop + scroll) / kRowHeight));
	return row >= 0 && row < static_cast<int>(shown_.size()) ? row : -1;
}

bool Launcher::on_power(double px, double py) const {
	const wlr_box b = power_box();
	return b.width > 0 && px >= b.x && px < b.x + b.width && py >= b.y && py < b.y + b.height;
}

bool Launcher::on_settings(double px, double py) const {
	const wlr_box b = settings_box();
	return b.width > 0 && px >= b.x && px < b.x + b.width && py >= b.y && py < b.y + b.height;
}

void Launcher::motion(double lx, double ly) {
	const double px = lx - box_.x, py = ly - box_.y;
	const int row = row_at(px, py);
	const bool power = on_power(px, py);
	const bool settings = on_settings(px, py);
	if (row != hover_row_ || power != hover_power_ || settings != hover_settings_) {
		hover_row_ = row;
		hover_power_ = power;
		hover_settings_ = settings;
		update_highlights();   // no redraw needed
	}
}

void Launcher::leave() {
	if (open_ && (hover_row_ != -1 || hover_power_ || hover_settings_)) {
		hover_row_ = -1;
		hover_power_ = false;
		hover_settings_ = false;
		update_highlights();
	}
}

// The selection and hover highlights, where the rows are drawn right now.
void Launcher::update_highlights() {
	const Color hover = full() ? rgb(0xffffff, 0.12) : with_alpha(theme::text, theme::dark ? 0.08 : 0.06);
	if (grid()) {
		const double scroll = fx_.get("scroll", first_row_ * cell_h_);
		const double ir = look_ == "windows" ? 6 : 18;
		auto cell = [&](int i, wlr_box *out) {
			if (i < 0 || i >= static_cast<int>(shown_.size())) return false;
			const wlr_box b = item_box(i, scroll);
			if (b.y < grid_.y - b.height / 2 || b.y + b.height > grid_.y + grid_rows_ * cell_h_ + b.height / 2) return false;
			*out = wlr_box{b.x + 4, b.y + 2, b.width - 8, b.height - 4};
			return true;
		};
		wlr_box b;
		if ((!query_.empty() || keyed_) && cell(selected_, &b)) {
			sel_.show(b, ir, full() ? rgb(0xffffff, 0.2) : with_alpha(theme::accent, theme::dark ? 0.30 : 0.22));
		} else {
			sel_.hide();
		}
		if (hover_row_ >= 0 && (hover_row_ != selected_ || (query_.empty() && !keyed_)) && cell(hover_row_, &b)) {
			hl_.show(b, ir, hover);
		} else if (hover_settings_ || hover_power_) {
			hl_.show(hover_settings_ ? settings_box() : power_box(), 8, hover);
		} else {
			hl_.hide();
		}
		return;
	}
	const double scroll = fx_.get("scroll", first_row_ * kRowHeight);
	const double row_r = inner_radius(theme::ui_radius, kPad);
	const int rh = kRowHeight - 4;
	const double list_bottom = kListTop + visible_rows() * kRowHeight;
	auto row_box = [&](int row, wlr_box *out) {
		const double ry = kListTop + row * kRowHeight - scroll;
		if (row < 0 || row >= static_cast<int>(shown_.size()) || ry < kListTop - rh / 2.0 ||
				ry + rh > list_bottom + rh / 2.0) {
			return false;
		}
		*out = wlr_box{kPad, static_cast<int>(std::lround(ry)), w_ - 2 * kPad, rh};
		return true;
	};
	wlr_box b;
	if (row_box(selected_, &b)) {
		sel_.show(b, row_r, with_alpha(theme::accent, theme::dark ? 0.30 : 0.22));
	} else {
		sel_.hide();
	}
	if (hover_row_ >= 0 && hover_row_ != selected_ && row_box(hover_row_, &b)) {
		hl_.show(b, row_r, hover);
	} else if (hover_settings_) {
		hl_.show(settings_box(), 18, hover);
	} else if (hover_power_) {
		hl_.show(power_box(), 18, hover);
	} else {
		hl_.hide();
	}
}

// The scroll bar's track (a bit wider than it's drawn, so it's easy to hit).
bool Launcher::on_bar(double px, double py) const {
	const int rows = visible_rows();
	return !grid() && static_cast<int>(shown_.size()) > rows && px >= w_ - 18 && px < w_ &&
		py >= kListTop && py < kListTop + rows * kRowHeight;
}

void Launcher::drag_bar(double lx, double ly) {
	(void)lx;
	const int rows = visible_rows();
	const int total = static_cast<int>(shown_.size());
	if (total <= rows) return;
	const double track = rows * kRowHeight;
	const double thumb = std::max(24.0, track * rows / total);
	const double frac = std::clamp((ly - box_.y - kListTop - thumb / 2) / std::max(1.0, track - thumb), 0.0, 1.0);
	const int first = static_cast<int>(std::lround(frac * (total - rows)));
	if (first != first_row_) {
		first_row_ = first;
		redraw();
	}
}

void Launcher::click(double lx, double ly, uint32_t button) {
	if (button != BTN_LEFT) {
		return;
	}
	const double px = lx - box_.x, py = ly - box_.y;
	if (on_bar(px, py)) {
		bar_drag_ = true;
		drag_bar(lx, ly);
		return;
	}
	if (on_settings(px, py)) {
		close();
		server_->open_settings();
		return;
	}
	if (on_power(px, py)) {
		// Right by the button (under it, or over it when there's no room),
		// wherever the app menu is.
		const wlr_box p = power_box();
		server_->show_power_menu(output_, wlr_box{box_.x + p.x, box_.y + p.y, p.width, p.height}, "below");
		return;
	}
	const int row = row_at(px, py);
	if (row >= 0) {
		launch(row);
	} else if (full()) {
		close();   // the empty screen around the apps
	}
}

void Launcher::scroll(double delta, bool wheel) {
	// A mouse wheel moves a row per notch (15 units, or a part of one for
	// high-resolution wheels); a touchpad moves with the fingers.
	const int unit = grid() ? cell_h_ : kRowHeight;
	scroll_accum_ += wheel ? delta * (unit / 15.0) : delta * 1.4;
	int steps = 0;
	while (scroll_accum_ >= unit * 0.75) { scroll_accum_ -= unit; steps++; }
	while (scroll_accum_ <= -unit * 0.75) { scroll_accum_ += unit; steps--; }
	if (steps == 0) {
		return;
	}
	first_row_ = std::clamp(first_row_ + steps, 0, max_first());
	redraw();
}

void Launcher::keep_selection_visible() {
	if (grid()) {
		const int row = selected_ / std::max(1, cols_);
		if (row < first_row_) first_row_ = row;
		else if (row >= first_row_ + grid_rows_) first_row_ = row - grid_rows_ + 1;
		first_row_ = std::clamp(first_row_, 0, max_first());
		return;
	}
	if (selected_ < first_row_) {
		first_row_ = selected_;
	} else if (selected_ >= first_row_ + visible_rows()) {
		first_row_ = selected_ - visible_rows() + 1;
	}
}

bool Launcher::handle_key(xkb_keysym_t sym, const std::string &text) {
	const int count = static_cast<int>(shown_.size());
	switch (sym) {
	case XKB_KEY_Escape:
		close();
		return true;
	case XKB_KEY_Return:
	case XKB_KEY_KP_Enter:
		if (count > 0) {
			launch(selected_);
		}
		return true;
	case XKB_KEY_Down:
		if (count > 0) selected_ = std::min(selected_ + (grid() ? cols_ : 1), count - 1);
		if (grid() && query_.empty()) keyed_ = true;
		break;
	case XKB_KEY_Up:
		selected_ = std::max(selected_ - (grid() ? cols_ : 1), 0);
		if (grid() && query_.empty()) keyed_ = true;
		break;
	case XKB_KEY_Right:
		if (!grid()) return true;
		if (count > 0) selected_ = std::min(selected_ + 1, count - 1);
		keyed_ = true;
		break;
	case XKB_KEY_Left:
		if (!grid()) return true;
		selected_ = std::max(selected_ - 1, 0);
		keyed_ = true;
		break;
	case XKB_KEY_Page_Down:
		if (count > 0) selected_ = std::min(selected_ + (grid() ? cols_ * grid_rows_ : visible_rows()), count - 1);
		break;
	case XKB_KEY_Page_Up:
		selected_ = std::max(selected_ - (grid() ? cols_ * grid_rows_ : visible_rows()), 0);
		break;
	case XKB_KEY_BackSpace:
		if (!query_.empty()) {
			// Remove one whole UTF-8 character.
			size_t cut = query_.size() - 1;
			while (cut > 0 && (static_cast<unsigned char>(query_[cut]) & 0xc0) == 0x80) {
				cut--;
			}
			query_.erase(cut);
			filter();
		}
		break;
	case XKB_KEY_Tab:
		break;
	default:
		if (!text.empty() && static_cast<unsigned char>(text[0]) >= 0x20 && text[0] != 0x7f) {
			query_ += text;
			filter();
		}
		break;
	}
	keep_selection_visible();
	redraw();
	return true;   // the menu takes all keys while open
}

void Launcher::launch(int row) {
	if (row < 0 || row >= static_cast<int>(shown_.size())) {
		return;
	}
	const AppInfo &app = server_->apps.apps()[static_cast<size_t>(shown_[static_cast<size_t>(row)])];
	if (app.id.rfind("org.dusk.Settings", 0) == 0) {
		server_->open_settings("");   // the one that's open comes forward
		close();
		return;
	}
	server_->spawn(app.exec);
	close();
}

void Launcher::redraw() {
	if (!output_ || drawing_) {
		return;
	}
	if (grid()) {
		redraw_grid();
		return;
	}
	drawing_ = true;
	const auto &apps = server_->apps.apps();
	const float scale = output_->output->scale;
	Canvas canvas(w_, h_, scale);
	cairo_t *cr = canvas.cr();
	const double radius = theme::ui_radius;
	ui_card(cr, 0, 0, w_, h_, radius, theme::menu_bg);

	// Search field: a pill, its ends following the card's corners.
	fill_rounded(cr, kPad, kPad, w_ - 2 * kPad, kSearchHeight,
		std::min<double>(kSearchHeight / 2.0, inner_radius(radius, kPad)), theme::field_bg);
	// Magnifying glass.
	draw_named_icon(cr, server_->icons, "search", kPad + 13, kPad + kSearchHeight / 2.0 - 9, 18, theme::text_dim, scale);
	const int text_x = kPad + 38;
	if (query_.empty()) {
		draw_text(cr, "Type to search…", text_x, kPad, w_ - 2 * kPad - 52,
			kSearchHeight, theme::font_large, theme::text_dim);
	} else {
		draw_text(cr, query_, text_x, kPad, w_ - 2 * kPad - 52, kSearchHeight,
			theme::font_large, theme::text);
	}
	const int caret_x = text_x + (query_.empty() ? 0 : text_width(query_, theme::font_large)) + 1;
	if (caret_x < w_ - kPad - 16) {
		cairo_rectangle(cr, caret_x, kPad + 11, 2, kSearchHeight - 22);
		set_color(cr, theme::accent);
		cairo_fill(cr);
	}

	// App list: it scrolls smoothly and the selection glides between rows.
	const int rows = visible_rows();
	if (shown_.empty()) {
		draw_text(cr, apps.empty() ? "No apps found" : "No matches", kPad, kListTop,
			w_ - 2 * kPad, kRowHeight * 2, theme::font, theme::text_dim, Align::Center);
	}
	fx_.set("scroll", first_row_ * kRowHeight, 0);
	const double scroll = fx_.get("scroll");
	const double list_h = rows * kRowHeight;
	cairo_save(cr);
	cairo_rectangle(cr, 0, kListTop - 2, w_, list_h + 2);
	cairo_clip(cr);
	const double rh = kRowHeight - 4;
	const int first = std::max(0, static_cast<int>(scroll / kRowHeight));
	for (int row = first; row < static_cast<int>(shown_.size()) && row <= first + rows + 1; row++) {
		const int index = shown_[static_cast<size_t>(row)];
		const AppInfo &app = apps[static_cast<size_t>(index)];
		const double ry = kListTop + row * kRowHeight - scroll;
		draw_icon(cr, server_->icons, app.icon, app.name, kPad + 10, ry + (rh - 26) / 2.0, 26,
			scale);
		draw_text(cr, app.name, kPad + 46, ry, w_ - 2 * kPad - 56, rh, theme::font, theme::text);
	}
	cairo_restore(cr);

	// Scroll indicator.
	const int total = static_cast<int>(shown_.size());
	if (total > rows) {
		const double track = rows * kRowHeight;
		const double thumb = std::max(24.0, track * rows / total);
		const double pos = (track - thumb) * (scroll / kRowHeight) / std::max(1, total - rows);
		fill_rounded(cr, w_ - 9, kListTop + pos, 4, thumb, 2, with_alpha(theme::text, 0.3));
	}

	// Footer: Settings and log out.
	const int fy = h_ - kFooterHeight;
	cairo_rectangle(cr, kPad, fy, w_ - 2 * kPad, 1);
	set_color(cr, theme::divider);
	cairo_fill(cr);

	draw_named_icon(cr, server_->icons, "gear", kPad + 12, fy + 16, 20, theme::text, scale);
	draw_text(cr, "Settings", kPad + 40, fy + 8, 84, 36, theme::font, theme::text);
	if (server_->config.menu_power) {
		// The power button: a round button with the power symbol, its menu
		// set in Settings > Power.
		const wlr_box p = power_box();
		fill_rounded(cr, p.x, p.y, 36, 36, 18, theme::field_bg);
		draw_named_icon(cr, server_->icons, "power", p.x + 8, p.y + 8, 20, theme::text, scale);
	}
	layer_.present(canvas, wlr_box{0, 0, w_, h_}, radius);
	drawing_ = false;
	update_highlights();
}

// Windows 11's Start, GNOME's app grid and macOS's Launchpad: the apps as
// big icons with their names under them.
void Launcher::redraw_grid() {
	drawing_ = true;
	const auto &apps = server_->apps.apps();
	const float scale = output_->output->scale;
	Canvas canvas(w_, h_, scale);
	cairo_t *cr = canvas.cr();
	const bool win = look_ == "windows", mac = look_ == "macos";
	double radius = 0;
	Color fg = theme::text, dim = theme::text_dim;
	if (win) {
		radius = std::min<double>(theme::ui_radius, 10.0);
		ui_card(cr, 0, 0, w_, h_, radius, theme::menu_bg);
	} else {
		// Over everything (blurred behind), darkened so white names read on any wallpaper.
		cairo_set_source_rgba(cr, 0, 0, 0, mac ? 0.30 : 0.55);
		cairo_paint(cr);
		fg = rgb(0xffffff);
		dim = rgb(0xffffff, 0.65);
	}

	// The search field.
	const wlr_box &sb = search_;
	const double sr = win ? sb.height / 2.0 : mac ? 8 : sb.height / 2.0;
	fill_rounded(cr, sb.x, sb.y, sb.width, sb.height, sr,
		win ? theme::field_bg : rgb(0xffffff, mac ? 0.16 : 0.12));
	const bool centred = !win && query_.empty();
	const char *font = mac ? theme::font : theme::font_large;
	const std::string hint = win ? "Search for apps" : mac ? "Search" : "Type to search";
	const int hint_w = text_width(query_.empty() ? hint : query_, font);
	const double gx = centred ? sb.x + (sb.width - hint_w - 24) / 2.0 : sb.x + 12;
	draw_named_icon(cr, server_->icons, "search", gx, sb.y + sb.height / 2.0 - 8, 16, dim, scale);
	const double tx = gx + 24;
	draw_text(cr, query_.empty() ? hint : query_, tx, sb.y, sb.x + sb.width - tx - 10, sb.height, font,
		query_.empty() ? dim : fg);
	if (!query_.empty()) {
		const double cx = tx + (query_.empty() ? 0 : text_width(query_, font)) + 1;
		if (cx < sb.x + sb.width - 12) {
			cairo_rectangle(cr, cx, sb.y + 9, 2, sb.height - 18);
			set_color(cr, win ? theme::accent : fg);
			cairo_fill(cr);
		}
	}
	if (win) {
		draw_text(cr, query_.empty() ? "All apps" : "Best matches", grid_.x + 8, sb.y + sb.height + 16, 200, 24,
			theme::font_bold, theme::text);
	}

	// The apps.
	if (shown_.empty()) {
		draw_text(cr, apps.empty() ? "No apps found" : "No matches", grid_.x, grid_.y + 20, grid_.width, 40,
			theme::font, dim, Align::Center);
	}
	fx_.set("scroll", first_row_ * cell_h_, 0);
	const double scroll = fx_.get("scroll");
	const int area_h = grid_rows_ * cell_h_;
	cairo_save(cr);
	cairo_rectangle(cr, 0, grid_.y - 2, w_, area_h + 4);
	cairo_clip(cr);
	const int first = std::max(0, static_cast<int>(scroll / cell_h_)) * cols_;
	const int last = std::min(static_cast<int>(shown_.size()), first + (grid_rows_ + 2) * cols_);
	const char *name_font = win ? theme::font_small : theme::font;
	for (int i = first; i < last; i++) {
		const AppInfo &app = apps[static_cast<size_t>(shown_[static_cast<size_t>(i)])];
		const wlr_box b = item_box(i, scroll);
		const double iy = b.y + (win ? 12 : 10);
		draw_icon(cr, server_->icons, app.icon, app.name, b.x + (b.width - icon_) / 2.0, iy, icon_, scale);
		draw_text(cr, app.name, b.x + 6, iy + icon_ + (win ? 6 : 8), b.width - 12, 20, name_font, fg, Align::Center);
	}
	cairo_restore(cr);

	// More below (or above): a soft hint at the edge, and page dots for GNOME / macOS.
	const int pages = (max_first() + grid_rows_) / std::max(1, grid_rows_);
	if (!win && pages > 1) {
		const int page = std::min(pages - 1, (first_row_ + grid_rows_ / 2) / std::max(1, grid_rows_));
		const double dy = h_ - 22, step = 16;
		const double x0 = w_ / 2.0 - (pages - 1) * step / 2;
		for (int k = 0; k < pages; k++) {
			cairo_new_path(cr);
			cairo_arc(cr, x0 + k * step, dy, k == page ? 4 : 3, 0, 2 * M_PI);
			cairo_set_source_rgba(cr, 1, 1, 1, k == page ? 0.95 : 0.4);
			cairo_fill(cr);
		}
	} else if (win && max_first() > 0) {
		const double track = area_h;
		const int total_rows = max_first() + grid_rows_;
		const double thumb = std::max(24.0, track * grid_rows_ / total_rows);
		const double pos = (track - thumb) * (scroll / cell_h_) / std::max(1, max_first());
		fill_rounded(cr, w_ - 10, grid_.y + pos, 4, thumb, 2, with_alpha(theme::text, 0.3));
	}

	// Windows 11: you, Settings and the power button along the bottom.
	if (win) {
		const int fy = h_ - 64;
		cairo_save(cr);
		rounded_rect(cr, 0, 0, w_, h_, radius);
		cairo_clip(cr);
		cairo_rectangle(cr, 0, fy, w_, 64);
		set_color(cr, with_alpha(theme::text, theme::dark ? 0.05 : 0.04));
		cairo_fill(cr);
		cairo_rectangle(cr, 0, fy, w_, 1);
		set_color(cr, theme::divider);
		cairo_fill(cr);
		cairo_restore(cr);
		const double ax = 28, ay = fy + 16, as = 32;
		cairo_new_path(cr);
		cairo_arc(cr, ax + as / 2, ay + as / 2, as / 2, 0, 2 * M_PI);
		set_color(cr, theme::accent);
		cairo_fill(cr);
		const std::string initial = user_name_.empty() ? "?" : user_name_.substr(0, 1);
		draw_text(cr, initial, ax, ay, as, as, theme::font_bold, theme::on_accent, Align::Center);
		draw_text(cr, user_name_, ax + as + 12, fy, 220, 64, theme::font, theme::text);
		const wlr_box st = settings_box();
		draw_named_icon(cr, server_->icons, "gear", st.x + 10, st.y + 10, 20, theme::text, scale);
		if (server_->config.menu_power) {
			const wlr_box p = power_box();
			draw_named_icon(cr, server_->icons, "power", p.x + 10, p.y + 10, 20, theme::text, scale);
		}
	}
	layer_.present(canvas, wlr_box{0, 0, w_, h_}, radius);
	drawing_ = false;
	update_highlights();
}

} // namespace dusk
