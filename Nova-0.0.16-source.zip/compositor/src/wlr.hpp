// Single include point for wlroots from C++.
//
// wlroots is a C library and a few of its headers are not valid C++:
//   * `float color[static 4]` array parameters
//   * struct members named `class` (xwayland) and `namespace` (layer-shell)
// The usual trick (also used by Wayfire) is to pre-include every system /
// wayland header the wlroots headers pull in, then temporarily #define the
// offending keywords away while including wlroots itself.
#pragma once

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>

#include <linux/input-event-codes.h>
#include <pixman.h>
#include <wayland-server-core.h>
#include <wayland-server-protocol.h>
#include <xkbcommon/xkbcommon.h>
#include <libinput.h>
#ifdef NOVA_XWAYLAND
#include <xcb/xcb.h>
#endif

extern "C" {
#define static
#define class class_
#define namespace namespace_
#include <wlr/version.h>
#include <wlr/backend.h>
#include <wlr/backend/libinput.h>
#include <wlr/backend/session.h>
#include <wlr/interfaces/wlr_keyboard.h>
#include <wlr/render/allocator.h>
#include <wlr/render/wlr_renderer.h>
#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_cursor.h>
#include <wlr/types/wlr_cursor_shape_v1.h>
#include <wlr/types/wlr_data_control_v1.h>
#include <wlr/types/wlr_data_device.h>
#include <wlr/types/wlr_export_dmabuf_v1.h>
#include <wlr/types/wlr_foreign_toplevel_management_v1.h>
#include <wlr/types/wlr_fractional_scale_v1.h>
#include <wlr/types/wlr_gamma_control_v1.h>
#include <wlr/types/wlr_idle_inhibit_v1.h>
#include <wlr/types/wlr_idle_notify_v1.h>
#include <wlr/types/wlr_tearing_control_v1.h>
#include <wlr/types/wlr_pointer_gestures_v1.h>
#include <wlr/types/wlr_input_device.h>
#include <wlr/types/wlr_keyboard.h>
#include <wlr/types/wlr_layer_shell_v1.h>
#include <wlr/types/wlr_output.h>
#include <wlr/types/wlr_output_layout.h>
#include <wlr/types/wlr_output_management_v1.h>
#include <wlr/types/wlr_pointer.h>
#include <wlr/types/wlr_pointer_constraints_v1.h>
#include <wlr/types/wlr_presentation_time.h>
#include <wlr/types/wlr_primary_selection.h>
#include <wlr/types/wlr_primary_selection_v1.h>
#include <wlr/types/wlr_relative_pointer_v1.h>
#include <wlr/types/wlr_scene.h>
#include <wlr/types/wlr_screencopy_v1.h>
#include <wlr/types/wlr_seat.h>
#include <wlr/types/wlr_server_decoration.h>
#include <wlr/types/wlr_session_lock_v1.h>
#include <wlr/types/wlr_single_pixel_buffer_v1.h>
#include <wlr/types/wlr_subcompositor.h>
#include <wlr/types/wlr_viewporter.h>
#include <wlr/types/wlr_xcursor_manager.h>
#include <wlr/types/wlr_xdg_activation_v1.h>
#include <wlr/types/wlr_xdg_decoration_v1.h>
#include <wlr/types/wlr_xdg_output_v1.h>
#include <wlr/types/wlr_xdg_shell.h>
#include <wlr/xcursor.h>
#include <wlr/util/box.h>
#include <wlr/util/edges.h>
#include <wlr/util/log.h>
#include <wlr/util/region.h>
#ifdef NOVA_XWAYLAND
#include <wlr/xwayland.h>
#endif
#undef static
#undef class
#undef namespace
}

// ---- small version-compat layer -------------------------------------------
#define NOVA_WLR_AT_LEAST(maj, min) \
    (WLR_VERSION_MAJOR > (maj) || (WLR_VERSION_MAJOR == (maj) && WLR_VERSION_MINOR >= (min)))

#ifdef NOVA_XWAYLAND
inline bool nova_xwayland_wants_focus(wlr_xwayland_surface *xs) {
#if NOVA_WLR_AT_LEAST(0, 19)
    return wlr_xwayland_surface_override_redirect_wants_focus(xs);
#else
    return wlr_xwayland_or_surface_wants_focus(xs);
#endif
}
#endif

inline wlr_box nova_xdg_geometry(wlr_xdg_surface *s) {
#if NOVA_WLR_AT_LEAST(0, 19)
    return s->geometry;
#else
    wlr_box b{};
    wlr_xdg_surface_get_geometry(s, &b);
    return b;
#endif
}
