// novactl — talk to the Nova compositor.
//
//   novactl get workspaces|leds|windows
//   novactl dispatch workspace 3
//   novactl dispatch shell launcher
//   novactl lock
//   novactl subscribe            (prints JSON events forever)
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: novactl <get|dispatch|lock|subscribe> [args...]\n");
        return 1;
    }
    std::string path;
    if (const char *p = getenv("NOVA_SOCK")) path = p;
    else {
        const char *rt = getenv("XDG_RUNTIME_DIR"), *wd = getenv("WAYLAND_DISPLAY");
        if (!rt || !wd) {
            fprintf(stderr, "novactl: NOVA_SOCK not set and cannot guess socket path\n");
            return 1;
        }
        path = std::string(rt) + "/nova-" + wd + ".sock";
    }

    std::string cmd;
    for (int i = 1; i < argc; i++) {
        if (i > 1) cmd += ' ';
        cmd += argv[i];
    }
    cmd += '\n';

    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, path.c_str(), sizeof(addr.sun_path) - 1);
    if (fd < 0 || connect(fd, (sockaddr *)&addr, sizeof addr) < 0) {
        perror("novactl: connect");
        return 1;
    }
    if (write(fd, cmd.data(), cmd.size()) != (ssize_t)cmd.size()) {
        perror("novactl: write");
        return 1;
    }

    bool stream = std::string(argv[1]) == "subscribe";
    char buf[4096];
    std::string acc;
    ssize_t n;
    while ((n = read(fd, buf, sizeof buf)) > 0) {
        acc.append(buf, n);
        size_t nl;
        while ((nl = acc.find('\n')) != std::string::npos) {
            fwrite(acc.data(), 1, nl + 1, stdout);
            fflush(stdout);
            acc.erase(0, nl + 1);
            if (!stream) return 0;
        }
    }
    return 0;
}
