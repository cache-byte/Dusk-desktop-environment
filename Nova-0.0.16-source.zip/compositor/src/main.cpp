#include "ipc.hpp"
#include "server.hpp"

#include <csignal>
#include <cstring>
#include <getopt.h>

extern const char *kDefaultConfig;

static void usage(const char *argv0) {
    printf("Usage: %s [-s startup-command] [-d]\n"
           "  -s CMD   run CMD after startup (in addition to [autostart])\n"
           "  -d       debug logging\n"
           "  -v       print version\n"
           "  -c       print the default nova.conf (used by Settings to reset)\n",
           argv0);
}

int main(int argc, char **argv) {
    std::string startup;
    wlr_log_importance level = WLR_INFO;
    int c;
    while ((c = getopt(argc, argv, "s:dvch")) != -1) {
        switch (c) {
        case 's': startup = optarg; break;
        case 'd': level = WLR_DEBUG; break;
        case 'c': fputs(kDefaultConfig, stdout); return 0;
        case 'v': printf("nova %s (wlroots %s)\n", NOVA_VERSION, WLR_VERSION_STR); return 0;
        default: usage(argv[0]); return c == 'h' ? 0 : 1;
        }
    }
    wlr_log_init(level, nullptr);
    signal(SIGPIPE, SIG_IGN);

    Server server;
    if (!server.init()) {
        wlr_log(WLR_ERROR, "Nova failed to start");
        return 1;
    }
    if (!startup.empty()) server.spawn(startup);
    server.run();
    server.shutdown();
    return 0;
}
