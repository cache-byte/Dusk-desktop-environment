// RAII wrapper turning wl_signal callbacks into C++ lambdas.
//
//   Listener on_map;
//   on_map.connect(&surface->events.map, [this](void *) { ... });
//
// The listener disconnects itself when destroyed or reconnected, so objects
// that own Listeners can simply be deleted.
#pragma once
#include <functional>
#include <utility>
#include <wayland-server-core.h>

struct ListenerBase {
    wl_listener raw{};
};

class Listener : private ListenerBase {
public:
    using Fn = std::function<void(void *)>;

    Listener() {
        raw.notify = [](wl_listener *l, void *data) {
            auto *self = static_cast<Listener *>(reinterpret_cast<ListenerBase *>(l));
            if (self->fn_) self->fn_(data);
        };
        wl_list_init(&raw.link);
    }
    ~Listener() { disconnect(); }
    Listener(const Listener &) = delete;
    Listener &operator=(const Listener &) = delete;

    void connect(wl_signal *signal, Fn fn) {
        disconnect();
        fn_ = std::move(fn);
        wl_signal_add(signal, &raw);
        connected_ = true;
    }
    void disconnect() {
        if (connected_) {
            wl_list_remove(&raw.link);
            wl_list_init(&raw.link);
            connected_ = false;
        }
    }
    bool connected() const { return connected_; }

private:
    Fn fn_;
    bool connected_ = false;
};
