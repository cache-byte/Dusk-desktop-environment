#include "backend.hpp"

#include <QCommandLineParser>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    app.setApplicationName("nova-settings");
    app.setApplicationDisplayName("Settings");
    app.setDesktopFileName("nova-settings");
    QQuickStyle::setStyle("Basic");

    QCommandLineParser args;
    args.addHelpOption();
    QCommandLineOption page("page", "Open a page (e.g. Display)", "name", "For you");
    args.addOption(page);
    QCommandLineOption trim("trim", "Trim a screen recording", "file");
    args.addOption(trim);
    args.process(app);

    Backend backend(args.value(page));
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("Backend", &backend);
    engine.rootContext()->setContextProperty("TrimFile", args.value(trim));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app, [] { QCoreApplication::exit(1); },
                     Qt::QueuedConnection);
    engine.loadFromModule("Nova.Settings", args.isSet(trim) ? "Trim" : "Main");
    return app.exec();
}
