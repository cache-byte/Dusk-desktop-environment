#pragma once
#include <QFileSystemWatcher>
#include <QObject>
#include <QVariantMap>

// Everything the Settings UI needs from the system. Long-running commands
// (nmcli scans etc.) are quick enough to run synchronously with a timeout.
class Backend : public QObject {
    Q_OBJECT
    Q_PROPERTY(QVariantMap settings READ settings NOTIFY settingsChanged)
    Q_PROPERTY(QString startPage MEMBER m_startPage CONSTANT)

public:
    explicit Backend(const QString &startPage, QObject *parent = nullptr);

    QVariantMap settings() const { return m_settings; }

    // ~/.config/nova/settings.json (shared with the shell)
    Q_INVOKABLE void set(const QString &key, const QVariant &value);
    // ~/.config/nova/nova.conf (compositor) — reloads the compositor after writing
    Q_INVOKABLE QString conf(const QString &section, const QString &key, const QString &fallback = {}) const;
    Q_INVOKABLE void setConf(const QString &section, const QString &key, const QString &value);
    void setConfQuiet(const QString &section, const QString &key, const QString &value);

    Q_INVOKABLE QString run(const QStringList &cmd, int timeoutMs = 4000) const;
    Q_INVOKABLE void runDetached(const QStringList &cmd) const;
    // run without freezing the window; the result arrives as asyncDone(tag, output)
    Q_INVOKABLE void runAsync(const QStringList &cmd, const QString &tag);

    // appearance
    Q_INVOKABLE QStringList iconThemes() const;
    Q_INVOKABLE QStringList cursorThemes() const;
    Q_INVOKABLE QStringList fonts(bool monospace) const;
    Q_INVOKABLE QVariantList wallpapers() const;
    Q_INVOKABLE QString wallpaperDir() const;
    Q_INVOKABLE QString accentFromImage(const QString &path) const;
    Q_INVOKABLE void applyDesktopTheme();   // gsettings + compositor cursor

    // connections
    Q_INVOKABLE QVariantList wifiNetworks(bool rescan = false) const;
    Q_INVOKABLE bool wifiEnabled() const;
    Q_INVOKABLE QString wifiConnect(const QString &ssid, const QString &password) const;
    Q_INVOKABLE QVariantList bluetoothDevices() const;
    Q_INVOKABLE bool bluetoothPowered() const;
    Q_INVOKABLE QVariantList vpnConnections() const;
    Q_INVOKABLE QVariantMap wiredStatus() const;

    // displays (wlr-randr --json)
    Q_INVOKABLE QVariantList displays() const;
    Q_INVOKABLE QString applyDisplay(const QVariantMap &d) const;

    // system
    Q_INVOKABLE QVariantMap systemInfo() const;

    // defaults & reset (defaults.json is the same set of defaults the shell uses)
    Q_INVOKABLE QVariant defaultValue(const QString &key) const;
    Q_INVOKABLE bool isDefault(const QString &key) const;
    Q_INVOKABLE void reset(const QString &key);
    Q_INVOKABLE QString confDefault(const QString &section, const QString &key) const;
    Q_INVOKABLE bool isConfDefault(const QString &section, const QString &key) const;
    Q_INVOKABLE void resetConf(const QString &section, const QString &key);
    Q_INVOKABLE QVariantList resetGroups() const;               // [{id, label, hint}]
    Q_INVOKABLE QString resetSelected(const QStringList &groups);   // returns the backup folder
    Q_INVOKABLE QStringList resetBackups() const;
    Q_INVOKABLE void restoreBackup(const QString &dir);

    // updates & uninstall (run in a terminal so you see progress and the password prompt)
    Q_INVOKABLE QString installedVersion() const;
    Q_INVOKABLE QVariantMap checkUpdates() const;
    Q_INVOKABLE void runUpdate(bool force = false) const;          // in a terminal
    Q_INVOKABLE bool startUpdate(bool force = false);              // inside Settings: updateLine / updateFinished
    Q_INVOKABLE void cancelUpdate();
    Q_INVOKABLE QString updateLog() const;
    Q_INVOKABLE void uninstall(bool removeDeps, bool purge) const;
    Q_INVOKABLE void openInTerminal(const QString &shellCommand) const;
    Q_INVOKABLE QString gpuInfo() const;

    // keyboard shortcuts ([bindings] in nova.conf)
    Q_INVOKABLE QVariantList bindings() const;        // [{combo, action, isDefault}]
    Q_INVOKABLE QVariantList defaultBindings() const; // [{combo, action}]
    Q_INVOKABLE QString setBinding(const QString &oldCombo, const QString &newCombo, const QString &action);  // "" or an error
    Q_INVOKABLE void removeBinding(const QString &combo);
    Q_INVOKABLE QString normalizeCombo(const QString &combo) const;

    // trim a recording with ffmpeg (no re-encode). Returns the new file, or "" on failure.
    Q_INVOKABLE QString trimVideo(const QString &file, double start, double end, bool replace) const;

signals:
    void settingsChanged();
    void reloadPage();
    void asyncDone(const QString &tag, const QString &output);
    void updateLine(const QString &line);
    void updateFinished(int code);

private:
    void load();
    QString settingsPath() const;
    QString confPath() const;

    QVariantMap m_defaults, m_groups, m_confGroups;
    class QProcess *m_update = nullptr;
    void writeSettings();
    void loadDefaults();
    QVariantMap m_settings;
    QFileSystemWatcher m_watcher;
    QString m_startPage;
};
