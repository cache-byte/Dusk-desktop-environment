#include "backend.hpp"
#include <algorithm>

#include <QColor>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFontDatabase>
#include <QImage>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QSysInfo>
#include <QTextStream>
#include <cmath>

static QString configDir() {
    return QStandardPaths::writableLocation(QStandardPaths::GenericConfigLocation) + "/nova";
}

Backend::Backend(const QString &startPage, QObject *parent) : QObject(parent), m_startPage(startPage) {
    QDir().mkpath(configDir());
    loadDefaults();
    load();
    connect(&m_watcher, &QFileSystemWatcher::fileChanged, this, [this] {
        load();
        // editors replace files: re-add the watch
        if (!m_watcher.files().contains(settingsPath()) && QFile::exists(settingsPath())) m_watcher.addPath(settingsPath());
    });
    if (QFile::exists(settingsPath())) m_watcher.addPath(settingsPath());
}

QString Backend::settingsPath() const { return configDir() + "/settings.json"; }
QString Backend::confPath() const { return configDir() + "/nova.conf"; }

void Backend::load() {
    QFile f(settingsPath());
    if (f.open(QIODevice::ReadOnly)) m_settings = QJsonDocument::fromJson(f.readAll()).object().toVariantMap();
    emit settingsChanged();
}

void Backend::set(const QString &key, const QVariant &value) {
    m_settings[key] = value;
    writeSettings();
}

void Backend::writeSettings() {
    QFile f(settingsPath());
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        f.write(QJsonDocument(QJsonObject::fromVariantMap(m_settings)).toJson(QJsonDocument::Indented));
    f.close();
    if (!m_watcher.files().contains(settingsPath())) m_watcher.addPath(settingsPath());
    emit settingsChanged();
}

// ------------------------------------------------------------- nova.conf --
QString Backend::conf(const QString &section, const QString &key, const QString &fallback) const {
    QFile f(confPath());
    if (!f.open(QIODevice::ReadOnly)) return fallback;
    QString cur;
    QTextStream in(&f);
    while (!in.atEnd()) {
        const QString line = in.readLine().trimmed();
        if (line.startsWith('[') && line.endsWith(']')) { cur = line.mid(1, line.size() - 2); continue; }
        if (cur != section) continue;
        const int eq = line.indexOf('=');
        if (eq > 0 && line.left(eq).trimmed() == key) return line.mid(eq + 1).trimmed();
    }
    return fallback;
}

void Backend::setConf(const QString &section, const QString &key, const QString &value) {
    setConfQuiet(section, key, value);
    runDetached({"novactl", "dispatch", "reload"});
    emit settingsChanged();   // lets reset buttons refresh
}

// write nova.conf without asking the compositor to reload
void Backend::setConfQuiet(const QString &section, const QString &key, const QString &value) {
    QFile f(confPath());
    QStringList lines;
    if (f.open(QIODevice::ReadOnly)) {
        lines = QString::fromUtf8(f.readAll()).split('\n');
        f.close();
    }
    QString cur;
    int sectionEnd = -1;
    bool done = false;
    for (int i = 0; i < lines.size() && !done; i++) {
        const QString t = lines[i].trimmed();
        if (t.startsWith('[') && t.endsWith(']')) { cur = t.mid(1, t.size() - 2); continue; }
        if (cur != section) continue;
        sectionEnd = i;
        const int eq = t.indexOf('=');
        if (eq > 0 && t.left(eq).trimmed() == key) { lines[i] = key + " = " + value; done = true; }
    }
    if (!done) {
        if (sectionEnd >= 0) lines.insert(sectionEnd + 1, key + " = " + value);
        else lines << "" << "[" + section + "]" << key + " = " + value;
    }
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) f.write(lines.join('\n').toUtf8());
    f.close();
}

// ----------------------------------------------------------------- shell --
QString Backend::run(const QStringList &cmd, int timeoutMs) const {
    if (cmd.isEmpty()) return {};
    QProcess p;
    p.start(cmd.first(), cmd.mid(1));
    if (!p.waitForFinished(timeoutMs)) { p.kill(); return {}; }
    return QString::fromUtf8(p.readAllStandardOutput());
}

void Backend::runDetached(const QStringList &cmd) const {
    if (!cmd.isEmpty()) QProcess::startDetached(cmd.first(), cmd.mid(1));
}

// ------------------------------------------------------------ appearance --
static QStringList iconDirs() {
    return {QDir::homePath() + "/.local/share/icons", QDir::homePath() + "/.icons", "/usr/share/icons"};
}

QStringList Backend::iconThemes() const {
    QStringList out;
    for (const QString &d : iconDirs())
        for (const QString &t : QDir(d).entryList(QDir::Dirs | QDir::NoDotAndDotDot))
            if (QFile::exists(d + "/" + t + "/index.theme") && !QDir(d + "/" + t + "/cursors").exists() && t != "default" && t != "hicolor" && t != "locolor")
                out << t;
    out.removeDuplicates();
    out.sort(Qt::CaseInsensitive);
    return out;
}

QStringList Backend::cursorThemes() const {
    QStringList out;
    for (const QString &d : iconDirs())
        for (const QString &t : QDir(d).entryList(QDir::Dirs | QDir::NoDotAndDotDot))
            if (QDir(d + "/" + t + "/cursors").exists()) out << t;
    out.removeDuplicates();
    out.sort(Qt::CaseInsensitive);
    return out;
}

QStringList Backend::fonts(bool monospace) const {
    QStringList out;
    for (const QString &fam : QFontDatabase::families())
        if (QFontDatabase::isPrivateFamily(fam) == false && QFontDatabase::isFixedPitch(fam) == monospace) out << fam;
    return out;
}

QString Backend::wallpaperDir() const {
    return QStandardPaths::writableLocation(QStandardPaths::PicturesLocation) + "/Wallpapers";
}

QVariantList Backend::wallpapers() const {
    QVariantList out;
    static const QRegularExpression img("\\.(png|jpe?g|webp|bmp)$", QRegularExpression::CaseInsensitiveOption);
    static const QRegularExpression vid("\\.(mp4|webm|mkv|mov)$", QRegularExpression::CaseInsensitiveOption);
    QDir bundled("/usr/share/nova/shell/assets/wallpapers");
    for (const QString &n : bundled.entryList({"*.png", "*.jpg"}, QDir::Files, QDir::Name))
        out << QVariantMap{{"path", bundled.filePath(n)}, {"video", false}, {"bundled", true}};
    QDirIterator it(wallpaperDir(), QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        const QString p = it.next();
        if (img.match(p).hasMatch()) out << QVariantMap{{"path", p}, {"video", false}};
        else if (vid.match(p).hasMatch()) out << QVariantMap{{"path", p}, {"video", true}};
    }
    return out;
}

// Most "colourful" frequent hue in the image, nudged to a usable accent.
QString Backend::accentFromImage(const QString &path) const {
    QImage im(path);
    if (im.isNull()) return {};
    im = im.scaled(96, 96, Qt::IgnoreAspectRatio, Qt::SmoothTransformation).convertToFormat(QImage::Format_RGB32);
    double bins[36] = {}, sat[36] = {}, val[36] = {};
    for (int y = 0; y < im.height(); y++)
        for (int x = 0; x < im.width(); x++) {
            QColor c(im.pixel(x, y));
            float h, s, v;
            c.getHsvF(&h, &s, &v);
            if (h < 0 || s < 0.25 || v < 0.25) continue;
            int b = std::min(35, int(h * 36));
            double w = s * v;
            bins[b] += w;
            sat[b] += s * w;
            val[b] += v * w;
        }
    int best = 0;
    for (int i = 1; i < 36; i++)
        if (bins[i] > bins[best]) best = i;
    if (bins[best] <= 0) return "#c8b64a";
    QColor c = QColor::fromHsvF((best + 0.5) / 36.0, std::clamp(sat[best] / bins[best], 0.45, 0.75),
                                std::clamp(val[best] / bins[best], 0.70, 0.88));
    return c.name();
}

void Backend::applyDesktopTheme() {
    auto gs = [this](const QString &k, const QString &v) {
        runDetached({"gsettings", "set", "org.gnome.desktop.interface", k, v});
    };
    const QVariantMap &s = m_settings;
    const QString icon = s.value("iconTheme", "Papirus-Dark").toString();
    const QString cursor = s.value("cursorTheme", "Bibata-Modern-Classic").toString();
    const int csize = s.value("cursorSize", 24).toInt();
    const QString font = s.value("font", "Inter").toString();
    const int fsize = s.value("fontSize", 14).toInt();
    const QString mono = s.value("monoFont", "JetBrains Mono").toString();
    const QString mode = s.value("mode", "dark").toString();
    gs("icon-theme", icon);
    gs("cursor-theme", cursor);
    gs("cursor-size", QString::number(csize));
    // gsettings wants points; the UI shows px (1pt = 4/3 px at 96 dpi)
    gs("font-name", QString("%1 %2").arg(font).arg(std::lround(fsize * 0.75)));
    gs("monospace-font-name", QString("%1 %2").arg(mono).arg(std::lround(fsize * 0.75)));
    gs("color-scheme", mode == "light" ? "prefer-light" : "prefer-dark");
    gs("accent-color", "yellow");   // nearest GNOME accent for GTK4/libadwaita apps
    runDetached({"novactl", "dispatch", "cursor", cursor, QString::number(csize)});
    runDetached({"nova-theme", "apply"});   // GTK3 / Qt / Flatpak follow light & dark
    setConf("cursor", "theme", cursor);
    setConf("cursor", "size", QString::number(csize));
}

// ----------------------------------------------------------- connections --
static QStringList splitTerse(const QString &line) {
    // nmcli -t escapes ':' as '\:'
    QStringList out;
    QString cur;
    for (int i = 0; i < line.size(); i++) {
        if (line[i] == '\\' && i + 1 < line.size()) { cur += line[++i]; continue; }
        if (line[i] == ':') { out << cur; cur.clear(); continue; }
        cur += line[i];
    }
    out << cur;
    return out;
}

QVariantList Backend::wifiNetworks(bool rescan) const {
    QVariantList out;
    QStringList seen;
    const QString txt = run({"nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", rescan ? "yes" : "auto"}, 8000);
    for (const QString &l : txt.split('\n', Qt::SkipEmptyParts)) {
        const QStringList p = splitTerse(l);
        if (p.size() < 4 || p[1].isEmpty() || seen.contains(p[1])) continue;
        seen << p[1];
        out << QVariantMap{{"active", p[0] == "*"}, {"ssid", p[1]}, {"signal", p[2].toInt()}, {"secure", !p[3].isEmpty() && p[3] != "--"}};
    }
    return out;
}

bool Backend::wifiEnabled() const { return run({"nmcli", "radio", "wifi"}).trimmed() == "enabled"; }

QString Backend::wifiConnect(const QString &ssid, const QString &password) const {
    QStringList cmd{"nmcli", "dev", "wifi", "connect", ssid};
    if (!password.isEmpty()) cmd << "password" << password;
    QProcess p;
    p.start(cmd.first(), cmd.mid(1));
    p.waitForFinished(20000);
    return p.exitCode() == 0 ? QString() : QString::fromUtf8(p.readAllStandardError()).trimmed();
}

QVariantList Backend::bluetoothDevices() const {
    QVariantList out;
    const QString list = run({"bluetoothctl", "devices"});
    const QString paired = run({"bluetoothctl", "devices", "Paired"});
    for (const QString &l : list.split('\n', Qt::SkipEmptyParts)) {
        // "Device AA:BB:CC:DD:EE:FF Name"
        const QStringList p = l.split(' ');
        if (p.size() < 3 || p[0] != "Device") continue;
        const QString mac = p[1], name = p.mid(2).join(' ');
        const QString info = run({"bluetoothctl", "info", mac}, 2000);
        QRegularExpression bat("Battery Percentage: 0x[0-9a-fA-F]+ \\((\\d+)\\)");
        QRegularExpression icon("Icon: (\\S+)");
        auto bm = bat.match(info);
        auto im = icon.match(info);
        out << QVariantMap{{"mac", mac},
                           {"name", name},
                           {"paired", paired.contains(mac)},
                           {"connected", info.contains("Connected: yes")},
                           {"battery", bm.hasMatch() ? bm.captured(1).toInt() : -1},
                           {"icon", im.hasMatch() ? im.captured(1) : "bluetooth"}};
    }
    return out;
}

bool Backend::bluetoothPowered() const { return run({"bluetoothctl", "show"}).contains("Powered: yes"); }

QVariantList Backend::vpnConnections() const {
    QVariantList out;
    for (const QString &l : run({"nmcli", "-t", "-f", "NAME,TYPE,ACTIVE", "con", "show"}).split('\n', Qt::SkipEmptyParts)) {
        const QStringList p = splitTerse(l);
        if (p.size() >= 3 && (p[1] == "vpn" || p[1] == "wireguard"))
            out << QVariantMap{{"name", p[0]}, {"type", p[1]}, {"active", p[2] == "yes"}};
    }
    return out;
}

QVariantMap Backend::wiredStatus() const {
    for (const QString &l : run({"nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "dev"}).split('\n', Qt::SkipEmptyParts)) {
        const QStringList p = splitTerse(l);
        if (p.size() >= 4 && p[1] == "ethernet")
            return {{"device", p[0]}, {"connected", p[2] == "connected"}, {"state", p[2]}, {"connection", p[3]}};
    }
    return {{"device", ""}, {"connected", false}, {"state", "unavailable"}};
}

// --------------------------------------------------------------- display --
QVariantList Backend::displays() const {
    const QJsonDocument doc = QJsonDocument::fromJson(run({"wlr-randr", "--json"}).toUtf8());
    QVariantList out;
    for (const QJsonValue &v : doc.array()) {
        QJsonObject o = v.toObject();
        QVariantMap d;
        d["name"] = o["name"].toString();
        d["description"] = o["description"].toString();
        d["make"] = o["make"].toString();
        d["model"] = o["model"].toString();
        d["enabled"] = o["enabled"].toBool();
        d["scale"] = o["scale"].toDouble(1.0);
        d["transform"] = o["transform"].toString("normal");
        d["x"] = o["position"].toObject()["x"].toInt();
        d["y"] = o["position"].toObject()["y"].toInt();
        d["adaptiveSync"] = o["adaptive_sync"].toBool();
        const QJsonObject phys = o["physical_size"].toObject();
        const double diag = std::hypot(phys["width"].toDouble(), phys["height"].toDouble()) / 25.4;
        d["inches"] = diag > 1 ? QString::number(diag, 'f', 1) : QString();
        d["builtin"] = d["name"].toString().startsWith("eDP") || d["name"].toString().startsWith("LVDS");
        QVariantList modes;
        for (const QJsonValue &mv : o["modes"].toArray()) {
            const QJsonObject m = mv.toObject();
            QVariantMap mm{{"width", m["width"].toInt()},
                           {"height", m["height"].toInt()},
                           {"refresh", m["refresh"].toDouble()},
                           {"preferred", m["preferred"].toBool()},
                           {"current", m["current"].toBool()}};
            modes << mm;
            if (m["current"].toBool()) d["mode"] = mm;
        }
        d["modes"] = modes;
        out << d;
    }
    return out;
}

QString Backend::applyDisplay(const QVariantMap &d) const {
    QStringList cmd{"wlr-randr", "--output", d["name"].toString()};
    if (!d["enabled"].toBool()) cmd << "--off";
    else {
        cmd << "--on";
        const QVariantMap m = d["mode"].toMap();
        if (!m.isEmpty())
            cmd << "--mode" << QString("%1x%2@%3Hz").arg(m["width"].toInt()).arg(m["height"].toInt()).arg(m["refresh"].toDouble(), 0, 'f', 3);
        cmd << "--scale" << QString::number(std::clamp(d["scale"].toDouble(), 1.0, 2.0), 'f', 2);   // Nova caps scale at 200 %
        cmd << "--transform" << d["transform"].toString();
        cmd << "--pos" << QString("%1,%2").arg(d["x"].toInt()).arg(d["y"].toInt());
        // only touch adaptive sync when it's wanted: screens without VRR reject the option entirely
        if (d["adaptiveSync"].toBool()) cmd << "--adaptive-sync" << "enabled";
    }
    QProcess p;
    p.start(cmd.first(), cmd.mid(1));
    p.waitForFinished(5000);
    if (p.exitCode() != 0) return QString::fromUtf8(p.readAllStandardError()).trimmed();
    // remember it for the next login ([output NAME] in nova.conf; the compositor applies it at start)
    if (d["enabled"].toBool()) {
        Backend *self = const_cast<Backend *>(this);
        const QString sec = "output " + d["name"].toString();
        const QVariantMap m = d["mode"].toMap();
        if (!m.isEmpty())
            self->setConfQuiet(sec, "mode", QString("%1x%2@%3").arg(m["width"].toInt()).arg(m["height"].toInt()).arg(m["refresh"].toDouble(), 0, 'f', 3));
        self->setConfQuiet(sec, "scale", QString::number(std::clamp(d["scale"].toDouble(), 1.0, 2.0), 'f', 2));
        self->setConfQuiet(sec, "position", QString("%1,%2").arg(d["x"].toInt()).arg(d["y"].toInt()));
        self->setConfQuiet(sec, "transform", d["transform"].toString());
    }
    return {};
}

// ---------------------------------------------------------------- system --
QVariantMap Backend::systemInfo() const {
    QVariantMap m;
    m["os"] = QSysInfo::prettyProductName();
    m["kernel"] = QSysInfo::kernelVersion();
    m["host"] = QSysInfo::machineHostName();
    QFile cpu("/proc/cpuinfo");
    if (cpu.open(QIODevice::ReadOnly)) {
        int cores = 0;
        for (const QString &l : QString(cpu.readAll()).split('\n')) {
            if (l.startsWith("model name") && m["cpu"].isNull()) m["cpu"] = l.section(':', 1).trimmed();
            if (l.startsWith("processor")) cores++;
        }
        m["cores"] = cores;
    }
    QFile mem("/proc/meminfo");
    if (mem.open(QIODevice::ReadOnly)) {
        const QString first = QString(mem.readLine());
        m["memory"] = QString::number(first.section(':', 1).trimmed().split(' ').first().toDouble() / 1048576.0, 'f', 1) + " GB";
    }
    const QString gpu = run({"sh", "-c", "lspci 2>/dev/null | grep -Ei 'vga|3d|display' | cut -d: -f3 | sed 's/^ *//' | paste -sd'+' | sed 's/+/  +  /g'"}).trimmed();
    m["gpu"] = gpu.isEmpty() ? "Unknown" : gpu;
    m["desktop"] = "Nova " + QStringLiteral(NOVA_VERSION) + " (Wayland)";
    return m;
}
