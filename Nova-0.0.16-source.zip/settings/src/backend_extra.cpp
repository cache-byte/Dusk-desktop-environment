// Defaults / reset, updates and uninstall for the Settings app.
#include "backend.hpp"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QProcess>
#include <QSet>
#include <functional>
#include <QStandardPaths>

static QString cfgDir() {
    return QStandardPaths::writableLocation(QStandardPaths::GenericConfigLocation) + "/nova";
}

void Backend::loadDefaults() {
    for (const char *p : {":/qt/qml/Nova/Settings/defaults.json", ":/Nova/Settings/defaults.json"}) {
        QFile f(p);
        if (!f.open(QIODevice::ReadOnly)) continue;
        const QJsonObject o = QJsonDocument::fromJson(f.readAll()).object();
        m_defaults = o["values"].toObject().toVariantMap();
        m_groups = o["groups"].toObject().toVariantMap();
        m_confGroups = o["confGroups"].toObject().toVariantMap();
        return;
    }
}

QVariant Backend::defaultValue(const QString &key) const { return m_defaults.value(key); }

bool Backend::isDefault(const QString &key) const {
    if (!m_settings.contains(key) || !m_defaults.contains(key)) return true;
    return QJsonValue::fromVariant(m_settings.value(key)) == QJsonValue::fromVariant(m_defaults.value(key));
}

void Backend::reset(const QString &key) {
    if (!m_defaults.contains(key)) return;
    m_settings[key] = m_defaults.value(key);
    writeSettings();
    if (m_groups.value("appearance").toStringList().contains(key)) applyDesktopTheme();
    emit reloadPage();
}

// The compositor prints its built-in nova.conf with `nova -c`.
static QString defaultConfText() {
    static QString cached;
    if (cached.isEmpty()) {
        QProcess p;
        p.start("nova", {"-c"});
        p.waitForFinished(3000);
        cached = QString::fromUtf8(p.readAllStandardOutput());
    }
    return cached;
}
static QString iniValue(const QString &text, const QString &section, const QString &key) {
    QString cur;
    for (const QString &raw : text.split('\n')) {
        const QString l = raw.trimmed();
        if (l.startsWith('[') && l.endsWith(']')) { cur = l.mid(1, l.size() - 2); continue; }
        if (cur != section || l.startsWith('#')) continue;
        const int eq = l.indexOf('=');
        if (eq > 0 && l.left(eq).trimmed() == key) return l.mid(eq + 1).trimmed();
    }
    return {};
}

QString Backend::confDefault(const QString &section, const QString &key) const {
    return iniValue(defaultConfText(), section, key);
}
bool Backend::isConfDefault(const QString &section, const QString &key) const {
    const QString d = confDefault(section, key);
    return conf(section, key, d) == d;
}
void Backend::resetConf(const QString &section, const QString &key) {
    setConf(section, key, confDefault(section, key));
    emit reloadPage();
}

QVariantList Backend::resetGroups() const {
    // id, label, hint — shown as checkboxes on the About page
    const QList<QStringList> rows = {
        {"appearance", "Appearance", "Theme, accent, wallpaper, fonts, icons, cursor"},
        {"panel", "Panel & launcher", "Pinned apps, clock, desktop icons"},
        {"controlcentre", "Control centre layout", "Tile positions and sizes"},
        {"popups", "Popups & indicators", "Where OSDs and pop-ups appear"},
        {"notifications", "Notifications", "Do not disturb, grouping, timing"},
        {"sound", "Sound", "Volume above 100 %"},
        {"power", "Power & idle", "Dim, lock and sleep times, GPU choice"},
        {"music", "Music & lyrics", "Lyric and visualizer styles"},
        {"gaming", "Gaming & capture", "Game mode, replay, recording"},
        {"clipboard", "Clipboard", "History size and keeping it"},
        {"keyboard", "Keyboard, mouse & touchpad", "Layout, repeat, scrolling, tap to click, gestures"},
        {"shortcuts", "Keyboard shortcuts", "Every key binding"},
        {"windows", "Windows & tiling", "Gaps, focus, snapping"},
        {"updates", "Update channel", "Release or latest"},
    };
    QVariantList out;
    for (const auto &r : rows) out << QVariantMap{{"id", r[0]}, {"label", r[1]}, {"hint", r[2]}};
    return out;
}

QString Backend::resetSelected(const QStringList &groups) {
    // 1. back up everything first
    const QString stamp = QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss");
    const QString dir = cfgDir() + "/backup/reset-" + stamp;
    QDir().mkpath(dir);
    QFile::copy(settingsPath(), dir + "/settings.json");
    QFile::copy(confPath(), dir + "/nova.conf");

    // 2. settings.json groups
    bool appearance = false;
    for (const QString &g : groups) {
        for (const QString &k : m_groups.value(g).toStringList())
            if (m_defaults.contains(k)) m_settings[k] = m_defaults.value(k);
        if (g == "appearance") appearance = true;
    }
    writeSettings();

    // 3. nova.conf sections: replace them with the built-in defaults
    QStringList sections;
    for (const QString &g : groups) sections += m_confGroups.value(g).toStringList();
    if (!sections.isEmpty()) {
        const QString def = defaultConfText();
        QFile f(confPath());
        QStringList lines;
        if (f.open(QIODevice::ReadOnly)) { lines = QString::fromUtf8(f.readAll()).split('\n'); f.close(); }
        // drop the chosen sections from the user's file
        QStringList kept;
        QString cur;
        for (const QString &raw : lines) {
            const QString t = raw.trimmed();
            if (t.startsWith('[') && t.endsWith(']')) cur = t.mid(1, t.size() - 2);
            if (!sections.contains(cur)) kept << raw;
        }
        // append the default versions
        for (const QString &raw : def.split('\n')) {
            const QString t = raw.trimmed();
            if (t.startsWith('[') && t.endsWith(']')) cur = t.mid(1, t.size() - 2);
            if (sections.contains(cur)) kept << raw;
        }
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) f.write(kept.join('\n').toUtf8());
        runDetached({"novactl", "dispatch", "reload"});
    }
    if (appearance) { applyDesktopTheme(); runDetached({"nova-theme", "apply"}); }
    emit reloadPage();
    return dir;
}

QStringList Backend::resetBackups() const {
    QDir d(cfgDir() + "/backup");
    QStringList out;
    for (const QString &n : d.entryList({"reset-*"}, QDir::Dirs, QDir::Name | QDir::Reversed)) out << d.filePath(n);
    return out;
}

void Backend::restoreBackup(const QString &dir) {
    if (QFile::exists(dir + "/settings.json")) {
        QFile::remove(settingsPath());
        QFile::copy(dir + "/settings.json", settingsPath());
        load();
    }
    if (QFile::exists(dir + "/nova.conf")) {
        QFile::remove(confPath());
        QFile::copy(dir + "/nova.conf", confPath());
        runDetached({"novactl", "dispatch", "reload"});
    }
    applyDesktopTheme();
    runDetached({"nova-theme", "apply"});
    emit reloadPage();
}

// ---------------------------------------------------------------- updates --
QString Backend::installedVersion() const {
    QFile f("/usr/share/nova/VERSION");
    return f.open(QIODevice::ReadOnly) ? QString::fromUtf8(f.readAll()).trimmed() : QStringLiteral(NOVA_VERSION);
}

QVariantMap Backend::checkUpdates() const {
    const QString out = run({"nova-update", "--check"}, 20000).trimmed();
    QVariantMap m = QJsonDocument::fromJson(out.toUtf8()).object().toVariantMap();
    if (m.isEmpty()) m = {{"ok", false}, {"installed", installedVersion()}};
    return m;
}

void Backend::openInTerminal(const QString &shellCommand) const {
    const QString term = conf("general", "terminal", "ptyxis");
    const QString cmd = shellCommand + "; echo; read -r -p 'Press Enter to close' _";
    if (term == "ptyxis" || term == "gnome-terminal" || term == "kgx" || term == "kitty")
        runDetached({term, "--", "sh", "-c", cmd});
    else
        runDetached({term, "-e", "sh", "-c", cmd});
}

void Backend::runUpdate(bool force) const { openInTerminal(force ? "nova-update --force" : "nova-update"); }

void Backend::uninstall(bool removeDeps, bool purge) const {
    QString c = "nova-uninstall";
    if (removeDeps) c += " --remove-deps";
    if (purge) c += " --purge";
    openInTerminal(c);
}

QString Backend::gpuInfo() const { return run({"nova-gpu", "info"}).trimmed(); }

// ------------------------------------------------------------------- trim --
QString Backend::trimVideo(const QString &file, double start, double end, bool replace) const {
    const QFileInfo fi(file);
    const QString out = fi.path() + "/" + fi.completeBaseName() + "-trimmed." + fi.suffix();
    QProcess p;
    p.start("ffmpeg", {"-y", "-loglevel", "error", "-ss", QString::number(start, 'f', 3), "-to", QString::number(end, 'f', 3),
                       "-i", file, "-c", "copy", "-avoid_negative_ts", "make_zero", out});
    if (!p.waitForFinished(120000) || p.exitCode() != 0 || !QFile::exists(out)) return {};
    if (replace) {
        QFile::remove(file);
        QFile::rename(out, file);
        return file;
    }
    return out;
}

// -------------------------------------------------------------- shortcuts --
QString Backend::normalizeCombo(const QString &combo) const {
    // "shift+super+a" -> "Super+Shift+A": fixed modifier order so duplicates are easy to spot
    static const QStringList order = {"Super", "Ctrl", "Alt", "Shift"};
    QStringList parts = combo.split('+', Qt::SkipEmptyParts);
    for (QString &p : parts) p = p.trimmed();
    if (parts.isEmpty()) return {};
    QString key = parts.takeLast();
    QStringList mods;
    for (const QString &m : order)
        for (const QString &p : parts) {
            const QString l = p.toLower();
            const QString canon = (l == "mod4" || l == "logo" || l == "win") ? "super" : (l == "control") ? "ctrl" : (l == "mod1") ? "alt" : l;
            if (canon == m.toLower() && !mods.contains(m)) mods << m;
        }
    // a lone "Super" is the tap binding; keep it as is
    if (parts.isEmpty() && key.compare("super", Qt::CaseInsensitive) == 0) return "Super";
    if (key.size() == 1) key = key.toUpper();
    mods << key;
    return mods.join('+');
}

static QList<QPair<QString, QString>> parseBindings(const QString &text) {
    QList<QPair<QString, QString>> out;
    QString cur;
    for (const QString &raw : text.split('\n')) {
        const QString l = raw.trimmed();
        if (l.startsWith('[') && l.endsWith(']')) { cur = l.mid(1, l.size() - 2); continue; }
        if (cur != "bindings" || l.isEmpty() || l.startsWith('#')) continue;
        const int eq = l.indexOf('=');
        if (eq > 0) out << qMakePair(l.left(eq).trimmed(), l.mid(eq + 1).trimmed());
    }
    return out;
}

QVariantList Backend::defaultBindings() const {
    QVariantList out;
    for (const auto &b : parseBindings(defaultConfText()))
        out << QVariantMap{{"combo", normalizeCombo(b.first)}, {"action", b.second}};
    return out;
}

QVariantList Backend::bindings() const {
    QFile f(confPath());
    QString text;
    if (f.open(QIODevice::ReadOnly)) text = QString::fromUtf8(f.readAll());
    if (!text.contains("[bindings]")) text = defaultConfText();
    QSet<QString> defs;
    for (const auto &b : parseBindings(defaultConfText())) defs << normalizeCombo(b.first) + "=" + b.second;
    QVariantList out;
    for (const auto &b : parseBindings(text)) {
        const QString c = normalizeCombo(b.first);
        out << QVariantMap{{"combo", c}, {"action", b.second}, {"isDefault", defs.contains(c + "=" + b.second)}};
    }
    return out;
}

// Rewrites the [bindings] section of nova.conf line by line, keeping comments.
static void editBindings(const QString &path, const std::function<void(QStringList &, int, int)> &fn) {
    QFile f(path);
    QStringList lines;
    if (f.open(QIODevice::ReadOnly)) { lines = QString::fromUtf8(f.readAll()).split('\n'); f.close(); }
    int start = -1, end = lines.size();
    for (int i = 0; i < lines.size(); i++) {
        const QString t = lines[i].trimmed();
        if (t == "[bindings]") start = i;
        else if (start >= 0 && t.startsWith('[') && t.endsWith(']')) { end = i; break; }
    }
    if (start < 0) { lines << "" << "[bindings]"; start = lines.size() - 1; end = lines.size(); }
    fn(lines, start, end);
    if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) f.write(lines.join('\n').toUtf8());
}

QString Backend::setBinding(const QString &oldCombo, const QString &newCombo, const QString &action) {
    const QString nc = normalizeCombo(newCombo), oc = normalizeCombo(oldCombo);
    if (nc.isEmpty() || action.trimmed().isEmpty()) return "Pick a key and an action";
    for (const QVariant &v : bindings()) {
        const QVariantMap b = v.toMap();
        if (b["combo"].toString() == nc && nc != oc) return nc + " is already used for “" + b["action"].toString() + "”";
    }
    // nova.conf may not have a [bindings] section yet: start from the defaults
    {
        QFile f(confPath());
        QString text;
        if (f.open(QIODevice::ReadOnly)) { text = QString::fromUtf8(f.readAll()); f.close(); }
        if (!text.contains("[bindings]") && f.open(QIODevice::WriteOnly | QIODevice::Append)) {
            QString sect;
            bool in = false;
            for (const QString &raw : defaultConfText().split('\n')) {
                const QString t = raw.trimmed();
                if (t.startsWith('[') && t.endsWith(']')) in = (t == "[bindings]");
                if (in) sect += raw + "\n";
            }
            f.write(("\n" + sect).toUtf8());
        }
    }
    editBindings(confPath(), [&](QStringList &lines, int start, int end) {
        for (int i = start + 1; i < end; i++) {
            const QString t = lines[i].trimmed();
            const int eq = t.indexOf('=');
            if (eq > 0 && !t.startsWith('#') && !oc.isEmpty() && normalizeCombo(t.left(eq)) == oc) {
                lines[i] = QString("%1 = %2").arg(nc.leftJustified(23), action.trimmed());
                return;
            }
        }
        lines.insert(end, QString("%1 = %2").arg(nc.leftJustified(23), action.trimmed()));
    });
    runDetached({"novactl", "dispatch", "reload"});
    emit settingsChanged();
    return {};
}

void Backend::removeBinding(const QString &combo) {
    const QString c = normalizeCombo(combo);
    editBindings(confPath(), [&](QStringList &lines, int start, int end) {
        for (int i = end - 1; i > start; i--) {
            const QString t = lines[i].trimmed();
            const int eq = t.indexOf('=');
            if (eq > 0 && !t.startsWith('#') && normalizeCombo(t.left(eq)) == c) lines.removeAt(i);
        }
    });
    runDetached({"novactl", "dispatch", "reload"});
    emit settingsChanged();
}

// ------------------------------------------------------------------ async --
void Backend::runAsync(const QStringList &cmd, const QString &tag) {
    if (cmd.isEmpty()) return;
    auto *p = new QProcess(this);
    connect(p, &QProcess::finished, this, [this, p, tag](int, QProcess::ExitStatus) {
        emit asyncDone(tag, QString::fromUtf8(p->readAllStandardOutput()));
        p->deleteLater();
    });
    connect(p, &QProcess::errorOccurred, this, [this, p, tag](QProcess::ProcessError e) {
        if (e == QProcess::FailedToStart) { emit asyncDone(tag, QString()); p->deleteLater(); }
    });
    p->start(cmd.first(), cmd.mid(1));
}

// ------------------------------------------------------ in-app updater --
// Runs `nova-update --gui`: it prints "::step 2 8 Title", "::task Label", "::ok Label",
// "::fail Label", "::warn Text", "::done Title" lines; the polkit dialog asks for the password.
bool Backend::startUpdate(bool force) {
    if (m_update) return false;
    m_update = new QProcess(this);
    m_update->setProcessChannelMode(QProcess::MergedChannels);
    connect(m_update, &QProcess::readyRead, this, [this] {
        while (m_update && m_update->canReadLine())
            emit updateLine(QString::fromUtf8(m_update->readLine()).trimmed());
    });
    connect(m_update, &QProcess::finished, this, [this](int code, QProcess::ExitStatus st) {
        const QString rest = QString::fromUtf8(m_update->readAll()).trimmed();
        for (const QString &l : rest.split('\n', Qt::SkipEmptyParts)) emit updateLine(l);
        m_update->deleteLater();
        m_update = nullptr;
        emit updateFinished(st == QProcess::NormalExit ? code : -1);
    });
    QStringList args{"--gui"};
    if (force) args << "--force";
    m_update->start("nova-update", args);
    return true;
}

void Backend::cancelUpdate() {
    if (m_update) m_update->terminate();
}

QString Backend::updateLog() const {
    QFile f("/tmp/nova-install.log");
    return f.open(QIODevice::ReadOnly) ? QString::fromUtf8(f.readAll()).right(20000) : QString();
}
