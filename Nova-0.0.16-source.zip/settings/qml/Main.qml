import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import QtQuick.Window
import Nova.Settings

ApplicationWindow {
    id: win
    width: 1240; height: 780
    minimumWidth: 900; minimumHeight: 600
    visible: true
    title: "Settings"
    flags: Qt.Window | Qt.FramelessWindowHint
    color: "transparent"
    font.family: Theme.font

    property string page: Backend.startPage
    readonly property var pages: [
        ["nova", "For you"], null,
        ["palette", "Appearance"], ["wifi", "Connections"], ["monitor", "Display"], ["volume", "Sound"],
        ["battery", "Power"], ["bell", "Notifications"], ["frame", "Popups & indicators"], ["music", "Music & lyrics"], null,
        ["game", "Gaming"], ["square", "Windows & tiling"], ["keyboard", "Keyboard"], ["mouse", "Mouse & touchpad"],
        ["grid", "Panel & launcher"], ["user", "Users"], ["restart", "Updates"], ["info", "About"]
    ]
    property string filter: ""
    // after a reset, rebuild the page so every control shows the restored value
    Connections { target: Backend; function onReloadPage() { const p = win.page; win.page = ""; win.page = p } }

    Rectangle {
        anchors.fill: parent
        radius: win.visibility === Window.Maximized ? 0 : 16
        color: Theme.window
        border.color: Theme.border
        clip: true

        RowLayout {
            anchors.fill: parent
            spacing: 0

            // ---- sidebar ----
            Rectangle {
                Layout.preferredWidth: 268; Layout.fillHeight: true
                color: Theme.sidebar
                Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Theme.border }
                MouseArea { anchors.fill: parent; onPressed: win.startSystemMove() }
                ColumnLayout {
                    anchors.fill: parent; anchors.margins: 14; anchors.topMargin: 22
                    spacing: 3
                    Text { text: "Settings"; color: Theme.text; font.pixelSize: 20; font.weight: Font.DemiBold; Layout.leftMargin: 10; Layout.bottomMargin: 12 }
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: 38; radius: 11; color: Theme.surface2; border.color: Theme.border; Layout.bottomMargin: 12
                        RowLayout { anchors.fill: parent; anchors.leftMargin: 12; spacing: 10
                            Icon { name: "search"; size: 16; color: Theme.text3 }
                            TextInput { id: sf; Layout.fillWidth: true; color: Theme.text; font.pixelSize: 13; onTextChanged: win.filter = text.toLowerCase()
                                Text { visible: !sf.text; text: "Search settings"; color: Theme.text3; font: sf.font } } }
                    }
                    Flickable {
                        Layout.fillWidth: true; Layout.fillHeight: true
                        contentHeight: navCol.implicitHeight; clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        ColumnLayout {
                            id: navCol
                            width: parent.width; spacing: 2
                            Repeater {
                                model: win.pages
                                delegate: Item {
                                    required property var modelData
                                    Layout.fillWidth: true
                                    implicitHeight: modelData ? (visibleItem ? 36 : 0) : 13
                                    readonly property bool visibleItem: modelData && modelData[1].toLowerCase().includes(win.filter)
                                    visible: modelData ? visibleItem : win.filter === ""
                                    Rectangle { visible: !parent.modelData; anchors.centerIn: parent; width: parent.width - 20; height: 1; color: Theme.border }
                                    Rectangle {
                                        visible: !!parent.modelData
                                        anchors.fill: parent; radius: 11
                                        readonly property bool on: parent.modelData && win.page === parent.modelData[1]
                                        color: on ? Theme.accentSoft : nma.containsMouse ? Theme.surface2 : "transparent"
                                        Rectangle { visible: parent.on; width: 3; height: parent.height - 16; radius: 2; anchors.verticalCenter: parent.verticalCenter; color: Theme.accent }
                                        RowLayout { anchors.fill: parent; anchors.leftMargin: 12; spacing: 12
                                            Icon { name: parent.parent.parent.modelData ? parent.parent.parent.modelData[0] : "info"; size: 18; color: parent.parent.on ? Theme.accentBright : Theme.text2 }
                                            Text { text: parent.parent.parent.modelData ? parent.parent.parent.modelData[1] : ""; color: parent.parent.on ? Theme.accentBright : Theme.text2; font.pixelSize: 14; font.weight: parent.parent.on ? Font.DemiBold : Font.Normal } }
                                        MouseArea { id: nma; anchors.fill: parent; hoverEnabled: true; onClicked: win.page = parent.parent.modelData[1] }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ---- content ----
            ColumnLayout {
                Layout.fillWidth: true; Layout.fillHeight: true
                spacing: 0
                Item {
                    Layout.fillWidth: true; implicitHeight: 68
                    MouseArea { anchors.fill: parent; onPressed: win.startSystemMove(); onDoubleClicked: win.visibility === Window.Maximized ? win.showNormal() : win.showMaximized() }
                    Text { anchors.left: parent.left; anchors.leftMargin: 34; anchors.verticalCenter: parent.verticalCenter
                           text: win.page; color: Theme.accentBright; font.pixelSize: 26; font.weight: Font.DemiBold }
                    Row {
                        anchors.right: parent.right; anchors.rightMargin: 14; anchors.top: parent.top; anchors.topMargin: 12
                        spacing: 6
                        Repeater {
                            model: [["minus", () => win.showMinimized()], ["square", () => win.visibility === Window.Maximized ? win.showNormal() : win.showMaximized()], ["x", () => Qt.quit()]]
                            Rectangle {
                                required property var modelData; required property int index
                                width: 30; height: 30; radius: 9
                                color: wma.containsMouse ? (index === 2 ? Theme.danger : Theme.surface3) : "transparent"
                                Icon { anchors.centerIn: parent; name: modelData[0]; size: 16; color: wma.containsMouse && index === 2 ? "white" : Theme.text2 }
                                MouseArea { id: wma; anchors.fill: parent; hoverEnabled: true; onClicked: modelData[1]() }
                            }
                        }
                    }
                }
                ScrollView {
                    Layout.fillWidth: true; Layout.fillHeight: true
                    contentWidth: availableWidth
                    clip: true
                    Loader {
                        id: pageLoader
                        x: 34
                        width: parent.width - 68
                        source: win.page ? "pages/" + win.page.replace(/[^A-Za-z]/g, "") + "Page.qml" : ""
                    }
                }
            }
        }
        // resize grip
        MouseArea {
            width: 18; height: 18; anchors.right: parent.right; anchors.bottom: parent.bottom
            cursorShape: Qt.SizeFDiagCursor
            onPressed: win.startSystemResize(Qt.RightEdge | Qt.BottomEdge)
        }
    }
}
