// "Label .......... control  ↺" row.
// Give it `key` (settings.json) or `confKey: ["section", "key"]` (nova.conf) and a small
// reset button appears whenever the value differs from Nova's default.
import QtQuick
import Nova.Settings
import QtQuick.Layouts

RowLayout {
    id: root
    property string label
    property string hint
    property string key: ""
    property var confKey: null
    signal resetDone()
    default property alias control: slot.data
    readonly property bool changed: {
        Backend.settings;   // re-evaluate whenever settings change
        if (key !== "") return !Backend.isDefault(key);
        if (confKey) return !Backend.isConfDefault(confKey[0], confKey[1]);
        return false;
    }
    Layout.fillWidth: true
    spacing: 16
    ColumnLayout { Layout.fillWidth: true; Layout.minimumWidth: 160; spacing: 2
        Text { text: root.label; color: Theme.text; font.pixelSize: 14; elide: Text.ElideRight; Layout.fillWidth: true }
        Text { visible: root.hint !== ""; text: root.hint; color: Theme.text3; font.pixelSize: 12; wrapMode: Text.Wrap; Layout.fillWidth: true } }
    RowLayout { id: slot; spacing: 10 }
    ResetButton {
        visible: root.key !== "" || root.confKey !== null
        active: root.changed
        onClicked: {
            if (root.key !== "") Backend.reset(root.key);
            else Backend.resetConf(root.confKey[0], root.confKey[1]);
            root.resetDone();
        }
    }
}
