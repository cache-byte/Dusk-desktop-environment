import QtQuick
import Nova.Settings
Text { color: Theme.text3; font.pixelSize: 12; font.weight: Font.Medium; font.letterSpacing: 0.5; font.capitalization: Font.AllUppercase }
