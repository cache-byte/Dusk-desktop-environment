pragma Singleton
import QtQuick

QtObject {
    readonly property var s: Backend.settings
    readonly property bool dark: (s.mode ?? "dark") !== "light"
    readonly property color accent: s.accent ?? "#c8b64a"
    readonly property color accentBright: Qt.lighter(accent, 1.25)
    readonly property color onAccent: Qt.darker(accent, 4.2)
    readonly property color accentSoft: Qt.rgba(accent.r, accent.g, accent.b, 0.16)
    readonly property color accentLine: Qt.rgba(accent.r, accent.g, accent.b, 0.45)
    readonly property color window: dark ? Qt.rgba(0.086, 0.082, 0.118, 1 - (s.transparencyApps ?? 0.18)) : Qt.rgba(0.97, 0.96, 0.94, 1 - (s.transparencyApps ?? 0.18))
    readonly property color sidebar: dark ? Qt.rgba(1, 1, 1, 0.025) : Qt.rgba(0, 0, 0, 0.03)
    readonly property color surface2: dark ? Qt.rgba(1, 1, 1, 0.055) : Qt.rgba(0, 0, 0, 0.045)
    readonly property color surface3: dark ? Qt.rgba(1, 1, 1, 0.09) : Qt.rgba(0, 0, 0, 0.08)
    readonly property color border: dark ? Qt.rgba(1, 1, 1, 0.075) : Qt.rgba(0, 0, 0, 0.09)
    readonly property color text: dark ? "#eceae4" : "#1c1b22"
    readonly property color text2: dark ? "#a7a4ae" : "#55525c"
    readonly property color text3: dark ? "#6f6c78" : "#8a8792"
    readonly property color danger: "#e5484d"
    readonly property string font: s.font ?? "Inter"
    readonly property string mono: s.monoFont ?? "JetBrains Mono"
}
