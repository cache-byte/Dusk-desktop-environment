import QtQuick
import Nova.Settings
import QtQuick.Controls.Basic

ComboBox {
    id: c
    implicitHeight: 40
    font.family: Theme.font
    font.pixelSize: 14
    background: Rectangle { radius: 11; color: Theme.surface3; border.color: c.activeFocus ? Theme.accentLine : Theme.border }
    contentItem: Text { leftPadding: 14; text: c.displayText; color: Theme.text; font: c.font; verticalAlignment: Text.AlignVCenter; elide: Text.ElideRight }
    indicator: Icon { name: "chevd"; size: 15; color: Theme.text3; x: c.width - width - 12; y: (c.height - height) / 2 }
    delegate: ItemDelegate {
        required property int index
        required property var modelData
        width: c.width
        highlighted: c.highlightedIndex === index
        contentItem: Text { text: c.textRole ? modelData[c.textRole] : modelData; color: highlighted ? Theme.accentBright : Theme.text; font: c.font; elide: Text.ElideRight }
        background: Rectangle { radius: 8; color: highlighted ? Theme.accentSoft : "transparent" }
    }
    popup: Popup {
        y: c.height + 4; width: c.width; padding: 6
        implicitHeight: Math.min(contentItem.implicitHeight + 12, 320)
        contentItem: ListView { clip: true; implicitHeight: contentHeight; model: c.popup.visible ? c.delegateModel : null; currentIndex: c.highlightedIndex }
        background: Rectangle { radius: 12; color: Theme.dark ? "#201e2a" : "#ffffff"; border.color: Theme.border }
    }
}
