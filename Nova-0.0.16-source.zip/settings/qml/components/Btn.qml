import QtQuick
import Nova.Settings
import QtQuick.Layouts

Rectangle {
    id: root
    property string text
    property string icon
    property bool accent: false
    signal clicked()
    implicitHeight: 36; implicitWidth: row.implicitWidth + 30
    radius: 11
    color: accent ? (ma.containsMouse ? Theme.accentBright : Theme.accent) : (ma.containsMouse ? Qt.lighter(Theme.surface3, 1.4) : Theme.surface3)
    RowLayout { id: row; anchors.centerIn: parent; spacing: 8
        Icon { visible: root.icon !== ""; name: root.icon; size: 15; color: root.accent ? Theme.onAccent : Theme.text }
        Text { text: root.text; color: root.accent ? Theme.onAccent : Theme.text; font.pixelSize: 13; font.weight: Font.DemiBold } }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.clicked() }
}
