import QtQuick
import Nova.Settings
import QtQuick.Effects

Item {
    id: root
    property string name
    property color color: Theme.text
    property int size: 20
    implicitWidth: size; implicitHeight: size
    Image { id: img; anchors.fill: parent; source: "qrc:/qt/qml/Nova/Settings/icons/" + root.name + ".svg"; sourceSize: Qt.size(root.size * 2, root.size * 2); visible: false }
    MultiEffect { anchors.fill: parent; source: img; colorization: 1; brightness: 1; colorizationColor: root.color }
}
