// Small ↺ button. Takes its space even when inactive so rows stay aligned.
import QtQuick
import Nova.Settings

Rectangle {
    id: root
    property bool active: true
    property string tip: "Reset to default"
    property string iconName: "restart"
    signal clicked()
    implicitWidth: 28; implicitHeight: 28; radius: 9
    color: ma.containsMouse && active ? Theme.surface3 : "transparent"
    opacity: active ? 1 : 0
    Icon { anchors.centerIn: parent; name: root.iconName; size: 15; color: ma.containsMouse ? Theme.accentBright : Theme.text3 }
    MouseArea { id: ma; anchors.fill: parent; enabled: root.active; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.clicked() }
    ToolTipText { visible: ma.containsMouse && root.active; text: root.tip }
}
