import QtQuick
import Nova.Settings
import QtQuick.Layouts

RowLayout {
    id: root
    property real value: 0.5
    property real from: 0
    property real to: 1
    property string suffix: "%"
    property var format: v => Math.round((v - from) / (to - from) * 100) + suffix
    signal moved(real value)
    spacing: 12
    Item {
        id: track
        Layout.fillWidth: true; implicitHeight: 24
        readonly property real frac: (root.value - root.from) / (root.to - root.from)
        Rectangle { anchors.fill: parent; radius: 12; color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.07); border.color: Qt.rgba(1, 1, 1, 0.05) }
        Rectangle {
            height: parent.height; radius: 12
            width: Math.max(height, track.frac * track.width)
            gradient: Gradient { orientation: Gradient.Horizontal
                GradientStop { position: 0; color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.45) }
                GradientStop { position: 1; color: Theme.accent } }
            Rectangle { width: 16; height: 16; radius: 8; anchors.right: parent.right; anchors.rightMargin: 4; anchors.verticalCenter: parent.verticalCenter
                color: Qt.rgba(1, 1, 1, 0.93); border.width: 3; border.color: Qt.rgba(1, 1, 1, 0.22) }
        }
        MouseArea {
            anchors.fill: parent; cursorShape: Qt.PointingHandCursor
            function upd(x) { root.value = root.from + Math.max(0, Math.min(1, x / width)) * (root.to - root.from); root.moved(root.value) }
            onPressed: m => upd(m.x)
            onPositionChanged: m => { if (pressed) upd(m.x) }
        }
    }
    Text { text: root.format(root.value); color: Theme.text2; font.pixelSize: 13; Layout.preferredWidth: 42; horizontalAlignment: Text.AlignRight }
}
