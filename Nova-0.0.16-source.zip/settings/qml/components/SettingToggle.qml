// Toggle bound to a settings.json key
import QtQuick
import Nova.Settings
Toggle {
    property string key
    checked: Backend.settings[key] ?? Backend.defaultValue(key) ?? false
    onToggled: v => Backend.set(key, v)
}
