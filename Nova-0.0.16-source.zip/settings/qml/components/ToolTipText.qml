import QtQuick
import Nova.Settings

Rectangle {
    property alias text: t.text
    anchors.bottom: parent.top; anchors.bottomMargin: 6; anchors.horizontalCenter: parent.horizontalCenter
    implicitWidth: t.implicitWidth + 16; implicitHeight: 26; radius: 8
    color: Theme.surface3; border.color: Theme.border; z: 100
    Text { id: t; anchors.centerIn: parent; color: Theme.text; font.pixelSize: 12 }
}
