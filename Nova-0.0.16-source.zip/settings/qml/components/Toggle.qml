import QtQuick
import Nova.Settings

Item {
    id: root
    property bool checked
    signal toggled(bool checked)
    implicitWidth: 46; implicitHeight: 26
    Rectangle {
        anchors.fill: parent; radius: 13
        color: root.checked ? Theme.accent : "transparent"
        border.width: root.checked ? 0 : 2
        border.color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.3)
        Behavior on color { ColorAnimation { duration: 160 } }
    }
    Rectangle {
        width: root.checked ? 18 : 14; height: width; radius: width / 2
        y: (root.height - height) / 2
        x: root.checked ? root.width - width - 4 : 6
        color: root.checked ? "white" : Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.5)
        Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
    }
    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: { root.checked = !root.checked; root.toggled(root.checked) } }
}
