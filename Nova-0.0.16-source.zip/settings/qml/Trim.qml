// Trim a recording: drag the two handles, preview, then save a copy or replace the file.
import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import QtQuick.Window
import QtMultimedia
import Nova.Settings

ApplicationWindow {
    id: win
    width: 980; height: 700
    minimumWidth: 720; minimumHeight: 520
    visible: true
    title: "Trim recording"
    color: Theme.window
    font.family: Theme.font

    property real dur: player.duration / 1000
    property real a: 0
    property real b: dur
    onDurChanged: if (b <= 0 || b > dur) b = dur
    property string status: ""
    function fmt(t) { const m = Math.floor(t / 60), s = (t % 60).toFixed(1); return m + ":" + (s < 10 ? "0" : "") + s }

    MediaPlayer {
        id: player
        source: TrimFile ? "file://" + TrimFile : ""
        videoOutput: video
        audioOutput: AudioOutput {}
        onPositionChanged: if (playbackState === MediaPlayer.PlayingState && position / 1000 >= win.b) pause()
    }

    ColumnLayout {
        anchors.fill: parent; anchors.margins: 22; spacing: 16
        RowLayout {
            Text { text: "Trim recording"; color: Theme.accentBright; font.pixelSize: 22; font.weight: Font.DemiBold }
            Item { Layout.fillWidth: true }
            Text { text: TrimFile.split("/").pop(); color: Theme.text3; font.pixelSize: 13; elide: Text.ElideMiddle; Layout.maximumWidth: 420 }
        }
        Rectangle {
            Layout.fillWidth: true; Layout.fillHeight: true; radius: 16; color: "black"; clip: true
            VideoOutput { id: video; anchors.fill: parent }
            MouseArea { anchors.fill: parent; onClicked: player.playbackState === MediaPlayer.PlayingState ? player.pause() : play() }
        }
        // range bar: two handles + playhead
        Item {
            id: bar
            Layout.fillWidth: true; implicitHeight: 54
            readonly property real k: width / Math.max(0.01, win.dur)
            Rectangle { anchors.fill: parent; radius: 12; color: Theme.surface2; border.color: Theme.border }
            Rectangle { x: win.a * bar.k; width: (win.b - win.a) * bar.k; height: parent.height; radius: 12; color: Theme.accentSoft; border.color: Theme.accent; border.width: 2 }
            Rectangle { x: player.position / 1000 * bar.k - 1; width: 2; height: parent.height; color: Theme.text }
            Repeater {
                model: ["a", "b"]
                Rectangle {
                    required property string modelData
                    width: 14; height: bar.height + 8; y: -4; radius: 7; color: Theme.accent
                    x: win[modelData] * bar.k - width / 2
                    MouseArea {
                        anchors.fill: parent; anchors.margins: -8; cursorShape: Qt.SizeHorCursor
                        onPositionChanged: m => {
                            if (!pressed) return;
                            const t = Math.max(0, Math.min(win.dur, (parent.x + m.x + parent.width / 2) / bar.k));
                            if (parent.modelData === "a") win.a = Math.min(t, win.b - 0.5); else win.b = Math.max(t, win.a + 0.5);
                            player.position = (parent.modelData === "a" ? win.a : win.b) * 1000;
                        }
                    }
                }
            }
        }
        RowLayout {
            spacing: 10
            Btn { icon: player.playbackState === MediaPlayer.PlayingState ? "pause" : "play"; text: "Preview"
                  onClicked: player.playbackState === MediaPlayer.PlayingState ? player.pause() : play() }
            Text { text: fmt(win.a) + " → " + fmt(win.b) + "   ·   " + fmt(win.b - win.a); color: Theme.text2; font.pixelSize: 14 }
            Item { Layout.fillWidth: true }
            Text { text: win.status; color: Theme.text3; font.pixelSize: 13 }
            Btn { text: "Save as copy"; onClicked: save(false) }
            Btn { accent: true; text: "Replace"; onClicked: save(true) }
        }
    }
    function play() { if (player.position / 1000 < a || player.position / 1000 >= b) player.position = a * 1000; player.play() }
    function save(replace) {
        player.stop();
        status = "Saving…";
        const out = Backend.trimVideo(TrimFile, a, b, replace);
        status = out ? "Saved " + out.split("/").pop() : "Couldn't trim (is ffmpeg installed?)";
        if (out && replace) Qt.callLater(Qt.quit);
    }
}
