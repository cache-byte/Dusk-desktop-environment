// Where each popup appears and which way it runs. Click a square to move it,
// or drag the indicator on the preview to nudge it away from its anchor.
import QtQuick
import QtQuick.Layouts
import Nova.Settings

RowLayout {
    id: page
    spacing: 18
    readonly property var defaults: ({
        slider: { pos: 5, dir: "up", dx: 0, dy: 0 }, lock: { pos: 7, dir: "across", dx: 0, dy: 0 },
        power: { pos: 7, dir: "across", dx: 0, dy: 0 }, notifications: { pos: 8, dir: "up", dx: 0, dy: 0 },
        message: { pos: 1, dir: "across", dx: 0, dy: 0 }, nowplaying: { pos: 8, dir: "clock", dx: 0, dy: 0 },
        lyrics: { pos: 7, dir: "centre", dx: 0, dy: 40 }, visualizer: { pos: 7, dir: "across", dx: 0, dy: 0 }
    })
    readonly property var osd: Backend.settings.osd ?? ({})
    function cfg(k) { return Object.assign({}, defaults[k], osd[k] ?? {}) }
    function put(k, patch) { const o = Object.assign({}, osd); o[k] = Object.assign(cfg(k), patch); Backend.set("osd", o) }
    property string selected: "slider"

    readonly property var rows: [
        ["slider", "Volume, brightness & mic", "Also keyboard backlight", ["across", "Across", "up", "Up"]],
        ["lock", "Caps / Num Lock", "Shows when you press them", ["across", "Across", "up", "Up"]],
        ["power", "Power mode & charging", "", ["across", "Across", "up", "Up"]],
        ["notifications", "Notification pop-ups", "Newest nearest the edge", ["up", "Stack up", "down", "Stack down"]],
        ["message", "Small messages", "“Copied”, “Screenshot saved”", ["across", "Across", "up", "Up"]],
        ["nowplaying", "Now playing", "Opens when you hover the clock", ["clock", "Above clock", "free", "Free"]],
        ["lyrics", "Desktop lyrics", (Backend.settings.lyricsDesktop ?? false) ? "On" : "Off · turn on in Music & lyrics", ["centre", "Centred", "left", "Left"]],
        ["visualizer", "Desktop visualizer", "Used when its position is Custom", ["across", "Across", "up", "Up"]]
    ]

    // ---- list ----
    Rectangle {
        Layout.fillWidth: true; Layout.alignment: Qt.AlignTop
        implicitHeight: list.implicitHeight + 8
        radius: 18; color: Theme.surface2; border.color: Theme.border
        ColumnLayout {
            id: list
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 4; leftMargin: 20; rightMargin: 20 }
            spacing: 0
            Repeater {
                model: page.rows
                ColumnLayout {
                    required property var modelData
                    required property int index
                    readonly property var c: page.cfg(modelData[0])
                    Layout.fillWidth: true; spacing: 0
                    Rectangle { visible: index > 0; Layout.fillWidth: true; implicitHeight: 1; color: Theme.border }
                    RowLayout {
                        Layout.fillWidth: true; Layout.topMargin: 9; Layout.bottomMargin: 9; spacing: 14
                        ColumnLayout { Layout.fillWidth: true; spacing: 2
                            Text { text: modelData[1]; color: Theme.text; font.pixelSize: 14; font.weight: Font.Medium; elide: Text.ElideRight; Layout.fillWidth: true }
                            Text { visible: text !== ""; text: modelData[2]; color: Theme.text3; font.pixelSize: 12; elide: Text.ElideRight; Layout.fillWidth: true } }
                        // 3x3 anchor picker
                        Rectangle {
                            implicitWidth: 98; implicitHeight: 58; radius: 11
                            color: Qt.rgba(0, 0, 0, 0.25); border.color: Theme.border
                            opacity: parent.parent.modelData[0] === "nowplaying" && parent.parent.c.dir === "clock" ? 0.35 : 1
                            Grid {
                                anchors.centerIn: parent; columns: 3; spacing: 4
                                Repeater {
                                    model: 9
                                    Rectangle {
                                        required property int index
                                        readonly property var row: parent.parent.parent.parent
                                        width: 26; height: 13; radius: 4
                                        color: row.c.pos === index ? Theme.accent : cellMa.containsMouse ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(1, 1, 1, 0.07)
                                        MouseArea {
                                            id: cellMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                            onClicked: {
                                                const k = parent.row.modelData[0];
                                                const patch = { pos: index, dx: 0, dy: 0 };
                                                if (k === "nowplaying") patch.dir = "free";
                                                page.put(k, patch); page.selected = k;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // direction
                        Rectangle {
                            implicitWidth: 180; implicitHeight: 34; radius: 11; color: Theme.surface2
                            RowLayout {
                                anchors.fill: parent; anchors.margins: 3; spacing: 2
                                Repeater {
                                    model: [0, 2]
                                    Rectangle {
                                        required property int modelData
                                        readonly property var row: parent.parent.parent.parent
                                        readonly property bool on: row.c.dir === row.modelData[3][modelData]
                                        Layout.fillWidth: true; Layout.fillHeight: true; radius: 8
                                        color: on ? Theme.surface3 : "transparent"
                                        Text { anchors.centerIn: parent; text: parent.row.modelData[3][parent.modelData + 1]; font.pixelSize: 13
                                               color: parent.on ? Theme.text : Theme.text2; font.weight: parent.on ? Font.DemiBold : Font.Normal }
                                        MouseArea { anchors.fill: parent; onClicked: { page.put(parent.row.modelData[0], { dir: parent.row.modelData[3][parent.modelData] }); page.selected = parent.row.modelData[0] } }
                                    }
                                }
                            }
                        }
                        ResetButton {
                            readonly property string k: parent.parent.modelData[0]
                            active: !!page.osd[k]
                            onClicked: { const o = Object.assign({}, page.osd); delete o[k]; Backend.set("osd", o) }
                        }
                    }
                }
            }
        }
    }

    // ---- preview + behaviour ----
    ColumnLayout {
        Layout.preferredWidth: 330; Layout.alignment: Qt.AlignTop
        spacing: 12
        Label2 { text: "Preview" }
        Rectangle {
            id: pv
            Layout.fillWidth: true; implicitHeight: 190; radius: 14; clip: true; color: "black"
            border.color: Theme.border
            Image { anchors.fill: parent; fillMode: Image.PreserveAspectCrop; opacity: 0.7
                    source: Backend.settings.wallpaper && !/\.(mp4|webm|mkv|mov)$/i.test(Backend.settings.wallpaper) ? "file://" + Backend.settings.wallpaper : "file:///usr/share/nova/shell/assets/wallpapers/nova-" + (Theme.dark ? "dark" : "light") + ".jpg" }
            Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 14; color: Qt.rgba(0.06, 0.06, 0.09, 0.9) }
            readonly property real k: width / 1920        // preview scale vs a 1920 px screen
            Repeater {
                model: ["slider", "lock", "notifications", "message"]
                Rectangle {
                    id: chip
                    required property string modelData
                    readonly property var c: page.cfg(modelData)
                    readonly property bool vert: modelData === "slider" ? c.dir === "up" : modelData === "notifications" ? false : c.dir === "up"
                    readonly property int r: Math.floor(c.pos / 3)
                    readonly property int col: c.pos % 3
                    width: modelData === "notifications" ? 76 : vert ? 14 : 64
                    height: modelData === "notifications" ? 26 : vert ? 60 : 13
                    radius: Math.min(width, height) / 2
                    readonly property real edge: 8
                    x: col === 0 ? edge + c.dx * pv.k : col === 2 ? pv.width - width - edge + c.dx * pv.k : (pv.width - width) / 2
                    y: r === 0 ? edge + c.dy * pv.k : r === 2 ? pv.height - 14 - height - edge + c.dy * pv.k : (pv.height - 14 - height) / 2
                    color: page.selected === modelData ? Theme.accent : Qt.rgba(0.08, 0.075, 0.11, 0.9)
                    border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.22)
                    MouseArea {
                        anchors.fill: parent
                        drag.target: chip
                        onPressed: page.selected = chip.modelData
                        onReleased: {
                            // convert the drop position into an offset from the anchor (±200 px)
                            const ax = chip.col === 0 ? chip.edge : chip.col === 2 ? pv.width - chip.width - chip.edge : chip.x;
                            const ay = chip.r === 0 ? chip.edge : chip.r === 2 ? pv.height - 14 - chip.height - chip.edge : chip.y;
                            const clamp = v => Math.max(-200, Math.min(200, Math.round(v)));
                            page.put(chip.modelData, { dx: chip.col === 1 ? 0 : clamp((chip.x - ax) / pv.k), dy: chip.r === 1 ? 0 : clamp((chip.y - ay) / pv.k) });
                        }
                    }
                }
            }
        }
        Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.text3; font.pixelSize: 12
               text: "Drag an indicator to nudge it off its anchor. Centred positions stay centred." }

        Label2 { text: "Behaviour"; Layout.topMargin: 6 }
        Rectangle {
            Layout.fillWidth: true; implicitHeight: beh.implicitHeight + 12; radius: 18; color: Theme.surface2; border.color: Theme.border
            ColumnLayout {
                id: beh
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6; leftMargin: 16; rightMargin: 16 }
                spacing: 0
                Seg { label: "Hide after"; key: "osdTimeout"; values: [1000, 2000, 4000]; labels: ["1 s", "2 s", "4 s"]; fallback: 2000 }
                Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.border }
                Seg { label: "Size"; key: "osdSize"; values: ["S", "M", "L"]; labels: ["S", "M", "L"]; fallback: "M" }
                Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.border }
                Seg { label: "Show on"; key: "osdScreen"; values: ["active", "all"]; labels: ["Active screen", "All"]; fallback: "active" }
            }
        }
        Label2 { text: "Lock keys"; Layout.topMargin: 6 }
        Card {
            Row2 { confKey: ["input", "remember_locks"]; label: "Remember after restart"; hint: "Caps / Num Lock come back as you left them"
                Toggle { checked: Backend.conf("input", "remember_locks", "true") === "true"; onToggled: v => Backend.setConf("input", "remember_locks", v) } }
            Row2 { key: "lockInPanel"; label: "Show in panel when on"
                Toggle { checked: Backend.settings.lockInPanel ?? true; onToggled: v => Backend.set("lockInPanel", v) } }
        }
    }

    component Seg: RowLayout {
        property string label
        property string key
        property var values
        property var labels
        property var fallback
        readonly property var cur: Backend.settings[key] ?? fallback
        Layout.fillWidth: true; implicitHeight: 50
        Text { Layout.fillWidth: true; text: parent.label; color: Theme.text; font.pixelSize: 14 }
        Rectangle {
            implicitHeight: 34; implicitWidth: segRow.implicitWidth + 6; radius: 11; color: Theme.surface2
            Row {
                id: segRow; anchors.centerIn: parent; spacing: 2
                Repeater {
                    model: parent.parent.parent.values.length
                    Rectangle {
                        required property int index
                        readonly property var seg: parent.parent.parent
                        readonly property bool on: seg.cur === seg.values[index]
                        height: 28; width: t.implicitWidth + 24; radius: 8
                        color: on ? Theme.surface3 : "transparent"
                        Text { id: t; anchors.centerIn: parent; text: parent.seg.labels[parent.index]; font.pixelSize: 13
                               color: parent.on ? Theme.text : Theme.text2; font.weight: parent.on ? Font.DemiBold : Font.Normal }
                        MouseArea { anchors.fill: parent; onClicked: Backend.set(parent.seg.key, parent.seg.values[parent.index]) }
                    }
                }
            }
        }
    }
}
