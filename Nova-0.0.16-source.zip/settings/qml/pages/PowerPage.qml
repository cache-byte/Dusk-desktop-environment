import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    property string profile: Backend.run(["powerprofilesctl", "get"]).trim()
    readonly property string bat: Backend.run(["sh", "-c", "upower -i $(upower -e | grep -m1 BAT) 2>/dev/null"])
    function field(n) { const m = bat.match(new RegExp(n + ":\\s+(.+)")); return m ? m[1].trim() : "" }

    Card {
        title: "Power mode"; icon: "gauge"
        RowLayout {
            Layout.fillWidth: true; spacing: 4
            Repeater {
                model: [["power-saver", "leaf", "Saver"], ["balanced", "gauge", "Balanced"], ["performance", "bolt", "Performance"]]
                Rectangle {
                    required property var modelData
                    readonly property bool on: page.profile === modelData[0]
                    Layout.fillWidth: true; implicitHeight: 52; radius: 14; color: on ? Theme.accent : Theme.surface2
                    RowLayout { anchors.centerIn: parent; spacing: 8
                        Icon { name: parent.parent.modelData[1]; size: 17; color: parent.parent.on ? Theme.onAccent : Theme.text2 }
                        Text { text: parent.parent.modelData[2]; font.pixelSize: 14; font.weight: parent.parent.on ? Font.DemiBold : Font.Normal; color: parent.parent.on ? Theme.onAccent : Theme.text2 } }
                    MouseArea { anchors.fill: parent; onClicked: { Backend.run(["powerprofilesctl", "set", parent.modelData[0]]); page.profile = parent.modelData[0] } }
                }
            }
        }
    }
    Card {
        visible: page.bat !== ""
        title: "Battery"; icon: "battery"
        subtitle: page.field("percentage") + " · " + page.field("state")
        GridLayout { columns: 2; columnSpacing: 30; rowSpacing: 8
            Repeater { model: [["Time remaining", page.field("time to empty") || page.field("time to full") || "—"], ["Health", page.field("capacity") || "—"], ["Charge cycles", page.field("charge-cycles") || "—"], ["Model", page.field("model") || "—"]]
                RowLayout { required property var modelData; Layout.columnSpan: 2
                    Text { Layout.preferredWidth: 160; text: modelData[0]; color: Theme.text3; font.pixelSize: 13 }
                    Text { text: modelData[1]; color: Theme.text; font.pixelSize: 13 } } } }
    }
    Card {
        title: "When idle"; icon: "moon"
        subtitle: "Nothing dims, locks or sleeps while a game, video or anything fullscreen is running"
        ColumnLayout {
            Layout.fillWidth: true; spacing: 6
            RowLayout { Layout.fillWidth: true; spacing: 18
                Item { Layout.fillWidth: true }
                Label2 { text: "On battery"; Layout.preferredWidth: 150; horizontalAlignment: Text.AlignHCenter }
                Label2 { text: "Plugged in"; Layout.preferredWidth: 150; horizontalAlignment: Text.AlignHCenter }
                Item { implicitWidth: 28 } }
            Repeater {
                model: [["Dim the screen", "idleDimBattery", "idleDimAc"], ["Lock", "idleLockBattery", "idleLockAc"], ["Sleep", "idleSleepBattery", "idleSleepAc"]]
                delegate: Item {
                    required property var modelData
                    Layout.fillWidth: true; implicitHeight: 40
                    RowLayout { anchors.fill: parent; spacing: 18
                        Text { Layout.fillWidth: true; text: parent.parent.modelData[0]; color: Theme.text; font.pixelSize: 14 }
                        Minutes { key: parent.parent.modelData[1] }
                        Minutes { key: parent.parent.modelData[2] }
                        ResetButton {
                            readonly property var m: parent.parent.modelData
                            active: { Backend.settings; return !Backend.isDefault(m[1]) || !Backend.isDefault(m[2]) }
                            onClicked: { Backend.reset(m[1]); Backend.reset(m[2]) }
                        }
                    }
                }
            }
        }
    }
    Card {
        title: "Graphics"; icon: "monitor"
        subtitle: Backend.gpuInfo().split("\n").filter(l => l).map(l => l.split(" ")[1] + " (" + l.split(" ")[2] + ")").join(" · ") || "One GPU"
        Row2 { key: "gpuPrimary"; label: "Run the desktop on"; hint: "Integrated saves battery. Takes effect at next login."
            Segmented { key: "gpuPrimary"; values: ["auto", "integrated", "dedicated"]; labels: ["Automatic", "Integrated", "Dedicated"] } }
        Row2 { key: "gamesOnDedicatedGpu"; label: "Start games on the dedicated GPU"; hint: "Steam, Heroic, Lutris and anything in the Games category"
            SettingToggle { key: "gamesOnDedicatedGpu" } }
    }
}
