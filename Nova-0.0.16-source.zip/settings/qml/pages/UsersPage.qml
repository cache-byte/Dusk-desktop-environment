import QtQuick
import QtQuick.Dialogs
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    readonly property string home: Backend.run(["sh", "-c", "printf %s \"$HOME\""])
    readonly property string user: Backend.run(["sh", "-c", "printf %s \"$USER\""])
    readonly property string fullName: Backend.run(["sh", "-c", "getent passwd \"$USER\" | cut -d: -f5 | cut -d, -f1"]).trim()
    property int bump: 0
    FileDialog { id: pick; nameFilters: ["Images (*.png *.jpg *.jpeg *.webp)"]
        onAccepted: { Backend.run(["cp", selectedFile.toString().replace("file://", ""), page.home + "/.face"]); page.bump++ } }
    Card {
        RowLayout { spacing: 20
            Rectangle { implicitWidth: 96; implicitHeight: 96; radius: 48; clip: true
                gradient: Gradient { GradientStop { position: 0; color: "#d9925a" } GradientStop { position: 1; color: "#7d3f6b" } }
                Text { anchors.centerIn: parent; text: page.user.charAt(0).toUpperCase(); color: "white"; font.pixelSize: 40; font.weight: Font.DemiBold }
                Image { anchors.fill: parent; cache: false; source: "file://" + page.home + "/.face?" + page.bump; fillMode: Image.PreserveAspectCrop } }
            ColumnLayout { spacing: 4
                Text { text: page.fullName || page.user; color: Theme.text; font.pixelSize: 22; font.weight: Font.DemiBold }
                Text { text: page.user + " · Administrator"; color: Theme.text3; font.pixelSize: 13 }
                RowLayout { spacing: 8; Layout.topMargin: 8
                    Btn { icon: "image"; text: "Change picture"; onClicked: pick.open() }
                    Btn { icon: "lock"; text: "Change password"; onClicked: Backend.runDetached(["sh", "-c", "${TERMINAL:-ptyxis} -- passwd || foot passwd"]) } } } }
    }
}
