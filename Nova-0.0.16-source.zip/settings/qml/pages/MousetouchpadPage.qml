import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    spacing: 18
    Card {
        title: "Pointer"; icon: "mouse"
        Row2 { confKey: ["input", "accel"]; label: "Speed"
            PillSlider { implicitWidth: 300; from: -1; to: 1; value: parseFloat(Backend.conf("input", "accel", "0")); format: v => v.toFixed(2)
                onMoved: v => Backend.setConf("input", "accel", v.toFixed(2)) } }
        Row2 { confKey: ["general", "focus_follows_mouse"]; label: "Focus follows mouse"; hint: "Windows get keyboard focus when the pointer enters them"
            Toggle { checked: Backend.conf("general", "focus_follows_mouse", "false") === "true"; onToggled: v => Backend.setConf("general", "focus_follows_mouse", v) } }
    }
    Card {
        title: "Touchpad"
        Row2 { confKey: ["input", "tap_to_click"]; label: "Tap to click"; Toggle { checked: Backend.conf("input", "tap_to_click", "true") === "true"; onToggled: v => Backend.setConf("input", "tap_to_click", v) } }
        Row2 { confKey: ["input", "natural_scroll"]; label: "Natural scrolling"; hint: "Content follows your fingers"
            Toggle { checked: Backend.conf("input", "natural_scroll", "true") === "true"; onToggled: v => Backend.setConf("input", "natural_scroll", v) } }
    }
}
