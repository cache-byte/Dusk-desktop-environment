import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    readonly property var pinned: Backend.settings.pinned ?? []
    Card {
        title: "Panel"; icon: "grid"
        Row2 { key: "clock24"; label: "24-hour clock"; Toggle { checked: Backend.settings.clock24 ?? true; onToggled: v => Backend.set("clock24", v) } }
        Row2 { key: "showDesktopIcons"; label: "Desktop icons"; hint: "Show the contents of ~/Desktop on the wallpaper"
            Toggle { checked: Backend.settings.showDesktopIcons ?? true; onToggled: v => Backend.set("showDesktopIcons", v) } }
    }
    Card {
        title: "Launcher"
        Row2 { key: "launcherView"; label: "Default view"
            Dropdown { implicitWidth: 160; model: ["list", "grid"]; currentIndex: model.indexOf(Backend.settings.launcherView ?? "list"); onActivated: i => Backend.set("launcherView", model[i]) } }
    }
    Card {
        title: "Pinned apps"; subtitle: "Desktop file ids, in panel order"
        Repeater {
            model: page.pinned
            RowLayout { required property string modelData; required property int index; Layout.fillWidth: true
                Text { Layout.fillWidth: true; text: modelData; color: Theme.text; font.pixelSize: 14 }
                Btn { text: "↑"; visible: index > 0; onClicked: { const p = page.pinned.slice(); [p[index - 1], p[index]] = [p[index], p[index - 1]]; Backend.set("pinned", p) } }
                Btn { text: "Remove"; onClicked: Backend.set("pinned", page.pinned.filter((_, i) => i !== index)) } }
        }
        RowLayout { Layout.fillWidth: true
            Rectangle { Layout.fillWidth: true; implicitHeight: 38; radius: 11; color: Theme.surface3
                TextInput { id: add; anchors.fill: parent; anchors.leftMargin: 12; verticalAlignment: Text.AlignVCenter; color: Theme.text; font.pixelSize: 13
                    Text { visible: !add.text; text: "e.g. org.gnome.Calculator"; color: Theme.text3; font: add.font } } }
            Btn { icon: "plus"; text: "Pin"; onClicked: if (add.text) { Backend.set("pinned", page.pinned.concat([add.text])); add.text = "" } } }
    }
}
