import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    spacing: 18
    Card {
        title: "Windows"; icon: "square"
        Row2 { confKey: ["general", "gaps"]; label: "Gap between snapped windows"
            Stepper { value: parseInt(Backend.conf("general", "gaps", "8")); min: 0; max: 40; step: 2; onChanged: v => Backend.setConf("general", "gaps", v) } }
        Row2 { confKey: ["general", "focus_follows_mouse"]; label: "Focus follows mouse"; hint: "Off: click a window to focus it"
            Toggle { checked: Backend.conf("general", "focus_follows_mouse", "false") === "true"; onToggled: v => Backend.setConf("general", "focus_follows_mouse", v) } }
        Row2 { label: "Snapping"; hint: "Drag a window to the left or right edge to fill half the screen, the top edge to maximise. Super+arrows do the same."; Item {} }
    }
    Card {
        title: "Workspaces"; icon: "grid"
        subtitle: "Each monitor has its own workspaces. New ones appear when you need them; empty ones go away."
        Row2 { label: "Switch"; hint: "Super+1…9 on the monitor under the mouse · 3-finger swipe left/right"; Item {} }
        Row2 { label: "Overview"; hint: "Super+Tab · 3-finger swipe up"; Item {} }
        Row2 { confKey: ["input", "gesture_workspaces"]; label: "3-finger swipe switches workspace"
            Toggle { checked: Backend.conf("input", "gesture_workspaces", "true") === "true"; onToggled: v => Backend.setConf("input", "gesture_workspaces", v) } }
        Row2 { confKey: ["input", "gesture_overview"]; label: "3-finger swipe up opens the overview"
            Toggle { checked: Backend.conf("input", "gesture_overview", "true") === "true"; onToggled: v => Backend.setConf("input", "gesture_overview", v) } }
    }
}
