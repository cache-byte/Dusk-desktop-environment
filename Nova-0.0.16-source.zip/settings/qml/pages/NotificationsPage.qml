import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    spacing: 18
    Card {
        title: "Notifications"; icon: "bell"
        Row2 { key: "dnd"; label: "Do not disturb"; hint: "Only critical notifications pop up. Everything still lands in the list."
            Toggle { checked: Backend.settings.dnd ?? false; onToggled: v => Backend.set("dnd", v) } }
        Row2 { key: "notificationTimeout"; label: "Show for"; hint: "How long pop-ups stay on screen"
            PillSlider { implicitWidth: 260; from: 2000; to: 15000; value: Backend.settings.notificationTimeout ?? 6000
                format: v => Math.round(v / 1000) + " s"; onMoved: v => Backend.set("notificationTimeout", Math.round(v / 1000) * 1000) } }
    }
    Card {
        title: "Grouping & fullscreen"; icon: "bell"
        Row2 { key: "groupNotifications"; label: "Group by app"; hint: "Several notifications from one app fold into one stack"
            SettingToggle { key: "groupNotifications" } }
        Row2 { key: "autoDnd"; label: "Quiet while fullscreen"; hint: "Games and videos aren't interrupted; you get a count of what you missed afterwards"
            SettingToggle { key: "autoDnd" } }
    }
    Card {
        title: "Clipboard history"; icon: "clip"
        subtitle: "Super+V. Passwords copied from password managers are never kept."
        Row2 { key: "clipboardKeep"; label: "Keep history after restarting"; SettingToggle { key: "clipboardKeep" } }
        Row2 { label: "Clear history now"; Btn { text: "Clear"; onClicked: Backend.run(["cliphist", "wipe"]) } }
    }
}
