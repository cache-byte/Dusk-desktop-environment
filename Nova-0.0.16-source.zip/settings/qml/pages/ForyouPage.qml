import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    property string doctor: "Checking…"
    Component.onCompleted: Backend.runAsync(["nova-doctor"], "doctor")
    Connections { target: Backend; function onAsyncDone(tag, out) { if (tag === "doctor") page.doctor = out } }
    readonly property int problems: (doctor.match(/✗/g) || []).length
    readonly property int hour: new Date().getHours()
    Card {
        RowLayout { Layout.fillWidth: true; spacing: 18
            Rectangle { implicitWidth: 64; implicitHeight: 64; radius: 18; color: Theme.accent
                Icon { anchors.centerIn: parent; name: "nova"; size: 34; color: Theme.onAccent } }
            ColumnLayout { Layout.fillWidth: true; spacing: 4
                Text { text: (page.hour < 12 ? "Good morning" : page.hour < 18 ? "Good afternoon" : "Good evening"); color: Theme.text; font.pixelSize: 22; font.weight: Font.DemiBold }
                Text { text: page.problems === 0 ? "Everything is healthy" : page.problems + (page.problems === 1 ? " thing needs" : " things need") + " attention below"
                       color: Theme.text2; font.pixelSize: 14 } } }
    }
    Card {
        title: "Shortcuts worth knowing"; icon: "keyboard"
        GridLayout { Layout.fillWidth: true; columns: 2; columnSpacing: 30; rowSpacing: 10
            Repeater {
                model: [["Super", "Find any app or file"], ["Super + Tab", "See all windows"], ["Super + ←/→", "Snap to half"], ["Super + G", "Game overlay"], ["Super + V", "Clipboard history"], ["Super + L", "Lock"], ["Print", "Screenshot"], ["Super + Alt + R", "Save instant replay"]]
                RowLayout { required property var modelData; Layout.fillWidth: true; spacing: 12
                    Rectangle { implicitWidth: kt.implicitWidth + 18; implicitHeight: 28; radius: 8; color: Theme.surface3; border.color: Theme.border
                        Text { id: kt; anchors.centerIn: parent; text: modelData[0]; color: Theme.text; font.pixelSize: 12; font.weight: Font.DemiBold } }
                    Text { Layout.fillWidth: true; text: modelData[1]; color: Theme.text2; font.pixelSize: 13; elide: Text.ElideRight } } }
        }
    }
    Card {
        title: "Health check"; icon: "shield"
        subtitle: page.problems === 0 ? "All checks passed" : "Run nova-doctor in a terminal for details"
        Text { Layout.fillWidth: true; text: page.doctor.replace(/\x1b\[[0-9;]*m/g, ""); color: Theme.text2; font.family: Theme.mono; font.pixelSize: 12; wrapMode: Text.Wrap }
    }
}
