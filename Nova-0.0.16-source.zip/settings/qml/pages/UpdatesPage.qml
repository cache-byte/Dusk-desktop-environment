import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    property var info: ({ installed: Backend.installedVersion() })
    property bool checking: false

    // ---- in-app update state (fed by nova-update --gui) ----
    property string ustate: "idle"       // idle | running | done | failed
    property int phase: 0                // 1 = download (updater), 2 = install (installer)
    property int step: 0
    property int total: 1
    property string stepTitle: ""
    property string task: ""
    property var steps: []               // [{title, state}] for the installer
    property var log: []
    property var notes: []               // what's new: [{version, items}] newer than what's installed
    property bool showLog: false
    readonly property real progress: phase <= 1 ? 0.1 * step / Math.max(1, total)
                                               : 0.1 + 0.9 * Math.max(0, step - 1 + (ustate === "done" ? 1 : 0.5)) / Math.max(1, total)

    function check() { checking = true; Backend.runAsync(["nova-update", "--check"], "updates") }
    function start(force) {
        ustate = "running"; phase = 0; step = 0; total = 1; steps = []; log = []; task = "Starting…";
        if (!Backend.startUpdate(force)) ustate = "idle";
    }
    function handle(line) {
        const l = log.slice(); l.push(line); if (l.length > 400) l.shift(); log = l;
        const m = line.match(/^::(\w+)\s?(.*)$/);
        if (!m) return;
        const kind = m[1], rest = m[2];
        if (kind === "start") { phase++; step = 0 }
        else if (kind === "step") {
            const p = rest.match(/^(\d+) (\d+) (.*)$/); if (!p) return;
            step = +p[1]; total = +p[2]; stepTitle = p[3];
            if (phase >= 2) {
                const s = steps.map(x => Object.assign({}, x, { state: x.state === "now" ? "ok" : x.state }));
                s.push({ title: p[3], state: "now" }); steps = s;
            }
        }
        else if (kind === "task") task = rest;
        else if (kind === "notes") { try { notes = JSON.parse(rest) } catch (e) {} }
        else if (kind === "fail") task = "Failed: " + rest;
        else if (kind === "done") { stepTitle = rest; task = "" }
    }
    Component.onCompleted: check()
    Connections {
        target: Backend
        function onAsyncDone(tag, out) {
            if (tag !== "updates") return;
            try { page.info = JSON.parse(out) } catch (e) { page.info = { ok: false, installed: Backend.installedVersion() } }
            if (page.ustate === "idle") page.notes = page.info.notes ?? [];
            page.checking = false;
        }
        function onUpdateLine(line) { page.handle(line) }
        function onUpdateFinished(code) {
            page.ustate = code === 0 ? "done" : "failed";
            page.steps = page.steps.map(x => Object.assign({}, x, { state: x.state === "now" ? (code === 0 ? "ok" : "fail") : x.state }));
            if (code !== 0 && page.task === "") page.task = code === 126 ? "Permission wasn't given" : "Something went wrong — see the details";
            page.check();
        }
    }

    // ---- status ----
    Card {
        visible: page.ustate === "idle"
        RowLayout { Layout.fillWidth: true; spacing: 18
            Rectangle { implicitWidth: 64; implicitHeight: 64; radius: 18; color: Theme.accentSoft
                Icon { anchors.centerIn: parent; name: page.info.update ? "restart" : "check"; size: 30; color: Theme.accent } }
            ColumnLayout { Layout.fillWidth: true; spacing: 4
                Text { color: Theme.text; font.pixelSize: 19; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true
                       text: page.checking ? "Checking GitHub…" : page.info.update ? "Nova " + page.info.latest + " is available"
                             : page.info.ok === false ? "Couldn't reach GitHub" : "Nova is up to date" }
                Text { color: Theme.text2; font.pixelSize: 13
                       text: "Installed: " + (page.info.installed ?? "?") + (page.info.latest ? "   ·   On GitHub: " + page.info.latest : "") } }
            Btn { text: "Check again"; onClicked: page.check() }
            Btn { visible: !!page.info.update; accent: true; icon: "restart"; text: "Update now"; onClicked: page.start(false) }
        }
        Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.text3; font.pixelSize: 13
               text: "Nova downloads the newest version from GitHub, builds it and installs it. You'll be asked for your password once. Fedora packages and Flatpaks are updated by GNOME Software as usual." }
    }

    // ---- updating / finished ----
    Card {
        visible: page.ustate !== "idle"
        RowLayout { Layout.fillWidth: true; spacing: 18
            Rectangle {
                implicitWidth: 64; implicitHeight: 64; radius: 18
                color: page.ustate === "failed" ? Qt.rgba(0.9, 0.28, 0.3, 0.15) : Theme.accentSoft
                Icon { visible: page.ustate !== "running"; anchors.centerIn: parent; size: 30
                       color: page.ustate === "failed" ? Theme.danger : Theme.accent
                       name: page.ustate === "done" ? "check" : "x" }
                Icon { visible: page.ustate === "running"; anchors.centerIn: parent; size: 30; color: Theme.accent; name: "restart"
                       RotationAnimator on rotation { running: page.ustate === "running"; from: 0; to: 360; duration: 1400; loops: Animation.Infinite } } }
            ColumnLayout { Layout.fillWidth: true; spacing: 4
                Text { color: Theme.text; font.pixelSize: 19; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true
                       text: page.ustate === "done" ? "Nova " + (page.info.installed ?? "") + " is installed"
                             : page.ustate === "failed" ? "The update didn't finish"
                             : page.phase <= 1 ? "Getting Nova " + (page.info.latest ?? "") : "Installing Nova " + (page.info.latest ?? "") }
                Text { color: Theme.text2; font.pixelSize: 13; elide: Text.ElideRight; Layout.fillWidth: true
                       text: page.ustate === "done" ? "Log out and back in to start using it." : page.task || page.stepTitle } }
            Text { visible: page.ustate === "running"; text: Math.round(page.progress * 100) + "%"; color: Theme.accentBright; font.pixelSize: 15; font.weight: Font.DemiBold }
        }
        // progress bar
        Rectangle {
            Layout.fillWidth: true; implicitHeight: 8; radius: 4; color: Theme.surface3
            Rectangle {
                height: parent.height; radius: 4
                width: parent.width * (page.ustate === "done" ? 1 : page.progress)
                color: page.ustate === "failed" ? Theme.danger : Theme.accent
                Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
            }
        }
        // installer steps
        GridLayout {
            visible: page.steps.length > 0
            Layout.fillWidth: true; columns: 2; columnSpacing: 24; rowSpacing: 8; Layout.topMargin: 4
            Repeater {
                model: page.steps
                RowLayout {
                    required property var modelData
                    Layout.fillWidth: true; spacing: 10
                    Rectangle {
                        implicitWidth: 22; implicitHeight: 22; radius: 11
                        color: modelData.state === "ok" ? Theme.accent : modelData.state === "fail" ? Theme.danger : "transparent"
                        border.width: modelData.state === "now" ? 2 : 0; border.color: Theme.accent
                        Icon { visible: parent.parent.modelData.state !== "now"; anchors.centerIn: parent; size: 13
                               name: parent.parent.modelData.state === "fail" ? "x" : "check"; color: Theme.onAccent }
                        Rectangle { visible: parent.parent.modelData.state === "now"; anchors.centerIn: parent; width: 8; height: 8; radius: 4; color: Theme.accent
                            SequentialAnimation on opacity { running: page.ustate === "running"; loops: Animation.Infinite
                                NumberAnimation { to: 0.3; duration: 500 } NumberAnimation { to: 1; duration: 500 } } }
                    }
                    Text { Layout.fillWidth: true; text: modelData.title; elide: Text.ElideRight; font.pixelSize: 14
                           color: modelData.state === "now" ? Theme.text : Theme.text2; font.weight: modelData.state === "now" ? Font.DemiBold : Font.Normal }
                }
            }
        }
        RowLayout {
            Layout.fillWidth: true; spacing: 10
            Btn { text: page.showLog ? "Hide details" : "Show details"; icon: "terminal"; onClicked: page.showLog = !page.showLog }
            Item { Layout.fillWidth: true }
            Btn { visible: page.ustate === "running"; text: "Cancel"; onClicked: Backend.cancelUpdate() }
            Btn { visible: page.ustate === "failed"; text: "Try again"; onClicked: page.start(false) }
            Btn { visible: page.ustate === "failed"; text: "Open in terminal"; onClicked: Backend.runUpdate(false) }
            Btn { visible: page.ustate === "done"; accent: true; text: "Log out now"; onClicked: Backend.runDetached(["novactl", "dispatch", "exit"]) }
            Btn { visible: page.ustate === "done" || page.ustate === "failed"; text: "Close"; onClicked: page.ustate = "idle" }
        }
        Rectangle {
            visible: page.showLog
            Layout.fillWidth: true; implicitHeight: 220; radius: 12; color: Qt.rgba(0, 0, 0, 0.35); border.color: Theme.border; clip: true
            ListView {
                id: logView
                anchors.fill: parent; anchors.margins: 12
                model: page.log
                onCountChanged: positionViewAtEnd()
                delegate: Text {
                    required property string modelData
                    width: logView.width; wrapMode: Text.WrapAnywhere
                    text: modelData.replace(/^::(\w+) /, (m, k) => ({ step: "▸ ", task: "  … ", ok: "  ✓ ", fail: "  ✗ ", warn: "  ! ", info: "  · ", log: "    │ ", done: "★ ", start: "◆ " })[k] ?? "")
                    color: modelData.startsWith("::fail") ? Theme.danger : modelData.startsWith("::ok") ? Theme.text : Theme.text2
                    font.family: Theme.mono; font.pixelSize: 12
                }
            }
        }
    }

    // ---- what's new ----
    Card {
        id: wn
        readonly property bool upcoming: page.notes.length > 0
        readonly property var current: page.info.current ?? []
        visible: !page.checking && (upcoming || (page.ustate === "idle" && current.length > 0))
        title: upcoming ? (page.ustate === "done" ? "What's new in this update" : "What's new") : "In Nova " + (page.info.installed ?? "")
        icon: "nova"
        Repeater {
            model: wn.upcoming ? page.notes : [{ version: "", items: wn.current }]
            ColumnLayout {
                required property var modelData
                Layout.fillWidth: true; spacing: 6
                Text { visible: modelData.version !== ""; text: "Nova " + modelData.version; color: Theme.accentBright; font.pixelSize: 13; font.weight: Font.DemiBold }
                Repeater {
                    model: modelData.items
                    RowLayout {
                        required property string modelData
                        Layout.fillWidth: true; spacing: 10
                        Rectangle { Layout.alignment: Qt.AlignTop; Layout.topMargin: 7; implicitWidth: 6; implicitHeight: 6; radius: 3; color: Theme.accent }
                        Text { Layout.fillWidth: true; text: modelData; wrapMode: Text.Wrap; color: Theme.text; font.pixelSize: 14; lineHeight: 1.2 }
                    }
                }
            }
        }
    }
    Card {
        title: "Update settings"; icon: "settings"
        Row2 { key: "updateChannel"; label: "Channel"; hint: "Release: the highest version number.  Latest: the newest upload, even a test build."
            Segmented { key: "updateChannel"; values: ["release", "latest"]; labels: ["Release", "Latest"] } }
        Row2 { label: "Reinstall this version"; hint: "Rebuilds and reinstalls Nova if something seems broken"
            Btn { text: "Reinstall"; enabled: page.ustate !== "running"; onClicked: page.start(true) } }
        Row2 { label: "Use the terminal instead"; hint: "nova-update · shows the same steps in a terminal window"
            Btn { text: "Open terminal"; icon: "terminal"; onClicked: Backend.runUpdate(false) } }
    }
    Card {
        id: rm
        title: "Remove Nova"; icon: "trash"
        subtitle: "Puts your previous login screen and system files back. Your apps and files are not touched."
        property bool deps: false
        property bool purge: false
        Row2 { label: "Also remove packages Nova installed"; hint: "Only ones nothing else needs"
            Toggle { checked: rm.deps; onToggled: v => rm.deps = v } }
        Row2 { label: "Also delete my Nova settings"; hint: "~/.config/nova — otherwise kept in case you come back"
            Toggle { checked: rm.purge; onToggled: v => rm.purge = v } }
        RowLayout { Layout.fillWidth: true
            Item { Layout.fillWidth: true }
            Btn { text: "Uninstall Nova…"; icon: "trash"; onClicked: confirm.visible = true } }
        Rectangle {
            id: confirm
            visible: false
            Layout.fillWidth: true; implicitHeight: cr.implicitHeight + 28; radius: 14
            color: Qt.rgba(0.9, 0.28, 0.3, 0.12); border.color: Qt.rgba(0.9, 0.28, 0.3, 0.4)
            RowLayout { id: cr; anchors.fill: parent; anchors.margins: 14; spacing: 12
                Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.text; font.pixelSize: 13
                       text: "A terminal opens and asks for your password. Reboot afterwards to get your old login screen." }
                Btn { text: "Cancel"; onClicked: confirm.visible = false }
                Btn { accent: true; text: "Uninstall"; onClicked: { confirm.visible = false; Backend.uninstall(rm.deps, rm.purge) } } }
        }
    }
}
