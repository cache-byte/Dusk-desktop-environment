import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    readonly property var lyricStyles: ["Fade stack", "Karaoke sweep", "Terminal", "Word bloom", "Accent rail", "Outline"]
    readonly property var vizStyles: ["Bars", "Wave line", "Filled wave", "LED matrix", "Peak caps", "Mountains", "Pills"]
    readonly property var places: Backend.settings.vizPlaces ?? Backend.defaultValue("vizPlaces")

    component StyleTile: Rectangle {
        property string name
        property int number
        property bool on
        signal pick()
        Layout.fillWidth: true; Layout.minimumWidth: 0; implicitHeight: 64; radius: 12
        color: on ? Theme.accentSoft : Theme.surface2; border.width: on ? 2 : 1; border.color: on ? Theme.accent : Theme.border
        ColumnLayout { anchors.centerIn: parent; spacing: 2; width: parent.width - 12
            Text { Layout.alignment: Qt.AlignHCenter; text: String(parent.parent.number).padStart(2, "0"); color: parent.parent.on ? Theme.accent : Theme.text3; font.pixelSize: 11; font.weight: Font.DemiBold }
            Text { Layout.alignment: Qt.AlignHCenter; Layout.maximumWidth: parent.width; text: parent.parent.name; elide: Text.ElideRight
                   color: parent.parent.on ? Theme.text : Theme.text2; font.pixelSize: 13; font.weight: parent.parent.on ? Font.DemiBold : Font.Normal } }
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: parent.pick() }
    }

    Card {
        title: "Synced lyrics"; icon: "music"
        subtitle: "Found by title and artist. If that fails, SongRec identifies the song and Nova searches again."
        Row2 { key: "lyricsNowPlaying"; label: "In Now Playing"; hint: "A Lyrics tab when you hover the clock"; SettingToggle { key: "lyricsNowPlaying" } }
        Row2 { key: "lyricsDesktop"; label: "On the desktop"; hint: "Position it on the Popups & indicators page"; SettingToggle { key: "lyricsDesktop" } }
        Label2 { text: "Style"; Layout.topMargin: 4 }
        GridLayout { Layout.fillWidth: true; columns: 3; columnSpacing: 10; rowSpacing: 10
            Repeater { model: page.lyricStyles
                StyleTile { required property string modelData; required property int index
                    name: modelData; number: index + 1; on: (Backend.settings.lyricsStyle ?? 1) === index + 1
                    onPick: Backend.set("lyricsStyle", index + 1) } } }
        Row2 { key: "lyricsSize"; label: "Text size"; Segmented { key: "lyricsSize"; values: ["S", "M", "L", "XL"] } }
        Row2 { key: "lyricsOffset"; label: "Timing"; hint: "Move lyrics earlier or later if they don't line up"
            PillSlider { implicitWidth: 260; from: -2; to: 2; value: Backend.settings.lyricsOffset ?? 0.2
                format: v => (v >= 0 ? "+" : "") + v.toFixed(1) + " s"; onMoved: v => Backend.set("lyricsOffset", Math.round(v * 10) / 10) } }
        Row2 { key: "lyricsHideFullscreen"; label: "Hide when a window is fullscreen"; SettingToggle { key: "lyricsHideFullscreen" } }
        Row2 { key: "lyricsSongRec"; label: "Identify songs with SongRec"; hint: "Only when search finds nothing. Sends a short audio fingerprint to Shazam."
            SettingToggle { key: "lyricsSongRec" } }
        Row2 { label: "Saved lyrics"; hint: "Kept for offline use in ~/.cache/nova/lyrics"
            Btn { text: "Clear"; onClicked: Backend.run(["sh", "-c", "rm -rf \"${XDG_CACHE_HOME:-$HOME/.cache}/nova/lyrics\""]) } }
    }
    Card {
        title: "Beat visualizer"; icon: "music"
        subtitle: "Uses cava. Only runs while music is playing; slower on battery."
        Row2 { key: "vizPlaces"; label: "Show in"
            Repeater {
                model: [["nowplaying", "Now Playing"], ["lock", "Lock screen"], ["clock", "Clock pill"], ["desktop", "Desktop"]]
                Rectangle {
                    required property var modelData
                    readonly property bool on: page.places.includes(modelData[0])
                    implicitHeight: 32; implicitWidth: ct.implicitWidth + 26; radius: 16
                    color: on ? Theme.accent : Theme.surface2
                    Text { id: ct; anchors.centerIn: parent; text: (parent.on ? "✓ " : "") + parent.modelData[1]; font.pixelSize: 13
                           color: parent.on ? Theme.onAccent : Theme.text2; font.weight: parent.on ? Font.DemiBold : Font.Normal }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                        onClicked: Backend.set("vizPlaces", parent.on ? page.places.filter(p => p !== parent.modelData[0]) : page.places.concat([parent.modelData[0]])) }
                }
            }
        }
        Label2 { text: "Style"; Layout.topMargin: 4 }
        GridLayout { Layout.fillWidth: true; columns: 4; columnSpacing: 10; rowSpacing: 10
            Repeater { model: page.vizStyles
                StyleTile { required property string modelData; required property int index
                    name: modelData; number: index + 1; on: (Backend.settings.vizStyle ?? 1) === index + 1
                    onPick: Backend.set("vizStyle", index + 1) } } }
        Row2 { key: "vizColour"; label: "Colour"; Segmented { key: "vizColour"; values: ["accent", "art", "rainbow"]; labels: ["Accent", "Album art", "Rainbow"] } }
        Row2 { key: "vizBars"; label: "Bars"; Segmented { key: "vizBars"; values: [16, 32, 64] ; labels: ["16", "32", "64"] } }
        Row2 { key: "vizSensitivity"; label: "Sensitivity"
            PillSlider { implicitWidth: 260; value: Backend.settings.vizSensitivity ?? 0.55; onMoved: v => Backend.set("vizSensitivity", Math.round(v * 100) / 100) } }
        Label2 { text: "On the desktop"; Layout.topMargin: 4 }
        Row2 { key: "vizDesktopPos"; label: "Position"
            Segmented { key: "vizDesktopPos"; values: ["bottom", "centre", "top", "custom"]; labels: ["Bottom edge", "Centre", "Top edge", "Custom"] } }
        Row2 { key: "vizDesktopTitle"; label: "Show song title"; SettingToggle { key: "vizDesktopTitle" } }
        Row2 { key: "vizDesktopOpacity"; label: "Opacity"
            PillSlider { implicitWidth: 260; from: 0.2; to: 1; value: Backend.settings.vizDesktopOpacity ?? 0.85; onMoved: v => Backend.set("vizDesktopOpacity", Math.round(v * 100) / 100) } }
    }
}
