// Arrange monitors by dragging (edges snap), then pick resolution, refresh,
// scale and rotation for the selected one. Applied with wlr-randr.
import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    property var outs: Backend.displays()
    property int sel: Math.max(0, outs.findIndex(o => o.builtin))
    readonly property var cur: outs[sel] ?? null
    property string error: ""

    function update(i, patch) { const o = outs.slice(); o[i] = Object.assign({}, o[i], patch); outs = o }
    function logical(o) {   // size in layout pixels
        const m = o.mode ?? { width: 1920, height: 1080 };
        const rot = /90|270/.test(o.transform);
        return { w: (rot ? m.height : m.width) / o.scale, h: (rot ? m.width : m.height) / o.scale };
    }

    // ---- arrangement ----
    Card {
        Rectangle {
            id: canvas
            Layout.fillWidth: true; implicitHeight: 300; radius: 12; clip: true
            color: Qt.rgba(1, 1, 1, 0.02)
            // dotted grid
            Repeater { model: Math.ceil(canvas.width / 24)
                Rectangle { required property int index; x: index * 24; width: 1; height: canvas.height; color: Qt.rgba(1, 1, 1, 0.035) } }
            Repeater { model: Math.ceil(canvas.height / 24)
                Rectangle { required property int index; y: index * 24; height: 1; width: canvas.width; color: Qt.rgba(1, 1, 1, 0.035) } }

            readonly property var bounds: {
                let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
                for (const o of page.outs) { if (!o.enabled) continue; const s = page.logical(o);
                    x0 = Math.min(x0, o.x); y0 = Math.min(y0, o.y); x1 = Math.max(x1, o.x + s.w); y1 = Math.max(y1, o.y + s.h) }
                return x0 > x1 ? { x: 0, y: 0, w: 1920, h: 1080 } : { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
            }
            readonly property real k: Math.min((width - 160) / bounds.w, (height - 90) / bounds.h)
            readonly property real ox: (width - bounds.w * k) / 2 - bounds.x * k
            readonly property real oy: (height - bounds.h * k) / 2 - bounds.y * k - 10

            Repeater {
                model: page.outs
                Rectangle {
                    id: mon
                    required property var modelData
                    required property int index
                    readonly property var sz: page.logical(modelData)
                    visible: modelData.enabled
                    x: canvas.ox + modelData.x * canvas.k; y: canvas.oy + modelData.y * canvas.k
                    width: sz.w * canvas.k; height: sz.h * canvas.k
                    radius: 12
                    color: index === page.sel ? Theme.accentSoft : Qt.rgba(1, 1, 1, 0.06)
                    border.width: index === page.sel ? 2 : 1.5
                    border.color: index === page.sel ? Theme.accent : Qt.rgba(1, 1, 1, 0.22)
                    ColumnLayout { anchors.fill: parent; anchors.margins: 12
                        RowLayout { Layout.fillWidth: true
                            Text { Layout.fillWidth: true; elide: Text.ElideRight; text: mon.modelData.builtin ? "Built-in display" : (mon.modelData.model || mon.modelData.name); color: Theme.text; font.pixelSize: 14; font.weight: Font.DemiBold }
                            Rectangle { width: 24; height: 24; radius: 12; color: mon.index === page.sel ? Theme.accent : Theme.surface3
                                Text { anchors.centerIn: parent; text: mon.index + 1; font.pixelSize: 13; font.weight: Font.Bold; color: mon.index === page.sel ? Theme.onAccent : Theme.text } } }
                        Item { Layout.fillHeight: true }
                        Text { text: mon.modelData.mode ? mon.modelData.mode.width + " × " + mon.modelData.mode.height + " · " + Math.round(mon.modelData.mode.refresh) + " Hz" : ""; color: Theme.text2; font.pixelSize: 12 } }
                    MouseArea {
                        anchors.fill: parent
                        drag.target: page.outs.length > 1 ? mon : null
                        onPressed: page.sel = mon.index
                        onReleased: {
                            // back to layout coords, then snap to the nearest edge of another output
                            let nx = (mon.x - canvas.ox) / canvas.k, ny = (mon.y - canvas.oy) / canvas.k;
                            const me = mon.sz;
                            let best = null;
                            page.outs.forEach((o, i) => {
                                if (i === mon.index || !o.enabled) return;
                                const s = page.logical(o);
                                const cands = [{ x: o.x + s.w, y: ny }, { x: o.x - me.w, y: ny }, { x: nx, y: o.y + s.h }, { x: nx, y: o.y - me.h }];
                                for (const c of cands) {
                                    // keep the edges overlapping
                                    if (c.x === o.x + s.w || c.x === o.x - me.w) c.y = Math.max(o.y - me.h + 40, Math.min(o.y + s.h - 40, c.y));
                                    else c.x = Math.max(o.x - me.w + 40, Math.min(o.x + s.w - 40, c.x));
                                    const d = Math.hypot(c.x - nx, c.y - ny);
                                    if (!best || d < best.d) best = { x: Math.round(c.x), y: Math.round(c.y), d };
                                }
                            });
                            if (best) page.update(mon.index, { x: best.x, y: best.y });
                            else page.outs = page.outs.slice();   // re-bind position
                        }
                    }
                }
            }
            Text { anchors.left: parent.left; anchors.bottom: parent.bottom; anchors.margins: 14; text: "Drag screens to arrange them · edges snap together"; color: Theme.text3; font.pixelSize: 12 }
            Row { anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 12; spacing: 8
                Btn { text: "Identify"; onClicked: page.outs.forEach((o, i) => Backend.runDetached(["notify-send", "-a", "Display", "Display " + (i + 1), o.name + " — " + (o.description || "")])) }
                Btn { text: "Apply"; accent: true
                    onClicked: { page.error = ""; for (const o of page.outs) { const e = Backend.applyDisplay(o); if (e) page.error = e } page.outs = Backend.displays() } } }
        }
        Text { visible: page.error !== ""; text: page.error; color: "#ff8a7a"; font.pixelSize: 12 }
    }

    // ---- selected display ----
    Card {
        visible: page.cur !== null
        title: page.cur ? (page.cur.builtin ? "Built-in display" : (page.cur.make + " " + page.cur.model).trim() || page.cur.name) : ""
        subtitle: page.cur ? [page.cur.inches ? page.cur.inches + "″" : "", page.cur.name, page.sel === 0 ? "primary" : ""].filter(x => x).join(" · ") : ""
        icon: "monitor"
        headerExtra: [ Text { text: "Enabled"; color: Theme.text; font.pixelSize: 13 },
                       Toggle { checked: page.cur?.enabled ?? false; onToggled: v => page.update(page.sel, { enabled: v }) } ]

        GridLayout {
            Layout.fillWidth: true; columns: 2; columnSpacing: 26; rowSpacing: 18
            readonly property var resList: page.cur ? [...new Set(page.cur.modes.map(m => m.width + " × " + m.height))] : []
            readonly property string curRes: page.cur?.mode ? page.cur.mode.width + " × " + page.cur.mode.height : ""
            readonly property var rates: page.cur ? page.cur.modes.filter(m => m.width + " × " + m.height === curRes).sort((a, b) => b.refresh - a.refresh) : []

            ColumnLayout { Label2 { text: "Resolution" }
                Dropdown { Layout.fillWidth: true
                    model: parent.parent.resList.map(r => page.cur.modes.some(m => m.preferred && m.width + " × " + m.height === r) ? r + " (recommended)" : r)
                    currentIndex: parent.parent.resList.indexOf(parent.parent.curRes)
                    onActivated: i => {
                        const r = parent.parent.resList[i];
                        const m = page.cur.modes.filter(m => m.width + " × " + m.height === r).sort((a, b) => b.refresh - a.refresh)[0];
                        page.update(page.sel, { mode: m });
                    } } }
            ColumnLayout { Label2 { text: "Refresh rate" }
                Dropdown { Layout.fillWidth: true
                    model: parent.parent.rates.map(m => m.refresh.toFixed(m.refresh % 1 > 0.05 ? 2 : 0) + " Hz")
                    currentIndex: parent.parent.rates.findIndex(m => page.cur.mode && Math.abs(m.refresh - page.cur.mode.refresh) < 0.01)
                    onActivated: i => page.update(page.sel, { mode: parent.parent.rates[i] }) } }
            ColumnLayout { Label2 { text: "Scale" }
                RowLayout { spacing: 6
                    Repeater { model: [1, 1.25, 1.5, 1.75, 2]
                        Rectangle { required property real modelData
                            readonly property bool on: Math.abs((page.cur?.scale ?? 1) - modelData) < 0.01
                            implicitWidth: 58; implicitHeight: 32; radius: 16; color: on ? Theme.accent : Theme.surface2
                            Text { anchors.centerIn: parent; text: Math.round(parent.modelData * 100) + "%"; font.pixelSize: 13; color: parent.on ? Theme.onAccent : Theme.text2; font.weight: parent.on ? Font.DemiBold : Font.Normal }
                            MouseArea { anchors.fill: parent; onClicked: page.update(page.sel, { scale: parent.modelData }) } } }
                    Stepper { value: Math.round((page.cur?.scale ?? 1) * 100); step: 5; min: 100; max: 200; suffix: " %"; onChanged: v => page.update(page.sel, { scale: v / 100 }) } } }
            ColumnLayout { Label2 { text: "Rotation" }
                Dropdown { Layout.fillWidth: true
                    readonly property var vals: ["normal", "90", "180", "270", "flipped", "flipped-90", "flipped-180", "flipped-270"]
                    model: ["Normal", "90° counter-clockwise", "Upside down", "90° clockwise", "Flipped", "Flipped 90°", "Flipped 180°", "Flipped 270°"]
                    currentIndex: Math.max(0, vals.indexOf(page.cur?.transform ?? "normal"))
                    onActivated: i => page.update(page.sel, { transform: vals[i] }) } }
            Row2 { label: "Variable refresh rate"; hint: "Smoother games and video on supported screens"
                Toggle { checked: page.cur?.adaptiveSync ?? false; onToggled: v => page.update(page.sel, { adaptiveSync: v }) } }
            Row2 { visible: page.outs.length > 1; label: "Mirror to display " + (page.sel === 0 ? 2 : 1)
                Toggle { onToggled: v => { const o = page.outs[page.sel === 0 ? 1 : 0]; page.update(page.sel === 0 ? 1 : 0, { x: v ? page.cur.x : o.x + 1, y: v ? page.cur.y : o.y }) } } }
        }
    }
    Item { implicitHeight: 24 }
}
