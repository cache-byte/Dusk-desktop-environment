import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    function vol(dev) { const m = Backend.run(["wpctl", "get-volume", dev]).match(/Volume: ([\d.]+)( \[MUTED\])?/); return m ? { v: parseFloat(m[1]), muted: !!m[2] } : { v: 0, muted: false } }
    property var out: vol("@DEFAULT_AUDIO_SINK@")
    property var mic: vol("@DEFAULT_AUDIO_SOURCE@")
    readonly property var sinks: Backend.run(["sh", "-c", "wpctl status | sed -n '/Sinks:/,/Sources:/p' | grep -E '^ │ +\\*? *[0-9]+\\.' | sed -E 's/ \\[vol.*//'"]).split("\n").filter(l => l.trim())

    Card {
        title: "Output"; icon: "volume"
        headerExtra: [ Text { text: "Mute"; color: Theme.text; font.pixelSize: 13 },
                       Toggle { checked: page.out.muted; onToggled: v => { Backend.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", v ? "1" : "0"]); page.out = page.vol("@DEFAULT_AUDIO_SINK@") } } ]
        PillSlider { Layout.fillWidth: true; to: 1.5; value: page.out.v; onMoved: v => Backend.runDetached(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", v.toFixed(2)]) }
        Label2 { text: "Device" }
        Repeater {
            model: page.sinks
            Rectangle {
                required property string modelData
                readonly property bool on: modelData.includes("*")
                readonly property string id: (modelData.match(/(\d+)\./) ?? ["", ""])[1]
                Layout.fillWidth: true; implicitHeight: 46; radius: 12; color: on ? Theme.accentSoft : "transparent"
                RowLayout { anchors.fill: parent; anchors.leftMargin: 12; spacing: 12
                    Icon { name: "headphones"; color: parent.parent.on ? Theme.accentBright : Theme.text }
                    Text { Layout.fillWidth: true; elide: Text.ElideRight; text: parent.parent.modelData.replace(/^[^0-9]*\d+\.\s*/, ""); color: Theme.text; font.pixelSize: 14 } }
                MouseArea { anchors.fill: parent; onClicked: Backend.run(["wpctl", "set-default", parent.id]) }
            }
        }
    }
    Card {
        title: "Input"; icon: "mic"
        headerExtra: [ Text { text: "Mute"; color: Theme.text; font.pixelSize: 13 },
                       Toggle { checked: page.mic.muted; onToggled: v => Backend.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", v ? "1" : "0"]) } ]
        PillSlider { Layout.fillWidth: true; value: page.mic.v; onMoved: v => Backend.runDetached(["wpctl", "set-volume", "@DEFAULT_AUDIO_SOURCE@", v.toFixed(2)]) }
    }
    Card {
        title: "Volume"; icon: "volume"
        Row2 { key: "allowOverAmplify"; label: "Allow volume above 100 %"; hint: "Up to 150 % for quiet videos. May distort on small speakers."
            SettingToggle { key: "allowOverAmplify" } }
    }
    Btn { text: "Advanced mixer…"; onClicked: Backend.runDetached(["pavucontrol"]) }
}
