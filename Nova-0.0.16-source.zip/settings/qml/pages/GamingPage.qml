import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    spacing: 18
    readonly property bool hasGsr: Backend.run(["sh", "-c", "command -v gpu-screen-recorder"]).trim() !== ""
    Card {
        title: "Game mode"; icon: "game"
        subtitle: "Turns on when a game goes fullscreen: Feral GameMode, performance power profile, no pop-ups, nothing dims or sleeps"
        Row2 { key: "gameModeAuto"; label: "Automatic game mode"; SettingToggle { key: "gameModeAuto" } }
        Row2 { key: "gamesOnDedicatedGpu"; label: "Start games on the dedicated GPU"; hint: "For laptops with two GPUs"; SettingToggle { key: "gamesOnDedicatedGpu" } }
        Row2 { key: "mangohud"; label: "FPS & stats overlay (MangoHud)"; hint: "Shows FPS, frame time, CPU and GPU load inside games. Shift+F12 hides it in game."
            SettingToggle { key: "mangohud" } }
        Row2 { confKey: ["general", "tearing"]; label: "Allow tearing in fullscreen games"; hint: "Lowest input latency. Variable refresh rate is used when the screen supports it."
            Toggle { checked: Backend.conf("general", "tearing", "auto") !== "never"; onToggled: v => Backend.setConf("general", "tearing", v ? "auto" : "never") } }
        Row2 { confKey: ["general", "vrr"]; label: "Variable refresh rate in fullscreen"
            Toggle { checked: Backend.conf("general", "vrr", "true") === "true"; onToggled: v => Backend.setConf("general", "vrr", v) } }
    }
    Card {
        title: "Instant replay"; icon: "record"
        subtitle: hasGsr ? "Keeps the last moments of gameplay in memory. Super+Alt+R saves them." : "Needs gpu-screen-recorder (reinstall Nova to add it)"
        Row2 { key: "replayEnabled"; label: "Instant replay"; SettingToggle { key: "replayEnabled"; enabled: hasGsr } }
        Row2 { key: "replaySeconds"; label: "Keep the last"; Segmented { key: "replaySeconds"; values: [15, 30, 60, 120]; labels: ["15 s", "30 s", "1 min", "2 min"] } }
    }
    Card {
        title: "Recording"; icon: "video"
        Row2 { key: "recordFormat"; label: "Format"; hint: "MP4 plays everywhere; MKV survives crashes"
            Segmented { key: "recordFormat"; values: ["mp4", "mkv"]; labels: ["MP4 (H.264)", "MKV"] } }
        Row2 { key: "recordSystemAudio"; label: "Record system sound"; SettingToggle { key: "recordSystemAudio" } }
        Row2 { key: "recordMic"; label: "Record microphone"; SettingToggle { key: "recordMic" } }
        Row2 { label: "Saved to"; hint: "~/Videos/Recordings  ·  screenshots go to ~/Pictures/Screenshots and the clipboard"; Item {} }
    }
}
