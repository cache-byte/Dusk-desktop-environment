// Nova shell — runs on Quickshell (https://quickshell.org).
//   qs -p /usr/share/nova/shell
//@ pragma UseQApplication
import QtQuick
import Quickshell
import qs.services
import qs.modules

ShellRoot {
    // One set of surfaces per monitor.
    Variants {
        model: Quickshell.screens
        Scope {
            id: perScreen
            required property var modelData
            Wallpaper { screen: perScreen.modelData }
            Panel { screen: perScreen.modelData }
            Popouts { screen: perScreen.modelData }
            NowPlaying { screen: perScreen.modelData }
            Notifications { screen: perScreen.modelData }
            Osd { screen: perScreen.modelData }
            Overview { screen: perScreen.modelData }
            DesktopLyrics { screen: perScreen.modelData }
            DesktopVisualizer { screen: perScreen.modelData }
        }
    }
    Lock {}
    // background services that must start with the shell
    Component.onCompleted: { Idle.caffeine; Gaming.active; Replay.enabled; Lyrics.wanted }
}
