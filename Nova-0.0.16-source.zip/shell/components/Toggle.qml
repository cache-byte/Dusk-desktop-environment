// On: filled accent with white knob. Off: outlined pill, small grey knob.
import QtQuick
import qs.services

Item {
    id: root
    property bool checked: false
    signal toggled(bool checked)
    implicitWidth: 46
    implicitHeight: 26

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: root.checked ? Theme.accent : "transparent"
        border.width: root.checked ? 0 : 2
        border.color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.3)
        Behavior on color { ColorAnimation { duration: Theme.ms(160) } }
    }
    Rectangle {
        width: root.checked ? 18 : 14
        height: width
        radius: width / 2
        y: (root.height - height) / 2
        x: root.checked ? root.width - width - 4 : 6
        color: root.checked ? "white" : Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.5)
        Behavior on x { NumberAnimation { duration: Theme.ms(180); easing.type: Easing.OutCubic } }
        Behavior on width { NumberAnimation { duration: Theme.ms(180) } }
    }
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: { root.checked = !root.checked; root.toggled(root.checked) }
    }
}
