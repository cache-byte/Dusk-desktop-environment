// A layer-shell window placed at one of nine anchor points (Config.osd(kind)).
//   pos 0 1 2 / 3 4 5 / 6 7 8  — row 0 = top edge, row 2 = bottom edge (above the panel)
// dx / dy nudge the window away from its anchor (only on anchored edges).
import QtQuick
import Quickshell
import Quickshell.Wayland
import qs.services

PanelWindow {
    id: w
    property string kind: "slider"
    readonly property var cfg: Config.osd(kind)
    readonly property int row: Math.floor(cfg.pos / 3)
    readonly property int col: cfg.pos % 3
    readonly property int edge: 20
    // "Show on": the screen under the pointer, or every screen
    readonly property bool onThisScreen: Config.s.osdScreen === "all"
        || (Nova.activeOutput ? screen?.name === Nova.activeOutput : screen === Quickshell.screens[0])

    property var layerKind: WlrLayer.Overlay   // desktop lyrics sit under windows (Bottom)
    WlrLayershell.layer: layerKind
    WlrLayershell.namespace: "nova-" + kind
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    anchors {
        top: row === 0
        bottom: row === 2
        left: col === 0
        right: col === 2
    }
    margins {
        top: edge + Math.max(0, cfg.dy ?? 0)
        bottom: edge + Theme.panelHeight + Math.max(0, -(cfg.dy ?? 0))
        left: edge + Math.max(0, cfg.dx ?? 0)
        right: edge + Math.max(0, -(cfg.dx ?? 0))
    }
}
