// Monochrome line icon from shell/icons, tinted to any colour.
import QtQuick
import QtQuick.Effects
import Quickshell

Item {
    id: root
    property string name
    property color color: "white"
    property int size: 20
    implicitWidth: size
    implicitHeight: size

    Image {
        id: img
        anchors.fill: parent
        source: Quickshell.shellDir + "/icons/" + root.name + ".svg"
        sourceSize: Qt.size(root.size * 2, root.size * 2)
        visible: false
    }
    MultiEffect {
        anchors.fill: parent
        source: img
        colorization: 1.0
        colorizationColor: root.color
        brightness: 1.0
    }
}
