import QtQuick
import qs.services

Rectangle {
    id: root
    property string icon
    property color iconColor: Theme.text
    property int iconSize: 18
    signal clicked()
    implicitWidth: 40; implicitHeight: 40
    radius: 12
    color: ma.containsMouse ? Theme.surface3 : Theme.surface2
    Icon { anchors.centerIn: parent; name: root.icon; size: root.iconSize; color: root.iconColor }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.clicked() }
}
