// Compact pill: number inside, level drawn around the outline.
import QtQuick
import QtQuick.Shapes
import qs.services

Item {
    id: root
    property real level: 0.82          // 0..1
    property bool charging: false
    readonly property color col: level <= 0.15 ? Theme.danger : level <= 0.30 ? Theme.warn : Theme.accentBright
    implicitWidth: 40
    implicitHeight: 22

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: Qt.rgba(1, 1, 1, 0.06)
        border.width: 1.5
        border.color: Qt.rgba(1, 1, 1, 0.16)
    }
    // the outline from top-centre, clockwise, cut at the battery level (drawn as an SVG path)
    function arc(f) {
        f = Math.max(0.02, Math.min(1, f))
        const r = 10, segs = [9, Math.PI * r, 18, Math.PI * r, 9]
        let left = f * segs.reduce((a, b) => a + b, 0)
        let d = "M20 1"
        const take = len => { const t = Math.min(left, len); left -= t; return t }
        let t = take(segs[0]); d += "H" + (20 + t)
        if (left > 0) { t = take(segs[1]); const a = -Math.PI / 2 + t / r
            d += "A10 10 0 0 1 " + (29 + r * Math.cos(a)) + " " + (11 + r * Math.sin(a)) }
        if (left > 0) { t = take(segs[2]); d += "H" + (29 - t) }
        if (left > 0) { t = take(segs[3]); const a = Math.PI / 2 + t / r
            d += "A10 10 0 0 1 " + (11 + r * Math.cos(a)) + " " + (11 + r * Math.sin(a)) }
        if (left > 0) { t = take(segs[4]); d += "H" + (11 + t) }
        return d
    }
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            strokeColor: root.col
            strokeWidth: 2.2
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathSvg { path: root.arc(root.level) }
        }
    }
    Text {
        anchors.centerIn: parent
        text: root.charging ? "⚡" + Math.round(root.level * 100) : Math.round(root.level * 100)
        color: root.col
        font.family: Theme.font; font.pixelSize: 12; font.weight: Font.Bold
    }
}
