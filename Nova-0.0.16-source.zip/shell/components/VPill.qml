// Slim pill slider for the control centre and the volume / brightness OSD.
// vertical: fills from the bottom, icon in the round foot, % at the top.
// horizontal: fills from the left, icon in the round foot, % at the right.
import QtQuick
import qs.services

Item {
    id: root
    property real value: 0.5
    property string icon: "volume"
    property bool vertical: true
    property bool interactive: true
    property bool muted: false
    property bool showPercent: true
    signal moved(real value)
    implicitWidth: vertical ? 56 : 300
    implicitHeight: vertical ? 220 : 56

    readonly property real thick: vertical ? width : height
    readonly property real len: vertical ? height : width
    readonly property real fillLen: Math.max(thick, value * len)

    Rectangle {
        id: track
        anchors.fill: parent
        radius: root.thick / 2
        color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.07)
        border.color: Qt.rgba(1, 1, 1, 0.05)
        clip: true
        Rectangle {
            x: 0
            y: root.vertical ? root.height - height : 0
            width: root.vertical ? root.width : root.fillLen
            height: root.vertical ? root.fillLen : root.height
            radius: root.thick / 2
            color: root.muted ? Qt.rgba(0.91, 0.38, 0.30, 0.22) : Theme.accent
            gradient: root.muted ? null : grad
            Behavior on width { enabled: !root.vertical; NumberAnimation { duration: Theme.ms(110); easing.type: Easing.OutCubic } }
            Behavior on height { enabled: root.vertical; NumberAnimation { duration: Theme.ms(110); easing.type: Easing.OutCubic } }
        }
        Gradient {
            id: grad
            orientation: root.vertical ? Gradient.Vertical : Gradient.Horizontal
            GradientStop { position: 0; color: root.vertical ? Qt.lighter(Theme.accent, 1.18) : Theme.accent }
            GradientStop { position: 1; color: root.vertical ? Theme.accent : Qt.lighter(Theme.accent, 1.18) }
        }
    }
    Text {
        visible: root.showPercent && !root.muted
        x: root.vertical ? (root.width - width) / 2 : root.width - width - 14
        y: root.vertical ? 10 : (root.height - height) / 2
        text: Math.round(root.value * 100) + "%"
        color: Theme.text2
        font.family: Theme.font; font.pixelSize: root.thick < 50 ? 10 : 11.5
    }
    Icon {
        name: root.icon
        size: Math.round(root.thick * 0.38)
        x: root.vertical ? (root.width - size) / 2 : (root.thick - size) / 2
        y: root.vertical ? root.height - (root.thick + size) / 2 : (root.height - size) / 2
        color: root.muted ? Theme.danger : Theme.onAccent
    }
    MouseArea {
        anchors.fill: parent
        enabled: root.interactive
        cursorShape: Qt.PointingHandCursor
        function upd(m) {
            root.value = Math.max(0, Math.min(1, root.vertical ? 1 - m.y / height : m.x / width));
            root.moved(root.value);
        }
        onPressed: m => upd(m)
        onPositionChanged: m => { if (pressed) upd(m) }
        onWheel: w => { root.value = Math.max(0, Math.min(1, root.value + (w.angleDelta.y > 0 ? 0.05 : -0.05))); root.moved(root.value) }
    }
}
