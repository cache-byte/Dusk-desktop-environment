// Thick horizontal slider: gradient accent fill with a soft knob riding inside.
import QtQuick
import qs.services

Item {
    id: root
    property real value: 0.5          // 0..1
    signal moved(real value)
    implicitHeight: 28
    implicitWidth: 200

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.07)
        border.color: Qt.rgba(1, 1, 1, 0.05)
    }
    Rectangle {
        id: fill
        height: parent.height
        width: Math.max(height, root.value * root.width)
        radius: height / 2
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.45) }
            GradientStop { position: 1; color: Theme.accent }
        }
        Rectangle {
            width: root.height - 8; height: width; radius: width / 2
            anchors.right: parent.right; anchors.rightMargin: 4
            anchors.verticalCenter: parent.verticalCenter
            color: Qt.rgba(1, 1, 1, 0.93)
            border.width: 3
            border.color: Qt.rgba(1, 1, 1, 0.22)
        }
    }
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        function upd(x) { root.value = Math.max(0, Math.min(1, x / width)); root.moved(root.value) }
        onPressed: m => upd(m.x)
        onPositionChanged: m => { if (pressed) upd(m.x) }
        onWheel: w => { root.value = Math.max(0, Math.min(1, root.value + (w.angleDelta.y > 0 ? 0.05 : -0.05))); root.moved(root.value) }
    }
}
