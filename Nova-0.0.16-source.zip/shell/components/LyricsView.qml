// Synced lyrics in one of six styles:
// 1 Fade stack · 2 Karaoke sweep · 3 Terminal · 4 Word bloom · 5 Accent rail · 6 Outline
// The part of the current line already sung is in the accent colour in every style.
import QtQuick
import QtQuick.Layouts
import qs.services

Item {
    id: root
    property int style: Config.s.lyricsStyle ?? 1
    property real scale: ({ S: 0.8, M: 1, L: 1.25, XL: 1.55 })[Config.s.lyricsSize ?? "M"] ?? 1
    property bool center: true
    property color textColor: Theme.text
    readonly property int i: Lyrics.current
    readonly property string cur: Lyrics.line(i)
    readonly property var words: cur.split(" ")
    readonly property int sung: Math.round(Lyrics.progress * words.length)
    readonly property string accentHex: Theme.accent.toString()
    function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;") }
    // current line as rich text: sung words in accent
    function rich(extra) {
        return words.map((w, k) => k < sung ? `<span style="color:${accentHex}">${esc(w)}</span>` : esc(w)).join(" ")
    }
    function ts(t) { const m = Math.floor(t / 60), s = (t % 60).toFixed(2); return "[" + (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s + "]" }
    implicitHeight: col.implicitHeight

    Text {
        visible: !Lyrics.synced
        anchors.centerIn: parent
        text: Lyrics.loading ? "Finding lyrics…" : Lyrics.plain ? "Only unsynced lyrics found" : "No lyrics for this song"
        color: Theme.text3; font.pixelSize: Math.round(13 * root.scale); font.family: Theme.font
    }
    ColumnLayout {
        id: col
        visible: Lyrics.synced
        anchors.left: parent.left; anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
        spacing: 8 * root.scale

        // 1 Fade stack / 5 Accent rail: previous, current, next two
        Repeater {
            model: root.style === 1 || root.style === 5 ? [-1, 0, 1, 2] : []
            RowLayout {
                required property int modelData
                Layout.fillWidth: true; spacing: 10
                Rectangle { visible: root.style === 5; implicitWidth: 4; implicitHeight: 20 * root.scale; radius: 2; color: modelData === 0 ? Theme.accent : "transparent" }
                Text {
                    Layout.fillWidth: true
                    horizontalAlignment: root.center && root.style === 1 ? Text.AlignHCenter : Text.AlignLeft
                    textFormat: modelData === 0 ? Text.RichText : Text.PlainText
                    text: modelData === 0 ? root.rich() : root.esc(Lyrics.line(root.i + modelData))
                    wrapMode: Text.Wrap
                    color: root.textColor
                    opacity: modelData === 0 ? 1 : modelData === 1 ? 0.45 : modelData < 0 ? 0.3 : 0.22
                    font.family: Theme.font; font.weight: modelData === 0 ? Font.Bold : Font.DemiBold
                    font.pixelSize: (modelData === 0 ? 24 : 16) * root.scale
                    Behavior on opacity { NumberAnimation { duration: 220 } }
                }
            }
        }
        // 2 Karaoke sweep · 4 Word bloom · 6 Outline: big current line + next
        Text {
            visible: root.style === 2 || root.style === 4 || root.style === 6
            Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
            textFormat: Text.RichText
            text: root.style === 4
                ? root.words.map((w, k) => k === root.sung - 1 ? `<span style="color:${root.accentHex};font-size:${Math.round(30 * root.scale)}px">${root.esc(w)}</span>` : `<span style="opacity:${k < root.sung ? 1 : 0.5}">${root.esc(w)}</span>`).join(" ")
                : root.rich()
            color: root.textColor
            style: root.style === 6 ? Text.Outline : Text.Normal
            styleColor: Qt.rgba(1, 1, 1, 0.85)
            font.family: Theme.font; font.weight: root.style === 6 ? Font.Black : Font.Bold; font.pixelSize: Math.round(26 * root.scale)
        }
        Text {
            visible: root.style === 2
            Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
            text: Lyrics.line(root.i + 1); color: root.textColor; opacity: 0.5
            font.family: Theme.font; font.pixelSize: Math.round(15 * root.scale)
        }
        // 3 Terminal
        Repeater {
            model: root.style === 3 ? [-1, 0, 1] : []
            Text {
                required property int modelData
                readonly property int k: root.i + modelData
                visible: k >= 0 && k < Lyrics.lines.length
                Layout.fillWidth: true; wrapMode: Text.Wrap
                textFormat: Text.RichText
                text: visible ? root.ts(Lyrics.lines[k][0]) + " " + (modelData === 0 ? root.rich() + `<span style="background:${root.accentHex}">&nbsp;</span>` : root.esc(Lyrics.line(k))) : ""
                color: root.textColor; opacity: modelData === 0 ? 1 : 0.5
                font.family: Theme.mono; font.pixelSize: Math.round(14 * root.scale)
            }
        }
    }
}
