// Tiny animated equaliser shown on the clock pill while music plays.
import QtQuick
import qs.services

Row {
    id: root
    property bool active: true
    spacing: 2
    height: 12
    Repeater {
        model: 3
        Rectangle {
            required property int index
            width: 3; radius: 1.5
            anchors.bottom: parent.bottom
            color: Theme.accent
            height: 5
            SequentialAnimation on height {
                running: root.active
                loops: Animation.Infinite
                NumberAnimation { to: [10, 12, 8][index]; duration: 260 + index * 90; easing.type: Easing.InOutSine }
                NumberAnimation { to: [4, 6, 3][index]; duration: 300 + index * 70; easing.type: Easing.InOutSine }
            }
        }
    }
}
