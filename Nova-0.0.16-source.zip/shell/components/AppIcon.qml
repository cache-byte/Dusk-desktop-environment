// Icon for a desktop entry / app id from the user's icon theme (Papirus by default).
import QtQuick
import Quickshell
import Quickshell.Widgets

IconImage {
    property string appId: ""
    property var entry: appId ? DesktopEntries.heuristicLookup(appId) : null
    property string iconName: entry?.icon ?? appId
    source: Quickshell.iconPath(iconName, "application-x-executable")
    implicitSize: 32
}
