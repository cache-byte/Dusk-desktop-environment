// Beat visualizer. style: 1 Bars · 2 Wave line · 3 Filled wave · 4 LED matrix · 5 Peak caps · 6 Mountains · 7 Pills
// Uses Cava while visible; shows a gentle idle shape otherwise.
import QtQuick
import qs.services

Canvas {
    id: c
    property int style: Config.s.vizStyle ?? 1
    property string colour: Config.s.vizColour ?? "accent"
    property bool live: visible && Media.playing
    property var peaks: []
    readonly property var v: Cava.values.length ? Cava.values : Array.from({ length: Cava.bars }, (_, i) => 0.05 + 0.04 * Math.sin(i / 2))
    onLiveChanged: Cava.use(live ? 1 : -1)
    Component.onCompleted: if (live) Cava.use(1)
    Component.onDestruction: if (live) Cava.use(-1)
    onVChanged: requestPaint()
    onStyleChanged: requestPaint()

    function col(i, n, a) {
        if (colour === "rainbow") return Qt.hsla(i / Math.max(1, n), 0.65, 0.6, a);
        const base = colour === "art" ? Theme.accentBright : Theme.accent;
        return Qt.rgba(base.r, base.g, base.b, a);
    }
    function smooth(ctx, pts) {
        ctx.moveTo(pts[0][0], pts[0][1]);
        for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
            ctx.bezierCurveTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1]);
        }
    }
    onPaint: {
        const ctx = getContext("2d"), W = width, H = height, n = v.length;
        ctx.reset();
        if (!n || W <= 0 || H <= 0) return;
        const gap = Math.max(1, W * 0.006), bw = (W - gap * (n - 1)) / n;
        if (style === 1 || style === 7) {
            for (let i = 0; i < n; i++) {
                const h = Math.max(bw, v[i] * H * (style === 7 ? 0.8 : 1));
                const y = style === 7 ? (H - h) / 2 : H - h;
                ctx.fillStyle = col(i, n, style === 7 ? 0.85 : 0.6 + 0.4 * v[i]);
                ctx.beginPath(); ctx.roundedRect(i * (bw + gap), y, bw, h, bw / 2, bw / 2); ctx.fill();
            }
        } else if (style === 2 || style === 3 || style === 6) {
            const layers = style === 6 ? 3 : 1;
            for (let l = layers - 1; l >= 0; l--) {
                const pts = v.map((a, i) => [i / (n - 1) * W, H - Math.min(1, a * (1 - l * 0.22)) * H * 0.9 - H * 0.04]);
                ctx.beginPath(); smooth(ctx, pts);
                if (style !== 2) {
                    ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
                    ctx.fillStyle = col(l * 3, 9, style === 6 ? 0.25 + l * 0.2 : 0.35); ctx.fill();
                }
                ctx.strokeStyle = col(0, n, 0.95); ctx.lineWidth = style === 2 ? 3 : 2; ctx.stroke();
            }
        } else if (style === 4) {
            const rows = 14, ch = H / rows;
            for (let i = 0; i < n; i++) {
                const lit = Math.round(v[i] * rows);
                for (let r = 0; r < rows; r++) {
                    ctx.fillStyle = r < lit ? col(i, n, 0.45 + r / rows * 0.55) : Qt.rgba(1, 1, 1, 0.05);
                    ctx.fillRect(i * (bw + gap), H - (r + 1) * ch + ch * 0.15, bw, ch * 0.7);
                }
            }
        } else if (style === 5) {
            if (peaks.length !== n) peaks = Array(n).fill(0);
            for (let i = 0; i < n; i++) {
                peaks[i] = Math.max(v[i], peaks[i] - 0.012);
                const h = v[i] * H * 0.92;
                ctx.fillStyle = col(i, n, 0.7); ctx.fillRect(i * (bw + gap), H - h, bw, h);
                ctx.fillStyle = col(i, n, 1); ctx.fillRect(i * (bw + gap), H - peaks[i] * H * 0.92 - 4, bw, 3);
            }
        }
    }
}
