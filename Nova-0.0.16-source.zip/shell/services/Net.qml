// Wi-Fi state via nmcli (NetworkManager is the default on Fedora).
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property bool wifiEnabled: true
    property string ssid: ""
    property int signal: 0
    property bool wired: false

    function setWifi(on) { Quickshell.execDetached(["nmcli", "radio", "wifi", on ? "on" : "off"]); wifiEnabled = on; poll.restart() }
    function setAirplane(on) { Quickshell.execDetached(["nmcli", "radio", "all", on ? "off" : "on"]); poll.restart() }

    Timer { id: poll; interval: 8000; running: true; repeat: true; triggeredOnStart: true; onTriggered: proc.running = true }
    Process {
        id: proc
        command: ["sh", "-c", "nmcli radio wifi; nmcli -t -f ACTIVE,SSID,SIGNAL dev wifi 2>/dev/null | grep '^yes'; nmcli -t -f TYPE,STATE dev | grep '^ethernet:connected'"]
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = text.split("\n");
                root.wifiEnabled = lines[0].trim() === "enabled";
                const act = lines.find(l => l.startsWith("yes:"));
                if (act) { const p = act.split(":"); root.ssid = p[1]; root.signal = parseInt(p[2]) || 0 }
                else { root.ssid = ""; root.signal = 0 }
                root.wired = lines.some(l => l.startsWith("ethernet:connected"));
            }
        }
    }
}
