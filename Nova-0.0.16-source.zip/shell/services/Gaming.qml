// Game mode: while a game is fullscreen (Feral GameMode reports it active), switch to the
// performance power profile and restore the previous one afterwards. Do-not-disturb and
// "never dim/sleep" are handled by Notifs and the compositor.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property bool active: false
    property string savedProfile: ""
    readonly property bool watching: Config.s.gameModeAuto && Nova.fullscreen

    Timer { interval: 4000; repeat: true; triggeredOnStart: true; running: root.watching; onTriggered: check.running = true }
    onWatchingChanged: if (!watching) root.setActive(false)
    Process {
        id: check
        command: ["sh", "-c", "gamemoded -s 2>/dev/null"]
        stdout: StdioCollector { onStreamFinished: root.setActive(text.includes("is active")) }
    }
    function setActive(on) {
        if (on === active) return;
        active = on;
        if (on) prof.running = true;   // remember, then switch to performance
        else if (savedProfile) Quickshell.execDetached(["powerprofilesctl", "set", savedProfile]);
    }
    Process {
        id: prof
        command: ["powerprofilesctl", "get"]
        stdout: StdioCollector { onStreamFinished: {
            root.savedProfile = text.trim();
            Quickshell.execDetached(["powerprofilesctl", "set", "performance"]);
        } }
    }
}
