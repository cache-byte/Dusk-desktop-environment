pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property string device: ""
    property int max: 1
    property int current: 0
    readonly property real value: max > 0 ? current / max : 0
    readonly property bool available: device !== ""
    signal changed()

    function set(v) {
        v = Math.max(0.01, Math.min(1, v));
        Quickshell.execDetached(["brightnessctl", "-q", "set", Math.round(v * 100) + "%"]);
    }

    Process {
        running: true
        command: ["sh", "-c", "ls /sys/class/backlight | head -n1"]
        stdout: StdioCollector { onStreamFinished: root.device = text.trim() }
    }
    FileView {
        path: root.available ? `/sys/class/backlight/${root.device}/max_brightness` : ""
        onLoaded: root.max = parseInt(text()) || 1
    }
    FileView {
        id: cur
        path: root.available ? `/sys/class/backlight/${root.device}/brightness` : ""
        watchChanges: true
        onFileChanged: reload()
        onLoaded: {
            const v = parseInt(text()) || 0;
            if (v !== root.current) { root.current = v; root.changed() }
        }
    }
}
