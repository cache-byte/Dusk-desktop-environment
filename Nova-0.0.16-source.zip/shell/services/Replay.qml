// Instant replay with gpu-screen-recorder: keeps the last N seconds in memory.
// Super+Alt+R (or `novactl dispatch shell save-replay`) saves them to ~/Videos/Replays.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    readonly property bool enabled: Config.s.replayEnabled ?? false
    readonly property string dir: Quickshell.env("HOME") + "/Videos/Replays"
    signal saved(string path)
    function save() { if (proc.running) Quickshell.execDetached(["kill", "-USR1", String(proc.processId)]) }
    Connections { target: Nova; function onShellAction(a) { if (a === "save-replay") root.save() } }
    Process {
        id: proc
        running: root.enabled
        command: ["sh", "-c", "mkdir -p \"$1\" && exec gpu-screen-recorder -w screen -f 60 -c " + (Config.s.recordFormat === "mkv" ? "mkv" : "mp4") +
                  " -a default_output" + (Config.s.recordMic ? " -a default_input" : "") +
                  " -r " + (Config.s.replaySeconds ?? 30) + " -o \"$1\"", "sh", root.dir]
        stdout: SplitParser { onRead: line => { if (line.trim().startsWith("/")) root.saved(line.trim()) } }
    }
}
