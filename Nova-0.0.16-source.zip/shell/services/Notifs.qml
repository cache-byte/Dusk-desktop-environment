pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Services.Notifications

Singleton {
    id: root
    readonly property var all: server.trackedNotifications.values
    readonly property int count: all.length
    property var popups: []            // notifications currently shown as toasts

    // Do not disturb: the manual switch, or automatic while something is fullscreen.
    readonly property bool quiet: Config.s.dnd || (Config.s.autoDnd && Nova.fullscreen)
    property int missed: 0                     // notifications held back during fullscreen
    signal missedSummary(int count)
    Connections {
        target: Nova
        function onFullscreenChanged() {
            if (!Nova.fullscreen && root.missed > 0) { root.missedSummary(root.missed); root.missed = 0 }
        }
    }
    // Grouping for the notification centre: [{key, name, icon, items:[...]}], newest group first.
    readonly property var groups: {
        if (!Config.s.groupNotifications) return all.slice().reverse().map(n => ({ key: n.id, name: n.appName, icon: n.appIcon, items: [n] }));
        const m = new Map();
        for (const n of all.slice().reverse()) {
            const k = (n.appName || "System") + "|" + (n.category || "").split(".")[0];
            if (!m.has(k)) m.set(k, { key: k, name: n.appName || "System", icon: n.appIcon, items: [] });
            m.get(k).items.push(n);
        }
        return Array.from(m.values());
    }

    function dismissPopup(n) { popups = popups.filter(p => p !== n) }
    function clearAll() { for (const n of all.slice()) n.dismiss(); popups = [] }

    NotificationServer {
        id: server
        keepOnReload: true
        actionsSupported: true
        bodyMarkupSupported: true
        imageSupported: true
        persistenceSupported: true
        onNotification: n => {
            n.tracked = true;
            if (!root.quiet || n.urgency === NotificationUrgency.Critical)
                root.popups = [n].concat(root.popups).slice(0, 4);
            else if (!Config.s.dnd) root.missed++;
        }
    }
}
