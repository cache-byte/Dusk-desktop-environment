// Synced lyrics for the current song (see session/nova-lyrics for where they come from).
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property var lines: []            // [[seconds, text], ...]
    property string plain: ""
    property string source: ""
    property bool loading: false
    readonly property bool synced: lines.length > 0
    readonly property bool wanted: Config.s.lyricsNowPlaying || Config.s.lyricsDesktop
    readonly property string key: Media.artist + "|" + Media.title

    // index of the line being sung, and how far through it we are (0..1)
    readonly property real t: Media.position + (Config.s.lyricsOffset ?? 0)
    readonly property int current: {
        let i = -1;
        for (let k = 0; k < lines.length; k++) { if (lines[k][0] <= t) i = k; else break }
        return i;
    }
    readonly property real progress: {
        if (current < 0) return 0;
        const start = lines[current][0], end = current + 1 < lines.length ? lines[current + 1][0] : start + 4;
        return Math.max(0, Math.min(1, (t - start) / Math.max(0.5, end - start)));
    }
    function line(i) { return i >= 0 && i < lines.length ? lines[i][1] : "" }

    onKeyChanged: fetch.restart()
    onWantedChanged: if (wanted) fetch.restart()
    Timer { id: fetch; interval: 400; onTriggered: root.load() }

    function load() {
        lines = []; plain = ""; source = "";
        if (!wanted || !Media.player || Media.title === "Nothing playing") return;
        loading = true;
        proc.command = ["nova-lyrics", "--title", Media.title, "--artist", Media.artist, "--album", Media.album,
                        "--duration", String(Math.round(Media.length)), "--url", Media.url]
                       .concat(Config.s.lyricsSongRec ? ["--songrec"] : []);
        proc.running = true;
    }
    Process {
        id: proc
        property string forKey: ""
        onStarted: forKey = root.key
        stdout: StdioCollector {
            onStreamFinished: {
                root.loading = false;
                if (proc.forKey !== root.key) return;      // song changed meanwhile
                try {
                    const d = JSON.parse(text);
                    root.lines = d.synced || []; root.plain = d.plain || ""; root.source = d.source || "";
                } catch (e) {}
            }
        }
    }
}
