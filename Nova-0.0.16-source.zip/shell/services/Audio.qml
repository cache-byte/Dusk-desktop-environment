pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Services.Pipewire

Singleton {
    id: root
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var source: Pipewire.defaultAudioSource
    readonly property real volume: sink?.audio?.volume ?? 0
    readonly property bool muted: sink?.audio?.muted ?? false
    readonly property real micVolume: source?.audio?.volume ?? 0
    readonly property bool micMuted: source?.audio?.muted ?? false

    signal changed(string what)   // "volume" | "mic" — drives the OSD

    readonly property real maxVolume: Config.s.allowOverAmplify ? 1.5 : 1.0   // up to 150 % if allowed
    function setVolume(v) { if (sink?.audio) { sink.audio.muted = false; sink.audio.volume = Math.max(0, Math.min(maxVolume, v)) } }
    function toggleMute() { if (sink?.audio) sink.audio.muted = !sink.audio.muted }
    function toggleMic() { if (source?.audio) source.audio.muted = !source.audio.muted }

    PwObjectTracker { objects: [root.sink, root.source] }
    Connections {
        target: root.sink?.audio ?? null
        function onVolumeChanged() { root.changed("volume") }
        function onMutedChanged() { root.changed("volume") }
    }
    Connections {
        target: root.source?.audio ?? null
        function onMutedChanged() { root.changed("mic") }
    }
}
