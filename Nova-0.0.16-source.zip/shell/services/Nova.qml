// Connection to the Nova compositor IPC socket ($NOVA_SOCK).
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property int activeWorkspace: 1
    property var occupied: []
    property var outputs: ({})          // per monitor: name -> {active, occupied, base}
    function wsFor(name) { return outputs[name] ?? { active: activeWorkspace, occupied: occupied, base: 1 } }
    property bool capsLock: false
    property bool numLock: false
    property bool ledsKnown: false
    property var windows: []
    property bool fullscreen: false       // something is fullscreen (game, video)
    property string activeOutput: ""     // output under the pointer (for "show on active screen")

    signal shellAction(string action)
    signal lockRequested()
    signal ledsToggled(string which, bool on)

    function dispatch(action) {
        Quickshell.execDetached(["novactl", "dispatch"].concat(action.split(" ")));
    }
    function refreshWindows() { winProc.running = true }

    Socket {
        id: sock
        path: Quickshell.env("NOVA_SOCK")
        connected: true
        onConnectedChanged: {
            if (connected) { write("subscribe\n"); flush(); }
            else reconnect.start();
        }
        parser: SplitParser {
            onRead: line => {
                let e;
                try { e = JSON.parse(line) } catch (err) { return }
                switch (e.event) {
                case "workspaces":
                    root.activeWorkspace = e.active;
                    root.occupied = e.occupied;
                    { const m = {}; for (const o of (e.outputs || [])) m[o.name] = o; root.outputs = m }
                    break;
                case "leds":
                    if (root.ledsKnown && e.caps !== root.capsLock) root.ledsToggled("caps", e.caps);
                    if (root.ledsKnown && e.num !== root.numLock) root.ledsToggled("num", e.num);
                    root.capsLock = e.caps; root.numLock = e.num; root.ledsKnown = true;
                    break;
                case "output": root.activeOutput = e.name; break;
                case "fullscreen": root.fullscreen = e.active; break;
                case "shell": root.shellAction(e.action); break;
                case "lock": root.lockRequested(); break;
                }
            }
        }
    }
    Timer { id: reconnect; interval: 1000; onTriggered: { sock.connected = false; sock.connected = true } }

    Process {
        id: winProc
        command: ["novactl", "get", "windows"]
        stdout: StdioCollector {
            onStreamFinished: {
                try { root.windows = JSON.parse(text).windows } catch (e) { root.windows = [] }
            }
        }
    }
}
