// Live audio spectrum from cava. Runs only while music plays and something shows it;
// half the frame rate on battery.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower

Singleton {
    id: root
    property int users: 0                 // visualizers on screen call use(+1/-1)
    function use(d) { users = Math.max(0, users + d) }
    property var values: []               // 0..1 per bar
    readonly property int bars: Config.s.vizBars ?? 32
    readonly property int fps: UPower.onBattery ? 30 : 60
    readonly property bool running: users > 0 && Media.playing
    readonly property string confPath: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/nova-cava.conf"

    // regenerate cava's config when bars / speed / sensitivity change
    readonly property string conf: "[general]\nbars = " + bars + "\nframerate = " + fps +
        "\nsensitivity = " + Math.round(40 + (Config.s.vizSensitivity ?? 0.55) * 160) +
        "\n[input]\nmethod = pipewire\nsource = auto\n[output]\nmethod = raw\nraw_target = /dev/stdout\n" +
        "data_format = ascii\nascii_max_range = 1000\nbar_delimiter = 59\nframe_delimiter = 10\n" +
        "[smoothing]\nnoise_reduction = 66\n"
    FileView { id: cfgFile; path: root.confPath }
    onConfChanged: restart.restart()
    onRunningChanged: restart.restart()
    Timer {
        id: restart; interval: 120
        onTriggered: {
            proc.running = false;
            if (!root.running) { root.values = []; return }
            cfgFile.setText(root.conf);
            proc.running = true;
        }
    }
    Process {
        id: proc
        command: ["cava", "-p", root.confPath]
        stdout: SplitParser {
            onRead: line => {
                const v = line.split(";"); v.pop();
                root.values = v.map(x => (parseInt(x) || 0) / 1000);
            }
        }
    }
}
