pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Services.Mpris

Singleton {
    id: root
    // The player that played most recently; you can switch to another one in Now Playing.
    property string lastId: ""
    property string chosenId: ""          // set by the player switcher; cleared when that player goes away
    readonly property var players: Mpris.players.values
    function idOf(p) { return p ? (p.dbusName || p.identity) : "" }
    readonly property var player: {
        const ps = players;
        return ps.find(p => idOf(p) === chosenId) ?? ps.find(p => p.isPlaying && idOf(p) === lastId)
            ?? ps.find(p => p.isPlaying) ?? ps.find(p => idOf(p) === lastId) ?? ps[0] ?? null;
    }
    function choose(p) { chosenId = idOf(p) }
    Instantiator {
        model: Mpris.players
        delegate: Connections {
            required property var modelData
            target: modelData
            function onIsPlayingChanged() {
                if (modelData.isPlaying) { root.lastId = root.idOf(modelData); if (root.chosenId !== root.lastId) root.chosenId = "" }
            }
        }
    }
    readonly property bool playing: player?.isPlaying ?? false
    readonly property string title: player?.trackTitle || "Nothing playing"
    readonly property string artist: player?.trackArtist || ""
    readonly property string album: player?.trackAlbum || ""
    readonly property string art: player?.trackArtUrl || ""
    readonly property string app: player?.identity || ""
    readonly property real length: player?.length ?? 0
    readonly property string url: player?.metadata?.["xesam:url"] ?? ""
    // position ticks while playing (MPRIS doesn't push it)
    property real position: 0
    Timer {
        interval: 100; repeat: true; running: root.playing
        onTriggered: { root.player.positionChanged(); root.position = root.player.position }
    }
    onPlayerChanged: position = player?.position ?? 0

    function fmt(sec) {
        if (!isFinite(sec) || sec < 0) return "0:00";
        const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
        return m + ":" + (s < 10 ? "0" : "") + s;
    }
}
