// Beat visualizer on the desktop: along the bottom edge, in the centre, along the top,
// or placed freely (Custom = Popups & indicators placement).
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs.services
import qs.components

PanelWindow {
    id: w
    readonly property string pos: Config.s.vizDesktopPos ?? "bottom"
    visible: (Config.s.vizPlaces ?? []).includes("desktop") && Media.playing && !Nova.fullscreen
    WlrLayershell.layer: WlrLayer.Bottom
    WlrLayershell.namespace: "nova-visualizer"
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    mask: Region {}
    // Custom: uses the visualizer spot on Settings > Popups & indicators
    readonly property var cfg: Config.osd("visualizer")
    readonly property bool custom: pos === "custom"
    anchors {
        bottom: pos === "bottom" || (custom && Math.floor(cfg.pos / 3) === 2)
        top: pos === "top" || (custom && Math.floor(cfg.pos / 3) === 0)
        left: pos === "bottom" || pos === "top" || (custom && cfg.pos % 3 === 0)
        right: pos === "bottom" || pos === "top" || (custom && cfg.pos % 3 === 2)
    }
    margins.bottom: pos === "bottom" || custom ? Theme.panelHeight + 8 : 0
    margins.top: pos === "top" || custom ? 8 : 0
    margins.left: custom ? 20 : 0
    margins.right: custom ? 20 : 0
    implicitWidth: pos === "centre" || pos === "custom" ? 900 : 0
    implicitHeight: pos === "centre" || pos === "custom" ? 280 : 170

    ColumnLayout {
        anchors.fill: parent
        spacing: 12
        Visualizer {
            Layout.fillWidth: true; Layout.fillHeight: true
            opacity: Config.s.vizDesktopOpacity ?? 0.85
        }
        ColumnLayout {
            visible: Config.s.vizDesktopTitle
            Layout.alignment: Qt.AlignHCenter; spacing: 2
            Text { Layout.alignment: Qt.AlignHCenter; text: Media.title; color: "white"; font.pixelSize: 30; font.weight: Font.Bold; font.family: Theme.font }
            Text { Layout.alignment: Qt.AlignHCenter; text: Media.artist; color: Theme.accentBright; font.pixelSize: 16; font.family: Theme.font }
        }
    }
}
