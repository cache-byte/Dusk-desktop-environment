import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Services.Notifications
import qs.services
import qs.components

Rectangle {
    id: card
    required property var notif
    property bool popup: false
    signal closed()
    implicitWidth: 400
    implicitHeight: col.implicitHeight + 32
    radius: Theme.radius
    color: popup ? Theme.surface : Theme.surface2
    border.color: notif.urgency === NotificationUrgency.Critical ? Theme.danger : Theme.border

    ColumnLayout {
        id: col
        anchors.fill: parent; anchors.margins: 16
        spacing: 10
        RowLayout {
            spacing: 10
            AppIcon { implicitSize: 22; source: card.notif.appIcon ? Quickshell.iconPath(card.notif.appIcon, "dialog-information") : Quickshell.iconPath("dialog-information") }
            Text { text: card.notif.appName || "Notification"; color: Theme.text2; font.pixelSize: 13 }
            Text { text: "· " + Qt.formatTime(new Date(), "HH:mm"); color: Theme.text3; font.pixelSize: 13 }
            Item { Layout.fillWidth: true }
            Icon { name: "x"; size: 16; color: Theme.text3
                MouseArea { anchors.fill: parent; anchors.margins: -6; onClicked: { card.notif.dismiss(); card.closed() } } }
        }
        RowLayout {
            spacing: 14
            ColumnLayout {
                Layout.fillWidth: true; spacing: 4
                Text { Layout.fillWidth: true; text: card.notif.summary; wrapMode: Text.Wrap; maximumLineCount: 2; elide: Text.ElideRight; color: Theme.text; font.pixelSize: 15; font.weight: Font.DemiBold }
                Text { Layout.fillWidth: true; visible: text !== ""; text: card.notif.body; textFormat: Text.StyledText; wrapMode: Text.Wrap; maximumLineCount: 4; elide: Text.ElideRight; color: Theme.text2; font.pixelSize: 13; lineHeight: 1.15 }
            }
            Rectangle {
                visible: card.notif.image !== ""
                implicitWidth: 84; implicitHeight: 54; radius: 10; clip: true; color: Theme.surface3
                Image { anchors.fill: parent; source: card.notif.image; fillMode: Image.PreserveAspectCrop }
            }
        }
        RowLayout {
            visible: card.notif.actions.length > 0
            Layout.fillWidth: true; spacing: 8
            Repeater {
                model: card.notif.actions
                Rectangle {
                    required property var modelData
                    required property int index
                    Layout.fillWidth: true; implicitHeight: 34; radius: 11
                    color: index === card.notif.actions.length - 1 ? Theme.accent : Theme.surface3
                    Text { anchors.centerIn: parent; text: modelData.text; font.pixelSize: 13; font.weight: Font.DemiBold
                           color: parent.index === card.notif.actions.length - 1 ? Theme.onAccent : Theme.text }
                    MouseArea { anchors.fill: parent; onClicked: { modelData.invoke(); card.closed() } }
                }
            }
        }
    }
}
