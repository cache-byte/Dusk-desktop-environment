// Pops up above the clock while it's hovered (and something is playing).
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs.services
import qs.components

PanelWindow {
    id: win
    visible: Shell.npOpen && Shell.npScreen === screen
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "nova-nowplaying"
    exclusionMode: ExclusionMode.Ignore
    // "clock": pops up above the clock (default). Otherwise uses its own anchor.
    readonly property var cfg: Config.osd("nowplaying")
    readonly property bool atClock: cfg.dir === "clock"
    readonly property int row: atClock ? 2 : Math.floor(cfg.pos / 3)
    readonly property int col: atClock ? 2 : cfg.pos % 3
    anchors { top: row === 0; bottom: row === 2; left: col === 0; right: col === 2 }
    margins { top: 20; bottom: Theme.panelHeight + (atClock ? 8 : 20); left: 20; right: atClock ? 12 : 20 }
    implicitWidth: 380
    implicitHeight: card.implicitHeight
    color: "transparent"

    HoverHandler { onHoveredChanged: Shell.npCardHovered = hovered }
    property string tab: "player"          // player | lyrics (remembered while the shell runs)

    Glass {
        id: card
        anchors.fill: parent
        implicitHeight: col.implicitHeight + 32
        radius: 22
        ColumnLayout {
            id: col
            anchors.fill: parent
            spacing: 14
            RowLayout {
                spacing: 8
                MusicBars { active: Media.playing; visible: Media.playing }
                Text { Layout.fillWidth: true; text: "Now playing" + (Media.app ? " · " + Media.app : ""); elide: Text.ElideRight; color: Theme.text2; font.pixelSize: 12; font.family: Theme.font }
                Repeater {
                    model: Config.s.lyricsNowPlaying ? [["player", "Player"], ["lyrics", "Lyrics"]] : []
                    Rectangle {
                        required property var modelData
                        readonly property bool on: win.tab === modelData[0]
                        implicitHeight: 26; implicitWidth: tl.implicitWidth + 20; radius: 13
                        color: on ? Theme.accent : Theme.surface2
                        Text { id: tl; anchors.centerIn: parent; text: parent.modelData[1]; font.pixelSize: 12; font.family: Theme.font
                               color: parent.on ? Theme.onAccent : Theme.text2; font.weight: parent.on ? Font.DemiBold : Font.Normal }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: win.tab = parent.modelData[0] }
                    }
                }
            }
            // more than one player: pick which one these controls drive
            Flow {
                visible: Media.players.length > 1
                Layout.fillWidth: true; spacing: 6
                Repeater {
                    model: Media.players
                    Rectangle {
                        required property var modelData
                        readonly property bool on: Media.player === modelData
                        implicitHeight: 24; implicitWidth: pl.implicitWidth + 18; radius: 12
                        color: on ? Theme.surface3 : "transparent"; border.color: Theme.border
                        Text { id: pl; anchors.centerIn: parent; text: parent.modelData.identity; font.pixelSize: 12; font.family: Theme.font
                               color: parent.on ? Theme.text : Theme.text3 }
                        MouseArea { anchors.fill: parent; onClicked: Media.choose(parent.modelData) }
                    }
                }
            }
            LyricsView {
                visible: win.tab === "lyrics" && Config.s.lyricsNowPlaying
                Layout.fillWidth: true; Layout.preferredHeight: 210
                scale: 0.8
            }
            Text {
                visible: win.tab === "lyrics" && Lyrics.source !== ""
                Layout.alignment: Qt.AlignRight
                text: "Synced lyrics · " + Lyrics.source; color: Theme.text3; font.pixelSize: 11; font.family: Theme.font
            }
            RowLayout {
                visible: win.tab === "player" || !Config.s.lyricsNowPlaying
                spacing: 14
                Rectangle {
                    implicitWidth: 68; implicitHeight: 68; radius: 14; clip: true
                    color: Theme.surface3
                    Image { anchors.fill: parent; source: Media.art; fillMode: Image.PreserveAspectCrop; visible: Media.art !== "" }
                    Icon { anchors.centerIn: parent; name: "music"; size: 26; color: Theme.text3; visible: Media.art === "" }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 3
                    Text { Layout.fillWidth: true; text: Media.title; elide: Text.ElideRight; color: Theme.text; font.pixelSize: 16; font.weight: Font.DemiBold; font.family: Theme.font }
                    Text { Layout.fillWidth: true; text: [Media.artist, Media.album].filter(x => x).join(" · "); elide: Text.ElideRight; color: Theme.text2; font.pixelSize: 13; font.family: Theme.font }
                }
            }
            Visualizer {
                visible: (win.tab === "player" || !Config.s.lyricsNowPlaying) && (Config.s.vizPlaces ?? []).includes("nowplaying")
                Layout.fillWidth: true; Layout.preferredHeight: 54
            }
            ColumnLayout {
                Layout.fillWidth: true
                visible: Media.player?.positionSupported ?? false
                spacing: 7
                Rectangle {
                    Layout.fillWidth: true; implicitHeight: 10; radius: 5
                    color: Qt.rgba(1, 1, 1, 0.07)
                    Rectangle {
                        height: parent.height; radius: 5; color: Theme.accent
                        width: Media.player && Media.player.length > 0 ? parent.width * Media.player.position / Media.player.length : 0
                    }
                    MouseArea {
                        anchors.fill: parent
                        onClicked: m => { if (Media.player?.canSeek) Media.player.position = Media.player.length * m.x / width }
                    }
                }
                RowLayout {
                    Text { text: Media.fmt(Media.player?.position ?? 0); color: Theme.text3; font.pixelSize: 12 }
                    Item { Layout.fillWidth: true }
                    Text { text: "-" + Media.fmt((Media.player?.length ?? 0) - (Media.player?.position ?? 0)); color: Theme.text3; font.pixelSize: 12 }
                }
                // MPRIS position isn't pushed continuously; poll while visible.
                Timer { running: win.visible && Media.playing; interval: 1000; repeat: true; onTriggered: Media.player?.positionChanged() }
            }
            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 26
                IconButton { icon: "prev"; color: "transparent"; onClicked: Media.player?.previous() }
                Rectangle {
                    implicitWidth: 46; implicitHeight: 46; radius: 23; color: Theme.accent
                    Icon { anchors.centerIn: parent; name: Media.playing ? "pause" : "play"; size: 20; color: Theme.onAccent }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Media.player?.togglePlaying() }
                }
                IconButton { icon: "next"; color: "transparent"; onClicked: Media.player?.next() }
            }
        }
    }
}
