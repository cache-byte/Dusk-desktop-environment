// On-screen indicators, each placed and oriented from Settings → Popups & indicators:
//   slider  — volume / brightness / mic / keyboard backlight (pill, vertical or horizontal)
//   lock    — Caps / Num Lock toast
//   power   — power mode & charger toast
//   message — small messages: `qs ipc call nova toast "Copied" clip`
import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower
import qs.services
import qs.components

Scope {
    id: root
    required property var screen
    readonly property real sizeK: Config.s.osdSize === "S" ? 0.8 : Config.s.osdSize === "L" ? 1.22 : 1.0

    // ---- state ----
    property string kind: ""                       // slider kind: volume | brightness | mic
    property var toasts: ({ lock: null, power: null, message: null })   // {icon, text, on}
    function show(k) { kind = k; sliderTimer.restart() }
    function toast(slot, icon, text, on) {
        const t = Object.assign({}, toasts); t[slot] = { icon, text, on }; toasts = t;
        ({ lock: lockT, power: powerT, message: msgT })[slot].restart();
    }
    function clear(slot) { const t = Object.assign({}, toasts); t[slot] = null; toasts = t }

    Timer { id: sliderTimer; interval: Config.s.osdTimeout; onTriggered: root.kind = "" }
    Timer { id: lockT; interval: Config.s.osdTimeout; onTriggered: root.clear("lock") }
    Timer { id: powerT; interval: Config.s.osdTimeout; onTriggered: root.clear("power") }
    Timer { id: msgT; interval: Config.s.osdTimeout + 500; onTriggered: root.clear("message") }
    Timer { id: settle; interval: 1500; running: true }      // ignore initial values at startup

    Connections { target: Audio; function onChanged(what) { if (!settle.running) root.show(what) } }
    Connections { target: Brightness; function onChanged() { if (!settle.running) root.show("brightness") } }
    Connections {
        target: Replay
        function onSaved(path) { root.toast("message", "record", "Replay saved to Videos/Replays", true) }
    }
    Connections {
        target: Notifs
        function onMissedSummary(n) { root.toast("message", "bell", n + (n === 1 ? " notification" : " notifications") + " while you were in fullscreen", true) }
    }
    Connections {
        target: Nova
        function onLedsToggled(which, on) {
            root.toast("lock", which === "caps" ? "caps" : "hash", (which === "caps" ? "Caps Lock " : "Num Lock ") + (on ? "on" : "off"), on);
        }
    }
    Connections {
        target: PowerProfiles
        function onProfileChanged() {
            if (settle.running) return;
            const p = PowerProfiles.profile;
            root.toast("power", p === PowerProfile.PowerSaver ? "leaf" : p === PowerProfile.Performance ? "bolt" : "gauge",
                       p === PowerProfile.PowerSaver ? "Power saver" : p === PowerProfile.Performance ? "Performance" : "Balanced", true);
        }
    }
    Connections {
        target: UPower
        function onOnBatteryChanged() {
            if (!settle.running) root.toast("power", "bolt", UPower.onBattery ? "On battery" : "Charging", !UPower.onBattery);
        }
    }
    IpcHandler {
        target: "toast"
        function show(text: string, icon: string): void { root.toast("message", icon || "check", text, true) }
    }

    // ---- slider indicator ----
    Placed {
        id: sliderWin
        kind: "slider"
        screen: root.screen
        visible: root.kind !== "" && onThisScreen
        readonly property bool vert: cfg.dir !== "across"
        implicitWidth: Math.round((vert ? 60 : 300) * root.sizeK)
        implicitHeight: Math.round((vert ? 220 : 60) * root.sizeK)
        mask: Region {}
        Glass {
            anchors.fill: parent; radius: Math.min(width, height) / 2; padding: 5
            VPill {
                anchors.fill: parent
                vertical: sliderWin.vert
                interactive: false
                icon: root.kind === "brightness" ? "sun" : root.kind === "mic" ? (Audio.micMuted ? "mute" : "mic") : (Audio.muted ? "mute" : "volume")
                muted: (root.kind === "volume" && Audio.muted) || (root.kind === "mic" && Audio.micMuted)
                value: root.kind === "brightness" ? Brightness.value : root.kind === "mic" ? Audio.micVolume : Audio.volume
            }
        }
    }

    // ---- toasts ----
    Variants {
        model: ["lock", "power", "message"]
        Placed {
            id: tw
            required property var modelData
            kind: modelData
            screen: root.screen
            readonly property var t: root.toasts[modelData]
            readonly property bool vert: cfg.dir === "up"
            visible: t !== null && onThisScreen
            implicitWidth: vert ? Math.round(64 * root.sizeK) : row.implicitWidth + 28
            implicitHeight: vert ? Math.round(150 * root.sizeK) : Math.round(56 * root.sizeK)
            mask: Region {}
            Glass {
                anchors.fill: parent; radius: Math.min(width, height) / 2; padding: 9
                // across: icon + text in a row; up: icon on top, text rotated
                Row {
                    id: row
                    visible: !tw.vert
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 14
                    Rectangle {
                        width: 38 * root.sizeK; height: width; radius: width / 2
                        color: tw.t?.on ? Theme.accent : Theme.surface3
                        Icon { anchors.centerIn: parent; name: tw.t?.icon ?? "check"; color: tw.t?.on ? Theme.onAccent : Theme.text }
                    }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: tw.t?.text ?? ""; color: Theme.text; font.pixelSize: Math.round(14.5 * root.sizeK); font.weight: Font.Medium; rightPadding: 6 }
                }
                Column {
                    visible: tw.vert
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 10
                    Rectangle {
                        width: 38 * root.sizeK; height: width; radius: width / 2
                        color: tw.t?.on ? Theme.accent : Theme.surface3
                        Icon { anchors.centerIn: parent; name: tw.t?.icon ?? "check"; color: tw.t?.on ? Theme.onAccent : Theme.text }
                    }
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: (tw.t?.text ?? "").split(" ").pop(); color: Theme.text; font.pixelSize: Math.round(12 * root.sizeK); font.weight: Font.Medium }
                }
            }
        }
    }
}
