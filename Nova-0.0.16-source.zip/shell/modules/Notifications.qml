// Notification pop-ups, placed from Settings → Popups & indicators.
// "up" stacks newest nearest the edge going upward; "down" the other way.
import QtQuick
import Quickshell
import qs.services
import qs.components

Placed {
    id: win
    kind: "notifications"
    visible: onThisScreen && Notifs.popups.length > 0 && Shell.popout !== "notifications" && !Shell.npOpen
    implicitWidth: 400
    implicitHeight: Math.max(1, stack.implicitHeight)
    readonly property bool newestAtBottom: row === 2 ? cfg.dir !== "down" : cfg.dir === "up"

    Column {
        id: stack
        width: parent.width
        spacing: 10
        Repeater {
            model: win.newestAtBottom ? Notifs.popups.slice().reverse() : Notifs.popups
            NotificationCard {
                required property var modelData
                notif: modelData
                popup: true
                width: 400
                onClosed: Notifs.dismissPopup(modelData)
                Timer {
                    running: parent.notif.urgency !== 2 && !hov.hovered
                    interval: parent.notif.expireTimeout > 0 ? parent.notif.expireTimeout : Config.s.notificationTimeout
                    onTriggered: Notifs.dismissPopup(parent.notif)
                }
                HoverHandler { id: hov }
            }
        }
    }
}
