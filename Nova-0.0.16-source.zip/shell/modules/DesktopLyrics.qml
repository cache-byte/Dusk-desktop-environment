// Lyrics on the desktop (off by default). Sits under windows; placed from
// Settings > Popups & indicators like every other popup.
import QtQuick
import Quickshell
import Quickshell.Wayland
import qs.services
import qs.components

Placed {
    id: w
    kind: "lyrics"
    layerKind: WlrLayer.Bottom
    readonly property bool primary: screen === (Quickshell.screens.find(s => s.name === Nova.activeOutput) ?? Quickshell.screens[0])
    visible: Config.s.lyricsDesktop && Media.playing && Lyrics.synced && primary
             && !(Config.s.lyricsHideFullscreen && Nova.fullscreen)
    implicitWidth: Math.min(screen ? screen.width * 0.6 : 1100, 1100)
    implicitHeight: 230
    mask: Region {}                       // clicks go through to the desktop
    LyricsView {
        anchors.fill: parent
        center: w.cfg.dir !== "left"
        textColor: "white"
    }
}
