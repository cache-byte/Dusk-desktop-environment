// Full-screen transparent overlay (above everything but the panel) hosting the
// launcher, control centre, notification centre and clipboard. Clicking
// outside a card or pressing Esc closes it.
import QtQuick
import Quickshell
import Quickshell.Wayland
import qs.services

PanelWindow {
    id: win
    readonly property string which: Shell.isPopoutScreen(screen) ? Shell.popout : ""
    visible: which !== ""
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "nova-popout"
    WlrLayershell.keyboardFocus: which === "launcher" || which === "clipboard" || which === "capture" || which === "gameoverlay" ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.OnDemand
    exclusionMode: ExclusionMode.Ignore
    anchors { top: true; bottom: true; left: true; right: true }
    margins.bottom: Theme.panelHeight     // keep the panel clickable
    color: "transparent"

    MouseArea { anchors.fill: parent; onClicked: Shell.close() }

    Item {
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: Shell.close()

        Launcher {
            visible: win.which === "launcher"
            anchors { left: parent.left; bottom: parent.bottom; margins: Theme.gap }
        }
        ControlCentre {
            visible: win.which === "controlcentre"
            anchors { right: parent.right; bottom: parent.bottom; margins: Theme.gap }
        }
        NotificationCentre {
            visible: win.which === "notifications"
            anchors { right: parent.right; bottom: parent.bottom; margins: Theme.gap }
        }
        GameOverlay {
            visible: win.which === "gameoverlay"
            anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 40 }
        }
        Capture {
            visible: win.which === "capture"
            anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; margins: Theme.gap * 2 }
        }
        Clipboard {
            visible: win.which === "clipboard"
            anchors { right: parent.right; bottom: parent.bottom; margins: Theme.gap; rightMargin: 330 }
        }
    }
}
