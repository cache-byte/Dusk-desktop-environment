// Print: the capture bar. Screenshot or record; region, window or whole screen;
// sound and microphone for recordings; draw on a screenshot before saving.
import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.services
import qs.components

Glass {
    id: root
    width: row.implicitWidth + 2 * padding
    height: 76
    radius: 22
    padding: 14
    MouseArea { anchors.fill: parent; z: -1 }

    property string mode: "shot"            // shot | record
    property string area: "region"          // region | window | screen
    property bool edit: Config.s.captureEdit ?? false
    readonly property bool recording: Shell.recording

    function go() {
        Shell.close();
        const args = root.mode === "shot"
            ? ["nova-record", "shot", root.area].concat(root.edit ? ["--edit"] : [])
            : ["nova-record", "start", root.area]
                .concat(Config.s.recordSystemAudio ? ["--audio"] : ["--no-audio"])
                .concat(Config.s.recordMic ? ["--mic"] : ["--no-mic"]);
        // give the bar a moment to disappear so it isn't in the picture
        Quickshell.execDetached(["sh", "-c", "sleep 0.25; exec \"$@\"", "sh"].concat(args));
    }
    Keys.onReturnPressed: go()
    Keys.onEscapePressed: Shell.close()
    onVisibleChanged: if (visible) forceActiveFocus()

    component Seg: Rectangle {
        property var items: []          // [[value, icon, label], ...]
        property string value
        signal picked(string v)
        implicitHeight: 46; implicitWidth: segRow.implicitWidth + 8; radius: 14; color: Theme.surface2
        Row {
            id: segRow; anchors.centerIn: parent; spacing: 2
            Repeater {
                model: parent.parent.items
                Rectangle {
                    required property var modelData
                    readonly property bool on: parent.parent.value === modelData[0]
                    height: 38; width: sr.implicitWidth + 24; radius: 11
                    color: on ? Theme.accent : "transparent"
                    RowLayout { id: sr; anchors.centerIn: parent; spacing: 7
                        Icon { name: parent.parent.modelData[1]; size: 16; color: parent.parent.on ? Theme.onAccent : Theme.text2 }
                        Text { text: parent.parent.modelData[2]; font.pixelSize: 13; font.family: Theme.font
                               color: parent.parent.on ? Theme.onAccent : Theme.text2; font.weight: parent.parent.on ? Font.DemiBold : Font.Normal } }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: parent.parent.parent.parent.picked(parent.modelData[0]) }
                }
            }
        }
    }
    component Chip: Rectangle {
        property string icon
        property string label
        property bool on
        signal flipped()
        implicitHeight: 46; implicitWidth: cr.implicitWidth + 26; radius: 14
        color: on ? Theme.accentSoft : Theme.surface2; border.color: on ? Theme.accentLine : "transparent"
        RowLayout { id: cr; anchors.centerIn: parent; spacing: 7
            Icon { name: parent.parent.icon; size: 16; color: parent.parent.on ? Theme.accentBright : Theme.text3 }
            Text { text: parent.parent.label; font.pixelSize: 13; font.family: Theme.font; color: parent.parent.on ? Theme.text : Theme.text3 } }
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: parent.flipped() }
    }

    RowLayout {
        id: row
        anchors.centerIn: parent
        spacing: 10
        Seg { items: [["shot", "shot", "Screenshot"], ["record", "record", "Record"]]; value: root.mode; onPicked: v => root.mode = v }
        Rectangle { implicitWidth: 1; implicitHeight: 30; color: Theme.border }
        Seg { items: [["region", "frame", "Region"], ["window", "square", "Window"], ["screen", "monitor", "Screen"]]; value: root.area; onPicked: v => root.area = v }
        Rectangle { implicitWidth: 1; implicitHeight: 30; color: Theme.border }
        Chip { visible: root.mode === "shot"; icon: "pencil"; label: "Draw before saving"; on: root.edit
               onFlipped: { root.edit = !root.edit; Config.s.captureEdit = root.edit } }
        Chip { visible: root.mode === "record"; icon: "volume"; label: "Sound"; on: Config.s.recordSystemAudio
               onFlipped: Config.s.recordSystemAudio = !Config.s.recordSystemAudio }
        Chip { visible: root.mode === "record"; icon: "mic"; label: "Microphone"; on: Config.s.recordMic
               onFlipped: Config.s.recordMic = !Config.s.recordMic }
        Rectangle {
            implicitWidth: 120; implicitHeight: 46; radius: 14; color: Theme.accent
            RowLayout { anchors.centerIn: parent; spacing: 8
                Icon { name: root.mode === "shot" ? "shot" : "record"; size: 16; color: Theme.onAccent }
                Text { text: root.mode === "shot" ? "Capture" : "Start"; color: Theme.onAccent; font.pixelSize: 14; font.weight: Font.DemiBold; font.family: Theme.font } }
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.go() }
        }
        IconButton { icon: "x"; implicitWidth: 46; implicitHeight: 46; onClicked: Shell.close() }
    }
}
