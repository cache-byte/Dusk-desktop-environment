#!/usr/bin/env bash
# Same as `nova-update`, usable before Nova is installed.
exec bash "$(dirname "$(readlink -f "$0")")/session/nova-update" "$@"
