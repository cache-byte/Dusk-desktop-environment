# What's new in Nova

Each version lists what changed. The updater shows the entries newer than what you have.

## 0.0.16
- Fixed: the shell still didn't start (a property used a reserved word)
- The installer always sets up the Nova login screen (no more question)

## 0.0.15
- Fixed: the shell didn't start (black screen) — the battery indicator used a Qt feature that doesn't exist
- Fixed: the lock screen's wrong-password shake
- Idle dimming, locking and sleep work with older Quickshell versions too
- Password prompts for admin apps and the updater now work (Nova starts a polkit agent)
- Every QML file is now checked against the real Qt and Quickshell sources before release

## 0.0.14
- Fixed: the login screen theme and parts of the shell didn't load (text sizes must be whole numbers)

## 0.0.13
- Fixed: a black screen when an older, different "Nova" left its settings behind; the installer moves them aside
- The compositor always starts the shell, even if your config doesn't list it

## 0.0.12
- Fixed: the compositor didn't build with wlroots 0.19 (Fedora 43-45); it now builds against 0.19 and 0.20
- Fixed: one conflicting package (like RPM Fusion's ffmpeg) no longer stops all the optional extras installing
- The installer no longer shows errors for packages it simply looks for elsewhere (SongRec, Quickshell, the recorder)

## 0.0.11
- Nova now ships two wallpapers: a teal dark one and a lilac light one, picked by the theme
- The older wave and gaming wallpapers are gone; if you used one, Nova switches back to the default

## 0.0.10
- Settings → Updates shows what's new before you update, and after
- The terminal updater shows what's new too
- Three gaming wallpapers: Neon Waves, Arcade Waves and Game Dawn Waves

## 0.0.9
- New look for the installer, updater and uninstaller in the terminal: steps, spinners, a summary box
- Update from inside Settings with a progress bar and one password prompt
- Logs of every install, shown when something fails

## 0.0.8
- The lock and login screens no longer show lock-key chips in the password box
- Control centre is a 6 × 10 grid; empty rows are hidden

## 0.0.7
- The Settings sidebar scrolls instead of running off small windows

## 0.0.6
- Only the three wave wallpapers are bundled

## 0.0.5
- New default wallpapers: Dusk Waves (dark) and Dawn Blue Waves (light), plus Dawn Waves

## 0.0.4
- Fixes for reinstalling, updating and uninstalling
- Display settings are remembered between logins; HiDPI screens get a sensible scale
- Qt apps get title bars; touchpad settings apply right away; Settings no longer freezes while checking

## 0.0.3
- The light-mode wallpaper and a set of Nova wallpapers that follow light and dark mode

## 0.0.2
- Capture bar (Print), trim recordings, game overlay (Super+G), shortcut editor, blurred glass panels

## 0.0.1
- First version: compositor, shell, Settings, installer, updater and uninstaller
