#!/usr/bin/env bash
# Build the zip you upload to GitHub: Nova-<VERSION>-source.zip (zip root = project root).
set -euo pipefail
cd "$(dirname "$0")/.."
v=$(cat VERSION)
out="${1:-..}/Nova-$v-source.zip"
rm -f "$out"
zip -qr "$out" . -x 'build/*' '.git/*' '*.o' '*__pycache__*'
echo "$out"
