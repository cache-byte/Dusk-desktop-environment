# Nova — design decisions (Q&A, 11 Nov 2026)

## Platform & install
- Target Fedora 43 and newer. Use Fedora's wlroots package.
- Repo: https://github.com/cache-byte/Nova-desktop-environment — zip root = repo root.
- `install.sh` (also a one-line `curl … | bash` that clones and installs), `update.sh`, `nova-update` CLI, and an Updates section in Settings.
- Updates cover Nova only, from GitHub tagged releases (option to follow `main`). System/Flatpak updates stay with dnf / GNOME Software.
- `nova-uninstall` (and a Settings button) removes everything Nova added and restores what it changed (display manager, theme configs, PAM edits). The installer records every change in `/var/lib/nova/install-manifest` for this.
- Installed alongside GNOME/KDE as a fallback session.
- Login: switch to SDDM with the Nova theme; uninstall switches back to the previous display manager.
- GNOME Keyring unlocked by PAM at login (SDDM + Nova lock screen), so browsers, VS Code and Steam don't ask for a password.
- English UI, all strings translatable (qsTr).
- App store: GNOME Software, linked from the launcher.

## Hardware
- Main test machine: hybrid NVIDIA + Intel/AMD laptop, external port probably wired to NVIDIA.
- Desktop renders on the integrated GPU. Games are offloaded to NVIDIA (prime-run / `__NV_PRIME_RENDER_OFFLOAD`) automatically from the launcher and game mode.
- Multi-GPU output support so monitors on the NVIDIA port work (wlroots multi-GPU, `WLR_DRM_DEVICES` ordering set by nova-session).
- Must work on RPM Fusion akmod-nvidia, NVIDIA open modules and Nouveau/NVK. Tested on akmod-nvidia first (assumed).
- Lid closed with an external monitor: keep running on the external screen (assumed).

## Windows & workspaces
- Floating with snap by default; tiling optional per workspace.
- Title bars: apps draw their own for now (GTK/libadwaita, Firefox, Chrome, Electron); Qt apps use the Adwaita decoration plugin. Compositor-drawn title bars come with SceneFX. Buttons on the right.
- Dynamic workspaces, separate per monitor. Super+N acts on the monitor under the mouse. Overview shows one row per monitor.
- Blur faked from the wallpaper for v1 (SceneFX later).
- Smooth animations on. Click to focus.
- Fullscreen games: tearing allowed, VRR when available.

## Shell
- Panel at the bottom by default, position changeable. Panel per monitor is a setting.
- Desktop icons shown, toggle in Settings.
- Launcher (Super tap) searches apps, home-folder files (live with fd/plocate, no indexer), calculator/units, and offers a web search.
- Notifications grouped by app/type, grouping can be turned off.
- Auto Do Not Disturb when something is fullscreen, with a missed count afterwards.
- Clipboard history kept across reboots. Items marked secret by password managers are never stored.
- The password field has no lock-key chips; "Caps Lock is on" shows under it (lock and login screens).
- Control centre: 6 columns × up to 10 rows; rows with nothing in them are hidden.
- Lock screen shows media controls, notification count, battery and network (no notification content).

## Look
- Dark by default. Olive accent, option to take accent from the wallpaper. Inter font.
- GTK3 (adw-gtk3), GTK4/Flatpak (color-scheme portal) and Qt (qt6ct) set up automatically to follow light/dark.
- Two Nova wallpapers, one per theme: nova-dark.jpg (teal synthwave waves) and nova-light.jpg (lilac synthwave waves). They also serve game mode. Plus ~/Pictures/Wallpapers.
- Monitor scale 100–200 % only.
- Layouts must never squeeze or wrap labels.

## Settings
- Every changeable setting has its own reset button.
- About page, under the credits: "Reset settings" with checkboxes for what to reset or keep (appearance, shortcuts, panel, popups, audio, gaming, …). A backup of settings.json is kept first.

## Power & idle
- Battery: dim 5 min, lock 6 min, sleep 15 min. Plugged in: dim 5, lock 6, never sleep. All adjustable and can be turned off.
- Nothing dims, locks or sleeps while a fullscreen app/game or a video is playing (idle-inhibit), on battery or plugged in.
- Power profiles via tuned-ppd.
- Touchpad: 3-finger swipe = switch workspace, 3-finger up = overview.

## Media
- Volume up to 150 % (setting).
- Now Playing follows the player that played last, switchable.
- Lyrics: local .lrc → LRCLIB (automatic) → SongRec identify (automatic when search fails) → LRCLIB again. Lyrics cached on disk for offline use.
- Visualizer (cava) keeps running on battery at a lower frame rate.

## Gaming & capture
- Feral GameMode plus Nova extras (DND, power profile, direct scan-out).
- MangoHud for the in-game FPS overlay, toggled from Nova.
- gpu-screen-recorder for recording and instant replay. Replay is off until turned on.
- Recordings: MP4 H.264. Screenshots: clipboard + ~/Pictures/Screenshots.

## Build order
Everything. Start with booting reliably on the hybrid laptop (multi-GPU, keyring, SDDM, install/update/uninstall), then the rest.
