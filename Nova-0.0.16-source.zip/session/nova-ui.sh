# Shared look for Nova's installer, updater and uninstaller (sourced, not run).
#
# In a terminal: a banner, numbered steps, a spinner per task with the command's
# output kept in a log file, and a summary box at the end.
# With NOVA_PROGRESS=1 (used by Settings > Updates) it prints simple machine-readable
# lines instead:  ::step 3 8 Title  ::task Label  ::ok Label  ::warn Text  ::fail Label  ::done Text
#
#   ui_banner "installer" "0.0.8"
#   ui_steps 8
#   ui_step "Installing packages"
#   ui_task "Downloading Quickshell" dnf install -y quickshell
#   ui_ok "Already installed" ; ui_warn "..." ; ui_info "..."
#   ui_box "Nova 0.0.8 is installed" "line" "line"

NOVA_LOG="${NOVA_LOG:-${XDG_RUNTIME_DIR:-/tmp}/nova-install.log}"
: > "$NOVA_LOG" 2>/dev/null || NOVA_LOG=/tmp/nova-install-$$.log
UI_STEP=0; UI_TOTAL=0
if [ -n "${NOVA_PROGRESS:-}" ]; then UI_MODE=progress
elif [ -t 1 ]; then UI_MODE=tty
else UI_MODE=plain; fi

if [ "$UI_MODE" = tty ] && [ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]; then
    C_ACC=$'\e[38;2;200;182;74m'; C_ACC2=$'\e[38;2;233;214;122m'; C_DIM=$'\e[38;2;140;136;150m'
    C_OK=$'\e[38;2;127;209;139m'; C_WARN=$'\e[38;2;242;184;75m'; C_ERR=$'\e[38;2;232;96;76m'
    C_B=$'\e[1m'; C_R=$'\e[0m'; C_HIDE=$'\e[?25l'; C_SHOW=$'\e[?25h'; C_CLR=$'\r\e[2K'
else
    C_ACC=; C_ACC2=; C_DIM=; C_OK=; C_WARN=; C_ERR=; C_B=; C_R=; C_HIDE=; C_SHOW=; C_CLR=$'\n'
fi
trap 'printf "%s" "$C_SHOW"' EXIT

ui_banner() { # ui_banner <what> <version>
    [ "$UI_MODE" = progress ] && { echo "::start $1 $2"; return; }
    printf '\n'
    printf '   %s✦%s  %sN O V A%s\n' "$C_ACC" "$C_R" "$C_B" "$C_R"
    printf '   %s%s · %s%s\n' "$C_DIM" "$1" "$2" "$C_R"
    printf '   %s────────────────────────────────────────────%s\n' "$C_DIM" "$C_R"
}
ui_steps() { UI_TOTAL=$1; }
ui_step() {
    UI_STEP=$((UI_STEP + 1))
    echo "== $UI_STEP/$UI_TOTAL $* ==" >> "$NOVA_LOG"
    case "$UI_MODE" in
        progress) echo "::step $UI_STEP $UI_TOTAL $*" ;;
        *) printf '\n %s%s%d/%d%s  %s%s%s\n' "$C_ACC" "$C_B" "$UI_STEP" "$UI_TOTAL" "$C_R" "$C_B" "$*" "$C_R" ;;
    esac
}
ui_ok()   { case "$UI_MODE" in progress) echo "::ok $*" ;; *) printf '   %s✓%s %s\n' "$C_OK" "$C_R" "$*" ;; esac; }
ui_info() { case "$UI_MODE" in progress) echo "::info $*" ;; *) printf '   %s·%s %s%s%s\n' "$C_DIM" "$C_R" "$C_DIM" "$*" "$C_R" ;; esac; }
ui_warn() { case "$UI_MODE" in progress) echo "::warn $*" ;; *) printf '   %s!%s %s\n' "$C_WARN" "$C_R" "$*" ;; esac; echo "WARN: $*" >> "$NOVA_LOG"; }
ui_err()  { case "$UI_MODE" in progress) echo "::fail $*" ;; *) printf '   %s✗%s %s\n' "$C_ERR" "$C_R" "$*" ;; esac; echo "ERROR: $*" >> "$NOVA_LOG"; }

# ui_task <label> <command...>   run quietly; spinner in a terminal; returns the command's status
ui_task() {
    local label="$1"; shift
    echo "-- $label: $*" >> "$NOVA_LOG"
    if [ "$UI_MODE" = progress ]; then
        echo "::task $label"
        local rc=0; "$@" >> "$NOVA_LOG" 2>&1 || rc=$?
        if [ $rc -eq 0 ]; then echo "::ok $label"; return 0; fi
        echo "::fail $label"; tail -n 15 "$NOVA_LOG" | sed 's/^/::log /'; return $rc
    fi
    if [ "$UI_MODE" = plain ]; then
        printf '   … %s\n' "$label"
        local rc=0; "$@" >> "$NOVA_LOG" 2>&1 || rc=$?
        if [ $rc -eq 0 ]; then printf '   ✓ %s\n' "$label"; return 0; fi
        printf '   ✗ %s\n' "$label"; tail -n 15 "$NOVA_LOG" | sed 's/^/     /'; return $rc
    fi
    "$@" >> "$NOVA_LOG" 2>&1 &
    local pid=$! i=0 start=$SECONDS
    local frames=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏)
    printf '%s' "$C_HIDE"
    while kill -0 "$pid" 2>/dev/null; do
        local el=$((SECONDS - start)) t=""
        [ $el -ge 5 ] && t=" ${C_DIM}$((el / 60)):$(printf '%02d' $((el % 60)))${C_R}"
        printf '%s   %s%s%s %s%s' "$C_CLR" "$C_ACC" "${frames[i++ % 10]}" "$C_R" "$label" "$t"
        sleep 0.1
    done
    local rc=0; wait "$pid" || rc=$?
    printf '%s' "$C_SHOW"
    if [ $rc -eq 0 ]; then
        printf '%s   %s✓%s %s\n' "$C_CLR" "$C_OK" "$C_R" "$label"
    else
        printf '%s   %s✗%s %s\n' "$C_CLR" "$C_ERR" "$C_R" "$label"
        printf '\n   %sLast lines of the log (%s):%s\n' "$C_DIM" "$NOVA_LOG" "$C_R"
        tail -n 15 "$NOVA_LOG" | sed "s/^/     ${C_DIM}│${C_R} /"
        printf '\n'
    fi
    return $rc
}

# ui_box <title> [lines...]   rounded box for the final message
ui_box() {
    local title="$1"; shift
    if [ "$UI_MODE" = progress ]; then echo "::done $title"; for l in "$@"; do echo "::info $l"; done; return; fi
    local w=${#title} l
    for l in "$@"; do [ ${#l} -gt "$w" ] && w=${#l}; done
    w=$((w + 4))
    local bar; bar=$(printf '─%.0s' $(seq 1 "$w"))
    printf '\n   %s╭%s╮%s\n' "$C_ACC" "$bar" "$C_R"
    printf '   %s│%s  %s%s%s%s%*s%s│%s\n' "$C_ACC" "$C_R" "$C_B" "$C_ACC2" "$title" "$C_R" $((w - 2 - ${#title})) "" "$C_ACC" "$C_R"
    printf '   %s│%s%*s%s│%s\n' "$C_ACC" "$C_R" "$w" "" "$C_ACC" "$C_R"
    # pad by characters, not bytes, so lines with → or • keep the border straight
    for l in "$@"; do printf '   %s│%s  %s%*s%s│%s\n' "$C_ACC" "$C_R" "$l" $((w - 2 - ${#l})) "" "$C_ACC" "$C_R"; done
    printf '   %s╰%s╯%s\n\n' "$C_ACC" "$bar" "$C_R"
}

# keep sudo's password cached during long builds (the spinner hides prompts)
ui_sudo_keepalive() {
    [ "$(id -u)" -eq 0 ] && return 0
    sudo -v || return 1
    ( while kill -0 "$$" 2>/dev/null; do sudo -n true 2>/dev/null; sleep 45; done ) &
}
