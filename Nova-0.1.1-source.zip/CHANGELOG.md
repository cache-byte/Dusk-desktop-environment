# What's new in Nova

Each version lists what changed. The updater shows the entries newer than what you have.

## 0.1.1
- Fixed: clicking outside a pop-up, picking something in the launcher or opening an app crashed the shell (the desktop flashed and came back)
- Much less lag: each widget is measured once per layout instead of many times, and text sizes are remembered
- The panel no longer rebuilds when a window's title changes (browsers and players change it constantly)
- Music bars and the visualizer redraw less often
- Settings → Popups & indicators: the preview is gone

## 0.1.0
- The shell and Settings are rewritten in C++ and no longer use Quickshell or Qt: much less memory and CPU
- The compositor and the shell are separate programs; if the shell crashes, Nova restarts it
- `nova-shell` commands for scripts: `nova-shell toggle launcher`, `nova-shell toast "Copied" clip`, `nova-shell lock`
- Pop-ups size themselves to their card and close when you click anywhere else
- Control centre edit mode: drag tiles, resize from the corner, remove, add from the drawer
- Video wallpapers play with mpvpaper; the recording trimmer previews in mpv
- Settings: every page rebuilt with the same look; picking a file or colour uses the system dialog (zenity)
- nova-doctor shows how much memory the shell uses

## 0.0.20
- Workspaces slide when you switch; swiping never goes to a workspace that doesn't exist
- Maximized windows fill the screen edge to edge; new windows always open above the panel
- Less flicker in Chromium / Electron apps (Vivaldi, VS Code) on NVIDIA: explicit sync
- Shorter panel, now with blur behind it
- Blur and transparency default to 80 % everywhere, including Settings
- Now playing opens after resting on the clock for 1.5 s, sits right above it, and stays while you move onto it
- Launcher, calendar and control centre share one 6 × 10 grid; app search ranks names first
- Capture bar: 3 / 5 / 10 s delay so menus and pop-ups can be captured, countdown on the panel
- Drawing on screenshots: Satty from Flathub when Fedora doesn't have it; the calculator (qalc) is installed

## 0.0.19
- Fixed: opening any app window crashed Nova (an xdg-shell version check inside wlroots)
- Fixed: a binding loop in the pop-up layer and a layout warning in the launcher
- nova-doctor recognises the running shell more reliably

## 0.0.18
- Password prompts: Nova finds whichever polkit agent is installed
- Power profiles work with Fedora's tuned-ppd (no powerprofilesctl needed)
- nova-doctor shows the shell's last errors when the shell isn't running

## 0.0.17
- Fixed: clicking the panel or using a shortcut crashed Nova and logged you out (shell menus and pop-ups)
- Nova now uses the login screen you already have; the SDDM theme is gone and an earlier switch to SDDM is undone
- Screens start at 100 % scale unless they are very high resolution (1080p laptops were at 150 %)
- Closed windows no longer leave an empty scene node behind

## 0.0.16
- Fixed: the shell still didn't start (a property used a reserved word)
- The installer always sets up the Nova login screen (no more question)

## 0.0.15
- Fixed: the shell didn't start (black screen) — the battery indicator used a Qt feature that doesn't exist
- Fixed: the lock screen's wrong-password shake
- Idle dimming, locking and sleep work with older Quickshell versions too
- Password prompts for admin apps and the updater now work (Nova starts a polkit agent)
- Every QML file is now checked against the real Qt and Quickshell sources before release

## 0.0.14
- Fixed: the login screen theme and parts of the shell didn't load (text sizes must be whole numbers)

## 0.0.13
- Fixed: a black screen when an older, different "Nova" left its settings behind; the installer moves them aside
- The compositor always starts the shell, even if your config doesn't list it

## 0.0.12
- Fixed: the compositor didn't build with wlroots 0.19 (Fedora 43-45); it now builds against 0.19 and 0.20
- Fixed: one conflicting package (like RPM Fusion's ffmpeg) no longer stops all the optional extras installing
- The installer no longer shows errors for packages it simply looks for elsewhere (SongRec, Quickshell, the recorder)

## 0.0.11
- Nova now ships two wallpapers: a teal dark one and a lilac light one, picked by the theme
- The older wave and gaming wallpapers are gone; if you used one, Nova switches back to the default

## 0.0.10
- Settings → Updates shows what's new before you update, and after
- The terminal updater shows what's new too
- Three gaming wallpapers: Neon Waves, Arcade Waves and Game Dawn Waves

## 0.0.9
- New look for the installer, updater and uninstaller in the terminal: steps, spinners, a summary box
- Update from inside Settings with a progress bar and one password prompt
- Logs of every install, shown when something fails

## 0.0.8
- The lock and login screens no longer show lock-key chips in the password box
- Control centre is a 6 × 10 grid; empty rows are hidden

## 0.0.7
- The Settings sidebar scrolls instead of running off small windows

## 0.0.6
- Only the three wave wallpapers are bundled

## 0.0.5
- New default wallpapers: Dusk Waves (dark) and Dawn Blue Waves (light), plus Dawn Waves

## 0.0.4
- Fixes for reinstalling, updating and uninstalling
- Display settings are remembered between logins; HiDPI screens get a sensible scale
- Qt apps get title bars; touchpad settings apply right away; Settings no longer freezes while checking

## 0.0.3
- The light-mode wallpaper and a set of Nova wallpapers that follow light and dark mode

## 0.0.2
- Capture bar (Print), trim recordings, game overlay (Super+G), shortcut editor, blurred glass panels

## 0.0.1
- First version: compositor, shell, Settings, installer, updater and uninstaller
