#pragma once
#include "listener.hpp"
#include "wlr.hpp"

#include <array>
#include <list>
#include <memory>
#include <string>
#include <vector>

struct Server;
struct Output;

// Workspaces are per monitor: each output owns a slot of kWsPerOutput ids.
// Workspace id = slot * kWsPerOutput + index. Only occupied ones (plus the shown one)
// appear in the panel, so they come and go as needed.
constexpr int kWsPerOutput = 9;
constexpr int kMaxOutputs = 4;
constexpr int kWorkspaces = kWsPerOutput * kMaxOutputs;
int64_t now_ms();

// What a scene node belongs to. Stored in wlr_scene_node::data so hit-tests
// can find the owning object by walking up the scene tree.
enum class NodeKind { View, Layer, LockSurface };
struct NodeTag {
    NodeKind kind;
    void *ptr;
};

// --------------------------------------------------------------------------
struct View {
    enum class Kind { Xdg, XWayland };

    Server *server;
    Kind kind;
    wlr_xdg_toplevel *xdg = nullptr;
#ifdef NOVA_XWAYLAND
    wlr_xwayland_surface *xw = nullptr;
#endif
    wlr_scene_tree *tree = nullptr;   // container, positioned at window-geometry origin minus offset
    wlr_scene_tree *content = nullptr;
    wlr_foreign_toplevel_handle_v1 *ftl = nullptr;
    wlr_output *ftl_out = nullptr;
    NodeTag tag{NodeKind::View, this};

    int workspace = 0;
    bool mapped = false, minimized = false, maximized = false, fullscreen = false;
    enum class Tile { None, Left, Right } tile = Tile::None;
    int x = 0, y = 0;        // window geometry origin in layout coords
    wlr_box restore{};       // geometry before maximize / fullscreen / tile

    Listener map, unmap, commit, destroy;
    Listener req_move, req_resize, req_maximize, req_fullscreen, req_minimize;
    Listener set_title, set_app_id;
    Listener ftl_activate, ftl_close, ftl_minimize, ftl_maximize, ftl_fullscreen;
#ifdef NOVA_XWAYLAND
    Listener xw_associate, xw_dissociate, xw_configure, xw_activate, xw_set_geometry;
#endif

    View(Server *s, Kind k) : server(s), kind(k) {}

    wlr_surface *surface() const;
    wlr_box geometry() const;          // window geometry (size + CSD offset)
    std::string title() const;
    std::string app_id() const;
    bool override_redirect() const;

    void set_activated(bool on);
    void configure(int nx, int ny, int w, int h);
    void move_to(int nx, int ny);
    void close();
    void set_maximized(bool on);
    void set_fullscreen(bool on);
    void set_minimized(bool on);
    void set_tile(Tile t);
    void update_ftl_output();
    void place_initially();
    void on_map();
    void on_unmap();
};

struct Popup {
    wlr_xdg_popup *popup;
    Listener commit, destroy, reposition;
};

struct LayerSurface {
    Server *server;
    wlr_layer_surface_v1 *layer;
    wlr_scene_layer_surface_v1 *scene;
    wlr_scene_tree *popups;   // layer popups live above all layers
    Output *output = nullptr;
    bool configured = false;
    NodeTag tag{NodeKind::Layer, this};
    Listener map, unmap, commit, destroy, new_popup, output_destroy;
};

struct Output {
    Server *server;
    wlr_output *output;
    wlr_scene_output *scene_output;
    wlr_box full{}, usable{};
    wlr_scene_rect *lock_backdrop = nullptr;
    bool gamma_dirty = false;
    bool vrr_on = false;       // adaptive sync is switched on only while a game/video is fullscreen
    int slot = 0;              // which block of workspace ids this output owns
    int active = 0;            // workspace id shown on this output
    Listener frame, request_state, destroy;
};

struct Keyboard {
    Server *server;
    wlr_keyboard *kb;
    Listener modifiers, key, destroy;
};

struct LockSurface {
    wlr_session_lock_surface_v1 *surf;
    wlr_scene_tree *tree;
    NodeTag tag{NodeKind::LockSurface, this};
    Listener map, destroy;
};

struct Binding {
    uint32_t mods;
    xkb_keysym_t sym;
    std::string action;   // e.g. "exec foot", "workspace 3", "close"
    bool when_locked;     // media / brightness keys keep working on the lock screen
};

// Saved by Settings > Display in nova.conf as  [output eDP-1]  mode / scale / position / transform
struct OutputCfg {
    int width = 0, height = 0;   // 0 = preferred mode
    double refresh = 0;          // Hz
    double scale = 0;            // 0 = pick from the screen's DPI
    bool has_pos = false;
    int x = 0, y = 0;
    std::string transform;       // normal | 90 | 180 | 270 | flipped | flipped-90 ...
};

struct Config {
    std::string terminal = "ptyxis";
    std::vector<std::string> autostart;
    std::vector<Binding> binds;
    std::vector<std::pair<std::string, OutputCfg>> output_cfgs;
    const OutputCfg *output_cfg(const std::string &name) const {
        for (auto &p : output_cfgs) if (p.first == name) return &p.second;
        return nullptr;
    }
    std::string super_tap_action;   // "Super = ..." : runs when Super is pressed and released alone
    int super_tap_ms = 400;
    std::string kb_layout, kb_variant, kb_options, kb_model;
    int repeat_rate = 30, repeat_delay = 300;
    bool natural_scroll = false, tap_to_click = true;
    double pointer_accel = 0.0;
    bool gesture_workspaces = true, gesture_overview = true;   // 3-finger swipes
    bool vrr = true;                 // adaptive sync while something is fullscreen
    std::string tearing = "auto";   // auto: games that ask + fullscreen XWayland games | never | always
    std::string cursor_theme;
    int cursor_size = 24;
    int gaps = 0;            // gap between snapped windows (0 = none)
    bool focus_follows_mouse = false;
    bool remember_locks = true;    // restore Caps / Num Lock across restarts

    static std::string path();
    void load();
};

class Ipc;
struct Server;
void setup_effects(Server *s);
void set_blur_strength(Server *s, double strength);   // 0..1, from Settings via the shell

struct Server {
    // core
    wl_display *display = nullptr;
    wl_event_loop *loop = nullptr;
    wlr_backend *backend = nullptr;
    wlr_session *session = nullptr;
    wlr_renderer *renderer = nullptr;
    wlr_allocator *allocator = nullptr;
    wlr_compositor *compositor = nullptr;
    wlr_scene *scene = nullptr;
    wlr_scene_output_layout *scene_layout = nullptr;
    wlr_output_layout *output_layout = nullptr;

    // scene ordering (bottom -> top)
    wlr_scene_tree *layer_trees[4]{};      // background, bottom, top, overlay
    wlr_scene_tree *views_root = nullptr;
    std::array<wlr_scene_tree *, kWorkspaces> ws_trees{};
    wlr_scene_tree *popup_tree = nullptr;  // layer-surface popups
    wlr_scene_tree *drag_tree = nullptr;
    wlr_scene_tree *lock_tree = nullptr;
    wlr_scene_rect *snap_preview = nullptr;

    // protocols
    wlr_xdg_shell *xdg_shell = nullptr;
    wlr_layer_shell_v1 *layer_shell = nullptr;
    wlr_foreign_toplevel_manager_v1 *ftl_manager = nullptr;
    wlr_session_lock_manager_v1 *lock_manager = nullptr;
    wlr_idle_notifier_v1 *idle_notifier = nullptr;
    wlr_idle_inhibit_manager_v1 *idle_inhibit = nullptr;
    int inhibitors_active = 0;
    wlr_tearing_control_manager_v1 *tearing = nullptr;
    bool fullscreen_active = false, fullscreen_reported = false;
    wlr_relative_pointer_manager_v1 *relative_pointer = nullptr;
    wlr_pointer_constraints_v1 *pointer_constraints = nullptr;
    wlr_pointer_constraint_v1 *active_constraint = nullptr;
    wlr_output_manager_v1 *output_manager = nullptr;
    wlr_gamma_control_manager_v1 *gamma = nullptr;
    wlr_xdg_activation_v1 *activation = nullptr;
    wlr_cursor_shape_manager_v1 *cursor_shape = nullptr;
    wlr_xdg_decoration_manager_v1 *xdg_deco = nullptr;
#ifdef NOVA_XWAYLAND
    wlr_xwayland *xwayland = nullptr;
#endif

    // input
    wlr_seat *seat = nullptr;
    wlr_cursor *cursor = nullptr;
    wlr_xcursor_manager *xcursor = nullptr;
    std::list<std::unique_ptr<Keyboard>> keyboards;
    bool caps_on = false, num_on = false;
    bool super_grab = false;
    // Super-tap: armed on a lone Super press, cancelled by any other key, button or scroll.
    bool super_tap_armed = false;
    uint32_t super_tap_time = 0;
    std::string pointer_output;   // name of the output under the cursor (sent to the shell)   // grab started with Super+drag (don't forward the release)

    enum class Grab { None, Move, Resize } grab = Grab::None;
    View *grab_view = nullptr;
    double grab_x = 0, grab_y = 0;
    wlr_box grab_box{};
    uint32_t grab_edges = 0;
    enum class Snap { None, Left, Right, Max } snap = Snap::None;

    // state
    std::list<std::unique_ptr<Output>> outputs;
    std::list<View *> views;               // stacking order, front = topmost
    std::list<LayerSurface *> layers;
    wlr_layer_surface_v1 *exclusive_layer = nullptr;
    wlr_surface *focused_layer = nullptr;

    // session lock
    wlr_session_lock_v1 *lock = nullptr;
    bool locked = false;
    Listener lock_new_surface, lock_unlock, lock_destroy;

    Config config;
    std::unique_ptr<Ipc> ipc;
    std::string socket_name;

    // top-level listeners
    Listener new_output, new_input, new_xdg_toplevel, new_xdg_popup, new_layer_surface;
    Listener cursor_motion, cursor_motion_abs, cursor_button, cursor_axis, cursor_frame;
    // touchpad gestures: 3 fingers are Nova's, everything else goes to apps
    wlr_pointer_gestures_v1 *gestures = nullptr;
    Listener swipe_begin, swipe_update, swipe_end, pinch_begin, pinch_update, pinch_end, hold_begin, hold_end;
    bool swipe_ours = false;
    double swipe_dx = 0, swipe_dy = 0;
    Listener req_cursor, req_selection, req_primary, req_start_drag, start_drag;
    Listener new_lock, layout_change, om_apply, om_test, set_gamma, new_constraint;
    Listener new_inhibitor, activation_request, cursor_shape_request, new_deco;
#ifdef NOVA_XWAYLAND
    Listener xw_ready, xw_new_surface;
#endif

    bool init();
    void run();
    void shutdown();

    // outputs / layers
    void add_output(wlr_output *o);
    Output *output_at(double lx, double ly);
    Output *focused_output();
    void arrange_layers(Output *out);
    void arrange_all();
    void update_output_manager();
    void apply_output_config(wlr_output_configuration_v1 *cfg, bool test_only);

    // views
    void focus_view(View *v);
    void focus_surface(wlr_surface *s);
    void focus_top_view();
    NodeTag *tag_at(double lx, double ly, wlr_surface **surf, double *sx, double *sy);
    View *view_at(double lx, double ly, wlr_surface **surf, double *sx, double *sy);
    LayerSurface *layer_at(double lx, double ly, wlr_surface **surf, double *sx, double *sy);
    View *focused_view();
    View *view_for_surface(wlr_surface *s);
    void begin_grab(View *v, Grab g, uint32_t edges);
    void switch_workspace(int ws);
    // workspace slide: the old one slides out, the new one in (keyboard, gestures, panel)
    struct WsAnim { int from = -1, to = -1, dir = 0, width = 0; int64_t start_ms = 0; } ws_anim;
    wl_event_source *ws_anim_timer = nullptr;
    int ws_anim_ms = 240;
    void ws_anim_finish();
    int ws_anim_tick();
    bool ws_shown(int ws) const;                 // is this workspace on screen right now?
    int current_ws();                            // workspace shown on the output under the pointer
    Output *output_for_ws(int ws) const;
    int ws_index(int ws) const { return ws % kWsPerOutput; }
    void move_to_workspace(View *v, int ws);
    void cycle_focus(bool reverse);
    void update_fullscreen_layering();
    void update_idle_inhibit();
    View *fullscreen_view_on(Output *o) const;
    void broadcast_workspaces();
    std::string workspaces_json();

    // input
    void add_keyboard(wlr_input_device *dev);
    void add_pointer(wlr_input_device *dev);
    void apply_pointer_config(wlr_input_device *dev);
    std::vector<wlr_input_device *> pointers;
    void apply_keymap(Keyboard *k);
    bool handle_binding(uint32_t mods, xkb_keysym_t sym);
    void process_motion(uint32_t time_msec, wlr_input_device *dev, double dx, double dy,
                        double udx, double udy);
    void pointer_focus(uint32_t time_msec);
    void set_cursor_theme(const std::string &theme, int size);
    void update_leds(Keyboard *k);
    void check_constraint();

    // lock
    void on_new_lock(wlr_session_lock_v1 *l);
    void refresh_lock_backdrops();

    // actions
    void run_action(const std::string &action);
    void spawn(const std::string &cmd);
};

wlr_box output_box(Server *s, Output *o);
