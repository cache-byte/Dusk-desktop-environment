// ext-background-effect-v1: a client marks parts of its surface (a wl_region) that should
// show a blur of whatever is behind them. Quickshell uses this for BackgroundEffect.blurRegion,
// so the shell's panel and pop-ups blur the real windows underneath, not just the wallpaper.
//
// With SceneFX each connected part of the region becomes a blurred rounded rectangle placed
// just below the surface in the scene. Without SceneFX the protocol isn't offered at all, so
// the shell keeps its blurred-wallpaper fallback.
#include "server.hpp"
#include "ext-background-effect-v1-protocol.h"

#include <algorithm>
#include <cmath>
#include <numeric>
#include <vector>

#ifdef NOVA_SCENEFX

namespace {

struct BlurSurface {
    Server *server = nullptr;
    wl_resource *resource = nullptr;
    wlr_surface *surface = nullptr;
    pixman_region32_t pending{}, current{};
    bool pending_set = false;
    wlr_scene_tree *blur_tree = nullptr;   // our blurred rectangles, below the surface
    Listener commit, surface_destroy, tree_destroy;
};

// The scene tree whose origin is the surface's origin (layer surfaces and xdg toplevels).
wlr_scene_tree *tree_for_surface(wlr_surface *surface) {
    if (wlr_layer_surface_v1 *l = wlr_layer_surface_v1_try_from_wlr_surface(surface)) {
        auto *ls = static_cast<LayerSurface *>(l->data);
        return ls && ls->scene ? ls->scene->tree : nullptr;
    }
    if (wlr_xdg_surface *xs = wlr_xdg_surface_try_from_wlr_surface(surface)) {
        if (xs->role == WLR_XDG_SURFACE_ROLE_TOPLEVEL) return static_cast<wlr_scene_tree *>(xs->data);
    }
    return nullptr;
}

// Split the region into its connected parts. Clients describe rounded cards as a stack of
// thin rectangles, so for each part we take its bounding box and estimate the corner radius
// from how far the top rows are inset.
struct Part { int x, y, w, h, r; };
std::vector<Part> parts_of(const pixman_region32_t *reg) {
    int n = 0;
    const pixman_box32_t *b = pixman_region32_rectangles(const_cast<pixman_region32_t *>(reg), &n);
    std::vector<int> parent(n);
    std::iota(parent.begin(), parent.end(), 0);
    auto find = [&](int i) { while (parent[i] != i) i = parent[i] = parent[parent[i]]; return i; };
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            bool xo = b[i].x1 < b[j].x2 && b[j].x1 < b[i].x2;
            bool yo = b[i].y1 < b[j].y2 && b[j].y1 < b[i].y2;
            bool vtouch = xo && (b[i].y2 == b[j].y1 || b[j].y2 == b[i].y1);
            bool htouch = yo && (b[i].x2 == b[j].x1 || b[j].x2 == b[i].x1);
            if (xo && yo) vtouch = true;
            if (vtouch || htouch) parent[find(i)] = find(j);
        }
    std::vector<Part> out;
    std::vector<int> roots;
    for (int i = 0; i < n; i++) {
        int r = find(i);
        if (std::find(roots.begin(), roots.end(), r) != roots.end()) continue;
        roots.push_back(r);
        int x1 = INT32_MAX, y1 = INT32_MAX, x2 = INT32_MIN, y2 = INT32_MIN;
        for (int k = 0; k < n; k++)
            if (find(k) == r) {
                x1 = std::min(x1, (int)b[k].x1); y1 = std::min(y1, (int)b[k].y1);
                x2 = std::max(x2, (int)b[k].x2); y2 = std::max(y2, (int)b[k].y2);
            }
        // radius: total height of the top bands that don't reach the left edge
        int radius = 0, y = y1;
        while (y < y2) {
            int minx = INT32_MAX, bandh = 0;
            for (int k = 0; k < n; k++)
                if (find(k) == r && b[k].y1 == y) { minx = std::min(minx, (int)b[k].x1); bandh = b[k].y2 - b[k].y1; }
            if (bandh == 0 || minx <= x1) break;
            radius += bandh;
            y += bandh;
        }
        int w = x2 - x1, h = y2 - y1;
        radius = std::min(radius, std::min(w, h) / 2);
        if (w > 0 && h > 0) out.push_back({x1, y1, w, h, radius});
    }
    return out;
}

void rebuild(BlurSurface *bs) {
    if (bs->blur_tree) {
        bs->tree_destroy.disconnect();
        wlr_scene_node_destroy(&bs->blur_tree->node);
        bs->blur_tree = nullptr;
    }
    if (!pixman_region32_not_empty(&bs->current)) return;
    wlr_scene_tree *parent = tree_for_surface(bs->surface);
    if (!parent) return;
    bs->blur_tree = wlr_scene_tree_create(parent);
    wlr_scene_node_lower_to_bottom(&bs->blur_tree->node);
    bs->tree_destroy.connect(&bs->blur_tree->node.events.destroy, [bs](void *) {
        bs->tree_destroy.disconnect();
        bs->blur_tree = nullptr;   // the surface's tree went away and took ours with it
    });
    // nearly transparent: SceneFX skips fully transparent rectangles entirely
    static const float tint[4] = {0.f, 0.f, 0.f, 1.f / 255.f};
    for (const Part &p : parts_of(&bs->current)) {
        wlr_scene_rect *rect = wlr_scene_rect_create(bs->blur_tree, p.w, p.h, tint);
        wlr_scene_node_set_position(&rect->node, p.x, p.y);
        wlr_scene_rect_set_backdrop_blur(rect, true);
        wlr_scene_rect_set_corner_radius(rect, p.r, CORNER_LOCATION_ALL);
    }
}

void destroy_blur(BlurSurface *bs) {
    if (bs->blur_tree) {
        bs->tree_destroy.disconnect();
        wlr_scene_node_destroy(&bs->blur_tree->node);
    }
    pixman_region32_fini(&bs->pending);
    pixman_region32_fini(&bs->current);
    if (bs->resource) wl_resource_set_user_data(bs->resource, nullptr);
    delete bs;
}

void surf_destroy(wl_client *, wl_resource *res) { wl_resource_destroy(res); }

void surf_set_blur_region(wl_client *, wl_resource *res, wl_resource *region) {
    auto *bs = static_cast<BlurSurface *>(wl_resource_get_user_data(res));
    if (!bs) {
        wl_resource_post_error(res, EXT_BACKGROUND_EFFECT_SURFACE_V1_ERROR_SURFACE_DESTROYED,
                               "the surface was destroyed");
        return;
    }
    if (region) pixman_region32_copy(&bs->pending, wlr_region_from_resource(region));
    else pixman_region32_clear(&bs->pending);
    bs->pending_set = true;
}

const struct ext_background_effect_surface_v1_interface surf_impl = {
    .destroy = surf_destroy,
    .set_blur_region = surf_set_blur_region,
};

void surf_resource_destroy(wl_resource *res) {
    auto *bs = static_cast<BlurSurface *>(wl_resource_get_user_data(res));
    if (!bs) return;
    bs->resource = nullptr;
    destroy_blur(bs);   // the effect object is gone: no more blur
}

void mgr_destroy(wl_client *, wl_resource *res) { wl_resource_destroy(res); }

void mgr_get_background_effect(wl_client *client, wl_resource *mgr, uint32_t id, wl_resource *surface_res) {
    wlr_surface *surface = wlr_surface_from_resource(surface_res);
    auto *s = static_cast<Server *>(wl_resource_get_user_data(mgr));
    wl_resource *res = wl_resource_create(client, &ext_background_effect_surface_v1_interface,
                                          wl_resource_get_version(mgr), id);
    if (!res) { wl_client_post_no_memory(client); return; }
    auto *bs = new BlurSurface;
    bs->server = s;
    bs->resource = res;
    bs->surface = surface;
    pixman_region32_init(&bs->pending);
    pixman_region32_init(&bs->current);
    wl_resource_set_implementation(res, &surf_impl, bs, surf_resource_destroy);

    // double-buffered: the new region takes effect on the surface's next commit
    bs->commit.connect(&surface->events.commit, [bs](void *) {
        if (!bs->pending_set) return;
        bs->pending_set = false;
        pixman_region32_copy(&bs->current, &bs->pending);
        rebuild(bs);
    });
    bs->surface_destroy.connect(&surface->events.destroy, [bs](void *) {
        if (bs->blur_tree) { bs->tree_destroy.disconnect(); bs->blur_tree = nullptr; }   // went with the surface
        bs->commit.disconnect();
        bs->surface_destroy.disconnect();
        bs->surface = nullptr;
        pixman_region32_clear(&bs->current);
    });
}

const struct ext_background_effect_manager_v1_interface mgr_impl = {
    .destroy = mgr_destroy,
    .get_background_effect = mgr_get_background_effect,
};

void mgr_bind(wl_client *client, void *data, uint32_t version, uint32_t id) {
    wl_resource *res = wl_resource_create(client, &ext_background_effect_manager_v1_interface, version, id);
    if (!res) { wl_client_post_no_memory(client); return; }
    wl_resource_set_implementation(res, &mgr_impl, data, nullptr);
    // The 1.45 XML gives "blur" the value 0, which can't be tested as a bit; send bit 1, which
    // is what the fixed protocol uses. (Quickshell sends blur regions either way.)
    ext_background_effect_manager_v1_send_capabilities(res, 1u);
}

}  // namespace

void set_blur_strength(Server *s, double strength) {
    strength = std::clamp(strength, 0.0, 1.0);
    // passes x radius ~ how far the blur reaches; a little extra saturation keeps colours alive
    int passes = strength <= 0.01 ? 0 : 1 + (int)std::lround(strength * 3);
    int radius = 2 + (int)std::lround(strength * 6);
    wlr_scene_set_blur_data(s->scene, passes, radius, 0.02f, 0.95f, 0.95f, 1.15f);
}

void setup_effects(Server *s) {
    wl_global_create(s->display, &ext_background_effect_manager_v1_interface, 1, s, mgr_bind);
    set_blur_strength(s, 0.8);
}

#else

void set_blur_strength(Server *, double) {}
void setup_effects(Server *) {}

#endif
