#!/usr/bin/env bash
# Only for the earlier Nova preview (KWin + Quickshell, 0.1.x), whose updater
# runs setup.sh as root. Nova 1.0 is built and installed as you, with
# build.sh, so this puts the source in your home folder and says what to run.
# (Installing by hand? Run ./build.sh instead.)
set -u
here="$(cd "$(dirname "$0")" && pwd)"
user=""
while (($#)); do
	case "$1" in
	--user) user="${2:-}"; shift ;;
	esac
	shift
done
[[ -z "$user" && -n "${SUDO_USER:-}" ]] && user="$SUDO_USER"
[[ -z "$user" && -n "${PKEXEC_UID:-}" ]] && user="$(id -nu "$PKEXEC_UID" 2>/dev/null)"
if [[ $(id -u) -ne 0 || -z "$user" ]]; then
	exec "$here/build.sh" "$@"
fi
home="$(getent passwd "$user" | cut -d: -f6)"
version="$(sed -n "s/^[[:space:]]*version: '\([^']*\)'.*/\1/p" "$here/meson.build" | head -1)"
dest="$home/src/Nova-$version"
mkdir -p "$home/src"
rm -rf "$dest"
cp -a "$here" "$dest"
chown -R "$user": "$home/src"
chmod +x "$dest/build.sh" "$dest/install.sh" "$dest/uninstall.sh"
echo "PROGRESS 1 Downloaded"
echo "Nova $version is a new desktop built differently: open a terminal and run ~/src/Nova-$version/install.sh"
exit 1
