#!/usr/bin/env bash
# Installs Nova (or updates it): packages, build, and Nova on the login screen.
# Double-click it in Files and pick "Run as a program", or: ./install.sh
cd "$(dirname "$0")" && exec bash ./build.sh install "$@"
