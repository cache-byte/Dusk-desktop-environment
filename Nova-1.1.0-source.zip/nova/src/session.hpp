#pragma once

#include <string>
#include <vector>

namespace nova {

class Server;

struct AutostartApp {
	std::string file;   // e.g. "discord.desktop"
	std::string exec;
	bool run;           // enabled and meant for Nova
};

void start_keyring(Server &server);
void start_polkit_agent(Server &server);
std::vector<AutostartApp> list_autostart();
void run_autostart(Server &server);

} // namespace nova
