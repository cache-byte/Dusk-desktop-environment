// Protocols and input added in Nova 1.0, kept out of server.cpp:
//
//  * layer-shell: panels, docks, launchers, wallpapers and notification
//    pop-ups from other programs (Waybar, rofi, swaync, slurp…)
//  * ext-session-lock: lock screens from other programs (swaylock, hyprlock)
//  * window lists for other programs (wlr-foreign-toplevel, ext-foreign-toplevel-list)
//  * output management and power (wlr-randr, kanshi, wdisplays), gamma (wlsunset)
//  * security context: sandboxed (Flatpak) apps can't use the private ones above
//  * content type: games and videos say so (variable refresh on by itself)
//  * screen capture for the portal (screen sharing: Discord, OBS, browsers)
//  * input methods (Fcitx 5, IBus: Chinese, Japanese, Korean, emoji)
//  * touchscreens, pens and drawing tablets
//  * accessibility: sticky keys and bounce keys
//  * window rules and gaming touches (variable refresh, performance mode)
#pragma once

#include "wlr.hpp"

namespace nova {

class Server;
class View;
struct Output;
struct Keyboard;
struct Extras;

// Sets everything up. Call in Server::start once the seat and the scene exist.
Extras *extras_create(Server *s);

// ---- layer-shell ----
// Lays out other programs' panels on `o` and adds the space they keep free
// (top, right, bottom, left) to `reserve`.
void extras_arrange_layers(Server *s, Output *o, int reserve[4]);
// A click on one: it gets the keyboard if it asked for it.
void extras_layer_clicked(Server *s, wlr_surface *surface);
// True while a layer surface holds the keyboard on its own (a launcher like
// rofi): the keyboard stays there instead of going to `wanted`.
bool extras_keyboard_held(Server *s, wlr_surface *wanted);

// ---- session lock (swaylock and friends) ----
bool extras_session_locked(const Server *s);
void extras_lock_motion(Server *s, uint32_t time);
void extras_lock_button(Server *s, uint32_t time, uint32_t button, uint32_t state);

// ---- window lists for other programs ----
void extras_views_changed(Server *s);
void extras_view_gone(Server *s, View *v);

// ---- window rules (rule.N in the settings) ----
void extras_apply_rule(Server *s, View *v);

// ---- games ----
// A full-screen game started or stopped on `o` (variable refresh).
void extras_game_changed(Server *s, Output *o);
// Game mode on any screen changed (performance power mode).
void extras_game_mode_changed(Server *s);
// Another program sets this screen's colours (gamma): night light waits.
bool extras_gamma_owned(Server *s, wlr_output *o);

// ---- input ----
// Touchscreens and tablets. True if `device` was one of them.
bool extras_new_input(Server *s, wlr_input_device *device);
uint32_t extras_seat_caps(Server *s);
// Before Nova looks at a key: true = drop it (bounce keys).
bool extras_key_filter(Server *s, Keyboard *k, wlr_keyboard_key_event *ev);
// After Nova's shortcuts: true = it went to an input method instead of the app.
bool extras_key_to_input_method(Server *s, Keyboard *k, wlr_keyboard_key_event *ev);
bool extras_modifiers_to_input_method(Server *s, Keyboard *k);
// The keyboard moved to `surface` (may be null): text fields follow.
void extras_keyboard_focus(Server *s, wlr_surface *surface);

} // namespace nova
