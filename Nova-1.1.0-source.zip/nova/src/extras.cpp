// Protocols and input added in Nova 1.0. See extras.hpp for the list.
#include "extras.hpp"

#include <linux/input-event-codes.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <map>
#include <set>
#include <string>
#include <vector>

#include "lock.hpp"
#include "overview.hpp"
#include "server.hpp"

namespace nova {

namespace {

double now_msec() {
	timespec t{};
	clock_gettime(CLOCK_MONOTONIC, &t);
	return t.tv_sec * 1000.0 + t.tv_nsec / 1e6;
}

std::string safe(const char *s) { return s ? s : ""; }

} // namespace

struct LayerSurface;
struct LockSurface;
struct ToplevelHandle;
struct TextInput;
struct ImPopup;

// ---------------------------------------------------------------------------
// All the state
// ---------------------------------------------------------------------------

struct Extras {
	Server *s;

	// layer-shell
	wlr_layer_shell_v1 *layer_shell = nullptr;
	std::vector<LayerSurface *> layers;
	LayerSurface *kb_layer = nullptr;      // holds the keyboard on its own (exclusive)
	Listener on_new_layer;
	void handle_new_layer(void *data);
	wlr_scene_tree *tree_for(uint32_t layer) const;
	void arrange_output(Output *o);         // after a layer surface changed
	void give_keyboard(wlr_surface *surface);
	void layer_gone(LayerSurface *l);

	// session lock
	wlr_session_lock_manager_v1 *lock_manager = nullptr;
	wlr_session_lock_v1 *lock = nullptr;
	bool locked = false;
	std::vector<wlr_scene_rect *> lock_backdrops;
	std::vector<LockSurface *> lock_surfaces;
	Listener on_new_lock, on_lock_new_surface, on_lock_unlock, on_lock_destroy;
	void handle_new_lock(void *data);
	void handle_lock_new_surface(void *data);
	void handle_lock_unlock(void *data);
	void handle_lock_destroy(void *data);
	void end_lock();

	// window lists
	wlr_foreign_toplevel_manager_v1 *toplevel_manager = nullptr;
	wlr_ext_foreign_toplevel_list_v1 *toplevel_list = nullptr;
	std::map<View *, ToplevelHandle *> handles;

	// outputs
	wlr_output_manager_v1 *output_manager = nullptr;
	wlr_output_power_manager_v1 *output_power = nullptr;
	wlr_gamma_control_manager_v1 *gamma = nullptr;
	std::set<wlr_output *> gamma_owned;
	std::set<std::string> vrr_forced;   // screens with variable refresh on for a game
	Listener on_layout_change, on_output_apply, on_output_test, on_power_set_mode, on_set_gamma;
	void handle_layout_change(void *data);
	void handle_output_apply(void *data);
	void handle_output_test(void *data);
	void apply_output_config(wlr_output_configuration_v1 *config, bool test_only);
	void handle_power_set_mode(void *data);
	void handle_set_gamma(void *data);
	void send_output_state();
	wl_event_source *output_state_idle = nullptr;
	std::string power_before_games;    // the power mode before a game made it "performance"

	// security context, content type
	wlr_security_context_manager_v1 *security = nullptr;
	wlr_content_type_manager_v1 *content_type = nullptr;

	// input methods
	wlr_text_input_manager_v3 *text_inputs = nullptr;
	wlr_input_method_manager_v2 *input_methods = nullptr;
	wlr_input_method_v2 *im = nullptr;
	wlr_input_method_keyboard_grab_v2 *grab = nullptr;
	std::vector<TextInput *> tis;
	TextInput *active_ti = nullptr;
	std::vector<ImPopup *> im_popups;
	Listener on_new_text_input, on_new_input_method;
	Listener on_im_commit, on_im_grab, on_im_new_popup, on_im_destroy, on_grab_destroy;
	void handle_new_text_input(void *data);
	void handle_new_input_method(void *data);
	void handle_im_commit(void *data);
	void handle_im_grab(void *data);
	void handle_im_new_popup(void *data);
	void handle_im_destroy(void *data);
	void handle_grab_destroy(void *data);
	void send_im_state(TextInput *ti);
	void place_im_popups();

	// touch
	int touch_devices = 0;
	struct Touch {
		wlr_surface *surface = nullptr;   // null: Nova's own things (a pretend mouse)
		double ox = 0, oy = 0;            // where the surface is (layout coordinates)
	};
	std::map<int32_t, Touch> touches;
	int32_t pointer_touch = -1;           // the touch acting as the mouse
	Listener on_touch_down, on_touch_up, on_touch_motion, on_touch_cancel, on_touch_frame;
	void handle_touch_down(void *data);
	void handle_touch_up(void *data);
	void handle_touch_motion(void *data);
	void handle_touch_cancel(void *data);
	void handle_touch_frame(void *data);

	// pens and tablets
	wlr_tablet_manager_v2 *tablets = nullptr;
	struct Tool {
		wlr_tablet_v2_tablet_tool *v2 = nullptr;
		wlr_tablet_v2_tablet *tablet = nullptr;
		wlr_surface *over = nullptr;   // a window that understands pens
		double ox = 0, oy = 0;
		bool down = false;
		bool mouse_down = false;       // pretending to be a mouse (Nova's own things)
	};
	std::map<wlr_tablet_tool *, Tool> tools;
	Listener on_tool_axis, on_tool_proximity, on_tool_tip, on_tool_button;
	void handle_tool_axis(void *data);
	void handle_tool_proximity(void *data);
	void handle_tool_tip(void *data);
	void handle_tool_button(void *data);
	Tool &tool_for(wlr_tablet_tool *tool, wlr_tablet *tablet);
	void tool_moved(Tool &t, uint32_t time);

	// accessibility
	std::map<uint32_t, double> released_at;   // keycode -> when it was let go (bounce keys)
	std::set<uint32_t> bounced;               // presses dropped, so their release goes too
	xkb_mod_mask_t sticky_pending = 0;        // a modifier pressed on its own so far
	bool sticky_other = false;

	// pretend mouse buttons, for touches and pens on Nova's own things
	void fake_button(uint32_t time, uint32_t button, bool pressed);
	void fake_move(double lx, double ly, uint32_t time);
};

// ---------------------------------------------------------------------------
// layer-shell
// ---------------------------------------------------------------------------

struct LayerPopup {
	wlr_xdg_popup *popup;
	struct LayerSurface *owner;
	Listener on_commit, on_new_popup, on_destroy;

	LayerPopup(LayerSurface *owner, wlr_xdg_popup *popup, wlr_scene_tree *parent);
	void unconstrain();
	void handle_commit(void *) {
		if (popup->base->initial_commit) {
			unconstrain();
			wlr_xdg_surface_schedule_configure(popup->base);
		}
	}
	void handle_new_popup(void *data);
	void handle_destroy(void *) { delete this; }
};

struct LayerSurface {
	Extras *ex;
	wlr_layer_surface_v1 *ls;
	wlr_scene_layer_surface_v1 *scene = nullptr;
	NodeTag tag{NodeTag::Kind::Layer, this};
	uint32_t layer = 0;
	bool mapped = false;
	Listener on_map, on_unmap, on_commit, on_destroy, on_new_popup;

	LayerSurface(Extras *ex, wlr_layer_surface_v1 *ls) : ex(ex), ls(ls) {
		layer = ls->pending.layer;
		scene = wlr_scene_layer_surface_v1_create(ex->tree_for(layer), ls);
		scene->tree->node.data = &tag;
		ls->data = this;
		on_map.connect<&LayerSurface::handle_map>(&ls->surface->events.map, this);
		on_unmap.connect<&LayerSurface::handle_unmap>(&ls->surface->events.unmap, this);
		on_commit.connect<&LayerSurface::handle_commit>(&ls->surface->events.commit, this);
		on_destroy.connect<&LayerSurface::handle_destroy>(&ls->events.destroy, this);
		on_new_popup.connect<&LayerSurface::handle_new_popup>(&ls->events.new_popup, this);
	}

	Output *output() const {
		for (Output *o : ex->s->outputs) {
			if (o->output == ls->output) return o;
		}
		return nullptr;
	}

	bool wants_keyboard() const {
		return ls->current.keyboard_interactive == ZWLR_LAYER_SURFACE_V1_KEYBOARD_INTERACTIVITY_EXCLUSIVE &&
			layer >= ZWLR_LAYER_SHELL_V1_LAYER_TOP;
	}

	void handle_map(void *) {
		mapped = true;
		if (Output *o = output()) ex->arrange_output(o);
		if (wants_keyboard() && !ex->s->locked()) {
			ex->kb_layer = this;
			ex->give_keyboard(ls->surface);
		}
	}

	void handle_unmap(void *) {
		mapped = false;
		ex->layer_gone(this);
		if (Output *o = output()) ex->arrange_output(o);
	}

	void handle_commit(void *) {
		if (!ls->initialized) {
			return;
		}
		if (ls->current.layer != layer) {
			layer = ls->current.layer;
			wlr_scene_node_reparent(&scene->tree->node, ex->tree_for(layer));
		}
		if (ls->initial_commit || ls->current.committed) {
			if (Output *o = output()) ex->arrange_output(o);
		}
		// It asked for the keyboard after mapping (or stopped asking).
		if (mapped && wants_keyboard() && ex->kb_layer != this && !ex->s->locked()) {
			ex->kb_layer = this;
			ex->give_keyboard(ls->surface);
		} else if (ex->kb_layer == this && !wants_keyboard()) {
			ex->layer_gone(this);
		}
	}

	void handle_destroy(void *) {
		ex->layer_gone(this);
		ex->layers.erase(std::remove(ex->layers.begin(), ex->layers.end(), this), ex->layers.end());
		Output *o = output();
		delete this;
		if (o) ex->arrange_output(o);
	}

	void handle_new_popup(void *data) {
		new LayerPopup(this, static_cast<wlr_xdg_popup *>(data), scene->tree);
	}
};

LayerPopup::LayerPopup(LayerSurface *owner, wlr_xdg_popup *popup, wlr_scene_tree *parent)
		: popup(popup), owner(owner) {
	popup->base->surface->data = wlr_scene_xdg_surface_create(parent, popup->base);
	on_commit.connect<&LayerPopup::handle_commit>(&popup->base->surface->events.commit, this);
	on_new_popup.connect<&LayerPopup::handle_new_popup>(&popup->base->events.new_popup, this);
	on_destroy.connect<&LayerPopup::handle_destroy>(&popup->events.destroy, this);
}

void LayerPopup::handle_new_popup(void *data) {
	new LayerPopup(owner, static_cast<wlr_xdg_popup *>(data),
		static_cast<wlr_scene_tree *>(popup->base->surface->data));
}

// Menus stay on the screen: the screen's area, in the layer surface's own coordinates.
void LayerPopup::unconstrain() {
	Output *o = owner->output();
	if (!o) return;
	wlr_box box = o->box();
	box.x -= owner->scene->tree->node.x;
	box.y -= owner->scene->tree->node.y;
	wlr_xdg_popup_unconstrain_from_box(popup, &box);
}

wlr_scene_tree *Extras::tree_for(uint32_t layer) const {
	switch (layer) {
	case ZWLR_LAYER_SHELL_V1_LAYER_BACKGROUND: return s->layer_background;   // over Nova's wallpaper
	case ZWLR_LAYER_SHELL_V1_LAYER_BOTTOM: return s->layer_desktop;          // under the windows
	case ZWLR_LAYER_SHELL_V1_LAYER_TOP: return s->layer_panel;               // over windows, under full screen
	default: return s->layer_overlay;                                         // over everything
	}
}

void Extras::handle_new_layer(void *data) {
	auto *ls = static_cast<wlr_layer_surface_v1 *>(data);
	if (!ls->output) {
		Output *o = s->focused_output();
		if (!o && !s->outputs.empty()) o = s->outputs.front();
		if (!o) {
			wlr_layer_surface_v1_destroy(ls);
			return;
		}
		ls->output = o->output;
	}
	layers.push_back(new LayerSurface(this, ls));
}

void Extras::arrange_output(Output *o) {
	(void)o;
	s->arrange();   // panels, windows and every layer surface, with the new free space
}

void Extras::give_keyboard(wlr_surface *surface) {
	wlr_seat *seat = s->seat;
	if (wlr_keyboard *kb = wlr_seat_get_keyboard(seat)) {
		wlr_seat_keyboard_notify_enter(seat, surface, kb->keycodes, kb->num_keycodes, &kb->modifiers);
	} else {
		wlr_seat_keyboard_notify_enter(seat, surface, nullptr, 0, nullptr);
	}
	extras_keyboard_focus(s, surface);
}

void Extras::layer_gone(LayerSurface *l) {
	if (kb_layer != l) {
		// It had the keyboard after a click: give it back to the window.
		if (s->seat->keyboard_state.focused_surface == l->ls->surface) {
			s->focus_surface(s->focused ? s->focused->surface() : nullptr);
		}
		return;
	}
	kb_layer = nullptr;
	s->focus_surface(s->focused ? s->focused->surface() : nullptr);
}

void extras_arrange_layers(Server *s, Output *o, int reserve[4]) {
	Extras *ex = s->extras;
	if (!ex) return;
	const wlr_box full = o->box();
	wlr_box usable = full;
	usable.x += reserve[3];
	usable.y += reserve[0];
	usable.width = std::max(0, usable.width - reserve[1] - reserve[3]);
	usable.height = std::max(0, usable.height - reserve[0] - reserve[2]);
	// Top layers first, and those keeping space free before the rest.
	for (int pass = 0; pass < 2; pass++) {
		for (int layer = ZWLR_LAYER_SHELL_V1_LAYER_OVERLAY; layer >= 0; layer--) {
			for (LayerSurface *l : ex->layers) {
				if (l->ls->output != o->output || static_cast<int>(l->layer) != layer || !l->ls->initialized) continue;
				const bool exclusive = l->ls->current.exclusive_zone > 0;
				if (exclusive != (pass == 0)) continue;
				wlr_scene_layer_surface_v1_configure(l->scene, &full, &usable);
			}
		}
	}
	reserve[0] = usable.y - full.y;
	reserve[3] = usable.x - full.x;
	reserve[1] = (full.x + full.width) - (usable.x + usable.width);
	reserve[2] = (full.y + full.height) - (usable.y + usable.height);
}

void extras_layer_clicked(Server *s, wlr_surface *surface) {
	Extras *ex = s->extras;
	if (!ex || s->locked()) return;
	for (LayerSurface *l : ex->layers) {
		if (l->ls->surface != surface) continue;
		if (l->ls->current.keyboard_interactive != ZWLR_LAYER_SURFACE_V1_KEYBOARD_INTERACTIVITY_NONE) {
			ex->give_keyboard(surface);
		}
		return;
	}
}

bool extras_keyboard_held(Server *s, wlr_surface *wanted) {
	Extras *ex = s->extras;
	return ex && ex->kb_layer && ex->kb_layer->mapped && wanted != ex->kb_layer->ls->surface && !s->locked();
}

// ---------------------------------------------------------------------------
// Session lock (ext-session-lock-v1): swaylock, hyprlock, gtklock…
// ---------------------------------------------------------------------------

struct LockSurface {
	Extras *ex;
	wlr_session_lock_surface_v1 *ls;
	wlr_scene_tree *tree;
	Listener on_map, on_destroy;

	LockSurface(Extras *ex, wlr_session_lock_surface_v1 *ls) : ex(ex), ls(ls) {
		tree = wlr_scene_subsurface_tree_create(ex->s->layer_lock, ls->surface);
		for (Output *o : ex->s->outputs) {
			if (o->output != ls->output) continue;
			const wlr_box b = o->box();
			wlr_scene_node_set_position(&tree->node, b.x, b.y);
			wlr_session_lock_surface_v1_configure(ls, b.width, b.height);
		}
		on_map.connect<&LockSurface::handle_map>(&ls->surface->events.map, this);
		on_destroy.connect<&LockSurface::handle_destroy>(&ls->events.destroy, this);
	}
	void handle_map(void *) {
		// The first lock surface (or the one under the pointer) gets the keyboard.
		wlr_surface *now = ex->s->seat->keyboard_state.focused_surface;
		bool on_lock = false;
		for (LockSurface *l : ex->lock_surfaces) on_lock = on_lock || (now == l->ls->surface);
		if (!on_lock) ex->give_keyboard(ls->surface);
	}
	void handle_destroy(void *) {
		ex->lock_surfaces.erase(std::remove(ex->lock_surfaces.begin(), ex->lock_surfaces.end(), this),
			ex->lock_surfaces.end());
		wlr_scene_node_destroy(&tree->node);
		delete this;
	}
};

void Extras::handle_new_lock(void *data) {
	auto *l = static_cast<wlr_session_lock_v1 *>(data);
	if (lock || (s->lock && s->lock->active())) {
		wlr_session_lock_v1_destroy(l);   // already locked
		return;
	}
	lock = l;
	locked = true;
	s->close_popups();
	// Black over everything until the lock program draws its own.
	for (Output *o : s->outputs) {
		const wlr_box b = o->box();
		const float black[4] = {0, 0, 0, 1};
		wlr_scene_rect *r = wlr_scene_rect_create(s->layer_lock, b.width, b.height, black);
		wlr_scene_node_set_position(&r->node, b.x, b.y);
		lock_backdrops.push_back(r);
	}
	wlr_seat_pointer_notify_clear_focus(s->seat);
	wlr_seat_keyboard_notify_clear_focus(s->seat);
	on_lock_new_surface.connect<&Extras::handle_lock_new_surface>(&l->events.new_surface, this);
	on_lock_unlock.connect<&Extras::handle_lock_unlock>(&l->events.unlock, this);
	on_lock_destroy.connect<&Extras::handle_lock_destroy>(&l->events.destroy, this);
	wlr_session_lock_v1_send_locked(l);
}

void Extras::handle_lock_new_surface(void *data) {
	lock_surfaces.push_back(new LockSurface(this, static_cast<wlr_session_lock_surface_v1 *>(data)));
}

void Extras::end_lock() {
	for (wlr_scene_rect *r : lock_backdrops) wlr_scene_node_destroy(&r->node);
	lock_backdrops.clear();
	on_lock_new_surface.disconnect();
	on_lock_unlock.disconnect();
	on_lock_destroy.disconnect();
	lock = nullptr;
}

void Extras::handle_lock_unlock(void *) {
	locked = false;
	end_lock();
	s->focus_surface(s->focused ? s->focused->surface() : nullptr);
	s->schedule_frames();
}

void Extras::handle_lock_destroy(void *) {
	const bool still_locked = locked;
	end_lock();
	if (still_locked) {
		// The lock program went away without unlocking (it crashed): stay
		// locked, with Nova's own lock screen asking for the password.
		locked = false;
		if (s->lock) s->lock->lock();
	}
}

bool extras_session_locked(const Server *s) {
	return s->extras && s->extras->locked;
}

static wlr_surface *lock_surface_at(Server *s, double lx, double ly, double *sx, double *sy) {
	wlr_scene_node *node = wlr_scene_node_at(&s->layer_lock->node, lx, ly, sx, sy);
	if (!node || node->type != WLR_SCENE_NODE_BUFFER) return nullptr;
	wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(wlr_scene_buffer_from_node(node));
	return ss ? ss->surface : nullptr;
}

void extras_lock_motion(Server *s, uint32_t time) {
	double sx = 0, sy = 0;
	wlr_surface *surface = lock_surface_at(s, s->cursor->x, s->cursor->y, &sx, &sy);
	if (surface) {
		wlr_seat_pointer_notify_enter(s->seat, surface, sx, sy);
		wlr_seat_pointer_notify_motion(s->seat, time, sx, sy);
	} else {
		wlr_seat_pointer_notify_clear_focus(s->seat);
	}
}

void extras_lock_button(Server *s, uint32_t time, uint32_t button, uint32_t state) {
	double sx = 0, sy = 0;
	wlr_surface *surface = lock_surface_at(s, s->cursor->x, s->cursor->y, &sx, &sy);
	if (surface && state == WL_POINTER_BUTTON_STATE_PRESSED &&
			s->seat->keyboard_state.focused_surface != surface) {
		s->extras->give_keyboard(surface);   // a lock screen on each screen: the clicked one types
	}
	wlr_seat_pointer_notify_button(s->seat, time, button, static_cast<wl_pointer_button_state>(state));
}

// ---------------------------------------------------------------------------
// Window lists for other programs (taskbars, docks, switchers)
// ---------------------------------------------------------------------------

struct ToplevelHandle {
	Extras *ex;
	View *view;
	wlr_foreign_toplevel_handle_v1 *wlr = nullptr;
	wlr_ext_foreign_toplevel_handle_v1 *ext = nullptr;
	std::string title, app_id;
	wlr_output *on = nullptr;
	Listener on_activate, on_maximize, on_minimize, on_fullscreen, on_close, on_destroy;

	ToplevelHandle(Extras *ex, View *view) : ex(ex), view(view) {
		title = view->title();
		app_id = view->app_id();
		if (ex->toplevel_manager) {
			wlr = wlr_foreign_toplevel_handle_v1_create(ex->toplevel_manager);
			wlr_foreign_toplevel_handle_v1_set_title(wlr, title.c_str());
			wlr_foreign_toplevel_handle_v1_set_app_id(wlr, app_id.c_str());
			on_activate.connect<&ToplevelHandle::handle_activate>(&wlr->events.request_activate, this);
			on_maximize.connect<&ToplevelHandle::handle_maximize>(&wlr->events.request_maximize, this);
			on_minimize.connect<&ToplevelHandle::handle_minimize>(&wlr->events.request_minimize, this);
			on_fullscreen.connect<&ToplevelHandle::handle_fullscreen>(&wlr->events.request_fullscreen, this);
			on_close.connect<&ToplevelHandle::handle_close>(&wlr->events.request_close, this);
			on_destroy.connect<&ToplevelHandle::handle_destroy>(&wlr->events.destroy, this);
		}
		if (ex->toplevel_list) {
			wlr_ext_foreign_toplevel_handle_v1_state st{};
			st.title = title.c_str();
			st.app_id = app_id.c_str();
			ext = wlr_ext_foreign_toplevel_handle_v1_create(ex->toplevel_list, &st);
		}
		update();
	}

	~ToplevelHandle() {
		on_activate.disconnect();
		on_maximize.disconnect();
		on_minimize.disconnect();
		on_fullscreen.disconnect();
		on_close.disconnect();
		on_destroy.disconnect();
		if (wlr) wlr_foreign_toplevel_handle_v1_destroy(wlr);
		if (ext) wlr_ext_foreign_toplevel_handle_v1_destroy(ext);
	}

	void update() {
		const std::string t = view->title(), a = view->app_id();
		const bool names = t != title || a != app_id;
		title = t;
		app_id = a;
		if (wlr) {
			if (names) {
				wlr_foreign_toplevel_handle_v1_set_title(wlr, title.c_str());
				wlr_foreign_toplevel_handle_v1_set_app_id(wlr, app_id.c_str());
			}
			wlr_foreign_toplevel_handle_v1_set_activated(wlr, ex->s->focused == view);
			wlr_foreign_toplevel_handle_v1_set_maximized(wlr, view->maximized);
			wlr_foreign_toplevel_handle_v1_set_minimized(wlr, view->minimized);
			wlr_foreign_toplevel_handle_v1_set_fullscreen(wlr, view->fullscreen);
			Output *o = view->output();
			wlr_output *now = o ? o->output : nullptr;
			if (now != on) {
				if (on) wlr_foreign_toplevel_handle_v1_output_leave(wlr, on);
				if (now) wlr_foreign_toplevel_handle_v1_output_enter(wlr, now);
				on = now;
			}
		}
		if (ext && names) {
			wlr_ext_foreign_toplevel_handle_v1_state st{};
			st.title = title.c_str();
			st.app_id = app_id.c_str();
			wlr_ext_foreign_toplevel_handle_v1_update_state(ext, &st);
		}
	}

	void bring_forward() {
		Server *s = ex->s;
		if (view->minimized) view->restore_from_minimize();
		if (!view->sticky && view->workspace != s->workspace) s->switch_workspace(view->workspace);
		s->focus(view);
	}
	void handle_activate(void *) { bring_forward(); }
	void handle_maximize(void *data) {
		auto *e = static_cast<wlr_foreign_toplevel_handle_v1_maximized_event *>(data);
		if (e->maximized != view->maximized) view->set_maximized(e->maximized);
	}
	void handle_minimize(void *data) {
		auto *e = static_cast<wlr_foreign_toplevel_handle_v1_minimized_event *>(data);
		if (e->minimized && !view->minimized) view->minimize();
		else if (!e->minimized && view->minimized) bring_forward();
	}
	void handle_fullscreen(void *data) {
		auto *e = static_cast<wlr_foreign_toplevel_handle_v1_fullscreen_event *>(data);
		if (e->fullscreen != view->fullscreen) view->set_fullscreen(e->fullscreen);
	}
	void handle_close(void *) { view->close(); }
	void handle_destroy(void *) {
		// The protocol object went away under us (shutting down).
		wlr = nullptr;
		on_activate.disconnect();
		on_maximize.disconnect();
		on_minimize.disconnect();
		on_fullscreen.disconnect();
		on_close.disconnect();
		on_destroy.disconnect();
	}
};

void extras_views_changed(Server *s) {
	Extras *ex = s->extras;
	if (!ex) return;
	for (View *v : s->views) {
		auto it = ex->handles.find(v);
		if (v->mapped && it == ex->handles.end()) {
			ex->handles[v] = new ToplevelHandle(ex, v);
		} else if (!v->mapped && it != ex->handles.end()) {
			delete it->second;
			ex->handles.erase(it);
		} else if (it != ex->handles.end()) {
			it->second->update();
		}
	}
}

void extras_view_gone(Server *s, View *v) {
	Extras *ex = s->extras;
	if (!ex) return;
	auto it = ex->handles.find(v);
	if (it != ex->handles.end()) {
		delete it->second;
		ex->handles.erase(it);
	}
}

// ---------------------------------------------------------------------------
// Window rules
// ---------------------------------------------------------------------------

void extras_apply_rule(Server *s, View *v) {
	const WindowRule *r = s->config.rule_for(v->app_id(), v->title());
	if (!r) return;
	if (!r->output.empty()) {
		for (Output *o : s->outputs) {
			if (o->name() == r->output && o->enabled()) {
				s->move_to_screen(v, o, false);
				break;
			}
		}
	}
	if (r->width > 0 && r->height > 0) {
		v->request_content_size(r->width, r->height);
	}
	if (r->center) {
		if (Output *o = v->output()) {
			const wlr_box u = o->usable();
			const int fw = (r->width > 0 ? r->width : v->content_width()) + v->deco_width();
			const int fh = (r->height > 0 ? r->height : v->content_height()) + v->deco_height();
			v->move_to(u.x + (u.width - fw) / 2, u.y + (u.height - fh) / 2);
		}
	}
	if (r->sticky) {
		v->sticky = true;
	}
	if (r->workspace >= 0 && !r->sticky) {
		while (s->workspace_count <= r->workspace + 1) s->workspace_count++;   // dynamic: make room
		s->move_to_workspace(v, r->workspace, false);
	}
	if (r->fullscreen) {
		v->set_fullscreen(true);
	} else if (r->maximize) {
		v->set_maximized(true);
	}
}

// ---------------------------------------------------------------------------
// Outputs: management (wlr-randr, kanshi, wdisplays), power, gamma
// ---------------------------------------------------------------------------

void Extras::send_output_state() {
	if (!output_manager) return;
	wlr_output_configuration_v1 *config = wlr_output_configuration_v1_create();
	for (Output *o : s->outputs) {
		wlr_output_configuration_head_v1 *head = wlr_output_configuration_head_v1_create(config, o->output);
		const wlr_box b = o->box();
		head->state.enabled = o->enabled();
		head->state.x = b.x;
		head->state.y = b.y;
	}
	wlr_output_manager_v1_set_configuration(output_manager, config);
}

void Extras::handle_layout_change(void *) {
	// Several changes come together (a screen plugged in): tell programs once.
	if (output_state_idle) return;
	output_state_idle = wl_event_loop_add_idle(s->loop, [](void *data) {
		auto *ex = static_cast<Extras *>(data);
		ex->output_state_idle = nullptr;
		ex->send_output_state();
	}, this);
}

void Extras::apply_output_config(wlr_output_configuration_v1 *config, bool test_only) {
	bool ok = true;
	wlr_output_configuration_head_v1 *head;
	// Check every screen's new mode first.
	wl_list_for_each(head, &config->heads, link) {
		wlr_output_state st;
		wlr_output_state_init(&st);
		wlr_output_state_set_enabled(&st, head->state.enabled);
		if (head->state.enabled) {
			if (head->state.mode) {
				wlr_output_state_set_mode(&st, head->state.mode);
			} else if (head->state.custom_mode.width > 0) {
				wlr_output_state_set_custom_mode(&st, head->state.custom_mode.width,
					head->state.custom_mode.height, head->state.custom_mode.refresh);
			}
			wlr_output_state_set_transform(&st, head->state.transform);
			wlr_output_state_set_scale(&st, head->state.scale);
			wlr_output_state_set_adaptive_sync_enabled(&st, head->state.adaptive_sync_enabled);
		}
		ok = ok && wlr_output_test_state(head->state.output, &st);
		wlr_output_state_finish(&st);
	}
	if (ok && !test_only) {
		// Saved in Nova's settings like a change made in Settings › Displays:
		// Nova applies it from there (and keeps it for next time).
		wl_list_for_each(head, &config->heads, link) {
			const std::string name = safe(head->state.output->name);
			const auto &st = head->state;
			s->write_setting("output." + name + ".enabled", st.enabled ? "true" : "false");
			if (!st.enabled) continue;
			int w = 0, h = 0, mhz = 0;
			if (st.mode) { w = st.mode->width; h = st.mode->height; mhz = st.mode->refresh; }
			else { w = st.custom_mode.width; h = st.custom_mode.height; mhz = st.custom_mode.refresh; }
			if (w > 0 && h > 0) {
				char mode[64];
				std::snprintf(mode, sizeof mode, "%dx%d@%.3f", w, h, mhz / 1000.0);
				s->write_setting("output." + name + ".mode", mode);
			}
			s->write_setting("output." + name + ".position", std::to_string(st.x) + "," + std::to_string(st.y));
			const int rotation = st.transform == WL_OUTPUT_TRANSFORM_90 ? 90 : st.transform == WL_OUTPUT_TRANSFORM_180 ? 180
				: st.transform == WL_OUTPUT_TRANSFORM_270 ? 270 : 0;
			s->write_setting("output." + name + ".rotation", std::to_string(rotation));
			s->write_setting("output." + name + ".vrr", st.adaptive_sync_enabled ? "true" : "false");
			char scale[32];
			std::snprintf(scale, sizeof scale, "%.2f", static_cast<double>(st.scale));
			s->write_setting("scale." + name, scale);
		}
	}
	if (ok) wlr_output_configuration_v1_send_succeeded(config);
	else wlr_output_configuration_v1_send_failed(config);
	wlr_output_configuration_v1_destroy(config);
}

void Extras::handle_output_apply(void *data) {
	apply_output_config(static_cast<wlr_output_configuration_v1 *>(data), false);
}

void Extras::handle_output_test(void *data) {
	apply_output_config(static_cast<wlr_output_configuration_v1 *>(data), true);
}

void Extras::handle_power_set_mode(void *data) {
	auto *e = static_cast<wlr_output_power_v1_set_mode_event *>(data);
	wlr_output_state st;
	wlr_output_state_init(&st);
	wlr_output_state_set_enabled(&st, e->mode == ZWLR_OUTPUT_POWER_V1_MODE_ON);
	wlr_output_commit_state(e->output, &st);
	wlr_output_state_finish(&st);
	if (e->mode == ZWLR_OUTPUT_POWER_V1_MODE_ON) {
		for (Output *o : s->outputs) {
			if (o->output != e->output) continue;
			o->applied.clear();   // its mode, set again
			o->configure();
			wlr_output_schedule_frame(o->output);
		}
		s->arrange();
	}
}

void Extras::handle_set_gamma(void *data) {
	auto *e = static_cast<wlr_gamma_control_manager_v1_set_gamma_event *>(data);
	if (!e->control) {
		// The program let go: Nova's night light again.
		gamma_owned.erase(e->output);
		wlr_output_state reset;
		wlr_output_state_init(&reset);
		if (wlr_gamma_control_v1_apply(nullptr, &reset)) wlr_output_commit_state(e->output, &reset);
		wlr_output_state_finish(&reset);
		for (Output *o : s->outputs) {
			if (o->output != e->output) continue;
			o->gamma_temp = -1;
			o->apply_night_light();
		}
		return;
	}
	gamma_owned.insert(e->output);
	wlr_output_state st;
	wlr_output_state_init(&st);
	if (!wlr_gamma_control_v1_apply(e->control, &st) || !wlr_output_test_state(e->output, &st)) {
		wlr_gamma_control_v1_send_failed_and_destroy(e->control);
		gamma_owned.erase(e->output);
	} else {
		wlr_output_commit_state(e->output, &st);
	}
	wlr_output_state_finish(&st);
}

bool extras_gamma_owned(Server *s, wlr_output *o) {
	return s->extras && s->extras->gamma_owned.count(o) > 0;
}

// ---------------------------------------------------------------------------
// Games
// ---------------------------------------------------------------------------

void extras_game_changed(Server *s, Output *o) {
	Extras *ex = s->extras;
	if (!ex || !s->config.vrr_games || !o->output->adaptive_sync_supported) return;
	const std::string name = o->name();
	auto it = s->config.outputs.find(name);
	const bool always = it != s->config.outputs.end() && it->second.vrr;
	if (always) return;   // it's on all the time anyway
	const bool want = o->game;
	if (want == (ex->vrr_forced.count(name) > 0)) return;
	wlr_output_state st;
	wlr_output_state_init(&st);
	wlr_output_state_set_adaptive_sync_enabled(&st, want);
	if (wlr_output_test_state(o->output, &st) && wlr_output_commit_state(o->output, &st)) {
		if (want) ex->vrr_forced.insert(name);
		else ex->vrr_forced.erase(name);
	}
	wlr_output_state_finish(&st);
}

void extras_game_mode_changed(Server *s) {
	Extras *ex = s->extras;
	if (!ex || !s->config.game_boost) return;
	if (s->game_mode) {
		// Remember the mode you had, then performance while you play.
		s->run_capture("powerprofilesctl get 2>/dev/null", [ex](std::string out) {
			while (!out.empty() && (out.back() == '\n' || out.back() == ' ')) out.pop_back();
			if (out.empty() || out == "performance") return;
			ex->power_before_games = out;
			ex->s->spawn("powerprofilesctl set performance 2>/dev/null");
		});
	} else if (!ex->power_before_games.empty()) {
		ex->s->spawn("powerprofilesctl set " + shell_quote(ex->power_before_games) + " 2>/dev/null");
		ex->power_before_games.clear();
	}
}

// ---------------------------------------------------------------------------
// Input methods (Fcitx 5, IBus)
// ---------------------------------------------------------------------------

struct TextInput {
	Extras *ex;
	wlr_text_input_v3 *ti;
	Listener on_enable, on_commit, on_disable, on_destroy;

	TextInput(Extras *ex, wlr_text_input_v3 *ti) : ex(ex), ti(ti) {
		on_enable.connect<&TextInput::handle_enable>(&ti->events.enable, this);
		on_commit.connect<&TextInput::handle_commit>(&ti->events.commit, this);
		on_disable.connect<&TextInput::handle_disable>(&ti->events.disable, this);
		on_destroy.connect<&TextInput::handle_destroy>(&ti->events.destroy, this);
		// A text field in the window that already has the keyboard.
		wlr_surface *focused = ex->s->seat->keyboard_state.focused_surface;
		if (focused && wl_resource_get_client(focused->resource) == wl_resource_get_client(ti->resource)) {
			wlr_text_input_v3_send_enter(ti, focused);
		}
	}
	void handle_enable(void *) {
		ex->active_ti = this;
		if (ex->im) {
			wlr_input_method_v2_send_activate(ex->im);
			ex->send_im_state(this);
		}
	}
	void handle_commit(void *) {
		if (ex->active_ti != this || !ex->im) return;
		ex->send_im_state(this);
		ex->place_im_popups();
	}
	void handle_disable(void *) {
		if (ex->active_ti != this) return;
		ex->active_ti = nullptr;
		if (ex->im) {
			wlr_input_method_v2_send_deactivate(ex->im);
			wlr_input_method_v2_send_done(ex->im);
		}
	}
	void handle_destroy(void *) {
		if (ex->active_ti == this) {
			ex->active_ti = nullptr;
			if (ex->im) {
				wlr_input_method_v2_send_deactivate(ex->im);
				wlr_input_method_v2_send_done(ex->im);
			}
		}
		ex->tis.erase(std::remove(ex->tis.begin(), ex->tis.end(), this), ex->tis.end());
		delete this;
	}
};

struct ImPopup {
	Extras *ex;
	wlr_input_popup_surface_v2 *popup;
	wlr_scene_tree *tree;
	Listener on_map, on_unmap, on_destroy;

	ImPopup(Extras *ex, wlr_input_popup_surface_v2 *popup) : ex(ex), popup(popup) {
		tree = wlr_scene_subsurface_tree_create(ex->s->layer_overlay, popup->surface);
		wlr_scene_node_set_enabled(&tree->node, false);
		on_map.connect<&ImPopup::handle_map>(&popup->surface->events.map, this);
		on_unmap.connect<&ImPopup::handle_unmap>(&popup->surface->events.unmap, this);
		on_destroy.connect<&ImPopup::handle_destroy>(&popup->events.destroy, this);
	}
	void handle_map(void *) { ex->place_im_popups(); }
	void handle_unmap(void *) { wlr_scene_node_set_enabled(&tree->node, false); }
	void handle_destroy(void *) {
		ex->im_popups.erase(std::remove(ex->im_popups.begin(), ex->im_popups.end(), this), ex->im_popups.end());
		wlr_scene_node_destroy(&tree->node);
		delete this;
	}
};

void Extras::send_im_state(TextInput *t) {
	wlr_text_input_v3 *ti = t->ti;
	if (ti->active_features & WLR_TEXT_INPUT_V3_FEATURE_SURROUNDING_TEXT) {
		wlr_input_method_v2_send_surrounding_text(im, ti->current.surrounding.text ? ti->current.surrounding.text : "",
			ti->current.surrounding.cursor, ti->current.surrounding.anchor);
	}
	wlr_input_method_v2_send_text_change_cause(im, ti->current.text_change_cause);
	if (ti->active_features & WLR_TEXT_INPUT_V3_FEATURE_CONTENT_TYPE) {
		wlr_input_method_v2_send_content_type(im, ti->current.content_type.hint, ti->current.content_type.purpose);
	}
	wlr_input_method_v2_send_done(im);
}

// The candidate list goes just under the text cursor.
void Extras::place_im_popups() {
	if (im_popups.empty()) return;
	wlr_text_input_v3 *ti = active_ti ? active_ti->ti : nullptr;
	int x = 0, y = 0;
	wlr_box cursor_box{0, 0, 1, 1};
	bool known = false;
	if (ti && ti->focused_surface) {
		if (View *v = s->view_for_surface(ti->focused_surface)) {
			wlr_scene_node_coords(&v->content->node, &x, &y);
			known = true;
		}
		if (ti->active_features & WLR_TEXT_INPUT_V3_FEATURE_CURSOR_RECTANGLE) {
			cursor_box = ti->current.cursor_rectangle;
		}
	}
	for (ImPopup *p : im_popups) {
		if (!p->popup->surface->mapped) continue;
		if (!known) {
			wlr_scene_node_set_enabled(&p->tree->node, false);
			continue;
		}
		const int px = x + cursor_box.x, py = y + cursor_box.y + cursor_box.height;
		wlr_scene_node_set_position(&p->tree->node, px, py);
		wlr_scene_node_set_enabled(&p->tree->node, true);
		wlr_box rel{0, -cursor_box.height, cursor_box.width, cursor_box.height};
		wlr_input_popup_surface_v2_send_text_input_rectangle(p->popup, &rel);
	}
}

void Extras::handle_new_text_input(void *data) {
	tis.push_back(new TextInput(this, static_cast<wlr_text_input_v3 *>(data)));
}

void Extras::handle_new_input_method(void *data) {
	auto *m = static_cast<wlr_input_method_v2 *>(data);
	if (im) {
		wlr_input_method_v2_send_unavailable(m);   // one at a time
		return;
	}
	im = m;
	on_im_commit.connect<&Extras::handle_im_commit>(&m->events.commit, this);
	on_im_grab.connect<&Extras::handle_im_grab>(&m->events.grab_keyboard, this);
	on_im_new_popup.connect<&Extras::handle_im_new_popup>(&m->events.new_popup_surface, this);
	on_im_destroy.connect<&Extras::handle_im_destroy>(&m->events.destroy, this);
	if (active_ti) {
		wlr_input_method_v2_send_activate(im);
		send_im_state(active_ti);
	}
}

void Extras::handle_im_commit(void *) {
	if (!active_ti || !im) return;
	wlr_text_input_v3 *ti = active_ti->ti;
	if (im->current.preedit.text) {
		wlr_text_input_v3_send_preedit_string(ti, im->current.preedit.text, im->current.preedit.cursor_begin,
			im->current.preedit.cursor_end);
	}
	if (im->current.commit_text) {
		wlr_text_input_v3_send_commit_string(ti, im->current.commit_text);
	}
	if (im->current.delete_.before_length || im->current.delete_.after_length) {
		wlr_text_input_v3_send_delete_surrounding_text(ti, im->current.delete_.before_length,
			im->current.delete_.after_length);
	}
	wlr_text_input_v3_send_done(ti);
}

void Extras::handle_im_grab(void *data) {
	grab = static_cast<wlr_input_method_keyboard_grab_v2 *>(data);
	if (wlr_keyboard *kb = wlr_seat_get_keyboard(s->seat)) {
		wlr_input_method_keyboard_grab_v2_set_keyboard(grab, kb);
	}
	on_grab_destroy.connect<&Extras::handle_grab_destroy>(&grab->events.destroy, this);
}

void Extras::handle_grab_destroy(void *) {
	on_grab_destroy.disconnect();
	grab = nullptr;
	// Keys pressed while the input method had them: the app gets the state back.
	if (wlr_keyboard *kb = wlr_seat_get_keyboard(s->seat)) {
		wlr_seat_keyboard_notify_modifiers(s->seat, &kb->modifiers);
	}
}

void Extras::handle_im_new_popup(void *data) {
	im_popups.push_back(new ImPopup(this, static_cast<wlr_input_popup_surface_v2 *>(data)));
	place_im_popups();
}

void Extras::handle_im_destroy(void *) {
	on_im_commit.disconnect();
	on_im_grab.disconnect();
	on_im_new_popup.disconnect();
	on_im_destroy.disconnect();
	on_grab_destroy.disconnect();
	grab = nullptr;
	im = nullptr;
	if (active_ti) {
		// Whatever was half-typed goes away with it.
		wlr_text_input_v3_send_preedit_string(active_ti->ti, nullptr, 0, 0);
		wlr_text_input_v3_send_done(active_ti->ti);
	}
}

void extras_keyboard_focus(Server *s, wlr_surface *surface) {
	Extras *ex = s->extras;
	if (!ex) return;
	for (TextInput *t : ex->tis) {
		wlr_text_input_v3 *ti = t->ti;
		if (ti->focused_surface && ti->focused_surface != surface) {
			if (ex->active_ti == t) {
				ex->active_ti = nullptr;
				if (ex->im) {
					wlr_input_method_v2_send_deactivate(ex->im);
					wlr_input_method_v2_send_done(ex->im);
				}
			}
			wlr_text_input_v3_send_leave(ti);
		}
		if (surface && !ti->focused_surface &&
				wl_resource_get_client(surface->resource) == wl_resource_get_client(ti->resource)) {
			wlr_text_input_v3_send_enter(ti, surface);
		}
	}
}

bool extras_key_to_input_method(Server *s, Keyboard *k, wlr_keyboard_key_event *ev) {
	Extras *ex = s->extras;
	// Keys from programs (the input method's own replies come this way) go
	// straight to the app.
	if (!ex || !ex->grab || k->is_virtual || !ex->active_ti) return false;
	wlr_input_method_keyboard_grab_v2_set_keyboard(ex->grab, k->keyboard);
	wlr_input_method_keyboard_grab_v2_send_key(ex->grab, ev->time_msec, ev->keycode, ev->state);
	return true;
}

bool extras_modifiers_to_input_method(Server *s, Keyboard *k) {
	Extras *ex = s->extras;
	if (!ex || !ex->grab || k->is_virtual || !ex->active_ti) return false;
	wlr_input_method_keyboard_grab_v2_set_keyboard(ex->grab, k->keyboard);
	wlr_input_method_keyboard_grab_v2_send_modifiers(ex->grab, &k->keyboard->modifiers);
	return true;
}

// ---------------------------------------------------------------------------
// Accessibility: sticky keys and bounce keys
// ---------------------------------------------------------------------------

bool extras_key_filter(Server *s, Keyboard *k, wlr_keyboard_key_event *ev) {
	Extras *ex = s->extras;
	if (!ex || k->is_virtual) return false;
	const bool pressed = ev->state == WL_KEYBOARD_KEY_STATE_PRESSED;
	const double now = now_msec();

	// Bounce keys: a key that bounces (pressed again straight after) counts once.
	if (s->config.bounce_keys > 0) {
		if (pressed) {
			auto it = ex->released_at.find(ev->keycode);
			if (it != ex->released_at.end() && now - it->second < s->config.bounce_keys) {
				ex->bounced.insert(ev->keycode);
				return true;
			}
		} else {
			ex->released_at[ev->keycode] = now;
			if (ex->bounced.erase(ev->keycode)) return true;
		}
	}

	// Sticky keys: Shift, Ctrl, Alt or Super pressed and let go on its own
	// stays on for the next key.
	if (s->config.sticky_keys && k->keyboard->keymap) {
		const xkb_keysym_t sym = xkb_state_key_get_one_sym(k->keyboard->xkb_state, ev->keycode + 8);
		const char *mod = nullptr;
		switch (sym) {
		case XKB_KEY_Shift_L: case XKB_KEY_Shift_R: mod = XKB_MOD_NAME_SHIFT; break;
		case XKB_KEY_Control_L: case XKB_KEY_Control_R: mod = XKB_MOD_NAME_CTRL; break;
		case XKB_KEY_Alt_L: case XKB_KEY_Alt_R: mod = XKB_MOD_NAME_ALT; break;
		case XKB_KEY_Super_L: case XKB_KEY_Super_R: mod = XKB_MOD_NAME_LOGO; break;
		default: break;
		}
		if (mod) {
			const xkb_mod_index_t idx = xkb_keymap_mod_get_index(k->keyboard->keymap, mod);
			const xkb_mod_mask_t bit = idx == XKB_MOD_INVALID ? 0 : (1u << idx);
			if (pressed) {
				ex->sticky_pending = bit;
				ex->sticky_other = false;
			} else if (ex->sticky_pending == bit && !ex->sticky_other && bit) {
				ex->sticky_pending = 0;
				const wlr_keyboard_modifiers m = k->keyboard->modifiers;
				// Latched: on for the next key only. Tapped twice: locked on.
				const bool again = m.latched & bit;
				wlr_keyboard_notify_modifiers(k->keyboard, m.depressed, again ? (m.latched & ~bit) : (m.latched | bit),
					again ? (m.locked | bit) : (m.locked & ~bit), m.group);
			}
		} else if (pressed) {
			ex->sticky_other = true;
			ex->sticky_pending = 0;
		}
	}
	return false;
}

// ---------------------------------------------------------------------------
// Touchscreens and pens
// ---------------------------------------------------------------------------

void Extras::fake_move(double lx, double ly, uint32_t time) {
	wlr_cursor_warp_closest(s->cursor, nullptr, lx, ly);
	s->process_motion(time);
}

void Extras::fake_button(uint32_t time, uint32_t button, bool pressed) {
	wlr_pointer_button_event ev{};
	ev.pointer = nullptr;
	ev.time_msec = time;
	ev.button = button;
	ev.state = pressed ? WL_POINTER_BUTTON_STATE_PRESSED : WL_POINTER_BUTTON_STATE_RELEASED;
	s->handle_cursor_button(&ev);
	wlr_seat_pointer_notify_frame(s->seat);
}

void Extras::handle_touch_down(void *data) {
	auto *e = static_cast<wlr_touch_down_event *>(data);
	s->note_activity();
	double lx = 0, ly = 0;
	wlr_cursor_absolute_to_layout_coords(s->cursor, &e->touch->base, e->x, e->y, &lx, &ly);
	Touch t;
	if (s->locked() && !locked) {
		// Nova's own lock screen: a tap is a click.
	} else if (locked) {
		double sx = 0, sy = 0;
		if (wlr_surface *surface = lock_surface_at(s, lx, ly, &sx, &sy)) {
			t.surface = surface;
			t.ox = lx - sx;
			t.oy = ly - sy;
		}
	} else {
		Hit hit = s->hit_test(lx, ly);
		if (hit.surface && hit.region == Region::Content && !(s->overview && s->overview->is_open())) {
			t.surface = hit.surface;
			t.ox = lx - hit.sx;
			t.oy = ly - hit.sy;
			if (hit.view && hit.view != s->focused) s->focus(hit.view);
			if (hit.layer) extras_layer_clicked(s, hit.surface);
		}
	}
	if (t.surface) {
		touches[e->touch_id] = t;
		wlr_seat_touch_notify_down(s->seat, t.surface, e->time_msec, e->touch_id, lx - t.ox, ly - t.oy);
		return;
	}
	// Nova's own things (panels, menus, title bars): the first finger is a mouse.
	touches[e->touch_id] = t;
	if (pointer_touch < 0) {
		pointer_touch = e->touch_id;
		fake_move(lx, ly, e->time_msec);
		fake_button(e->time_msec, BTN_LEFT, true);
	}
}

void Extras::handle_touch_motion(void *data) {
	auto *e = static_cast<wlr_touch_motion_event *>(data);
	auto it = touches.find(e->touch_id);
	if (it == touches.end()) return;
	double lx = 0, ly = 0;
	wlr_cursor_absolute_to_layout_coords(s->cursor, &e->touch->base, e->x, e->y, &lx, &ly);
	if (it->second.surface) {
		wlr_seat_touch_notify_motion(s->seat, e->time_msec, e->touch_id, lx - it->second.ox, ly - it->second.oy);
	} else if (e->touch_id == pointer_touch) {
		fake_move(lx, ly, e->time_msec);
	}
}

void Extras::handle_touch_up(void *data) {
	auto *e = static_cast<wlr_touch_up_event *>(data);
	auto it = touches.find(e->touch_id);
	if (it == touches.end()) return;
	if (it->second.surface) {
		wlr_seat_touch_notify_up(s->seat, e->time_msec, e->touch_id);
	} else if (e->touch_id == pointer_touch) {
		fake_button(e->time_msec, BTN_LEFT, false);
		pointer_touch = -1;
	}
	touches.erase(it);
}

void Extras::handle_touch_cancel(void *data) {
	auto *e = static_cast<wlr_touch_cancel_event *>(data);
	wlr_touch_up_event up{};
	up.touch = e->touch;
	up.time_msec = e->time_msec;
	up.touch_id = e->touch_id;
	handle_touch_up(&up);
}

void Extras::handle_touch_frame(void *) {
	wlr_seat_touch_notify_frame(s->seat);
}

Extras::Tool &Extras::tool_for(wlr_tablet_tool *tool, wlr_tablet *tablet) {
	Tool &t = tools[tool];
	if (!t.v2 && tablets) t.v2 = wlr_tablet_tool_create(tablets, s->seat, tool);
	if (!t.tablet && tablet) t.tablet = static_cast<wlr_tablet_v2_tablet *>(tablet->base.data);
	return t;
}

// The pen moved: to a window that understands pens, or as a mouse.
void Extras::tool_moved(Tool &t, uint32_t time) {
	const double lx = s->cursor->x, ly = s->cursor->y;
	if (t.down && t.over) {
		// Drawing: everything goes to the window it started in.
		wlr_send_tablet_v2_tablet_tool_motion(t.v2, lx - t.ox, ly - t.oy);
		return;
	}
	wlr_surface *surface = nullptr;
	double sx = 0, sy = 0;
	if (!s->locked()) {
		Hit hit = s->hit_test(lx, ly);
		if (hit.surface && hit.region == Region::Content) {
			surface = hit.surface;
			sx = hit.sx;
			sy = hit.sy;
		}
	}
	const bool pen_aware = surface && t.v2 && t.tablet && wlr_surface_accepts_tablet_v2(surface, t.tablet);
	if (!pen_aware) {
		if (t.over) {
			wlr_send_tablet_v2_tablet_tool_proximity_out(t.v2);
			t.over = nullptr;
		}
		s->process_motion(time);   // a mouse, for everything else
		return;
	}
	if (t.over != surface) {
		if (t.over) wlr_send_tablet_v2_tablet_tool_proximity_out(t.v2);
		wlr_send_tablet_v2_tablet_tool_proximity_in(t.v2, t.tablet, surface);
		t.over = surface;
	}
	t.ox = lx - sx;
	t.oy = ly - sy;
	wlr_send_tablet_v2_tablet_tool_motion(t.v2, sx, sy);
}

void Extras::handle_tool_proximity(void *data) {
	auto *e = static_cast<wlr_tablet_tool_proximity_event *>(data);
	s->note_activity();
	Tool &t = tool_for(e->tool, e->tablet);
	if (e->state == WLR_TABLET_TOOL_PROXIMITY_OUT) {
		if (t.over) wlr_send_tablet_v2_tablet_tool_proximity_out(t.v2);
		t.over = nullptr;
		if (t.mouse_down) {
			fake_button(e->time_msec, BTN_LEFT, false);
			t.mouse_down = false;
		}
		return;
	}
	wlr_cursor_warp_absolute(s->cursor, &e->tablet->base, e->x, e->y);
	tool_moved(t, e->time_msec);
}

void Extras::handle_tool_axis(void *data) {
	auto *e = static_cast<wlr_tablet_tool_axis_event *>(data);
	s->note_activity();
	Tool &t = tool_for(e->tool, e->tablet);
	if (e->updated_axes & (WLR_TABLET_TOOL_AXIS_X | WLR_TABLET_TOOL_AXIS_Y)) {
		wlr_cursor_warp_absolute(s->cursor, &e->tablet->base,
			(e->updated_axes & WLR_TABLET_TOOL_AXIS_X) ? e->x : NAN,
			(e->updated_axes & WLR_TABLET_TOOL_AXIS_Y) ? e->y : NAN);
		tool_moved(t, e->time_msec);
	}
	if (!t.over) return;
	if (e->updated_axes & WLR_TABLET_TOOL_AXIS_PRESSURE) wlr_send_tablet_v2_tablet_tool_pressure(t.v2, e->pressure);
	if (e->updated_axes & WLR_TABLET_TOOL_AXIS_DISTANCE) wlr_send_tablet_v2_tablet_tool_distance(t.v2, e->distance);
	if (e->updated_axes & (WLR_TABLET_TOOL_AXIS_TILT_X | WLR_TABLET_TOOL_AXIS_TILT_Y)) {
		wlr_send_tablet_v2_tablet_tool_tilt(t.v2, e->tilt_x, e->tilt_y);
	}
	if (e->updated_axes & WLR_TABLET_TOOL_AXIS_ROTATION) wlr_send_tablet_v2_tablet_tool_rotation(t.v2, e->rotation);
	if (e->updated_axes & WLR_TABLET_TOOL_AXIS_SLIDER) wlr_send_tablet_v2_tablet_tool_slider(t.v2, e->slider);
}

void Extras::handle_tool_tip(void *data) {
	auto *e = static_cast<wlr_tablet_tool_tip_event *>(data);
	s->note_activity();
	Tool &t = tool_for(e->tool, e->tablet);
	const bool down = e->state == WLR_TABLET_TOOL_TIP_DOWN;
	if (t.over) {
		if (down) {
			wlr_send_tablet_v2_tablet_tool_down(t.v2);
			if (View *v = s->view_for_surface(t.over)) {
				if (v != s->focused) s->focus(v);
			}
		} else {
			wlr_send_tablet_v2_tablet_tool_up(t.v2);
		}
		t.down = down;
		return;
	}
	// A mouse click for Nova's own things and apps that don't know pens.
	if (down != t.mouse_down) {
		fake_button(e->time_msec, BTN_LEFT, down);
		t.mouse_down = down;
	}
}

void Extras::handle_tool_button(void *data) {
	auto *e = static_cast<wlr_tablet_tool_button_event *>(data);
	Tool &t = tool_for(e->tool, e->tablet);
	const bool pressed = static_cast<int>(e->state) == 1;
	if (t.over) {
		wlr_send_tablet_v2_tablet_tool_button(t.v2, e->button,
			static_cast<zwp_tablet_pad_v2_button_state>(pressed ? 1 : 0));
		return;
	}
	// The pen's side buttons: right and middle click.
	fake_button(e->time_msec, e->button == BTN_STYLUS2 ? BTN_MIDDLE : BTN_RIGHT, pressed);
}

bool extras_new_input(Server *s, wlr_input_device *device) {
	Extras *ex = s->extras;
	if (!ex) return false;
	switch (device->type) {
	case WLR_INPUT_DEVICE_TOUCH: {
		wlr_cursor_attach_input_device(s->cursor, device);
		// A touchscreen built into a screen touches that screen only.
		wlr_touch *touch = wlr_touch_from_input_device(device);
		for (Output *o : s->outputs) {
			if (touch->output_name && o->name() == touch->output_name) {
				wlr_cursor_map_input_to_output(s->cursor, device, o->output);
			}
		}
		ex->touch_devices++;
		return true;
	}
	case WLR_INPUT_DEVICE_TABLET:
		wlr_cursor_attach_input_device(s->cursor, device);
		if (ex->tablets) device->data = wlr_tablet_create(ex->tablets, s->seat, device);
		return true;
	case WLR_INPUT_DEVICE_TABLET_PAD:
		return true;   // pad buttons: not yet
	default:
		return false;
	}
}

uint32_t extras_seat_caps(Server *s) {
	return s->extras && s->extras->touch_devices > 0 ? WL_SEAT_CAPABILITY_TOUCH : 0;
}

// ---------------------------------------------------------------------------
// Set-up
// ---------------------------------------------------------------------------

namespace {

// Privileged protocols sandboxed apps (Flatpak) don't get: these can read
// the screen or other apps' windows, type for you, or cover the screen.
bool privileged(const char *name) {
	static const char *const list[] = {
		"zwlr_layer_shell_v1", "ext_session_lock_manager_v1", "zwlr_foreign_toplevel_manager_v1",
		"ext_foreign_toplevel_list_v1", "zwlr_output_manager_v1", "zwlr_output_power_manager_v1",
		"zwlr_gamma_control_manager_v1", "zwlr_screencopy_manager_v1", "zwlr_data_control_manager_v1",
		"ext_data_control_manager_v1", "zwp_virtual_keyboard_manager_v1", "zwlr_virtual_pointer_manager_v1",
		"zwp_input_method_manager_v2", "ext_image_copy_capture_manager_v1",
		"ext_output_image_capture_source_manager_v1", "wp_security_context_manager_v1",
	};
	for (const char *p : list) {
		if (std::strcmp(p, name) == 0) return true;
	}
	return false;
}

bool global_filter(const wl_client *client, const wl_global *global, void *data) {
	auto *s = static_cast<Server *>(data);
	const char *name = wl_global_get_interface(global)->name;
#ifdef NOVA_XWAYLAND
	// Xwayland's own protocol: for Xwayland only.
	if (std::strcmp(name, "xwayland_shell_v1") == 0) {
		return s->xwayland && s->xwayland->server && client == s->xwayland->server->client;
	}
#endif
	if (s->extras && s->extras->security &&
			wlr_security_context_manager_v1_lookup_client(s->extras->security, client) != nullptr) {
		return !privileged(name);
	}
	return true;
}

} // namespace

Extras *extras_create(Server *s) {
	auto *ex = new Extras{};
	ex->s = s;
	s->extras = ex;
	wl_display *d = s->display;

	ex->layer_shell = wlr_layer_shell_v1_create(d, 4);
	ex->on_new_layer.connect<&Extras::handle_new_layer>(&ex->layer_shell->events.new_surface, ex);

	ex->lock_manager = wlr_session_lock_manager_v1_create(d);
	ex->on_new_lock.connect<&Extras::handle_new_lock>(&ex->lock_manager->events.new_lock, ex);

	ex->toplevel_manager = wlr_foreign_toplevel_manager_v1_create(d);
	ex->toplevel_list = wlr_ext_foreign_toplevel_list_v1_create(d, 1);

	ex->output_manager = wlr_output_manager_v1_create(d);
	ex->on_output_apply.connect<&Extras::handle_output_apply>(&ex->output_manager->events.apply, ex);
	ex->on_output_test.connect<&Extras::handle_output_test>(&ex->output_manager->events.test, ex);
	ex->on_layout_change.connect<&Extras::handle_layout_change>(&s->layout->events.change, ex);
	ex->output_power = wlr_output_power_manager_v1_create(d);
	ex->on_power_set_mode.connect<&Extras::handle_power_set_mode>(&ex->output_power->events.set_mode, ex);
	ex->gamma = wlr_gamma_control_manager_v1_create(d);
	ex->on_set_gamma.connect<&Extras::handle_set_gamma>(&ex->gamma->events.set_gamma, ex);

	// Screen capture through the newer protocol too (xdg-desktop-portal-wlr
	// 0.8: screen sharing in browsers, Discord and OBS).
	wlr_ext_image_copy_capture_manager_v1_create(d, 1);
	wlr_ext_output_image_capture_source_manager_v1_create(d, 1);

	ex->content_type = wlr_content_type_manager_v1_create(d, 1);
	ex->security = wlr_security_context_manager_v1_create(d);
	wl_display_set_global_filter(d, global_filter, s);

	ex->text_inputs = wlr_text_input_manager_v3_create(d);
	ex->on_new_text_input.connect<&Extras::handle_new_text_input>(&ex->text_inputs->events.new_text_input, ex);
	ex->input_methods = wlr_input_method_manager_v2_create(d);
	ex->on_new_input_method.connect<&Extras::handle_new_input_method>(&ex->input_methods->events.new_input_method, ex);

	ex->on_touch_down.connect<&Extras::handle_touch_down>(&s->cursor->events.touch_down, ex);
	ex->on_touch_up.connect<&Extras::handle_touch_up>(&s->cursor->events.touch_up, ex);
	ex->on_touch_motion.connect<&Extras::handle_touch_motion>(&s->cursor->events.touch_motion, ex);
	ex->on_touch_cancel.connect<&Extras::handle_touch_cancel>(&s->cursor->events.touch_cancel, ex);
	ex->on_touch_frame.connect<&Extras::handle_touch_frame>(&s->cursor->events.touch_frame, ex);

	ex->tablets = wlr_tablet_v2_create(d);
	ex->on_tool_axis.connect<&Extras::handle_tool_axis>(&s->cursor->events.tablet_tool_axis, ex);
	ex->on_tool_proximity.connect<&Extras::handle_tool_proximity>(&s->cursor->events.tablet_tool_proximity, ex);
	ex->on_tool_tip.connect<&Extras::handle_tool_tip>(&s->cursor->events.tablet_tool_tip, ex);
	ex->on_tool_button.connect<&Extras::handle_tool_button>(&s->cursor->events.tablet_tool_button, ex);
	return ex;
}

} // namespace nova
