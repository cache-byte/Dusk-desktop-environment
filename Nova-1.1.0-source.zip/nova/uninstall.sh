#!/usr/bin/env bash
# Removes Nova (your settings in ~/.config/nova are kept unless you say otherwise).
cd "$(dirname "$0")" && exec bash ./build.sh uninstall "$@"
