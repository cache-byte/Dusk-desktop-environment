// Keyboards, pointers, cursor, seat requests, pointer constraints.
#include "ipc.hpp"
#include "server.hpp"

#include <algorithm>
#include <fstream>
#include <sys/stat.h>

// Lock-key state lives in $XDG_STATE_HOME/nova/locks ("caps=0 num=1").
static std::string locks_path() {
    const char *x = getenv("XDG_STATE_HOME");
    std::string base = x && *x ? x : std::string(getenv("HOME") ? getenv("HOME") : "/tmp") + "/.local/state";
    mkdir(base.c_str(), 0755);
    mkdir((base + "/nova").c_str(), 0755);
    return base + "/nova/locks";
}
#include <cmath>

// --------------------------------------------------------------- keyboard --
void Server::apply_keymap(Keyboard *k) {
    xkb_rule_names names{};
    auto opt = [](const std::string &s) -> const char * { return s.empty() ? nullptr : s.c_str(); };
    names.layout = opt(config.kb_layout);
    names.variant = opt(config.kb_variant);
    names.options = opt(config.kb_options);
    names.model = opt(config.kb_model);

    xkb_context *ctx = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
    xkb_keymap *km = xkb_keymap_new_from_names(ctx, &names, XKB_KEYMAP_COMPILE_NO_FLAGS);
    if (!km) {
        wlr_log(WLR_ERROR, "invalid keyboard layout '%s', falling back to defaults", config.kb_layout.c_str());
        xkb_rule_names def{};
        km = xkb_keymap_new_from_names(ctx, &def, XKB_KEYMAP_COMPILE_NO_FLAGS);
    }
    wlr_keyboard_set_keymap(k->kb, km);
    wlr_keyboard_set_repeat_info(k->kb, config.repeat_rate, config.repeat_delay);

    // Num Lock on by default; with remember_locks, restore what was set last time.
    bool want_num = true, want_caps = false;
    if (config.remember_locks) {
        std::ifstream in(locks_path());
        std::string tok;
        while (in >> tok) {
            if (tok == "caps=1") want_caps = true;
            if (tok == "num=0") want_num = false;
        }
    }
    xkb_mod_index_t num = xkb_keymap_mod_get_index(km, XKB_MOD_NAME_NUM);
    xkb_mod_index_t caps = xkb_keymap_mod_get_index(km, XKB_MOD_NAME_CAPS);
    uint32_t locked = k->kb->modifiers.locked;
    if (num != XKB_MOD_INVALID && want_num) locked |= 1u << num;
    if (caps != XKB_MOD_INVALID && want_caps) locked |= 1u << caps;
    wlr_keyboard_modifiers m = k->kb->modifiers;
    wlr_keyboard_notify_modifiers(k->kb, m.depressed, m.latched, locked, m.group);
    xkb_keymap_unref(km);
    xkb_context_unref(ctx);
}

void Server::update_leds(Keyboard *k) {
    if (!k->kb->xkb_state) return;
    bool caps = xkb_state_led_name_is_active(k->kb->xkb_state, XKB_LED_NAME_CAPS) > 0;
    bool num = xkb_state_led_name_is_active(k->kb->xkb_state, XKB_LED_NAME_NUM) > 0;
    if (caps == caps_on && num == num_on) return;
    caps_on = caps;
    num_on = num;
    if (config.remember_locks) std::ofstream(locks_path()) << "caps=" << caps << " num=" << num << "\n";
    if (ipc)
        ipc->broadcast(std::string("{\"event\":\"leds\",\"caps\":") + (caps ? "true" : "false") +
                       ",\"num\":" + (num ? "true" : "false") + "}");
}

bool Server::handle_binding(uint32_t mods, xkb_keysym_t sym) {
    sym = xkb_keysym_to_lower(sym);
    uint32_t mask = mods & (WLR_MODIFIER_SHIFT | WLR_MODIFIER_CTRL | WLR_MODIFIER_ALT | WLR_MODIFIER_LOGO);
    for (const Binding &b : config.binds) {
        if (b.mods == mask && b.sym == sym) {
            if (locked && !b.when_locked) return false;
            run_action(b.action);
            return true;
        }
    }
    return false;
}

void Server::add_keyboard(wlr_input_device *dev) {
    auto k = std::make_unique<Keyboard>();
    Keyboard *kp = k.get();
    kp->server = this;
    kp->kb = wlr_keyboard_from_input_device(dev);
    apply_keymap(kp);

    kp->modifiers.connect(&kp->kb->events.modifiers, [this, kp](void *) {
        wlr_seat_set_keyboard(seat, kp->kb);
        wlr_seat_keyboard_notify_modifiers(seat, &kp->kb->modifiers);
        update_leds(kp);
    });
    kp->key.connect(&kp->kb->events.key, [this, kp](void *data) {
        auto *e = static_cast<wlr_keyboard_key_event *>(data);
        wlr_idle_notifier_v1_notify_activity(idle_notifier, seat);
        uint32_t keycode = e->keycode + 8;
        bool handled = false;

        // ---- Super tap (press + release with nothing in between) ----
        {
            const xkb_keysym_t *raw;
            int rn = xkb_state_key_get_syms(kp->kb->xkb_state, keycode, &raw);
            bool is_super = false;
            for (int i = 0; i < rn; i++)
                if (raw[i] == XKB_KEY_Super_L || raw[i] == XKB_KEY_Super_R) is_super = true;
            if (e->state == WL_KEYBOARD_KEY_STATE_PRESSED) {
                uint32_t others = wlr_keyboard_get_modifiers(kp->kb) &
                                  (WLR_MODIFIER_SHIFT | WLR_MODIFIER_CTRL | WLR_MODIFIER_ALT);
                if (is_super && !others && !config.super_tap_action.empty()) {
                    super_tap_armed = true;
                    super_tap_time = e->time_msec;
                } else {
                    super_tap_armed = false;   // Super+anything is a chord, not a tap
                }
            } else if (is_super && super_tap_armed) {
                super_tap_armed = false;
                if (!locked && e->time_msec - super_tap_time <= (uint32_t)config.super_tap_ms)
                    run_action(config.super_tap_action);
                // The release is still forwarded so clients never see a stuck Super.
            }
        }

        if (e->state == WL_KEYBOARD_KEY_STATE_PRESSED) {
            xkb_state *st = kp->kb->xkb_state;
            // VT switching (Ctrl+Alt+F1..F12) uses the translated symbol.
            const xkb_keysym_t *tsyms;
            int tn = xkb_state_key_get_syms(st, keycode, &tsyms);
            for (int i = 0; i < tn; i++) {
                if (tsyms[i] >= XKB_KEY_XF86Switch_VT_1 && tsyms[i] <= XKB_KEY_XF86Switch_VT_12 && session) {
                    wlr_session_change_vt(session, tsyms[i] - XKB_KEY_XF86Switch_VT_1 + 1);
                    handled = true;
                }
            }
            // Bindings match the unshifted (level 0) symbol so "Super+Shift+1" works on any layout.
            if (!handled) {
                const xkb_keysym_t *syms;
                xkb_layout_index_t layout = xkb_state_key_get_layout(st, keycode);
                int n = xkb_keymap_key_get_syms_by_level(kp->kb->keymap, keycode, layout, 0, &syms);
                uint32_t mods = wlr_keyboard_get_modifiers(kp->kb);
                for (int i = 0; i < n && !handled; i++) handled = handle_binding(mods, syms[i]);
            }
        }
        if (!handled) {
            wlr_seat_set_keyboard(seat, kp->kb);
            wlr_seat_keyboard_notify_key(seat, e->time_msec, e->keycode, e->state);
        }
    });
    kp->destroy.connect(&dev->events.destroy, [this, kp](void *) {
        // Copy captures to locals first: removing kp destroys this very closure.
        Server *srv = this;
        Keyboard *victim = kp;
        srv->keyboards.remove_if([victim](const std::unique_ptr<Keyboard> &x) { return x.get() == victim; });
        uint32_t caps = WL_SEAT_CAPABILITY_POINTER;
        if (!srv->keyboards.empty()) caps |= WL_SEAT_CAPABILITY_KEYBOARD;
        wlr_seat_set_capabilities(srv->seat, caps);
    });

    wlr_seat_set_keyboard(seat, kp->kb);
    keyboards.push_back(std::move(k));
    update_leds(kp);
}

// ---------------------------------------------------------------- pointer --
void Server::add_pointer(wlr_input_device *dev) {
    apply_pointer_config(dev);
    wlr_cursor_attach_input_device(cursor, dev);
    // remember it so Settings changes (tap to click, scrolling, speed) apply without logging out
    struct Watch { Listener destroy; };
    auto *w = new Watch;
    pointers.push_back(dev);
    w->destroy.connect(&dev->events.destroy, [this, dev, w](void *) {
        Server *srv = this;
        wlr_input_device *d = dev;
        delete w;
        srv->pointers.erase(std::remove(srv->pointers.begin(), srv->pointers.end(), d), srv->pointers.end());
    });
}

void Server::apply_pointer_config(wlr_input_device *dev) {
    if (wlr_input_device_is_libinput(dev)) {
        libinput_device *ld = wlr_libinput_get_device_handle(dev);
        bool touchpad = libinput_device_config_tap_get_finger_count(ld) > 0;
        if (touchpad) {
            libinput_device_config_tap_set_enabled(
                ld, config.tap_to_click ? LIBINPUT_CONFIG_TAP_ENABLED : LIBINPUT_CONFIG_TAP_DISABLED);
            if (libinput_device_config_scroll_has_natural_scroll(ld))
                libinput_device_config_scroll_set_natural_scroll_enabled(ld, config.natural_scroll);
            if (libinput_device_config_dwt_is_available(ld))
                libinput_device_config_dwt_set_enabled(ld, LIBINPUT_CONFIG_DWT_ENABLED);
        }
        if (libinput_device_config_accel_is_available(ld))
            libinput_device_config_accel_set_speed(ld, config.pointer_accel);
    }
}

void Server::set_cursor_theme(const std::string &theme, int size) {
    if (xcursor) wlr_xcursor_manager_destroy(xcursor);
    xcursor = wlr_xcursor_manager_create(theme.empty() ? nullptr : theme.c_str(), size);
    if (!theme.empty()) setenv("XCURSOR_THEME", theme.c_str(), 1);
    setenv("XCURSOR_SIZE", std::to_string(size).c_str(), 1);
    wlr_cursor_set_xcursor(cursor, xcursor, "default");
}

void Server::check_constraint() {
    wlr_surface *s = seat->keyboard_state.focused_surface;
    wlr_pointer_constraint_v1 *c =
        s ? wlr_pointer_constraints_v1_constraint_for_surface(pointer_constraints, s, seat) : nullptr;
    if (c == active_constraint) return;
    if (active_constraint) wlr_pointer_constraint_v1_send_deactivated(active_constraint);
    active_constraint = c;
    if (c) wlr_pointer_constraint_v1_send_activated(c);
}

void Server::pointer_focus(uint32_t time_msec) {
    wlr_surface *surf = nullptr;
    double sx = 0, sy = 0;
    NodeTag *tag = tag_at(cursor->x, cursor->y, &surf, &sx, &sy);

    if (locked && (!tag || tag->kind != NodeKind::LockSurface)) surf = nullptr;

    if (!surf) {
        wlr_cursor_set_xcursor(cursor, xcursor, "default");
        wlr_seat_pointer_clear_focus(seat);
        return;
    }
    wlr_seat_pointer_notify_enter(seat, surf, sx, sy);
    wlr_seat_pointer_notify_motion(seat, time_msec, sx, sy);

    if (config.focus_follows_mouse && tag && tag->kind == NodeKind::View && !locked) {
        auto *v = static_cast<View *>(tag->ptr);
        if (v != focused_view()) focus_view(v);
    }
}

static void process_grab(Server *s) {
    View *v = s->grab_view;
    if (!v) return;
    wlr_cursor *c = s->cursor;

    if (s->grab == Server::Grab::Move) {
        v->move_to((int)(c->x - s->grab_x), (int)(c->y - s->grab_y));

        // Edge snapping preview: left / right half, top = maximize.
        Output *o = s->output_at(c->x, c->y);
        s->snap = Server::Snap::None;
        if (o) {
            const wlr_box &f = o->full;
            if (c->y <= f.y + 2) s->snap = Server::Snap::Max;
            else if (c->x <= f.x + 2) s->snap = Server::Snap::Left;
            else if (c->x >= f.x + f.width - 3) s->snap = Server::Snap::Right;
        }
        if (s->snap != Server::Snap::None && o) {
            const wlr_box &u = o->usable;
            int g = s->config.gaps;
            wlr_box b = {u.x + g, u.y + g, u.width - 2 * g, u.height - 2 * g};
            if (s->snap == Server::Snap::Left) b.width = u.width / 2 - g - g / 2;
            if (s->snap == Server::Snap::Right) {
                b.x = u.x + u.width / 2 + g / 2;
                b.width = u.width - u.width / 2 - g - g / 2;
            }
            wlr_scene_rect_set_size(s->snap_preview, b.width, b.height);
            wlr_scene_node_set_position(&s->snap_preview->node, b.x, b.y);
            wlr_scene_node_raise_to_top(&s->snap_preview->node);
            wlr_scene_node_set_enabled(&s->snap_preview->node, true);
        } else {
            wlr_scene_node_set_enabled(&s->snap_preview->node, false);
        }
        return;
    }

    // Resize
    double dx = c->x - s->grab_x, dy = c->y - s->grab_y;
    wlr_box b = s->grab_box;
    uint32_t e = s->grab_edges;
    if (e & WLR_EDGE_LEFT) { b.x += (int)dx; b.width -= (int)dx; }
    if (e & WLR_EDGE_RIGHT) b.width += (int)dx;
    if (e & WLR_EDGE_TOP) { b.y += (int)dy; b.height -= (int)dy; }
    if (e & WLR_EDGE_BOTTOM) b.height += (int)dy;

    int minw = 160, minh = 100;
    if (v->kind == View::Kind::Xdg) {
        minw = std::max(minw, v->xdg->current.min_width);
        minh = std::max(minh, v->xdg->current.min_height);
        if (v->xdg->current.max_width > 0) b.width = std::min(b.width, v->xdg->current.max_width);
        if (v->xdg->current.max_height > 0) b.height = std::min(b.height, v->xdg->current.max_height);
    }
    if (b.width < minw) {
        if (e & WLR_EDGE_LEFT) b.x -= minw - b.width;
        b.width = minw;
    }
    if (b.height < minh) {
        if (e & WLR_EDGE_TOP) b.y -= minh - b.height;
        b.height = minh;
    }
    if (v->kind == View::Kind::Xdg) {
        wlr_xdg_toplevel_set_size(v->xdg, b.width, b.height);   // position fixed up on commit
    } else {
        v->configure(b.x, b.y, b.width, b.height);
    }
}

void Server::process_motion(uint32_t time_msec, wlr_input_device *dev, double dx, double dy, double udx,
                            double udy) {
    wlr_idle_notifier_v1_notify_activity(idle_notifier, seat);
    wlr_relative_pointer_manager_v1_send_relative_motion(relative_pointer, seat, (uint64_t)time_msec * 1000, dx, dy,
                                                         udx, udy);

    if (active_constraint && grab == Grab::None && !locked) {
        if (active_constraint->type == WLR_POINTER_CONSTRAINT_V1_LOCKED) return;
        // Confined: refuse motion that would leave the confinement region.
        double ox = cursor->x - seat->pointer_state.sx, oy = cursor->y - seat->pointer_state.sy;
        double nx = cursor->x + dx - ox, ny = cursor->y + dy - oy;
        if (!pixman_region32_contains_point(&active_constraint->region, (int)std::floor(nx), (int)std::floor(ny),
                                            nullptr))
            return;
    }

    wlr_cursor_move(cursor, dev, dx, dy);
    if (Output *o = output_at(cursor->x, cursor->y); o && ipc && pointer_output != o->output->name) {
        pointer_output = o->output->name;
        ipc->broadcast("{\"event\":\"output\",\"name\":\"" + json_escape(pointer_output) + "\"}");
        broadcast_workspaces();
    }
    wlr_scene_node_set_position(&drag_tree->node, (int)cursor->x, (int)cursor->y);

    if (grab != Grab::None) process_grab(this);
    else pointer_focus(time_msec);
}

static void finish_grab(Server *s) {
    if (s->grab == Server::Grab::Move && s->grab_view && s->snap != Server::Snap::None) {
        View *v = s->grab_view;
        if (s->snap == Server::Snap::Max) v->set_maximized(true);
        else v->set_tile(s->snap == Server::Snap::Left ? View::Tile::Left : View::Tile::Right);
    }
    // Dragged onto another monitor: it now belongs to that monitor's current workspace,
    // so it hides and shows with that screen's workspaces.
    if (s->grab == Server::Grab::Move && s->grab_view && s->grab_view->tree) {
        View *v = s->grab_view;
        wlr_box g = v->geometry();
        Output *o = s->output_at(v->x + g.width / 2.0, v->y + g.height / 2.0);
        if (o && o->slot != v->workspace / kWsPerOutput) {
            wlr_scene_node_reparent(&v->tree->node, s->ws_trees[o->active]);
            v->workspace = o->active;
            s->update_fullscreen_layering();
            s->broadcast_workspaces();
        }
    }
    wlr_scene_node_set_enabled(&s->snap_preview->node, false);
    s->snap = Server::Snap::None;
    s->grab = Server::Grab::None;
    s->grab_view = nullptr;
    wlr_cursor_set_xcursor(s->cursor, s->xcursor, "default");
}

void setup_cursor_listeners(Server *s) {
    s->cursor_motion.connect(&s->cursor->events.motion, [s](void *data) {
        auto *e = static_cast<wlr_pointer_motion_event *>(data);
        s->process_motion(e->time_msec, &e->pointer->base, e->delta_x, e->delta_y, e->unaccel_dx, e->unaccel_dy);
    });
    s->cursor_motion_abs.connect(&s->cursor->events.motion_absolute, [s](void *data) {
        auto *e = static_cast<wlr_pointer_motion_absolute_event *>(data);
        double lx, ly;
        wlr_cursor_absolute_to_layout_coords(s->cursor, &e->pointer->base, e->x, e->y, &lx, &ly);
        double dx = lx - s->cursor->x, dy = ly - s->cursor->y;
        s->process_motion(e->time_msec, &e->pointer->base, dx, dy, dx, dy);
    });
    s->cursor_button.connect(&s->cursor->events.button, [s](void *data) {
        auto *e = static_cast<wlr_pointer_button_event *>(data);
        wlr_idle_notifier_v1_notify_activity(s->idle_notifier, s->seat);
        s->super_tap_armed = false;   // Super+drag / Super+click is not a tap

        if (e->state == WL_POINTER_BUTTON_STATE_RELEASED) {
            bool swallow = s->super_grab;
            s->super_grab = false;
            if (s->grab != Server::Grab::None) {
                finish_grab(s);
                s->pointer_focus(e->time_msec);
            }
            if (!swallow) wlr_seat_pointer_notify_button(s->seat, e->time_msec, e->button, e->state);
            return;
        }

        wlr_surface *surf = nullptr;
        double sx, sy;
        NodeTag *tag = s->tag_at(s->cursor->x, s->cursor->y, &surf, &sx, &sy);

        if (s->locked) {
            if (tag && tag->kind == NodeKind::LockSurface && surf) s->focus_surface(surf);
            wlr_seat_pointer_notify_button(s->seat, e->time_msec, e->button, e->state);
            return;
        }

        if (tag && tag->kind == NodeKind::View) {
            auto *v = static_cast<View *>(tag->ptr);
            wlr_keyboard *kb = wlr_seat_get_keyboard(s->seat);
            bool super = kb && (wlr_keyboard_get_modifiers(kb) & WLR_MODIFIER_LOGO);
            if (super && !v->override_redirect()) {
                s->focus_view(v);
                if (e->button == BTN_LEFT) {
                    s->super_grab = true;
                    s->begin_grab(v, Server::Grab::Move, 0);
                    return;
                }
                if (e->button == BTN_RIGHT) {
                    s->super_grab = true;
                    s->begin_grab(v, Server::Grab::Resize, WLR_EDGE_BOTTOM | WLR_EDGE_RIGHT);
                    return;
                }
            }
            if (!v->override_redirect()) s->focus_view(v);
        } else if (tag && tag->kind == NodeKind::Layer) {
            auto *ls = static_cast<LayerSurface *>(tag->ptr);
            if (ls->layer->current.keyboard_interactive != ZWLR_LAYER_SURFACE_V1_KEYBOARD_INTERACTIVITY_NONE) {
                if (View *f = s->focused_view()) f->set_activated(false);
                s->focused_layer = ls->layer->surface;
                s->focus_surface(ls->layer->surface);
            }
        }
        wlr_seat_pointer_notify_button(s->seat, e->time_msec, e->button, e->state);
    });
    s->cursor_axis.connect(&s->cursor->events.axis, [s](void *data) {
        auto *e = static_cast<wlr_pointer_axis_event *>(data);
        wlr_idle_notifier_v1_notify_activity(s->idle_notifier, s->seat);
        s->super_tap_armed = false;
        wlr_seat_pointer_notify_axis(s->seat, e->time_msec, e->orientation, e->delta, e->delta_discrete, e->source,
                                     e->relative_direction);
    });
    s->cursor_frame.connect(&s->cursor->events.frame, [s](void *) { wlr_seat_pointer_notify_frame(s->seat); });

    // ---- touchpad gestures ----
    s->gestures = wlr_pointer_gestures_v1_create(s->display);
    s->swipe_begin.connect(&s->cursor->events.swipe_begin, [s](void *data) {
        auto *e = static_cast<wlr_pointer_swipe_begin_event *>(data);
        s->swipe_ours = e->fingers == 3 && !s->locked && (s->config.gesture_workspaces || s->config.gesture_overview);
        s->swipe_dx = s->swipe_dy = 0;
        if (!s->swipe_ours) wlr_pointer_gestures_v1_send_swipe_begin(s->gestures, s->seat, e->time_msec, e->fingers);
    });
    s->swipe_update.connect(&s->cursor->events.swipe_update, [s](void *data) {
        auto *e = static_cast<wlr_pointer_swipe_update_event *>(data);
        if (s->swipe_ours) { s->swipe_dx += e->dx; s->swipe_dy += e->dy; return; }
        wlr_pointer_gestures_v1_send_swipe_update(s->gestures, s->seat, e->time_msec, e->dx, e->dy);
    });
    s->swipe_end.connect(&s->cursor->events.swipe_end, [s](void *data) {
        auto *e = static_cast<wlr_pointer_swipe_end_event *>(data);
        if (!s->swipe_ours) { wlr_pointer_gestures_v1_send_swipe_end(s->gestures, s->seat, e->time_msec, e->cancelled); return; }
        s->swipe_ours = false;
        if (e->cancelled) return;
        const double ax = std::abs(s->swipe_dx), ay = std::abs(s->swipe_dy);
        if (ax > 120 && ax > ay && s->config.gesture_workspaces)
            s->run_action(s->swipe_dx < 0 ? "workspace next-existing" : "workspace prev-existing");   // fingers move left -> next
        else if (ay > 100 && ay > ax && s->config.gesture_overview)
            s->run_action(s->swipe_dy < 0 ? "shell overview-open" : "shell close");
    });
    s->pinch_begin.connect(&s->cursor->events.pinch_begin, [s](void *data) {
        auto *e = static_cast<wlr_pointer_pinch_begin_event *>(data);
        wlr_pointer_gestures_v1_send_pinch_begin(s->gestures, s->seat, e->time_msec, e->fingers);
    });
    s->pinch_update.connect(&s->cursor->events.pinch_update, [s](void *data) {
        auto *e = static_cast<wlr_pointer_pinch_update_event *>(data);
        wlr_pointer_gestures_v1_send_pinch_update(s->gestures, s->seat, e->time_msec, e->dx, e->dy, e->scale, e->rotation);
    });
    s->pinch_end.connect(&s->cursor->events.pinch_end, [s](void *data) {
        auto *e = static_cast<wlr_pointer_pinch_end_event *>(data);
        wlr_pointer_gestures_v1_send_pinch_end(s->gestures, s->seat, e->time_msec, e->cancelled);
    });
    s->hold_begin.connect(&s->cursor->events.hold_begin, [s](void *data) {
        auto *e = static_cast<wlr_pointer_hold_begin_event *>(data);
        wlr_pointer_gestures_v1_send_hold_begin(s->gestures, s->seat, e->time_msec, e->fingers);
    });
    s->hold_end.connect(&s->cursor->events.hold_end, [s](void *data) {
        auto *e = static_cast<wlr_pointer_hold_end_event *>(data);
        wlr_pointer_gestures_v1_send_hold_end(s->gestures, s->seat, e->time_msec, e->cancelled);
    });

    // ---- seat requests ----
    s->req_cursor.connect(&s->seat->events.request_set_cursor, [s](void *data) {
        auto *e = static_cast<wlr_seat_pointer_request_set_cursor_event *>(data);
        if (s->grab == Server::Grab::None && s->seat->pointer_state.focused_client == e->seat_client)
            wlr_cursor_set_surface(s->cursor, e->surface, e->hotspot_x, e->hotspot_y);
    });
    s->cursor_shape_request.connect(&s->cursor_shape->events.request_set_shape, [s](void *data) {
        auto *e = static_cast<wlr_cursor_shape_manager_v1_request_set_shape_event *>(data);
        if (s->grab == Server::Grab::None && s->seat->pointer_state.focused_client == e->seat_client)
            wlr_cursor_set_xcursor(s->cursor, s->xcursor, wlr_cursor_shape_v1_name(e->shape));
    });
    s->req_selection.connect(&s->seat->events.request_set_selection, [s](void *data) {
        auto *e = static_cast<wlr_seat_request_set_selection_event *>(data);
        wlr_seat_set_selection(s->seat, e->source, e->serial);
    });
    s->req_primary.connect(&s->seat->events.request_set_primary_selection, [s](void *data) {
        auto *e = static_cast<wlr_seat_request_set_primary_selection_event *>(data);
        wlr_seat_set_primary_selection(s->seat, e->source, e->serial);
    });
    s->req_start_drag.connect(&s->seat->events.request_start_drag, [s](void *data) {
        auto *e = static_cast<wlr_seat_request_start_drag_event *>(data);
        if (wlr_seat_validate_pointer_grab_serial(s->seat, e->origin, e->serial))
            wlr_seat_start_pointer_drag(s->seat, e->drag, e->serial);
        else
            wlr_data_source_destroy(e->drag->source);
    });
    s->start_drag.connect(&s->seat->events.start_drag, [s](void *data) {
        auto *drag = static_cast<wlr_drag *>(data);
        if (drag->icon) wlr_scene_drag_icon_create(s->drag_tree, drag->icon);
    });

    // ---- pointer constraints (games, remote desktop) ----
    s->new_constraint.connect(&s->pointer_constraints->events.new_constraint, [s](void *data) {
        auto *c = static_cast<wlr_pointer_constraint_v1 *>(data);
        struct Watch {
            Listener destroy;
        };
        auto *w = new Watch;
        w->destroy.connect(&c->events.destroy, [s, c, w](void *) {
            if (s->active_constraint == c) s->active_constraint = nullptr;
            // Deleting the Watch (and its Listener) from inside its own callback is safe:
            // wl_signal_emit_mutable tolerates removal of the current listener.
            delete w;
        });
        s->check_constraint();
    });
}

void setup_input(Server *s) {
    s->new_input.connect(&s->backend->events.new_input, [s](void *data) {
        auto *dev = static_cast<wlr_input_device *>(data);
        switch (dev->type) {
        case WLR_INPUT_DEVICE_KEYBOARD: s->add_keyboard(dev); break;
        case WLR_INPUT_DEVICE_POINTER: s->add_pointer(dev); break;
        default: break;
        }
        uint32_t caps = WL_SEAT_CAPABILITY_POINTER;
        if (!s->keyboards.empty()) caps |= WL_SEAT_CAPABILITY_KEYBOARD;
        wlr_seat_set_capabilities(s->seat, caps);
    });
    setup_cursor_listeners(s);
}
