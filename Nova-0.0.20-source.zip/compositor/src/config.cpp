// ~/.config/nova/nova.conf parsing, key bindings and actions.
#include "ipc.hpp"
#include "server.hpp"

#include <csignal>
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include <sys/wait.h>

const char *kDefaultConfig = R"(# Nova compositor configuration
# Reload with:  novactl dispatch reload   (or Super+Shift+R)

[general]
terminal = ptyxis
gaps = 8
focus_follows_mouse = false
# Fullscreen games: variable refresh rate and tearing (lowest latency)
vrr = true
tearing = auto

[input]
layout = us
variant =
options =
repeat_rate = 30
repeat_delay = 300
natural_scroll = true
tap_to_click = true
accel = 0
remember_locks = true
# 3-finger swipe left/right = workspace, up = overview
gesture_workspaces = true
gesture_overview = true

[cursor]
theme = Bibata-Modern-Classic
size = 24

[autostart]
exec = nova-shell
# Dim / lock / sleep timers live in the shell (Settings > Power). swayidle only locks before sleep.
exec = swayidle -w before-sleep 'novactl lock' lock 'novactl lock'
exec = /usr/libexec/polkit-gnome-authentication-agent-1
# clipboard history; password managers mark secrets and cliphist skips them
exec = wl-paste --watch cliphist -max-items 200 store

[bindings]
# Apps
Super+Return            = exec $terminal
Super+E                 = exec nautilus
Super                   = shell launcher
Super+Space             = shell launcher
Super+Tab               = shell overview
Super+A                 = shell controlcentre
Super+N                 = shell notifications
Super+V                 = shell clipboard
Super+L                 = lock
Print                   = shell capture
Alt+Print               = exec nova-record shot region
Shift+Print             = exec nova-record shot screen
Ctrl+Print              = exec nova-record shot edit
Super+Shift+S           = exec nova-record shot edit
Super+Shift+R           = exec nova-record toggle screen
Super+Alt+R             = shell save-replay
Super+G                 = shell gameoverlay

# Windows
Super+Q                 = close
Alt+F4                  = close
Super+F                 = fullscreen
Super+Up                = maximize
Super+Down              = restore
Super+Left              = tile-left
Super+Right             = tile-right
Super+H                 = minimize
Alt+Tab                 = cycle
Alt+Shift+Tab           = cycle-reverse

# Workspaces
Super+1 = workspace 1
Super+2 = workspace 2
Super+3 = workspace 3
Super+4 = workspace 4
Super+5 = workspace 5
Super+6 = workspace 6
Super+7 = workspace 7
Super+8 = workspace 8
Super+9 = workspace 9
Super+Shift+1 = move-to-workspace 1
Super+Shift+2 = move-to-workspace 2
Super+Shift+3 = move-to-workspace 3
Super+Shift+4 = move-to-workspace 4
Super+Shift+5 = move-to-workspace 5
Super+Shift+6 = move-to-workspace 6
Super+Shift+7 = move-to-workspace 7
Super+Shift+8 = move-to-workspace 8
Super+Shift+9 = move-to-workspace 9
Super+Ctrl+Right = workspace next
Super+Ctrl+Left  = workspace prev
Super+Shift+O    = move-to-output next

# Hardware keys (these also work on the lock screen)
XF86AudioRaiseVolume    = exec wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%+
XF86AudioLowerVolume    = exec wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-
XF86AudioMute           = exec wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle
XF86AudioMicMute        = exec wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle
XF86MonBrightnessUp     = exec brightnessctl -e set 5%+
XF86MonBrightnessDown   = exec brightnessctl -e set 5%-
XF86AudioPlay           = exec playerctl play-pause
XF86AudioNext           = exec playerctl next
XF86AudioPrev           = exec playerctl previous

# Session
Super+Shift+R           = reload
Super+Shift+E           = exit
)";

std::string Config::path() {
    const char *xdg = getenv("XDG_CONFIG_HOME");
    std::string base = xdg && *xdg ? xdg : std::string(getenv("HOME") ? getenv("HOME") : "/tmp") + "/.config";
    return base + "/nova/nova.conf";
}

static std::string trim(const std::string &s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static bool to_bool(const std::string &v) { return v == "true" || v == "yes" || v == "1" || v == "on"; }

static bool parse_combo(const std::string &combo, uint32_t &mods, xkb_keysym_t &sym) {
    mods = 0;
    std::stringstream ss(combo);
    std::string part, key;
    std::vector<std::string> parts;
    while (std::getline(ss, part, '+')) parts.push_back(trim(part));
    if (parts.empty()) return false;
    key = parts.back();
    parts.pop_back();
    for (auto &m : parts) {
        std::string l;
        for (char c : m) l += (char)tolower((unsigned char)c);
        if (l == "super" || l == "mod4" || l == "logo" || l == "win") mods |= WLR_MODIFIER_LOGO;
        else if (l == "ctrl" || l == "control") mods |= WLR_MODIFIER_CTRL;
        else if (l == "alt" || l == "mod1") mods |= WLR_MODIFIER_ALT;
        else if (l == "shift") mods |= WLR_MODIFIER_SHIFT;
        else return false;
    }
    sym = xkb_keysym_from_name(key.c_str(), XKB_KEYSYM_CASE_INSENSITIVE);
    if (sym == XKB_KEY_NoSymbol) return false;
    sym = xkb_keysym_to_lower(sym);
    return true;
}

void Config::load() {
    std::string p = path();
    std::ifstream in(p);
    std::string text;
    if (!in) {
        // First run: write the defaults so the user has something to edit.
        std::string dir = p.substr(0, p.rfind('/'));
        std::string parent = dir.substr(0, dir.rfind('/'));
        mkdir(parent.c_str(), 0755);
        mkdir(dir.c_str(), 0755);
        std::ofstream(p) << kDefaultConfig;
        text = kDefaultConfig;
    } else {
        std::stringstream buf;
        buf << in.rdbuf();
        text = buf.str();
    }

    *this = Config{};   // reset to defaults
    std::stringstream ss(text);
    std::string line, section;
    int lineno = 0;
    while (std::getline(ss, line)) {
        lineno++;
        line = trim(line);
        if (line.empty() || line[0] == '#' || line[0] == ';') continue;
        if (line.front() == '[' && line.back() == ']') {
            section = line.substr(1, line.size() - 2);
            continue;
        }
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = trim(line.substr(0, eq)), v = trim(line.substr(eq + 1));

        if (section == "general") {
            if (k == "terminal") terminal = v;
            else if (k == "gaps") gaps = std::max(0, atoi(v.c_str()));
            else if (k == "focus_follows_mouse") focus_follows_mouse = to_bool(v);
            else if (k == "vrr") vrr = to_bool(v);
            else if (k == "tearing") tearing = v;
        } else if (section == "input") {
            if (k == "layout") kb_layout = v;
            else if (k == "variant") kb_variant = v;
            else if (k == "options") kb_options = v;
            else if (k == "model") kb_model = v;
            else if (k == "repeat_rate") repeat_rate = atoi(v.c_str());
            else if (k == "repeat_delay") repeat_delay = atoi(v.c_str());
            else if (k == "natural_scroll") natural_scroll = to_bool(v);
            else if (k == "tap_to_click") tap_to_click = to_bool(v);
            else if (k == "accel") pointer_accel = std::clamp(atof(v.c_str()), -1.0, 1.0);
            else if (k == "remember_locks") remember_locks = to_bool(v);
            else if (k == "gesture_workspaces") gesture_workspaces = to_bool(v);
            else if (k == "gesture_overview") gesture_overview = to_bool(v);
            else if (k == "super_tap_ms") super_tap_ms = std::clamp(atoi(v.c_str()), 100, 2000);
        } else if (section.rfind("output ", 0) == 0) {
            std::string name = trim(section.substr(7));
            OutputCfg *oc = nullptr;
            for (auto &p : output_cfgs) if (p.first == name) oc = &p.second;
            if (!oc) { output_cfgs.push_back({name, OutputCfg{}}); oc = &output_cfgs.back().second; }
            if (k == "mode") {   // 2560x1440@144.000
                double r = 0;
                if (sscanf(v.c_str(), "%dx%d@%lf", &oc->width, &oc->height, &r) >= 2) oc->refresh = r;
            } else if (k == "scale") oc->scale = std::clamp(atof(v.c_str()), 1.0, 2.0);
            else if (k == "position") oc->has_pos = sscanf(v.c_str(), "%d,%d", &oc->x, &oc->y) == 2;
            else if (k == "transform") oc->transform = v;
        } else if (section == "cursor") {
            if (k == "theme") cursor_theme = v;
            else if (k == "size") cursor_size = std::max(8, atoi(v.c_str()));
        } else if (section == "autostart") {
            if (k == "exec" && !v.empty()) autostart.push_back(v);
        } else if (section == "bindings") {
            std::string lk;
            for (char c : k) lk += (char)tolower((unsigned char)c);
            if (lk == "super" || lk == "mod4" || lk == "logo" || lk == "win") {
                super_tap_action = v;   // empty value disables the tap
                continue;
            }
            Binding b{};
            if (!parse_combo(k, b.mods, b.sym)) {
                wlr_log(WLR_ERROR, "%s:%d: bad key combo '%s'", p.c_str(), lineno, k.c_str());
                continue;
            }
            b.action = v;
            b.when_locked = k.find("XF86") != std::string::npos;
            binds.push_back(b);
        }
    }
}

// ----------------------------------------------------------------- actions --
void Server::spawn(const std::string &cmd_in) {
    std::string cmd = cmd_in;
    size_t pos;
    while ((pos = cmd.find("$terminal")) != std::string::npos) cmd.replace(pos, 9, config.terminal);

    pid_t pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        setsid();
        sigset_t set;
        sigemptyset(&set);
        sigprocmask(SIG_SETMASK, &set, nullptr);
        signal(SIGPIPE, SIG_DFL);
        signal(SIGCHLD, SIG_DFL);
        // Double fork so the compositor never has to reap.
        if (fork() == 0) {
            execl("/bin/sh", "sh", "-c", cmd.c_str(), (char *)nullptr);
            _exit(127);
        }
        _exit(0);
    }
    waitpid(pid, nullptr, 0);
}

void Server::run_action(const std::string &action_in) {
    std::string action = trim(action_in);
    std::string verb = action.substr(0, action.find(' '));
    std::string arg = action.size() > verb.size() ? trim(action.substr(verb.size())) : "";
    View *f = focused_view();

    if (verb == "exec") spawn(arg);
    else if (verb == "close") { if (f) f->close(); }
    else if (verb == "fullscreen") { if (f) f->set_fullscreen(!f->fullscreen); }
    else if (verb == "maximize") { if (f) f->set_maximized(!f->maximized); }
    else if (verb == "minimize") { if (f) f->set_minimized(true); }
    else if (verb == "restore") {
        if (!f) return;
        if (f->fullscreen) f->set_fullscreen(false);
        else if (f->maximized) f->set_maximized(false);
        else if (f->tile != View::Tile::None) f->set_tile(View::Tile::None);
        else f->set_minimized(true);
    }
    else if (verb == "tile-left") { if (f) f->set_tile(f->tile == View::Tile::Left ? View::Tile::None : View::Tile::Left); }
    else if (verb == "tile-right") { if (f) f->set_tile(f->tile == View::Tile::Right ? View::Tile::None : View::Tile::Right); }
    else if (verb == "workspace") {
        // Numbers are per monitor: "workspace 2" = 2nd workspace of the monitor under the pointer.
        // next / prev are dynamic: you can go one past the last workspace that has windows.
        int cur = current_ws(), base = cur - cur % kWsPerOutput, idx = cur % kWsPerOutput;
        int last = 0;
        for (View *v : views)
            if (v->mapped && v->workspace / kWsPerOutput == base / kWsPerOutput) last = std::max(last, v->workspace % kWsPerOutput);
        if (arg == "next") { if (idx < std::min(last + 1, kWsPerOutput - 1)) switch_workspace(cur + 1); }
        else if (arg == "next-existing") { if (idx < last) switch_workspace(cur + 1); }   // swipes: never into nothing
        else if (arg == "prev" || arg == "prev-existing") { if (idx > 0) switch_workspace(cur - 1); }
        else { int n = atoi(arg.c_str()); if (n >= 1 && n <= kWsPerOutput) switch_workspace(base + n - 1); }
    }
    else if (verb == "move-to-workspace") {
        if (f) {
            int base = f->workspace - f->workspace % kWsPerOutput, n = atoi(arg.c_str());
            if (n >= 1 && n <= kWsPerOutput) move_to_workspace(f, base + n - 1);
        }
    }
    else if (verb == "move-to-output") {   // "move-to-output next": send the focused window to the other monitor
        if (f && outputs.size() > 1) {
            Output *from = output_for_ws(f->workspace), *to = nullptr;
            bool take = false;
            for (auto &o : outputs) { if (take) { to = o.get(); break; } if (o.get() == from) take = true; }
            if (!to) to = outputs.front().get();
            if (to != from) move_to_workspace(f, to->active);
        }
    }
    else if (verb == "cycle") cycle_focus(false);
    else if (verb == "cycle-reverse") cycle_focus(true);
    else if (verb == "shell") { if (ipc) ipc->broadcast("{\"event\":\"shell\",\"action\":\"" + json_escape(arg) + "\"}"); }
    else if (verb == "lock") { if (ipc) ipc->broadcast("{\"event\":\"lock\"}"); }
    else if (verb == "reload") {
        config.load();
        for (auto &k : keyboards) apply_keymap(k.get());
        for (wlr_input_device *d : pointers) apply_pointer_config(d);
        set_cursor_theme(config.cursor_theme, config.cursor_size);
        arrange_all();
        if (ipc) ipc->broadcast("{\"event\":\"reload\"}");
    }
    else if (verb == "cursor") {   // "cursor <theme> <size>" — used by Settings
        std::stringstream ss(arg);
        std::string theme;
        int size = config.cursor_size;
        ss >> theme >> size;
        config.cursor_theme = theme;
        config.cursor_size = size;
        set_cursor_theme(theme, size);
    }
    else if (verb == "focus-window" || verb == "close-window" || verb == "window-to-workspace") {
        // Overview / taskbar helpers. Window ids come from "get windows".
        std::stringstream ss(arg);
        std::string id;
        int ws = 0;
        ss >> id >> ws;
        for (View *v : views) {
            char buf[32];
            snprintf(buf, sizeof buf, "%p", (void *)v);
            if (id != buf) continue;
            if (verb == "close-window") v->close();
            else if (verb == "window-to-workspace") move_to_workspace(v, ws - 1);
            else {
                if (!ws_shown(v->workspace)) switch_workspace(v->workspace);
                if (v->minimized) v->set_minimized(false);
                else focus_view(v);
            }
            break;
        }
    }
    else if (verb == "close-workspace") {
        // Windows on a closed workspace move to the previous one.
        // ids are global (the overview sends base + n - 1); stays on the same monitor
        int ws = atoi(arg.c_str()) - 1;
        if (ws < 0 || ws >= kWorkspaces) return;
        int idx = ws % kWsPerOutput;
        int dest = idx > 0 ? ws - 1 : ws + 1;
        std::vector<View *> move;
        for (View *v : views)
            if (v->workspace == ws) move.push_back(v);
        for (View *v : move) move_to_workspace(v, dest);
        if (ws_shown(ws)) switch_workspace(dest);
    }
    else if (verb == "exit") wl_display_terminate(display);
    else wlr_log(WLR_ERROR, "unknown action '%s'", action.c_str());
}
