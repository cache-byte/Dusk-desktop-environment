// Translucent card with a soft shadow and "fake blur": a blurred copy of the wallpaper,
// lined up with the real one behind the card. Strength = Settings > Appearance > Blur.
// (Real compositor blur that also blurs windows needs SceneFX; this is the v1 approach.)
import QtQuick
import QtQuick.Effects
import Quickshell
import qs.services

Item {
    id: root
    default property alias content: inner.data
    property real radius: Theme.radius
    property color color: Theme.surface
    property int padding: 16
    property real blurStrength: Config.s.blurUi ?? 0.8
    property bool shadow: true

    RectangularShadow {
        visible: root.shadow
        anchors.fill: bg
        radius: root.radius
        blur: 36
        spread: -10
        offset.y: 14
        color: Qt.rgba(0, 0, 0, 0.5)
    }

    // ---- fake blur ----
    // Where this card sits on the screen: window origin (from its layer-shell anchors) + position in the window.
    readonly property var win: QsWindow.window
    property point onScreen: Qt.point(0, 0)
    function place() {
        const w = win;
        if (!w || !w.screen) return;
        const sw = w.screen.width, sh = w.screen.height, a = w.anchors ?? {}, m = w.margins ?? {};
        const ox = a.left && !a.right ? (m.left || 0) : (!a.left && a.right ? sw - w.width - (m.right || 0) : (a.left && a.right ? 0 : (sw - w.width) / 2));
        const oy = a.top && !a.bottom ? (m.top || 0) : (!a.top && a.bottom ? sh - w.height - (m.bottom || 0) : (a.top && a.bottom ? 0 : (sh - w.height) / 2));
        const p = root.mapToItem(null, 0, 0);
        onScreen = Qt.point(ox + p.x, oy + p.y);
    }
    onVisibleChanged: if (visible) place()
    onWidthChanged: place()
    onHeightChanged: place()
    Component.onCompleted: place()
    Connections { target: root.win; ignoreUnknownSignals: true; function onWidthChanged() { root.place() } function onHeightChanged() { root.place() } }

    Item {
        id: blurClip
        anchors.fill: parent
        visible: root.blurStrength > 0.02 && !Theme.wallpaperIsVideo && root.win?.screen !== undefined
        layer.enabled: visible
        layer.effect: MultiEffect { maskEnabled: true; maskSource: mask; maskThresholdMin: 0.5; maskSpreadAtMin: 1 }
        Image {
            id: wp
            x: -root.onScreen.x; y: -root.onScreen.y
            width: root.win?.screen?.width ?? 1920; height: root.win?.screen?.height ?? 1080
            source: blurClip.visible ? Theme.wallpaperUrl : ""
            sourceSize: Qt.size(width / 2, height / 2)       // blur doesn't need full resolution
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            visible: false
        }
        MultiEffect {
            x: wp.x; y: wp.y; width: wp.width; height: wp.height
            source: wp
            blurEnabled: true
            blur: 1.0
            blurMax: Math.round(16 + root.blurStrength * 48)
            saturation: 0.15
        }
    }
    Rectangle { id: mask; anchors.fill: parent; radius: root.radius; visible: false; layer.enabled: true }

    Rectangle {
        id: bg
        anchors.fill: parent
        radius: root.radius
        color: root.color
        border.color: Theme.border
        border.width: 1
    }
    Item {
        id: inner
        anchors.fill: parent
        anchors.margins: root.padding
    }
}
