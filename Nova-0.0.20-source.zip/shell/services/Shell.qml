// Which popout is open, plus `qs ipc call nova toggle launcher` support.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property string popout: ""          // launcher | controlcentre | notifications | clipboard
    property bool overview: false
    property bool ccEditing: false
    // is a screen recording running? (nova-record writes a pid file)
    property bool recording: false
    Process { id: recPoll; command: ["nova-record", "status"]; stdout: StdioCollector { onStreamFinished: root.recording = text.trim() === "recording" } }
    Timer { interval: 1500; repeat: true; running: true; onTriggered: recPoll.running = true }
    property var popoutScreen: null    // screen the popout belongs to (null = first screen)

    // Clock hover -> now playing popup
    property bool clockHovered: false
    property bool npCardHovered: false
    property var npScreen: null
    readonly property bool npWanted: (clockHovered || npCardHovered) && Media.player !== null
    property bool npOpen: false
    onNpWantedChanged: { if (npWanted) { npClose.stop(); npOpenT.restart() } else { npOpenT.stop(); npClose.restart() } }
    // opens after resting on the clock for 1.5 s; stays open long enough to move onto it
    Timer { id: npOpenT; interval: 1500; onTriggered: root.npOpen = true }
    Timer { id: npClose; interval: 700; onTriggered: root.npOpen = false }
    // where the clock pill is (distance from the screen's right edge), so the card sits right above it
    // capture delay countdown, shown as a small chip on the panel (not in the picture)
    property int countdown: 0
    function captureCountdown(s) { countdown = s; countdownT.restart() }
    Timer { id: countdownT; interval: 1000; repeat: true; onTriggered: { root.countdown--; if (root.countdown <= 0) stop() } }
    property real clockRightGap: 12
    property real clockWidth: 120

    function isPopoutScreen(screen) {
        return popoutScreen ? popoutScreen === screen : screen === Quickshell.screens[0];
    }

    function toggleOn(name, screen) { popoutScreen = screen; toggle(name) }
    function toggle(name) {
        if (name === "overview") { overview = !overview; popout = ""; if (overview) Nova.refreshWindows(); return }
        overview = false;
        popout = popout === name ? "" : name;
        if (popout !== "controlcentre") ccEditing = false;
    }
    function close() { popout = ""; overview = false; ccEditing = false }

    Connections {
        target: Nova
        function onShellAction(action) {
            // open on the monitor under the pointer
            root.popoutScreen = Quickshell.screens.find(s => s.name === Nova.activeOutput) ?? root.popoutScreen;
            if (action === "close") root.close();
            else if (action === "overview-open") { if (!root.overview) root.toggle("overview") }
            else root.toggle(action);
        }
    }
    IpcHandler {
        target: "nova"
        function toggle(name: string): void { root.toggle(name) }
        function close(): void { root.close() }
    }
}
