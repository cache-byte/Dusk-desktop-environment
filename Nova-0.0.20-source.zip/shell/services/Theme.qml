pragma Singleton
import QtQuick
import Quickshell

Singleton {
    readonly property var c: Config.s
    readonly property bool dark: c.mode !== "light"

    readonly property color accent: c.accent
    readonly property color accentBright: Qt.lighter(accent, 1.25)
    readonly property color onAccent: Qt.darker(accent, 4.2)
    readonly property color accentSoft: Qt.rgba(accent.r, accent.g, accent.b, 0.16)
    readonly property color accentLine: Qt.rgba(accent.r, accent.g, accent.b, 0.45)

    readonly property color surface: dark ? Qt.rgba(0.08, 0.075, 0.11, 1 - c.transparencyUi) : Qt.rgba(0.97, 0.96, 0.94, 1 - c.transparencyUi)
    readonly property color panel: dark ? Qt.rgba(0.063, 0.059, 0.086, 1 - c.transparencyPanel) : Qt.rgba(0.96, 0.95, 0.93, 1 - c.transparencyPanel)
    readonly property color surface2: dark ? Qt.rgba(1, 1, 1, 0.055) : Qt.rgba(0, 0, 0, 0.05)
    readonly property color surface3: dark ? Qt.rgba(1, 1, 1, 0.09) : Qt.rgba(0, 0, 0, 0.08)
    readonly property color border: dark ? Qt.rgba(1, 1, 1, 0.075) : Qt.rgba(0, 0, 0, 0.08)
    readonly property color text: dark ? "#eceae4" : "#1c1b22"
    readonly property color text2: dark ? "#a7a4ae" : "#55525c"
    readonly property color text3: dark ? "#6f6c78" : "#8a8792"
    readonly property color danger: "#e8604c"
    readonly property color warn: "#f2b84b"

    // wallpaper, for the blurred glass behind popups
    // no wallpaper picked: the light waves in light mode, the dark waves in dark mode
    readonly property string defaultWallpaper: Quickshell.shellDir + "/assets/wallpapers/nova-" + (dark ? "dark" : "light") + ".jpg"
    readonly property string wallpaperPath: c.wallpaper || defaultWallpaper
    readonly property string wallpaperUrl: "file://" + wallpaperPath.replace(/^file:\/\//, "")
    readonly property bool wallpaperIsVideo: /\.(mp4|webm|mkv|mov)$/i.test(wallpaperPath)

    readonly property string font: c.font
    readonly property string mono: c.monoFont
    readonly property int radius: 20
    readonly property int radiusS: 14
    readonly property int panelHeight: 48
    // The popout grid (control centre, launcher, calendar): 6 columns × up to 10 rows of
    // square cells. Every popout is sized in whole cells so they all line up.
    readonly property int gridCols: 6
    readonly property int gridRows: 10
    readonly property int gridCell: 52
    readonly property int gridGap: 10
    readonly property int gridPad: 18
    readonly property int gridWidth: gridCols * gridCell + (gridCols - 1) * gridGap + 2 * gridPad
    function gridHeight(rows) { return rows * gridCell + (rows - 1) * gridGap + 2 * gridPad }
    // rows needed for content of this height (at least 1, at most gridRows)
    function gridRowsFor(h) { return Math.max(1, Math.min(gridRows, Math.ceil((h - 2 * gridPad + gridGap) / (gridCell + gridGap)))) }
    readonly property int gap: 12
    function ms(t) { return Math.round(t / Math.max(0.1, c.animationSpeed)) }
}
