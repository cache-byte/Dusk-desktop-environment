// User settings shared by the shell and the Settings app:
//   ~/.config/nova/settings.json  (written by both; watched for changes)
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    readonly property string dir: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config")) + "/nova"
    property alias s: adapter
    // 6-column grid, 52 px rows
    readonly property var defaultCcLayout: [
        { "id": "wifi", "x": 0, "y": 0, "w": 3, "h": 1 },
        { "id": "bluetooth", "x": 0, "y": 1, "w": 3, "h": 1 },
        { "id": "brightness", "x": 3, "y": 0, "w": 1, "h": 3 },
        { "id": "volume", "x": 4, "y": 0, "w": 1, "h": 3 },
        { "id": "micvol", "x": 5, "y": 0, "w": 1, "h": 3 },
        { "id": "dnd", "x": 0, "y": 2, "w": 1, "h": 1 },
        { "id": "nightlight", "x": 1, "y": 2, "w": 1, "h": 1 },
        { "id": "airplane", "x": 2, "y": 2, "w": 1, "h": 1 },
        { "id": "darkmode", "x": 0, "y": 3, "w": 1, "h": 1 },
        { "id": "screenshot", "x": 1, "y": 3, "w": 1, "h": 1 },
        { "id": "caffeine", "x": 2, "y": 3, "w": 1, "h": 1 },
        { "id": "record", "x": 3, "y": 3, "w": 1, "h": 1 },
        { "id": "hotspot", "x": 4, "y": 3, "w": 1, "h": 1 },
        { "id": "kbl", "x": 5, "y": 3, "w": 1, "h": 1 },
        { "id": "power", "x": 0, "y": 4, "w": 6, "h": 1 }
    ]
    // Where each popup goes. pos = 0..8 on a 3x3 grid (0 top-left, 4 centre, 8 bottom-right).
    // dir: "up" (vertical) | "across" (horizontal); notifications use "up" / "down" for stacking.
    readonly property var defaultOsd: ({
        "slider": { "pos": 5, "dir": "up", "dx": 0, "dy": 0 },
        "lock": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 },
        "power": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 },
        "notifications": { "pos": 8, "dir": "up", "dx": 0, "dy": 0 },
        "message": { "pos": 1, "dir": "across", "dx": 0, "dy": 0 },
        "nowplaying": { "pos": 8, "dir": "clock", "dx": 0, "dy": 0 },
        "lyrics": { "pos": 7, "dir": "centre", "dx": 0, "dy": 40 },
        "visualizer": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 }
    })
    function osd(kind) { return Object.assign({}, defaultOsd[kind], (adapter.osd ?? {})[kind] ?? {}) }

    FileView {
        id: file
        path: root.dir + "/settings.json"
        watchChanges: true
        blockLoading: true
        onFileChanged: reload()
        onAdapterUpdated: writeAdapter()
        onLoadFailed: err => { if (err === FileViewError.FileNotFound) writeAdapter() }
        onLoaded: {
            // migrate a 4-column layout from an early build
            if ((adapter.ccVersion ?? 1) < 2) { adapter.ccLayout = root.defaultCcLayout; adapter.ccVersion = 2 }
        }

        JsonAdapter {
            id: adapter
            // appearance
            property string mode: "dark"            // dark | light | auto
            property string accent: "#c8b64a"
            property bool accentFromWallpaper: false
            property string wallpaper: ""           // empty = bundled Nova wallpaper
            property string wallpaperFill: "fill"   // fill | fit | center
            property real blurUi: 0.80
            property real blurPanel: 0.80
            property real blurApps: 0.80
            property real transparencyUi: 0.80
            property real transparencyPanel: 0.80
            property real transparencyApps: 0.80
            property string iconTheme: "Papirus-Dark"
            property string cursorTheme: "Bibata-Modern-Classic"
            property int cursorSize: 24
            property string font: "Inter"
            property int fontSize: 14
            property string monoFont: "JetBrains Mono"
            property int cornerRadius: 14
            property real animationSpeed: 1.0
            // shell
            property list<string> pinned: ["org.gnome.Nautilus", "org.mozilla.firefox", "org.gnome.Ptyxis", "org.gnome.TextEditor", "org.gnome.Settings"]
            property string launcherView: "list"
            property bool clock24: true
            property bool showDesktopIcons: true
            property bool dnd: false
            property int notificationTimeout: 6000
            // control centre: tiles on a 4-column grid
            property var ccLayout: root.defaultCcLayout
            property int ccVersion: 2              // bumped when the grid changed (4 -> 6 columns)
            // popups & indicators
            property var osd: ({})
            property int osdTimeout: 2000
            property string osdSize: "M"           // S | M | L
            property string osdScreen: "active"    // active | all
            property bool lockInPanel: true
            property bool allowOverAmplify: false       // volume up to 150 %
            // power & idle (minutes, 0 = off)
            property int idleDimBattery: 5
            property int idleLockBattery: 6
            property int idleSleepBattery: 15
            property int idleDimAc: 5
            property int idleLockAc: 6
            property int idleSleepAc: 0
            property string gpuPrimary: "auto"          // auto | integrated | dedicated
            property bool gamesOnDedicatedGpu: true
            // notifications
            property bool groupNotifications: true
            property bool autoDnd: true                 // DND while something is fullscreen
            // clipboard
            property bool clipboardKeep: true           // keep history across reboots
            property int clipboardMax: 200
            // updates
            property string updateChannel: "release"   // release | latest
            property string updateRepo: "cache-byte/Nova-desktop-environment"
            // music & lyrics
            property bool lyricsNowPlaying: true
            property bool lyricsDesktop: false
            property int lyricsStyle: 1
            property string lyricsSize: "M"
            property real lyricsOffset: 0.2
            property bool lyricsHideFullscreen: true
            property bool lyricsSongRec: true
            property var vizPlaces: ["nowplaying", "lock", "clock"]
            property int vizStyle: 1
            property string vizColour: "accent"        // accent | art | rainbow
            property int vizBars: 32
            property real vizSensitivity: 0.55
            property string vizDesktopPos: "bottom"    // bottom | centre | top | custom
            property bool vizDesktopTitle: false
            property real vizDesktopOpacity: 0.85
            // gaming & capture
            property bool gameModeAuto: true
            property bool mangohud: false
            property bool replayEnabled: false
            property int replaySeconds: 30
            property string recordFormat: "mp4"
            property bool recordSystemAudio: true
            property bool recordMic: false
            property bool captureEdit: false
        }
    }
}
