// Dim, lock and sleep after inactivity. Separate times on battery and plugged in
// (Settings > Power; 0 = off). Nothing happens while an app inhibits idle
// (video players, browsers playing video) or while anything is fullscreen —
// the compositor treats fullscreen windows as an inhibitor — or with Caffeine on.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Services.UPower

Singleton {
    id: root
    property bool caffeine: false
    readonly property bool onBattery: UPower.onBattery
    readonly property int dimMin:   caffeine ? 0 : (onBattery ? Config.s.idleDimBattery   : Config.s.idleDimAc)
    readonly property int lockMin:  caffeine ? 0 : (onBattery ? Config.s.idleLockBattery  : Config.s.idleLockAc)
    readonly property int sleepMin: caffeine ? 0 : (onBattery ? Config.s.idleSleepBattery : Config.s.idleSleepAc)
    readonly property bool gameMode: Nova.fullscreen
    property real savedBrightness: -1

    // IdleMonitor needs Quickshell 0.3+. It is created from a string so an older
    // Quickshell can't stop the whole shell loading; then swayidle does lock and sleep.
    property bool native: false
    function monitor(minutes, onIdle) {
        const m = Qt.createQmlObject('import Quickshell.Wayland; IdleMonitor { respectInhibitors: true }', root, "Idle")
        m.enabled = Qt.binding(() => minutes() > 0)
        m.timeout = Qt.binding(() => Math.max(1, minutes()) * 60)
        m.isIdleChanged.connect(() => onIdle(m.isIdle))
        return m
    }
    Component.onCompleted: {
        try {
            monitor(() => Brightness.available ? root.dimMin : 0, idle => {
                if (idle) { root.savedBrightness = Brightness.value; Brightness.set(Math.min(Brightness.value, 0.25)) }
                else if (root.savedBrightness > 0) { Brightness.set(root.savedBrightness); root.savedBrightness = -1 }
            })
            monitor(() => root.lockMin, idle => { if (idle) Nova.lockRequested() })
            monitor(() => root.sleepMin, idle => { if (idle) Quickshell.execDetached(["systemctl", "suspend"]) })
            native = true
        } catch (e) {
            console.warn("Idle: IdleMonitor unavailable (Quickshell older than 0.3), using swayidle:", e)
        }
    }
    Process {
        running: !root.native && (root.lockMin > 0 || root.sleepMin > 0)
        command: ["swayidle", "-w"]
            .concat(root.lockMin > 0 ? ["timeout", String(root.lockMin * 60), "novactl dispatch lock"] : [])
            .concat(root.sleepMin > 0 ? ["timeout", String(root.sleepMin * 60), "systemctl suspend"] : [])
    }
}
