#include "osk.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <linux/input-event-codes.h>
#include <xkbcommon/xkbcommon.h>

#include "anim.hpp"
#include "clipboard.hpp"
#include "draw.hpp"
#include "glyphs.hpp"

namespace dusk {

namespace {

// The emoji, by category (the first one is the tab's picture).
struct Category {
	const char *name;
	std::vector<const char *> emoji;
};
const std::vector<Category> &categories() {
	static const std::vector<Category> kCats = {
		{"Smileys", {"😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "🙃", "😉", "😊", "😇", "🥰", "😍", "🤩",
			"😘", "😗", "😚", "😋", "😛", "😜", "🤪", "😝", "🤗", "🤭", "🤫", "🤔", "🤐", "🤨", "😐", "😑",
			"😶", "😏", "😒", "🙄", "😬", "😌", "😔", "😪", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🥵", "🥶",
			"🥴", "😵", "🤯", "🤠", "🥳", "😎", "🤓", "🧐", "😕", "😟", "🙁", "😮", "😯", "😲", "😳", "🥺",
			"😦", "😧", "😨", "😰", "😥", "😢", "😭", "😱", "😖", "😣", "😞", "😓", "😩", "😫", "🥱", "😤",
			"😡", "😠", "🤬", "😈", "👿", "💀", "💩", "🤡", "👻", "👽", "🤖", "🎃"}},
		{"People", {"👋", "🤚", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "👇",
			"☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "💪", "🦾", "👀",
			"🧠", "👶", "🧒", "👦", "👧", "🧑", "👨", "👩", "🧓", "👴", "👵", "🙋", "🤷", "🤦", "🙇", "💃",
			"🕺", "🏃", "🚶", "🧍", "🧑‍💻", "🧑‍🍳", "🧑‍🎓", "🧑‍🎨", "👮", "🥷", "🧙", "🧛", "🧟", "🧞"}},
		{"Hearts", {"❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖",
			"💘", "💝", "💟", "♥️", "💋", "💯", "💢", "💥", "💫", "💦", "💨", "💬", "💭", "💤", "✨", "⭐",
			"🌟", "🔥", "⚡", "🌈", "☀️", "🌙", "❄️", "☔", "✅", "❌", "❗", "❓", "➕", "➖", "➡️", "⬅️"}},
		{"Animals", {"🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🐔",
			"🐧", "🐦", "🐤", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞",
			"🐢", "🐍", "🦎", "🐙", "🦑", "🦀", "🐠", "🐟", "🐬", "🐳", "🦈", "🐊", "🐘", "🦒", "🐑", "🐐",
			"🌵", "🌲", "🌳", "🌴", "🌱", "🌿", "🍀", "🍁", "🍂", "🌷", "🌹", "🌻", "🌸", "🌼", "🍄", "🌍"}},
		{"Food", {"🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝",
			"🍅", "🥑", "🥦", "🌽", "🥕", "🥔", "🍞", "🥐", "🧀", "🥚", "🍳", "🥓", "🍗", "🍖", "🌭", "🍔",
			"🍟", "🍕", "🌮", "🌯", "🥗", "🍝", "🍜", "🍲", "🍛", "🍣", "🍱", "🍚", "🍦", "🍩", "🍪", "🎂",
			"🍰", "🧁", "🍫", "🍬", "🍭", "🍯", "☕", "🍵", "🥤", "🧃", "🍺", "🍷", "🥂", "🍾", "🧊", "🍴"}},
		{"Things", {"⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🎱", "🏓", "🎮", "🕹️", "🎲", "🧩", "🎯", "🎳", "🎸", "🎹",
			"🎧", "🎤", "🎬", "🎨", "📷", "📱", "💻", "🖥️", "⌨️", "🖱️", "💾", "💡", "🔋", "🔌", "📚", "✏️",
			"📝", "📌", "📎", "✂️", "🔒", "🔑", "🔨", "🛠️", "⚙️", "🧲", "💰", "💳", "🎁", "🎈", "🎉", "🎊",
			"🚗", "🚕", "🚌", "🚲", "🛵", "✈️", "🚀", "🛸", "🚢", "🏠", "🏫", "🏥", "⛪", "🗺️", "⏰", "📅"}},
	};
	return kCats;
}

// UTF-8 to code points.
std::vector<uint32_t> codepoints(const std::string &s) {
	std::vector<uint32_t> out;
	for (size_t i = 0; i < s.size();) {
		const unsigned char c = static_cast<unsigned char>(s[i]);
		uint32_t cp = 0;
		int n = 0;
		if (c < 0x80) { cp = c; n = 1; }
		else if ((c >> 5) == 0x6) { cp = c & 0x1f; n = 2; }
		else if ((c >> 4) == 0xe) { cp = c & 0x0f; n = 3; }
		else { cp = c & 0x07; n = 4; }
		for (int k = 1; k < n && i + k < s.size(); k++) cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3f);
		out.push_back(cp);
		i += n;
	}
	return out;
}

} // namespace

Osk::Osk(Server *server) : Popover(server, 900, 300) {
	xkb_ = xkb_context_new(XKB_CONTEXT_NO_FLAGS);
	repeat_ = wl_event_loop_add_timer(server->loop, &Osk::handle_repeat, this);
}

Osk::~Osk() {
	if (repeat_) wl_event_source_remove(repeat_);
	if (xkb_) xkb_context_unref(xkb_);
}

void Osk::toggle(Output *output) {
	if (is_open()) {
		close();
	} else {
		show(output);
	}
}

void Osk::show(Output *output) {
	if (!output) output = server_->focused_output();
	if (!output) return;
	output_ = output;
	fit();
	const wlr_box u = output->usable();
	open(output, wlr_box{u.x, u.y + u.height - 1, u.width, 1}, "bottom");
}

void Osk::on_open() {
	fit();
}

// As wide as the screen allows: on a wide screen (a laptop or a big tablet
// in landscape) the keys split into two halves at the sides.
void Osk::fit() {
	if (!output_) return;
	const wlr_box u = output_->usable();
	split_ = u.width >= 1100 && u.width > u.height;
	const int w = split_ ? u.width - 24 : std::min(u.width - 24, 1000);
	const double unit = split_ ? std::min(w * 0.40, 560.0) / 5.5 : (w - 24) / 10.0;
	const int row_h = static_cast<int>(std::clamp(unit * 0.82, 40.0, 64.0));
	const int h = 12 + 44 + 5 * (row_h + 6) + 8;
	resize(w, std::min(h, u.height - 20));
	emoji_cols_ = std::max(6, static_cast<int>((w - 24) / std::max(44.0, unit * 0.9)));
	emoji_rows_ = 4;
}

std::vector<std::vector<Osk::Key>> Osk::rows() const {
	std::vector<std::vector<Key>> r;
	auto chars = [&](const std::string &list, int split_after, double indent = 0) {
		std::vector<Key> row;
		const std::vector<uint32_t> cps = codepoints(list);
		int i = 0;
		for (size_t at = 0; at < list.size();) {
			const unsigned char c = static_cast<unsigned char>(list[at]);
			const size_t n = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xe ? 3 : 4;
			std::string ch = list.substr(at, n);
			at += n;
			std::string shown = ch;
			if (mode_ == Mode::Letters && (shift_ || caps_) && ch.size() == 1 && std::isalpha(static_cast<unsigned char>(ch[0]))) {
				shown = std::string(1, static_cast<char>(std::toupper(static_cast<unsigned char>(ch[0]))));
			}
			row.push_back(Key{"c:" + shown, shown, 1, false, i == split_after});
			i++;
		}
		(void)cps;
		(void)indent;
		return row;
	};
	if (mode_ == Mode::Emoji) return r;
	r.push_back(chars("1234567890", 4));
	if (mode_ == Mode::Letters) {
		r.push_back(chars("qwertyuiop", 4));
		r.push_back(chars("asdfghjkl", 4));
		std::vector<Key> r3;
		r3.push_back(Key{"shift", caps_ ? "⇪" : "⇧", 1.5, true});
		for (Key &k : chars("zxcvbnm", 3)) r3.push_back(k);
		r3[4].gap_after = true;   // after "v"
		r3.push_back(Key{"backspace", "⌫", 1.5, true});
		for (size_t i = 0; i < r3.size(); i++) if (i != 4) r3[i].gap_after = false;
		r.push_back(r3);
	} else {
		r.push_back(chars("!@#$%^&*()", 4));
		r.push_back(chars("-_=+/\\:;'\"", 4));
		std::vector<Key> r3 = chars("~`|<>[]{}", 4);
		r3.push_back(Key{"backspace", "⌫", 1.5, true});
		r.push_back(r3);
	}
	std::vector<Key> r4;
	r4.push_back(Key{"mode", mode_ == Mode::Letters ? "!#1" : "abc", 1.5, true});
	r4.push_back(Key{"emoji", "☺", 1, true});
	r4.push_back(Key{"c:,", ",", 1});
	if (split_) {
		r4.push_back(Key{"c: ", "", 2.0, false, true});   // a space bar under each thumb
		r4.push_back(Key{"c: ", "", 2.0});
	} else {
		r4.push_back(Key{"c: ", "", 4.0});
	}
	r4.push_back(Key{"c:.", ".", 1});
	r4.push_back(Key{"enter", "↵", 1.5, true});
	r.push_back(r4);
	return r;
}

void Osk::draw(cairo_t *cr, float scale) {
	const Config &c = server_->config;
	const int pad = 12, bar = 44;
	const Color key_bg = with_alpha(theme::text, theme::dark ? 0.12 : 0.09);
	const Color special_bg = with_alpha(theme::text, theme::dark ? 0.06 : 0.05);
	const std::string family = c.font.empty() ? "Sans" : c.font;

	// The bar along the top: emoji, the clipboard, settings ... and hide.
	{
		const double y = pad / 2.0 + 2;
		struct Tool {
			const char *id, *glyph;
		};
		const Tool tools[] = {{"emoji", ""}, {"clipboard", "clipboard"}, {"settings", "settings"}};
		double x = pad;
		for (const Tool &t : tools) {
			const bool on = std::string(t.id) == "emoji" && mode_ == Mode::Emoji;
			if (on) fill_rounded(cr, x, y, 40, 36, 18, with_alpha(theme::accent, 0.25));
			if (std::string(t.id) == "emoji") {
				draw_text(cr, "☺", x, y, 40, 36, (family + " 15").c_str(), theme::text, Align::Center);
			} else {
				draw_glyph(cr, t.glyph, x + 20, y + 18, 18, theme::text);
			}
			add_hot(std::string("tool:") + t.id, x, y, 40, 36, 18);
			x += 48;
		}
		draw_glyph(cr, "chevron-down", w_ - pad - 20, y + 18, 20, theme::text);
		add_hot("tool:hide", w_ - pad - 40, y, 40, 36, 18);
		if (mode_ == Mode::Emoji) {
			// The categories, in the middle of the bar.
			const auto &cats = categories();
			const double tw = 44;
			double cx = (w_ - tw * cats.size()) / 2.0;
			for (size_t i = 0; i < cats.size(); i++) {
				if (static_cast<int>(i) == category_) fill_rounded(cr, cx + 2, y, tw - 4, 36, 14, with_alpha(theme::accent, 0.25));
				draw_text(cr, cats[i].emoji[0], cx, y, tw, 36, "Noto Color Emoji 15", theme::text, Align::Center);
				add_hot("cat:" + std::to_string(i), cx + 2, y, tw - 4, 36, 14);
				cx += tw;
			}
		}
	}

	const double top = pad / 2.0 + bar;
	const double area_h = h_ - top - pad / 2.0;
	const double row_h = area_h / 5.0;

	if (mode_ == Mode::Emoji) {
		const auto &list = categories()[static_cast<size_t>(category_)].emoji;
		const int per_page = emoji_cols_ * emoji_rows_;
		const int pages = std::max(1, (static_cast<int>(list.size()) + per_page - 1) / per_page);
		page_ = std::clamp(page_, 0, pages - 1);
		const double cw = (w_ - 2.0 * pad) / emoji_cols_;
		const double pt = std::clamp(row_h * 0.42, 14.0, 26.0);
		const std::string ef = "Noto Color Emoji " + std::to_string(static_cast<int>(pt));
		for (int i = 0; i < per_page; i++) {
			const size_t at = static_cast<size_t>(page_ * per_page + i);
			if (at >= list.size()) break;
			const double x = pad + (i % emoji_cols_) * cw, y = top + (i / emoji_cols_) * row_h;
			draw_text(cr, list[at], x, y, cw, row_h, ef.c_str(), theme::text, Align::Center);
			add_hot(std::string("e:") + list[at], x + 2, y + 2, cw - 4, row_h - 4, 12);
		}
		// The last row: back to letters, pages, space, delete.
		const double y = top + 4 * row_h + 3, kh = row_h - 6;
		struct Bottom {
			const char *id, *label;
			double units;
		};
		const Bottom keys[] = {{"mode-letters", "abc", 1.5}, {"page-prev", "‹", 1}, {"page-next", "›", 1},
			{"c: ", "", 4.5}, {"backspace", "⌫", 2}};
		double units = 0;
		for (const Bottom &b : keys) units += b.units;
		const double u = (w_ - 2.0 * pad) / units;
		double x = pad;
		for (const Bottom &b : keys) {
			const bool special = std::string(b.id) != "c: ";
			fill_rounded(cr, x + 3, y, b.units * u - 6, kh, 10, special ? special_bg : key_bg);
			draw_text(cr, b.label, x, y, b.units * u, kh, (family + " 14").c_str(), theme::text, Align::Center);
			add_hot(b.id, x + 3, y, b.units * u - 6, kh, 10);
			x += b.units * u;
		}
		(void)scale;
		return;
	}

	const auto r = rows();
	const double font_pt = std::clamp(row_h * 0.30, 11.0, 18.0);
	const std::string kf = family + " " + std::to_string(static_cast<int>(font_pt));
	const std::string kf_small = family + " " + std::to_string(static_cast<int>(font_pt * 0.75));
	for (size_t ri = 0; ri < r.size(); ri++) {
		const auto &row = r[ri];
		const double y = top + ri * row_h + 3, kh = row_h - 6;
		auto draw_key = [&](const Key &k, double x, double w) {
			const bool active = (k.id == "shift" && (shift_ || caps_)) || k.id == "enter";
			Color bg = k.special ? special_bg : key_bg;
			if (active) bg = k.id == "enter" ? theme::accent : with_alpha(theme::accent, 0.35);
			fill_rounded(cr, x + 3, y, w - 6, kh, 10, bg);
			const Color fg = k.id == "enter" ? theme::on_accent : theme::text;
			const bool small = k.label.size() > 1 && k.id.rfind("c:", 0) != 0 && k.label != "⌫" && k.label != "⇧" &&
				k.label != "⇪" && k.label != "↵" && k.label != "☺";
			draw_text(cr, k.label, x + 3, y, w - 6, kh, (small ? kf_small : kf).c_str(), fg, Align::Center);
			add_hot(k.id, x + 3, y, w - 6, kh, 10);
		};
		if (!split_) {
			double units = 0;
			for (const Key &k : row) units += k.units;
			const double u = (w_ - 2.0 * pad) / 10.0;
			double x = pad + ((w_ - 2.0 * pad) - units * u) / 2.0;
			for (const Key &k : row) {
				draw_key(k, x, k.units * u);
				x += k.units * u;
			}
		} else {
			// Two halves at the sides: the keys up to the split on the left,
			// the rest on the right.
			const double half = std::min(w_ * 0.40, 560.0);
			const double u = half / 5.5;
			size_t cut = row.size() / 2;
			for (size_t i = 0; i < row.size(); i++) {
				if (row[i].gap_after) {
					cut = i + 1;
					break;
				}
			}
			double lu = 0, ru = 0;
			for (size_t i = 0; i < row.size(); i++) (i < cut ? lu : ru) += row[i].units;
			double x = pad + (ri == 2 ? u * 0.5 : 0);
			for (size_t i = 0; i < cut; i++) {
				draw_key(row[i], x, row[i].units * u);
				x += row[i].units * u;
			}
			x = w_ - pad - ru * u - (ri == 2 ? u * 0.5 : 0);
			for (size_t i = cut; i < row.size(); i++) {
				draw_key(row[i], x, row[i].units * u);
				x += row[i].units * u;
			}
			(void)lu;
		}
	}
}

bool Osk::draggable(const std::string &id) const {
	return id == "backspace";   // held: it repeats
}

void Osk::on_drag(const std::string &id, double, double) {
	// (Called on every move while it's held: only the first one types.)
	if (held_ == id) return;
	held_ = id;
	press_key(id);
	wl_event_source_timer_update(repeat_, 450);
}

int Osk::handle_repeat(void *data) {
	auto *self = static_cast<Osk *>(data);
	if (self->dragging_ == "backspace") {
		self->send_keycode(KEY_BACKSPACE, false);
		wl_event_source_timer_update(self->repeat_, 60);
	}
	return 0;
}

void Osk::on_scroll(double delta) {
	if (mode_ != Mode::Emoji) return;
	page_ += delta > 0 ? 1 : -1;
	page_ = std::max(0, page_);
	redraw();
}

void Osk::activate(const std::string &id, uint32_t button, double px, double) {
	if (button != BTN_LEFT) return;
	if (px < 0) {
		// Let go of a held key.
		wl_event_source_timer_update(repeat_, 0);
		held_.clear();
		return;
	}
	press_key(id);
}

void Osk::press_key(const std::string &id) {
	if (id.rfind("c:", 0) == 0) {
		type_text(id.substr(2));
		if (shift_ && !caps_) {
			shift_ = false;
			redraw();
		}
		return;
	}
	if (id.rfind("e:", 0) == 0) {
		type_text(id.substr(2));
		return;
	}
	if (id == "backspace") {
		send_keycode(KEY_BACKSPACE, false);
	} else if (id == "enter") {
		send_keycode(KEY_ENTER, false);
	} else if (id == "shift") {
		// Once: the next letter. Twice quickly: Caps Lock. Again: off.
		const double now = now_ms();
		if (caps_) {
			caps_ = shift_ = false;
		} else if (shift_ && now - last_shift_ < 400) {
			caps_ = true;
		} else {
			shift_ = !shift_;
		}
		last_shift_ = now;
		redraw();
	} else if (id == "mode") {
		mode_ = mode_ == Mode::Letters ? Mode::Symbols : Mode::Letters;
		redraw();
	} else if (id == "emoji" || id == "tool:emoji") {
		mode_ = mode_ == Mode::Emoji ? Mode::Letters : Mode::Emoji;
		redraw();
	} else if (id == "mode-letters") {
		mode_ = Mode::Letters;
		redraw();
	} else if (id.rfind("cat:", 0) == 0) {
		category_ = std::atoi(id.c_str() + 4);
		page_ = 0;
		redraw();
	} else if (id == "page-prev") {
		page_ = std::max(0, page_ - 1);
		redraw();
	} else if (id == "page-next") {
		page_++;
		redraw();
	} else if (id == "tool:clipboard") {
		if (server_->clipboard_card && output_) {
			const wlr_box u = output_->usable();
			server_->clipboard_card->open(output_, wlr_box{u.x + u.width / 2, u.y + u.height / 2, 0, 0}, "bottom");
		}
	} else if (id == "tool:settings") {
		server_->open_settings("keyboard");
	} else if (id == "tool:hide") {
		close();
	}
}

// ---- Typing ------------------------------------------------------------------------------

wlr_keyboard *Osk::target() const {
	// A real keyboard's (its keymap is the layout set in Settings).
	for (Keyboard *k : server_->keyboards) {
		if (!k->is_virtual && k->keyboard && k->keyboard->keymap) return k->keyboard;
	}
	for (Keyboard *k : server_->keyboards) {
		if (k->keyboard && k->keyboard->keymap) return k->keyboard;
	}
	return nullptr;
}

bool Osk::send_keycode(uint32_t evdev, bool shift) {
	wlr_keyboard *kb = target();
	if (!kb) return false;
	wlr_seat_set_keyboard(server_->seat, kb);
	wlr_keyboard_modifiers mods{};
	if (shift) {
		const xkb_mod_index_t si = xkb_keymap_mod_get_index(kb->keymap, XKB_MOD_NAME_SHIFT);
		if (si != XKB_MOD_INVALID) mods.depressed = 1u << si;
	}
	mods.group = kb->modifiers.group;
	wlr_seat_keyboard_notify_modifiers(server_->seat, &mods);
	const uint32_t t = static_cast<uint32_t>(now_ms());
	wlr_seat_keyboard_notify_key(server_->seat, t, evdev, WL_KEYBOARD_KEY_STATE_PRESSED);
	wlr_seat_keyboard_notify_key(server_->seat, t + 1, evdev, WL_KEYBOARD_KEY_STATE_RELEASED);
	wlr_seat_keyboard_notify_modifiers(server_->seat, &kb->modifiers);
	return true;
}

bool Osk::type_text(const std::string &utf8) {
	wlr_keyboard *kb = target();
	if (!kb) return false;
	const std::vector<uint32_t> cps = codepoints(utf8);
	// A single character the layout has (on its first two levels): its key.
	if (cps.size() == 1) {
		const xkb_keysym_t want = xkb_utf32_to_keysym(cps[0]);
		xkb_keymap *km = kb->keymap;
		const xkb_layout_index_t group = kb->modifiers.group;
		for (xkb_keycode_t kc = xkb_keymap_min_keycode(km); kc <= xkb_keymap_max_keycode(km); kc++) {
			for (xkb_level_index_t level = 0; level < 2; level++) {
				const xkb_keysym_t *syms = nullptr;
				const int n = xkb_keymap_key_get_syms_by_level(km, kc, group, level, &syms);
				if (n == 1 && syms[0] == want && kc >= 8) {
					return send_keycode(kc - 8, level == 1);
				}
			}
		}
	}
	return type_codepoints(cps);
}

// Anything else (emoji...): a keymap with just these characters on it, for a
// moment, then the real one back. The app is sent each keymap in turn.
bool Osk::type_codepoints(const std::vector<uint32_t> &cps) {
	wlr_keyboard *kb = target();
	if (!kb || cps.empty() || !xkb_) return false;
	std::string keycodes, symbols;
	const size_t n = std::min<size_t>(cps.size(), 16);
	for (size_t i = 0; i < n; i++) {
		char name[64] = {0};
		xkb_keysym_get_name(xkb_utf32_to_keysym(cps[i]), name, sizeof name);
		keycodes += "<K" + std::to_string(i) + "> = " + std::to_string(9 + i) + "; ";
		symbols += "key <K" + std::to_string(i) + "> { [ " + std::string(name) + " ] }; ";
	}
	const std::string text = "xkb_keymap { xkb_keycodes \"dusk\" { minimum = 8; maximum = 255; " + keycodes +
		"}; xkb_types \"dusk\" { include \"complete\" }; xkb_compatibility \"dusk\" { include \"complete\" }; "
		"xkb_symbols \"dusk\" { " + symbols + "}; };";
	xkb_keymap *temp = xkb_keymap_new_from_string(xkb_, text.c_str(), XKB_KEYMAP_FORMAT_TEXT_V1,
		XKB_KEYMAP_COMPILE_NO_FLAGS);
	if (!temp) return false;
	xkb_keymap *real = xkb_keymap_ref(kb->keymap);
	wlr_seat_set_keyboard(server_->seat, kb);
	wlr_keyboard_set_keymap(kb, temp);
	wlr_keyboard_modifiers none{};
	wlr_seat_keyboard_notify_modifiers(server_->seat, &none);
	uint32_t t = static_cast<uint32_t>(now_ms());
	for (size_t i = 0; i < n; i++) {
		wlr_seat_keyboard_notify_key(server_->seat, t++, static_cast<uint32_t>(1 + i), WL_KEYBOARD_KEY_STATE_PRESSED);
		wlr_seat_keyboard_notify_key(server_->seat, t++, static_cast<uint32_t>(1 + i), WL_KEYBOARD_KEY_STATE_RELEASED);
	}
	wlr_keyboard_set_keymap(kb, real);
	wlr_seat_keyboard_notify_modifiers(server_->seat, &kb->modifiers);
	xkb_keymap_unref(real);
	xkb_keymap_unref(temp);
	return true;
}

} // namespace dusk
