#include "core.hpp"

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <poll.h>
#include <pwd.h>
#include <signal.h>
#include <sstream>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

namespace ui {

// ------------------------------------------------------------------ geometry --
Rect Rect::united(const Rect &o) const {
    if (empty()) return o;
    if (o.empty()) return *this;
    double x1 = std::min(x, o.x), y1 = std::min(y, o.y);
    double x2 = std::max(right(), o.right()), y2 = std::max(bottom(), o.bottom());
    return {x1, y1, x2 - x1, y2 - y1};
}
Rect Rect::intersected(const Rect &o) const {
    double x1 = std::max(x, o.x), y1 = std::max(y, o.y);
    double x2 = std::min(right(), o.right()), y2 = std::min(bottom(), o.bottom());
    if (x2 <= x1 || y2 <= y1) return {};
    return {x1, y1, x2 - x1, y2 - y1};
}

// ------------------------------------------------------------------ colours --
static int hexv(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}
Color Color::hex(const std::string &in, Color fallback) {
    std::string s = in;
    if (!s.empty() && s[0] == '#') s.erase(0, 1);
    for (char c : s) if (hexv(c) < 0) return fallback;
    auto b = [&](int i) { return (hexv(s[i]) * 16 + hexv(s[i + 1])) / 255.0; };
    if (s.size() == 3) return {hexv(s[0]) / 15.0, hexv(s[1]) / 15.0, hexv(s[2]) / 15.0, 1};
    if (s.size() == 6) return {b(0), b(2), b(4), 1};
    if (s.size() == 8) return {b(2), b(4), b(6), b(0)};
    return fallback;
}
static void toHsl(const Color &c, double &h, double &s, double &l) {
    double mx = std::max({c.r, c.g, c.b}), mn = std::min({c.r, c.g, c.b});
    l = (mx + mn) / 2;
    if (mx == mn) { h = s = 0; return; }
    double d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx == c.r) h = (c.g - c.b) / d + (c.g < c.b ? 6 : 0);
    else if (mx == c.g) h = (c.b - c.r) / d + 2;
    else h = (c.r - c.g) / d + 4;
    h /= 6;
}
static double hue2rgb(double p, double q, double t) {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1.0 / 6) return p + (q - p) * 6 * t;
    if (t < 1.0 / 2) return q;
    if (t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6;
    return p;
}
static Color fromHsl(double h, double s, double l, double a) {
    if (s == 0) return {l, l, l, a};
    double q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return {hue2rgb(p, q, h + 1.0 / 3), hue2rgb(p, q, h), hue2rgb(p, q, h - 1.0 / 3), a};
}
Color Color::lighter(double f) const {
    double h, s, l;
    toHsl(*this, h, s, l);
    return fromHsl(h, s, std::clamp(l * f, 0.0, 1.0), a);
}
Color Color::darker(double f) const { return lighter(1.0 / f); }
std::string Color::toHex() const {
    char buf[16];
    snprintf(buf, sizeof buf, "#%02x%02x%02x", (int)std::lround(r * 255), (int)std::lround(g * 255), (int)std::lround(b * 255));
    return buf;
}

// ---------------------------------------------------------------- event loop --
Loop &Loop::get() {
    static Loop l;
    return l;
}
int Loop::addFd(int fd, short events, FdFn fn) {
    watches_.push_back({++nextId_, fd, events, std::move(fn)});
    return nextId_;
}
void Loop::setFdEvents(int id, short events) {
    for (auto &w : watches_) if (w.id == id) w.events = events;
}
void Loop::removeFd(int id) {
    for (auto &w : watches_) if (w.id == id) w.dead = true;
}
int Loop::addTimer(int ms, std::function<void()> fn, bool repeat) {
    timers_.push_back({++nextId_, nowMs() + std::max(0, ms), std::max(0, ms), repeat, std::move(fn)});
    return nextId_;
}
void Loop::removeTimer(int id) {
    for (auto &t : timers_) if (t.id == id) t.dead = true;
}
void Loop::restartTimer(int id) {
    for (auto &t : timers_) if (t.id == id) { t.due = nowMs() + t.interval; t.dead = false; }
}
bool Loop::timerActive(int id) const {
    for (auto &t : timers_) if (t.id == id && !t.dead) return true;
    return false;
}
void Loop::defer(std::function<void()> fn) { deferred_.push_back(std::move(fn)); }

void Loop::iterate(int maxWaitMs) {
    // deferred work first (may add more; those wait for the next pass)
    auto d = std::move(deferred_);
    deferred_.clear();
    for (auto &f : d) f();

    for (auto &f : prePoll_) f();

    int64_t now = nowMs();
    int wait = maxWaitMs;
    for (auto &t : timers_)
        if (!t.dead) wait = wait < 0 ? (int)std::max<int64_t>(0, t.due - now) : (int)std::min<int64_t>(wait, std::max<int64_t>(0, t.due - now));
    if (!deferred_.empty()) wait = 0;

    std::erase_if(watches_, [](const Watch &w) { return w.dead; });
    std::vector<pollfd> fds;
    std::vector<int> ids;
    for (auto &w : watches_) { fds.push_back({w.fd, w.events, 0}); ids.push_back(w.id); }
    int n = poll(fds.data(), fds.size(), wait);
    if (n < 0 && errno != EINTR) return;
    for (size_t i = 0; n > 0 && i < fds.size(); i++) {
        if (!fds[i].revents) continue;
        for (auto &w : watches_)
            if (w.id == ids[i] && !w.dead) { auto fn = w.fn; fn(fds[i].fd, fds[i].revents); break; }
    }
    // timers
    now = nowMs();
    std::vector<std::function<void()>> fire;
    for (auto &t : timers_) {
        if (t.dead || t.due > now) continue;
        fire.push_back(t.fn);
        if (t.repeat) t.due = now + std::max(1, t.interval);
        else t.dead = true;
    }
    std::erase_if(timers_, [](const Timer &t) { return t.dead; });
    for (auto &f : fire) f();
}

void Loop::run() {
    running_ = true;
    signal(SIGPIPE, SIG_IGN);
    while (running_) iterate(-1);
}

// ---------------------------------------------------------------- animation --
double ease(Ease e, double t) {
    t = std::clamp(t, 0.0, 1.0);
    switch (e) {
    case Ease::Linear: return t;
    case Ease::OutCubic: return 1 - std::pow(1 - t, 3);
    case Ease::OutQuint: return 1 - std::pow(1 - t, 5);
    case Ease::InOutCubic: return t < 0.5 ? 4 * t * t * t : 1 - std::pow(-2 * t + 2, 3) / 2;
    case Ease::OutBack: {
        const double c1 = 1.70158, c3 = c1 + 1;
        return 1 + c3 * std::pow(t - 1, 3) + c1 * std::pow(t - 1, 2);
    }
    }
    return t;
}
void Anim::animate(double to, int ms, Ease e) {
    if (ms <= 0) { set(to); return; }
    if (running_ && to == to_) return;
    from_ = value_;
    to_ = to;
    start_ = nowMs();
    dur_ = ms;
    ease_ = e;
    running_ = from_ != to_;
}
bool Anim::tick(int64_t now) {
    if (!running_) return false;
    double t = (now - start_) / (double)dur_;
    if (t >= 1) { value_ = to_; running_ = false; return false; }
    value_ = from_ + (to_ - from_) * ease(ease_, t);
    return true;
}

// ------------------------------------------------------------------- theme --
Theme &Theme::get() {
    static Theme t = [] { Theme x; x.rebuild(); return x; }();
    return t;
}
void Theme::rebuild() {
    double a = 1 - transparencyUi;
    if (dark) {
        text = Color::hex("#eeeaf3");
        text2 = Color::hex("#b9b4c4");
        text3 = Color::hex("#837e8f");
        surface = Color{0.08, 0.075, 0.11, a};
        surface2 = Color{1, 1, 1, 0.06};
        surface3 = Color{1, 1, 1, 0.11};
        border = Color{1, 1, 1, 0.09};
        panel = Color{0.063, 0.059, 0.086, 1 - transparencyPanel};
        window = Color{0.086, 0.082, 0.118, 1 - transparencyApps};
    } else {
        text = Color::hex("#1c1a22");
        text2 = Color::hex("#4c4856");
        text3 = Color::hex("#7d7888");
        surface = Color{0.97, 0.96, 0.94, a};
        surface2 = Color{0, 0, 0, 0.05};
        surface3 = Color{0, 0, 0, 0.09};
        border = Color{0, 0, 0, 0.09};
        panel = Color{0.96, 0.95, 0.93, 1 - transparencyPanel};
        window = Color{0.97, 0.96, 0.94, 1 - transparencyApps};
    }
    accentBright = dark ? accent.lighter(1.18) : accent.darker(1.25);
    accentSoft = accent.alpha(dark ? 0.18 : 0.16);
    accentLine = accent.alpha(0.45);
    onAccent = accent.luminance() > 0.45 ? accent.darker(4.2) : Color{1, 1, 1, 1};
    changed.emit();
}

// ---------------------------------------------------------------- strings --
std::string trim(const std::string &s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}
std::vector<std::string> split(const std::string &s, char sep) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == sep) { out.push_back(cur); cur.clear(); }
        else cur += c;
    }
    out.push_back(cur);
    return out;
}
std::string lower(std::string s) {
    for (auto &c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}
bool startsWith(const std::string &s, const std::string &p) { return s.rfind(p, 0) == 0; }
bool endsWith(const std::string &s, const std::string &p) {
    return s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0;
}
std::string replaceAll(std::string s, const std::string &from, const std::string &to) {
    if (from.empty()) return s;
    size_t pos = 0;
    while ((pos = s.find(from, pos)) != std::string::npos) { s.replace(pos, from.size(), to); pos += to.size(); }
    return s;
}
std::string homeDir() {
    if (const char *h = getenv("HOME"); h && *h) return h;
    if (passwd *pw = getpwuid(getuid())) return pw->pw_dir;
    return "/tmp";
}
std::string configDir() {
    if (const char *x = getenv("XDG_CONFIG_HOME"); x && *x) return x;
    return homeDir() + "/.config";
}
std::string runtimeDir() {
    if (const char *x = getenv("XDG_RUNTIME_DIR"); x && *x) return x;
    return "/tmp";
}
std::string readFile(const std::string &path, bool *ok) {
    std::ifstream f(path, std::ios::binary);
    if (ok) *ok = (bool)f;
    if (!f) return "";
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}
bool writeFile(const std::string &path, const std::string &data) {
    std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f << data;
        if (!f) return false;
    }
    return rename(tmp.c_str(), path.c_str()) == 0;
}
std::string shellQuote(const std::string &s) { return "'" + replaceAll(s, "'", "'\\''") + "'"; }

void spawn(const std::vector<std::string> &argv) {
    if (argv.empty()) return;
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        setsid();
        if (fork() == 0) {
            sigset_t set;
            sigemptyset(&set);
            sigprocmask(SIG_SETMASK, &set, nullptr);
            signal(SIGPIPE, SIG_DFL);
            int nul = open("/dev/null", O_RDWR);
            if (nul >= 0) { dup2(nul, 0); }
            std::vector<char *> a;
            for (auto &s : argv) a.push_back(const_cast<char *>(s.c_str()));
            a.push_back(nullptr);
            execvp(a[0], a.data());
            _exit(127);
        }
        _exit(0);
    }
    waitpid(pid, nullptr, 0);
}
void spawnShell(const std::string &cmd) { spawn({"sh", "-c", cmd}); }

}  // namespace ui
