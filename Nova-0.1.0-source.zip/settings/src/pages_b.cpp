// Sound, Power, Notifications, Popups & indicators, Music & lyrics, Gaming, Windows & tiling,
// Keyboard (with the shortcut editor), Mouse & touchpad, Panel & launcher, Users
#include "pages.hpp"
#include "ui/sys.hpp"

#include <cmath>
#include <filesystem>
#include <regex>
#include <xkbcommon/xkbcommon.h>

namespace settings {

using namespace ui;

static std::string fmt1(const char *f, double v) { char b[32]; snprintf(b, sizeof b, f, v); return b; }

// ===================================================================== Sound ==
struct Vol { double v = 0; bool muted = false; };
static Vol readVol(const std::string &dev) {
    std::string o = Backend::run({"wpctl", "get-volume", dev});
    std::smatch m;
    Vol r;
    if (std::regex_search(o, m, std::regex("Volume: ([\\d.]+)( \\[MUTED\\])?"))) { r.v = atof(m[1].str().c_str()); r.muted = m[2].matched; }
    return r;
}

void pageSound(Page *p) {
    const Theme &t = theme();
    Vol out = readVol("@DEFAULT_AUDIO_SINK@"), mic = readVol("@DEFAULT_AUDIO_SOURCE@");
    auto o = card(p, "Output", "volume");
    o.extra->add<Label>("Mute", 13)->fill = false;
    o.extra->add<Toggle>(out.muted)->onToggled = [](bool v) { Backend::run({"wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", v ? "1" : "0"}); };
    auto pct = [](double v) { return std::to_string((int)std::lround(v * 100)) + " %"; };
    auto *vs = o.body->add<RangeSlider>(0, 1.5, out.v, pct);
    vs->onMoved = [](double v) { Backend::runDetached({"wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", fmt1("%.2f", v)}); };
    o.body->add<Label>("Device", 12, Weight::DemiBold, Role::Text3);
    std::string sinks = Backend::run({"sh", "-c", "wpctl status | sed -n '/Sinks:/,/Sources:/p' | grep -E '^ │ +\\*? *[0-9]+\\.' | sed -E 's/ \\[vol.*//'"});
    for (auto &l : split(sinks, '\n')) {
        if (trim(l).empty()) continue;
        bool on = l.find('*') != std::string::npos;
        std::smatch m;
        std::string id = std::regex_search(l, m, std::regex("(\\d+)\\.")) ? m[1].str() : "";
        std::string name = std::regex_replace(l, std::regex("^[^0-9]*\\d+\\.\\s*"), "");
        auto *b = o.body->add<Button>(Dir::Row, 12);
        b->fixedH = 46;
        b->radius = 12;
        b->padding(12, 0);
        b->bg = on ? t.accentSoft : Color{0, 0, 0, 0};
        b->hoverBg = on ? t.accentSoft : t.surface3;
        b->add<IconW>("headphones", 20, on ? Role::AccentBright : Role::Text);
        b->add<Label>(trim(name), 14)->grow = 1;
        b->onClick = [p, id] { Backend::run({"wpctl", "set-default", id}); p->rebuildSoon(); };
    }
    auto i = card(p, "Input", "mic");
    i.extra->add<Label>("Mute", 13)->fill = false;
    i.extra->add<Toggle>(mic.muted)->onToggled = [](bool v) { Backend::run({"wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", v ? "1" : "0"}); };
    auto *ms = i.body->add<RangeSlider>(0, 1, mic.v, pct);
    ms->onMoved = [](double v) { Backend::runDetached({"wpctl", "set-volume", "@DEFAULT_AUDIO_SOURCE@", fmt1("%.2f", v)}); };
    auto v = card(p, "Volume", "volume");
    toggleKey(row2(v.body, "Allow volume above 100 %", {.key = "allowOverAmplify", .hint = "Up to 150 % for quiet videos. May distort on small speakers."}), "allowOverAmplify");
    btn(p, "Advanced mixer…")->onClick = [] { Backend::runDetached({"pavucontrol"}); };
}

// ===================================================================== Power ==
static Box *profileRow(Widget *parent, const std::string &current, std::function<void(const std::string &)> pick) {
    const Theme &t = theme();
    auto *r = row(parent, 4);
    for (auto [id, icon, label] : std::vector<std::tuple<std::string, std::string, std::string>>{
             {"power-saver", "leaf", "Saver"}, {"balanced", "gauge", "Balanced"}, {"performance", "bolt", "Performance"}}) {
        bool on = current == id;
        auto *b = r->add<Button>(Dir::Row, 8);
        b->grow = 1;
        b->fixedH = 52;
        b->radius = 14;
        b->justify = Justify::Center;
        b->bg = on ? t.accent : t.surface3;
        b->hoverBg = on ? t.accentBright : t.surface3.lighter(0.05);
        b->add<IconW>(icon, 17, on ? Role::OnAccent : Role::Text2);
        b->add<Label>(label, 14, on ? Weight::DemiBold : Weight::Normal, on ? Role::OnAccent : Role::Text2)->fill = false;
        std::string v = id;
        b->onClick = [pick, v] { pick(v); };
    }
    return r;
}

void pagePower(Page *p) {
    std::string profile = trim(Backend::run({"nova-power", "get"}));
    auto pm = card(p, "Power mode", "gauge");
    profileRow(pm.body, profile, [p](const std::string &v) { Backend::run({"nova-power", "set", v}); p->rebuildSoon(); });

    std::string bat = Backend::run({"sh", "-c", "upower -i $(upower -e | grep -m1 BAT) 2>/dev/null"});
    auto field = [&bat](const std::string &n) {
        std::smatch m;
        return std::regex_search(bat, m, std::regex(n + ":\\s+(.+)")) ? trim(m[1].str()) : std::string();
    };
    if (!trim(bat).empty() && !field("percentage").empty()) {
        auto b = card(p, "Battery", "battery", field("percentage") + " · " + field("state"));
        std::string left = field("time to empty");
        if (left.empty()) left = field("time to full");
        for (auto [k, v] : std::vector<std::pair<std::string, std::string>>{
                 {"Time remaining", left}, {"Health", field("capacity")}, {"Charge cycles", field("charge-cycles")}, {"Model", field("model")}}) {
            auto *r = row(b.body, 0);
            auto *kl = r->add<Label>(k, 13, Weight::Normal, Role::Text3);
            kl->fixedW = 160;
            r->add<Label>(v.empty() ? "—" : v, 13)->grow = 1;
        }
    }

    auto idle = card(p, "When idle", "moon", "Nothing dims, locks or sleeps while a game, video or anything fullscreen is running");
    auto *h = row(idle.body, 18);
    stretch(h);
    for (const char *s : {"On battery", "Plugged in"}) {
        auto *l = h->add<Label>(s, 12, Weight::DemiBold, Role::Text3);
        l->fixedW = 150;
        l->hAlign = Align::Center;
    }
    h->add<Spacer>(28, 0);
    for (auto [label, kb, ka] : std::vector<std::tuple<std::string, std::string, std::string>>{
             {"Dim the screen", "idleDimBattery", "idleDimAc"}, {"Lock", "idleLockBattery", "idleLockAc"}, {"Sleep", "idleSleepBattery", "idleSleepAc"}}) {
        auto *r = row(idle.body, 18);
        r->fixedH = 40;
        r->add<Label>(label, 14)->grow = 1;
        minutesKey(r, kb);
        minutesKey(r, ka);
        std::string a = kb, b = ka;
        r->add<ResetButton>([a, b] { return !backend().isDefault(a) || !backend().isDefault(b); }, [a, b] { backend().reset(a); backend().reset(b); });
    }

    std::string gpus;
    for (auto &l : split(backend().gpuInfo(), '\n')) {
        auto w = split(trim(l), ' ');
        if (w.size() >= 3) gpus += (gpus.empty() ? "" : " · ") + w[1] + " (" + w[2] + ")";
    }
    auto g = card(p, "Graphics", "monitor", gpus.empty() ? "One GPU" : gpus);
    segKey(row2(g.body, "Run the desktop on", {.key = "gpuPrimary", .hint = "Integrated saves battery. Takes effect at next login."}), "gpuPrimary",
           {"auto", "integrated", "dedicated"}, {"Automatic", "Integrated", "Dedicated"});
    toggleKey(row2(g.body, "Start games on the dedicated GPU", {.key = "gamesOnDedicatedGpu", .hint = "Steam, Heroic, Lutris and anything in the Games category"}),
              "gamesOnDedicatedGpu");
}

// ============================================================= Notifications ==
void pageNotifications(Page *p) {
    auto n = card(p, "Notifications", "bell");
    toggleKey(row2(n.body, "Do not disturb", {.key = "dnd", .hint = "Only critical notifications pop up. Everything still lands in the list."}), "dnd");
    sliderKey(row2(n.body, "Show for", {.key = "notificationTimeout", .hint = "How long pop-ups stay on screen"}), "notificationTimeout", 2000, 15000,
              [](double v) { return std::to_string((int)std::lround(v / 1000)) + " s"; }, 1000);
    auto g = card(p, "Grouping & fullscreen", "bell");
    toggleKey(row2(g.body, "Group by app", {.key = "groupNotifications", .hint = "Several notifications from one app fold into one stack"}), "groupNotifications");
    toggleKey(row2(g.body, "Quiet while fullscreen", {.key = "autoDnd", .hint = "Games and videos aren't interrupted; you get a count of what you missed afterwards"}),
              "autoDnd");
    auto c = card(p, "Clipboard history", "clip", "Super+V. Passwords copied from password managers are never kept.");
    toggleKey(row2(c.body, "Keep history after restarting", {.key = "clipboardKeep"}), "clipboardKeep");
    btn(row2(c.body, "Clear history now"), "Clear")->onClick = [] { Backend::run({"cliphist", "wipe"}); };
}

// ======================================================= Popups & indicators ==
static json osdDefaults() {
    return json::parse(R"({
        "slider": { "pos": 5, "dir": "up", "dx": 0, "dy": 0 }, "lock": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 },
        "power": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 }, "notifications": { "pos": 8, "dir": "up", "dx": 0, "dy": 0 },
        "message": { "pos": 1, "dir": "across", "dx": 0, "dy": 0 }, "nowplaying": { "pos": 8, "dir": "clock", "dx": 0, "dy": 0 },
        "lyrics": { "pos": 7, "dir": "centre", "dx": 0, "dy": 40 }, "visualizer": { "pos": 7, "dir": "across", "dx": 0, "dy": 0 }})");
}
static json osdOf(const std::string &k) {
    json o = osdDefaults()[k];
    json user = backend().value("osd");
    if (user.is_object() && user.contains(k) && user[k].is_object()) for (auto &[a, v] : user[k].items()) o[a] = v;
    return o;
}
static void osdPut(const std::string &k, const json &patch) {
    json all = backend().value("osd");
    if (!all.is_object()) all = json::object();
    json o = osdOf(k);
    for (auto &[a, v] : patch.items()) o[a] = v;
    all[k] = o;
    backend().set("osd", all);
}

// 3×3 anchor picker
class AnchorPicker : public Widget {
public:
    int pos = 8;
    std::function<void(int)> picked;
    AnchorPicker() { interactive = true; cursor = Cursor::Pointer; }
    Size sizeHint(double, double) override { return {98, 58}; }
    Rect cell(int i) const { return {geom.x + 7 + (i % 3) * 30, geom.y + 7 + (i / 3) * 15.5, 26, 13}; }
    void paint(Painter &p) override {
        p.fill(geom, Color{0, 0, 0, 0.25}, 11);
        p.stroke(geom.inset(0.5), theme().border, 1, 11);
        for (int i = 0; i < 9; i++)
            p.fill(cell(i), i == pos ? theme().accent : i == hot_ ? Color{1, 1, 1, 0.14} : Color{1, 1, 1, 0.07}, 4);
    }
    void pointerMove(Point pt) override {
        int h = -1;
        for (int i = 0; i < 9; i++) if (cell(i).contains(pt)) h = i;
        if (h != hot_) { hot_ = h; update(); }
    }
    void pointerLeave() override { hot_ = -1; Widget::pointerLeave(); }
    bool pointerPress(Point pt, int) override {
        for (int i = 0; i < 9; i++) if (cell(i).contains(pt) && picked) picked(i);
        return true;
    }
private:
    int hot_ = -1;
};

// preview with draggable indicators
class OsdPreview : public Widget {
public:
    std::shared_ptr<Image> wp;
    std::string *selected = nullptr;
    std::function<void()> changed;
    OsdPreview() { interactive = true; fixedH = 190; }
    struct Chip { std::string k; Rect r; int row, col; };
    std::vector<Chip> chips() const {
        std::vector<Chip> out;
        double k = geom.w / 1920, edge = 8;
        for (std::string id : {"slider", "lock", "notifications", "message"}) {
            json c = osdOf(id);
            int pos = c.value("pos", 8), r = pos / 3, cl = pos % 3;
            bool vert = id == "notifications" ? false : c.value("dir", std::string()) == "up";
            double w = id == "notifications" ? 76 : vert ? 14 : 64, h = id == "notifications" ? 26 : vert ? 60 : 13;
            double dx = c.value("dx", 0.0), dy = c.value("dy", 0.0);
            double x = cl == 0 ? edge + dx * k : cl == 2 ? geom.w - w - edge + dx * k : (geom.w - w) / 2;
            double y = r == 0 ? edge + dy * k : r == 2 ? geom.h - 14 - h - edge + dy * k : (geom.h - 14 - h) / 2;
            Rect rr{geom.x + x, geom.y + y, w, h};
            if (id == drag_) rr = rr.translated(off_.x, off_.y);
            out.push_back({id, rr, r, cl});
        }
        return out;
    }
    void paint(Painter &p) override {
        p.save();
        p.clip(geom, 14);
        p.fill(geom, Color{0, 0, 0, 1});
        if (wp && wp->valid()) p.image(*wp, geom, 0, true, 0.7);
        p.fill({geom.x, geom.bottom() - 14, geom.w, 14}, Color{0.06, 0.06, 0.09, 0.9});
        for (auto &c : chips()) {
            double rad = std::min(c.r.w, c.r.h) / 2;
            p.fill(c.r, selected && *selected == c.k ? theme().accent : Color{0.08, 0.075, 0.11, 0.9}, rad);
            p.stroke(c.r, Color{1, 1, 1, 0.22}, 1, rad);
        }
        p.restore();
        p.stroke(geom.inset(0.5), theme().border, 1, 14);
    }
    bool pointerPress(Point pt, int) override {
        for (auto &c : chips())
            if (c.r.contains(pt)) { drag_ = c.k; start_ = pt; off_ = {0, 0}; if (selected) *selected = c.k; update(); }
        return true;
    }
    void pointerMove(Point pt) override { if (!drag_.empty()) { off_ = {pt.x - start_.x, pt.y - start_.y}; update(); } }
    void pointerRelease(Point, int) override {
        if (drag_.empty()) return;
        double k = geom.w / 1920;
        json c = osdOf(drag_);
        int pos = c.value("pos", 8);
        auto clampv = [](double v) { return (int)std::clamp(std::lround(v), -200L, 200L); };
        json patch;
        patch["dx"] = pos % 3 == 1 ? 0 : clampv(c.value("dx", 0.0) + off_.x / k);
        patch["dy"] = pos / 3 == 1 ? 0 : clampv(c.value("dy", 0.0) + off_.y / k);
        osdPut(drag_, patch);
        drag_.clear();
        off_ = {0, 0};
        if (changed) changed();
    }
private:
    std::string drag_;
    Point start_, off_;
};

void pagePopups(Page *p) {
    const Theme &t = theme();
    static std::string selected = "slider";
    auto *cols = p->add<Columns>();
    cols->threshold = 1000;
    // ---- list ----
    auto list = card(cols);
    list.body->spacing = 0;
    std::vector<std::tuple<std::string, std::string, std::string, std::array<std::string, 4>>> rows = {
        {"slider", "Volume, brightness & mic", "Also keyboard backlight", {"across", "Across", "up", "Up"}},
        {"lock", "Caps / Num Lock", "Shows when you press them", {"across", "Across", "up", "Up"}},
        {"power", "Power mode & charging", "", {"across", "Across", "up", "Up"}},
        {"notifications", "Notification pop-ups", "Newest nearest the edge", {"up", "Stack up", "down", "Stack down"}},
        {"message", "Small messages", "“Copied”, “Screenshot saved”", {"across", "Across", "up", "Up"}},
        {"nowplaying", "Now playing", "Opens when you hover the clock", {"clock", "Above clock", "free", "Free"}},
        {"lyrics", "Desktop lyrics", backend().b("lyricsDesktop") ? "On" : "Off · turn on in Music & lyrics", {"centre", "Centred", "left", "Left"}},
        {"visualizer", "Desktop visualizer", "Used when its position is Custom", {"across", "Across", "up", "Up"}}};
    json userOsd = backend().value("osd");
    for (size_t i = 0; i < rows.size(); i++) {
        auto &[k, label, hint, dirs] = rows[i];
        json c = osdOf(k);
        if (i) list.body->add<Separator>();
        auto *r = row(list.body, 14);
        r->pt = r->pb = 9;
        auto *tc = col(r, 2);
        tc->grow = 1;
        tc->add<Label>(label, 14, Weight::Medium);
        if (!hint.empty()) tc->add<Label>(hint, 12, Weight::Normal, Role::Text3);
        auto *ap = r->add<AnchorPicker>();
        ap->pos = c.value("pos", 8);
        if (k == "nowplaying" && c.value("dir", std::string()) == "clock") ap->opacity.set(0.35);
        std::string key = k;
        ap->picked = [p, key](int pos) {
            json patch = {{"pos", pos}, {"dx", 0}, {"dy", 0}};
            if (key == "nowplaying") patch["dir"] = "free";
            osdPut(key, patch);
            selected = key;
            p->rebuildSoon();
        };
        auto *seg = r->add<Segmented>();
        seg->small = true;
        seg->fill = false;
        seg->options = {{dirs[0], dirs[1], ""}, {dirs[2], dirs[3], ""}};
        seg->value = c.value("dir", dirs[0]);
        seg->onPicked = [p, key](const std::string &v) { osdPut(key, {{"dir", v}}); selected = key; p->rebuildSoon(); };
        bool custom = userOsd.is_object() && userOsd.contains(k);
        r->add<ResetButton>([custom] { return custom; }, [p, key] {
            json all = backend().value("osd");
            if (all.is_object()) all.erase(key);
            backend().set("osd", all);
            p->rebuildSoon();
        });
    }
    // ---- preview + behaviour ----
    auto *side = col(cols, 12);
    side->add<Label>("Preview", 12, Weight::DemiBold, Role::Text3);
    auto *pv = side->add<OsdPreview>();
    pv->wp = thumbnail(wallpaperOrDefault(), 640);
    pv->selected = &selected;
    pv->changed = [p] { p->rebuildSoon(); };
    caption(side, "Drag an indicator to nudge it off its anchor. Centred positions stay centred.");
    side->add<Label>("Behaviour", 12, Weight::DemiBold, Role::Text3)->mt = 6;
    auto beh = card(side);
    segKey(row2(beh.body, "Hide after", {.key = "osdTimeout"}), "osdTimeout", {1000, 2000, 4000}, {"1 s", "2 s", "4 s"});
    segKey(row2(beh.body, "Size", {.key = "osdSize"}), "osdSize", {"S", "M", "L"});
    segKey(row2(beh.body, "Show on", {.key = "osdScreen"}), "osdScreen", {"active", "all"}, {"Active screen", "All"});
    side->add<Label>("Lock keys", 12, Weight::DemiBold, Role::Text3)->mt = 6;
    auto lk = card(side);
    toggleConf(row2(lk.body, "Remember after restart", {.section = "input", .confKey = "remember_locks", .hint = "Caps / Num Lock come back as you left them"}),
               "input", "remember_locks", "true");
    toggleKey(row2(lk.body, "Show in panel when on", {.key = "lockInPanel"}), "lockInPanel");
    (void)t;
}

// ============================================================ Music & lyrics ==
class StyleTile : public Button {
public:
    StyleTile(int number, const std::string &name, bool on) : Button(Dir::Column, 2) {
        const Theme &t = theme();
        grow = 1;
        fixedH = 64;
        radius = 12;
        justify = Justify::Center;
        crossAlign = Align::Center;
        bg = on ? t.accentSoft : t.surface3;
        border = on ? t.accent : t.border;
        borderWidth = on ? 2 : 1;
        char b[8];
        snprintf(b, sizeof b, "%02d", number);
        add<Label>(b, 11, Weight::DemiBold, on ? Role::Accent : Role::Text3)->fill = false;
        add<Label>(name, 13, on ? Weight::DemiBold : Weight::Normal, on ? Role::Text : Role::Text2)->fill = false;
    }
};
static void styleGrid(Widget *parent, const std::vector<std::string> &names, int perRow, const std::string &key, Page *p) {
    int cur = (int)backend().d(key, 1);
    Box *line = nullptr;
    auto *g = col(parent, 10);
    for (size_t i = 0; i < names.size(); i++) {
        if (i % perRow == 0) line = row(g, 10);
        auto *tile = line->add<StyleTile>((int)i + 1, names[i], cur == (int)i + 1);
        int v = (int)i + 1;
        tile->onClick = [p, key, v] { backend().set(key, v); p->rebuildSoon(); };
    }
    if (line) while ((int)line->children().size() < perRow) line->add<Spacer>()->grow = 1;
}

void pageMusic(Page *p) {
    auto l = card(p, "Synced lyrics", "music", "Found by title and artist. If that fails, SongRec identifies the song and Nova searches again.");
    toggleKey(row2(l.body, "In Now Playing", {.key = "lyricsNowPlaying", .hint = "A Lyrics tab when you hover the clock"}), "lyricsNowPlaying");
    toggleKey(row2(l.body, "On the desktop", {.key = "lyricsDesktop", .hint = "Position it on the Popups & indicators page"}), "lyricsDesktop");
    l.body->add<Label>("Style", 12, Weight::DemiBold, Role::Text3)->mt = 4;
    styleGrid(l.body, {"Fade stack", "Karaoke sweep", "Terminal", "Word bloom", "Accent rail", "Outline"}, 3, "lyricsStyle", p);
    segKey(row2(l.body, "Text size", {.key = "lyricsSize"}), "lyricsSize", {"S", "M", "L", "XL"});
    sliderKey(row2(l.body, "Timing", {.key = "lyricsOffset", .hint = "Move lyrics earlier or later if they don't line up"}), "lyricsOffset", -2, 2,
              [](double v) { return fmt1(v >= 0 ? "+%.1f s" : "%.1f s", v); }, 0.1);
    toggleKey(row2(l.body, "Hide when a window is fullscreen", {.key = "lyricsHideFullscreen"}), "lyricsHideFullscreen");
    toggleKey(row2(l.body, "Identify songs with SongRec", {.key = "lyricsSongRec", .hint = "Only when search finds nothing. Sends a short audio fingerprint to Shazam."}),
              "lyricsSongRec");
    btn(row2(l.body, "Saved lyrics", {.hint = "Kept for offline use in ~/.cache/nova/lyrics"}), "Clear")->onClick = [] {
        Backend::run({"sh", "-c", "rm -rf \"${XDG_CACHE_HOME:-$HOME/.cache}/nova/lyrics\""});
    };

    auto v = card(p, "Beat visualizer", "music", "Uses cava. Only runs while music is playing; slower on battery.");
    json places = backend().value("vizPlaces");
    if (!places.is_array()) places = json::array();
    auto *pl = row2(v.body, "Show in", {.key = "vizPlaces"});
    for (auto [id, label] : std::vector<std::pair<std::string, std::string>>{{"nowplaying", "Now Playing"}, {"lock", "Lock screen"}, {"clock", "Clock pill"}, {"desktop", "Desktop"}}) {
        bool on = std::find(places.begin(), places.end(), id) != places.end();
        std::string k = id;
        chip(pl, label, on, [p, k, on, places] {
            json n = json::array();
            for (auto &x : places) if (x != k) n.push_back(x);
            if (!on) n.push_back(k);
            backend().set("vizPlaces", n);
            p->rebuildSoon();
        });
    }
    v.body->add<Label>("Style", 12, Weight::DemiBold, Role::Text3)->mt = 4;
    styleGrid(v.body, {"Bars", "Wave line", "Filled wave", "LED matrix", "Peak caps", "Mountains", "Pills"}, 4, "vizStyle", p);
    segKey(row2(v.body, "Colour", {.key = "vizColour"}), "vizColour", {"accent", "art", "rainbow"}, {"Accent", "Album art", "Rainbow"});
    segKey(row2(v.body, "Bars", {.key = "vizBars"}), "vizBars", {16, 32, 64}, {"16", "32", "64"});
    sliderKey(row2(v.body, "Sensitivity", {.key = "vizSensitivity"}), "vizSensitivity", 0, 1,
              [](double x) { return std::to_string((int)std::lround(x * 100)) + " %"; });
    v.body->add<Label>("On the desktop", 12, Weight::DemiBold, Role::Text3)->mt = 4;
    segKey(row2(v.body, "Position", {.key = "vizDesktopPos"}), "vizDesktopPos", {"bottom", "centre", "top", "custom"}, {"Bottom edge", "Centre", "Top edge", "Custom"});
    toggleKey(row2(v.body, "Show song title", {.key = "vizDesktopTitle"}), "vizDesktopTitle");
    sliderKey(row2(v.body, "Opacity", {.key = "vizDesktopOpacity"}), "vizDesktopOpacity", 0.2, 1,
              [](double x) { return std::to_string((int)std::lround(x * 100)) + " %"; });
}

// ==================================================================== Gaming ==
void pageGaming(Page *p) {
    bool gsr = haveProgram("gpu-screen-recorder");
    auto g = card(p, "Game mode", "game", "Turns on when a game goes fullscreen: Feral GameMode, performance power profile, no pop-ups, nothing dims or sleeps");
    toggleKey(row2(g.body, "Automatic game mode", {.key = "gameModeAuto"}), "gameModeAuto");
    toggleKey(row2(g.body, "Start games on the dedicated GPU", {.key = "gamesOnDedicatedGpu", .hint = "For laptops with two GPUs"}), "gamesOnDedicatedGpu");
    toggleKey(row2(g.body, "FPS & stats overlay (MangoHud)", {.key = "mangohud", .hint = "Shows FPS, frame time, CPU and GPU load inside games. Shift+F12 hides it in game."}),
              "mangohud");
    auto *tear = row2(g.body, "Allow tearing in fullscreen games", {.section = "general", .confKey = "tearing", .hint = "Lowest input latency. Variable refresh rate is used when the screen supports it."});
    tear->add<Toggle>(backend().conf("general", "tearing", "auto") != "never")->onToggled = [](bool v) { backend().setConf("general", "tearing", v ? "auto" : "never"); };
    toggleConf(row2(g.body, "Variable refresh rate in fullscreen", {.section = "general", .confKey = "vrr"}), "general", "vrr", "true");

    auto r = card(p, "Instant replay", "record", gsr ? "Keeps the last moments of gameplay in memory. Super+Alt+R saves them." : "Needs gpu-screen-recorder (reinstall Nova to add it)");
    auto *rt = toggleKey(row2(r.body, "Instant replay", {.key = "replayEnabled"}), "replayEnabled");
    if (!gsr) { rt->interactive = false; rt->opacity.set(0.4); }
    segKey(row2(r.body, "Keep the last", {.key = "replaySeconds"}), "replaySeconds", {15, 30, 60, 120}, {"15 s", "30 s", "1 min", "2 min"});

    auto rec = card(p, "Recording", "video");
    segKey(row2(rec.body, "Format", {.key = "recordFormat", .hint = "MP4 plays everywhere; MKV survives crashes"}), "recordFormat", {"mp4", "mkv"}, {"MP4 (H.264)", "MKV"});
    toggleKey(row2(rec.body, "Record system sound", {.key = "recordSystemAudio"}), "recordSystemAudio");
    toggleKey(row2(rec.body, "Record microphone", {.key = "recordMic"}), "recordMic");
    row2(rec.body, "Saved to", {.hint = "~/Videos/Recordings  ·  screenshots go to ~/Pictures/Screenshots and the clipboard"});
}

// ========================================================== Windows & tiling ==
void pageWindows(Page *p) {
    auto w = card(p, "Windows", "square");
    auto *gs = row2(w.body, "Gap between snapped windows", {.section = "general", .confKey = "gaps"});
    auto *st = gs->add<Stepper>();
    st->value = atoi(backend().conf("general", "gaps", "0").c_str());
    st->min = 0;
    st->max = 40;
    st->step = 2;
    st->onChanged = [](double v) { backend().setConf("general", "gaps", std::to_string((int)v)); };
    toggleConf(row2(w.body, "Focus follows mouse", {.section = "general", .confKey = "focus_follows_mouse", .hint = "Off: click a window to focus it"}),
               "general", "focus_follows_mouse");
    row2(w.body, "Snapping", {.hint = "Drag a window to the left or right edge to fill half the screen, the top edge to maximise. Super+arrows do the same."});
    auto ws = card(p, "Workspaces", "grid", "Each monitor has its own workspaces. New ones appear when you need them; empty ones go away.");
    row2(ws.body, "Switch", {.hint = "Super+1…9 on the monitor under the mouse · 3-finger swipe left/right"});
    row2(ws.body, "Overview", {.hint = "Super+Tab · 3-finger swipe up"});
    toggleConf(row2(ws.body, "3-finger swipe switches workspace", {.section = "input", .confKey = "gesture_workspaces"}), "input", "gesture_workspaces", "true");
    toggleConf(row2(ws.body, "3-finger swipe up opens the overview", {.section = "input", .confKey = "gesture_overview"}), "input", "gesture_overview", "true");
}

// ================================================================== Keyboard ==
static std::string actionLabel(const std::string &a) {
    static const std::map<std::string, std::string> names = {
        {"shell launcher", "Open the launcher"}, {"shell overview", "Overview"}, {"shell controlcentre", "Control centre"},
        {"shell notifications", "Notifications"}, {"shell clipboard", "Clipboard history"}, {"lock", "Lock the screen"},
        {"shell capture", "Screenshot / record bar"}, {"shell save-replay", "Save instant replay"}, {"shell gameoverlay", "Game overlay"},
        {"close", "Close window"}, {"fullscreen", "Fullscreen"}, {"maximize", "Maximise"}, {"restore", "Restore / minimise"},
        {"tile-left", "Snap left"}, {"tile-right", "Snap right"}, {"minimize", "Minimise"}, {"cycle", "Next window"},
        {"cycle-reverse", "Previous window"}, {"workspace next", "Next workspace"}, {"workspace prev", "Previous workspace"},
        {"move-to-output next", "Move window to other monitor"}, {"exec $terminal", "Terminal"}, {"exec nautilus", "Files"},
        {"reload", "Reload Nova settings"}};
    auto it = names.find(a);
    if (it != names.end()) return it->second;
    std::smatch m;
    if (std::regex_match(a, m, std::regex("workspace (\\d)"))) return "Workspace " + m[1].str();
    if (std::regex_match(a, m, std::regex("move-to-workspace (\\d)"))) return "Move window to workspace " + m[1].str();
    if (startsWith(a, "exec nova-record shot")) return "Screenshot (" + trim(a.substr(21)) + ")";
    if (startsWith(a, "exec nova-record toggle")) return "Start / stop recording";
    if (startsWith(a, "exec ")) return "Run: " + a.substr(5);
    return a;
}

// key event -> nova.conf key name ("" for a lone modifier)
static std::string comboFrom(const KeyEvent &e) {
    uint32_t s = e.sym;
    if (s == XKB_KEY_Super_L || s == XKB_KEY_Super_R || s == XKB_KEY_Control_L || s == XKB_KEY_Control_R || s == XKB_KEY_Alt_L ||
        s == XKB_KEY_Alt_R || s == XKB_KEY_Shift_L || s == XKB_KEY_Shift_R || s == XKB_KEY_Meta_L || s == XKB_KEY_Meta_R || s == XKB_KEY_ISO_Level3_Shift)
        return "";
    uint32_t base = xkb_keysym_to_lower(s);
    if (base == XKB_KEY_ISO_Left_Tab) base = XKB_KEY_Tab;
    char name[64];
    if (xkb_keysym_get_name(base, name, sizeof name) <= 0) return "";
    std::string k = name;
    if (k.size() == 1) k[0] = (char)toupper(k[0]);
    if (k == "space") k = "Space";
    std::string out;
    if (e.super) out += "Super+";
    if (e.ctrl) out += "Ctrl+";
    if (e.alt) out += "Alt+";
    if (e.shift) out += "Shift+";
    return out + k;
}

struct ShortcutState {
    std::string filter, recording, error, newAction = "exec ";
    bool adding = false;
    int addPick = 0;
};

static void buildShortcuts(Box *ed, Page *p, std::shared_ptr<ShortcutState> st) {
    const Theme &t = theme();
    ed->clear();
    auto again = [ed, p, st] { p->conns.later([ed, p, st] { buildShortcuts(ed, p, st); }); };
    auto list = backend().bindings();
    auto defs = backend().defaultBindings();
    auto *top = row(ed, 10);
    auto *q = top->add<TextInput>();
    q->leadingIcon = "search";
    q->placeholder = "Search shortcuts";
    q->grow = 1;
    q->setText(st->filter);
    q->onChanged = [st, again](const std::string &s) { st->filter = lower(s); again(); };
    btn(top, "Add shortcut", "plus")->onClick = [st, again] { st->adding = !st->adding; st->error.clear(); again(); };
    if (!st->error.empty()) {
        auto *e = ed->add<Label>(st->error, 13);
        e->role = Role::Danger;
    }
    if (!st->recording.empty()) ed->add<Label>("Press the new keys…  (Esc cancels)", 13, Weight::Normal, Role::AccentBright);
    if (st->adding) {
        auto *a = row(ed, 10);
        a->radius = 14;
        a->bg = t.accentSoft;
        a->border = t.accentLine;
        a->padding(12);
        auto *dd = a->add<Dropdown>();
        dd->fixedW = 230;
        std::vector<std::pair<std::string, std::string>> acts = {
            {"exec ", "Run a command"}, {"shell launcher", "Open the launcher"}, {"shell overview", "Overview"}, {"lock", "Lock the screen"},
            {"shell capture", "Screenshot / record bar"}, {"shell gameoverlay", "Game overlay"}, {"close", "Close window"}, {"fullscreen", "Fullscreen"}};
        dd->items = acts;
        bool isCmd = startsWith(st->newAction, "exec ");
        dd->setValue(isCmd ? "exec " : st->newAction);
        dd->onPicked = [st, again](const std::string &v) { st->newAction = v; again(); };
        if (isCmd) {
            auto *cmd = a->add<TextInput>();
            cmd->grow = 1;
            cmd->placeholder = "Command, e.g. firefox";
            cmd->setText(st->newAction.substr(5));
            cmd->onChanged = [st](const std::string &s) { st->newAction = "exec " + s; };
        } else stretch(a);
        btn(a, st->recording == "+new" ? "Press keys…" : "Set keys", "", true)->onClick = [st, again] { st->error.clear(); st->recording = "+new"; again(); };
    }
    for (auto &b : list) {
        std::string label = actionLabel(b.action);
        if (!st->filter.empty() && lower(label).find(st->filter) == std::string::npos && lower(b.combo).find(st->filter) == std::string::npos) continue;
        auto *r = row(ed, 10);
        r->add<Label>(label, 14)->grow = 1;
        bool rec = st->recording == b.combo;
        auto *k = r->add<Button>(Dir::Row, 0);
        k->fixedH = 32;
        k->minW = 110;
        k->radius = 9;
        k->padding(12, 0);
        k->justify = Justify::Center;
        k->bg = rec ? t.accent : t.surface2;
        k->hoverBg = rec ? t.accent : t.surface3;
        k->border = t.border;
        auto *kl = k->add<Label>(rec ? "Press keys…" : replaceAll(b.combo, "+", " + "), 13, Weight::DemiBold, rec ? Role::OnAccent : Role::Text);
        kl->font.mono = true;
        kl->fill = false;
        std::string combo = b.combo, action = b.action;
        k->onClick = [st, combo, again] { st->error.clear(); st->recording = combo; again(); };
        std::vector<std::string> dfor;
        for (auto &d : defs) if (d.action == b.action) dfor.push_back(d.combo);
        bool canReset = !b.isDefault && !dfor.empty() && std::find(dfor.begin(), dfor.end(), b.combo) == dfor.end();
        auto *rb = r->add<ResetButton>([canReset] { return canReset; }, [st, combo, action, dfor, again] {
            st->error = backend().setBinding(combo, dfor[0], action);
            again();
        });
        if (!dfor.empty()) rb->tooltip = "Back to " + dfor[0];
        auto *x = r->add<ResetButton>(nullptr, [combo, again] { backend().removeBinding(combo); again(); }, "x");
        x->tooltip = "Remove";
    }
    // key capture while recording
    if (ed->window()) {
        ed->window()->onKey = [st, again, list](const KeyEvent &e) {
            if (st->recording.empty() || !e.pressed) return false;
            if (e.sym == key::Escape) { st->recording.clear(); st->error.clear(); again(); return true; }
            std::string c = comboFrom(e);
            if (c.empty()) return true;    // wait for the real key
            std::string old = st->recording == "+new" ? "" : st->recording;
            std::string act = st->newAction;
            if (st->recording != "+new")
                for (auto &b : list) if (b.combo == old) act = b.action;
            st->error = backend().setBinding(old, c, act);
            if (st->error.empty()) { st->recording.clear(); st->adding = false; }
            again();
            return true;
        };
        if (!st->recording.empty()) ed->window()->setFocus(nullptr);
    }
    ed->relayout();
}

void pageKeyboard(Page *p) {
    auto l = card(p, "Layout", "keyboard", "Comma-separate several layouts and switch with the options below (e.g. grp:alt_shift_toggle)");
    auto *lc = l.body->add<Columns>();
    lc->threshold = 500;
    lc->spacing = 14;
    for (auto [k, label, def] : std::vector<std::tuple<std::string, std::string, std::string>>{{"layout", "Layouts", "us"}, {"variant", "Variants", ""}, {"options", "Options", ""}}) {
        auto *c = col(lc, 6);
        c->add<Label>(label, 12, Weight::DemiBold, Role::Text3);
        auto *f = field(c, backend().conf("input", k, def));
        std::string key = k;
        f->onSubmit = [key](const std::string &v) { backend().setConf("input", key, trim(v)); };
        f->onChanged = [key, f](const std::string &) {};
        // save when focus leaves too
        auto *fp = f;
        f->onKeyFirst = [key, fp](const KeyEvent &e) {
            if (e.pressed && e.sym == key::Tab) backend().setConf("input", key, trim(fp->text()));
            return false;
        };
    }
    auto ty = card(p, "Typing");
    auto *ds = row2(ty.body, "Repeat delay", {.section = "input", .confKey = "repeat_delay"})
                   ->add<RangeSlider>(150, 1000, atof(backend().conf("input", "repeat_delay", "300").c_str()),
                                      [](double v) { return std::to_string((int)std::lround(v)) + " ms"; });
    ds->fixedW = 300;
    ds->onReleased = [](double v) { backend().setConf("input", "repeat_delay", std::to_string((int)std::lround(v))); };
    auto *rs = row2(ty.body, "Repeat rate", {.section = "input", .confKey = "repeat_rate"})
                   ->add<RangeSlider>(10, 80, atof(backend().conf("input", "repeat_rate", "30").c_str()),
                                      [](double v) { return std::to_string((int)std::lround(v)) + " /s"; });
    rs->fixedW = 300;
    rs->onReleased = [](double v) { backend().setConf("input", "repeat_rate", std::to_string((int)std::lround(v))); };

    auto sc = card(p, "Shortcuts", "keyboard", "Click a shortcut and press the new keys. A tap of Super on its own opens the launcher.");
    auto *ed = col(sc.body, 10);
    auto st = std::make_shared<ShortcutState>();
    p->conns.later([ed, p, st] { buildShortcuts(ed, p, st); });
}

// ========================================================== Mouse & touchpad ==
void pageMouse(Page *p) {
    auto pt = card(p, "Pointer", "mouse");
    auto *sp = row2(pt.body, "Speed", {.section = "input", .confKey = "accel"})
                   ->add<RangeSlider>(-1, 1, atof(backend().conf("input", "accel", "0").c_str()), [](double v) { return fmt1("%.2f", v); });
    sp->fixedW = 300;
    sp->onReleased = [](double v) { backend().setConf("input", "accel", fmt1("%.2f", v)); };
    toggleConf(row2(pt.body, "Focus follows mouse", {.section = "general", .confKey = "focus_follows_mouse", .hint = "Windows get keyboard focus when the pointer enters them"}),
               "general", "focus_follows_mouse");
    auto tp = card(p, "Touchpad");
    toggleConf(row2(tp.body, "Tap to click", {.section = "input", .confKey = "tap_to_click"}), "input", "tap_to_click", "true");
    toggleConf(row2(tp.body, "Natural scrolling", {.section = "input", .confKey = "natural_scroll", .hint = "Content follows your fingers"}), "input", "natural_scroll", "true");
}

// ========================================================== Panel & launcher ==
void pagePanel(Page *p) {
    auto pn = card(p, "Panel", "grid");
    toggleKey(row2(pn.body, "24-hour clock", {.key = "clock24"}), "clock24");
    toggleKey(row2(pn.body, "Desktop icons", {.key = "showDesktopIcons", .hint = "Show the contents of ~/Desktop on the wallpaper"}), "showDesktopIcons");
    auto l = card(p, "Launcher");
    dropKey(row2(l.body, "Default view", {.key = "launcherView"}), "launcherView", {"list", "grid"}, {"List", "Grid"})->fixedW = 160;
    auto pin = card(p, "Pinned apps", "", "Desktop file ids, in panel order");
    json pinned = backend().value("pinned");
    if (!pinned.is_array()) pinned = json::array();
    for (size_t i = 0; i < pinned.size(); i++) {
        auto *r = row(pin.body, 8);
        r->add<Label>(pinned[i].is_string() ? pinned[i].get<std::string>() : "", 14)->grow = 1;
        if (i > 0) btn(r, "↑")->onClick = [p, pinned, i] { json n = pinned; std::swap(n[i - 1], n[i]); backend().set("pinned", n); p->rebuildSoon(); };
        btn(r, "Remove")->onClick = [p, pinned, i] { json n = pinned; n.erase(n.begin() + i); backend().set("pinned", n); p->rebuildSoon(); };
    }
    auto *ar = row(pin.body, 8);
    auto *f = ar->add<TextInput>();
    f->grow = 1;
    f->placeholder = "e.g. org.gnome.Calculator";
    auto add = [p, f, pinned] {
        std::string v = trim(f->text());
        if (v.empty()) return;
        json n = pinned;
        n.push_back(v);
        backend().set("pinned", n);
        p->rebuildSoon();
    };
    f->onSubmit = [add](const std::string &) { add(); };
    btn(ar, "Pin", "plus")->onClick = add;
}

// ===================================================================== Users ==
class AvatarBig : public Widget {
public:
    std::shared_ptr<Image> face;
    std::string letter;
    Size sizeHint(double, double) override { return {96, 96}; }
    void paint(Painter &p) override {
        p.save();
        p.clip(geom, 48);
        p.gradient(geom, Color::hex("#d9925a"), Color::hex("#7d3f6b"));
        Font f;
        f.size = 40;
        f.weight = Weight::DemiBold;
        Text t(letter, f);
        p.textIn(t, geom, Color{1, 1, 1, 1}, Align::Center);
        if (face && face->valid()) p.image(*face, geom, 48);
        p.restore();
    }
};

void pageUsers(Page *p) {
    const char *u = getenv("USER");
    std::string user = u ? u : "";
    std::string full = trim(Backend::run({"sh", "-c", "getent passwd \"$USER\" | cut -d: -f5 | cut -d, -f1"}));
    auto c = card(p);
    auto *r = row(c.body, 20);
    auto *av = r->add<AvatarBig>();
    std::string face = homeDir() + "/.face";
    if (std::filesystem::exists(face)) av->face = std::make_shared<Image>(face, 192, 192);
    av->letter = user.empty() ? "?" : std::string(1, (char)toupper(user[0]));
    auto *tc = col(r, 4);
    tc->grow = 1;
    tc->add<Label>(full.empty() ? user : full, 22, Weight::DemiBold);
    tc->add<Label>(user + " · Administrator", 13, Weight::Normal, Role::Text3);
    auto *br = row(tc, 8);
    br->mt = 8;
    btn(br, "Change picture", "image")->onClick = [p, face] {
        pickFile("Choose a picture", "Images | *.png *.jpg *.jpeg *.webp", [p, face](const std::string &f) {
            Backend::run({"cp", f, face});
            p->rebuildSoon();
        });
    };
    btn(br, "Change password", "lock")->onClick = [] { backend().openInTerminal("passwd"); };
}

}  // namespace settings
