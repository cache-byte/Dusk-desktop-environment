// Widgets and helpers shared by several shell modules.
#pragma once
#include "config.hpp"
#include "ui/widget.hpp"
#include "ui/window.hpp"

namespace nova {

// Signal connections that are dropped together (a window's subscriptions to services)
class Connections {
public:
    ~Connections() { *alive_ = false; clear(); }
    // run on the next loop pass, unless the owner is gone by then (rebuilds from click handlers)
    void later(std::function<void()> f) {
        auto a = alive_;
        ui::Loop::get().defer([a, f = std::move(f)] { if (*a) f(); });
    }
    template <typename S, typename F> void on(S &sig, F f) {
        int id = sig.connect(std::move(f));
        drops_.push_back([&sig, id] { sig.disconnect(id); });
    }
    void after(int ms, std::function<void()> f) {
        auto a = alive_;
        ui::Loop::get().addTimer(ms, [a, f = std::move(f)] { if (*a) f(); });
    }
    std::shared_ptr<bool> token() const { return alive_; }   // *token == false once the owner is gone
    void clear() { for (auto &d : drops_) d(); drops_.clear(); }
private:
    std::vector<std::function<void()>> drops_;
    std::shared_ptr<bool> alive_ = std::make_shared<bool>(true);
};

// ---- wallpaper images (decoded once per size, shared by the wallpaper, glass and lock) ----
std::string wallpaperPath();                    // chosen wallpaper or the theme's default
bool wallpaperIsVideo();
std::shared_ptr<ui::Image> wallpaperImage(ui::Size screen);
std::shared_ptr<ui::Image> blurredWallpaper(ui::Size screen);
// point a window's fake-blur backdrop at the blurred wallpaper (screenRect = where it sits)
void setBackdrop(ui::Window &w, ui::Size screen, ui::Rect screenRect);

// square button on the panel (launcher, pinned apps, clipboard)
class PanelButton : public ui::Button {
public:
    PanelButton();
};

// rounded pill on the panel (status, clock, tray)
class Pill : public ui::Button {
public:
    Pill();
    bool highlighted = false;
    void paint(ui::Painter &p) override;
};

// battery: number inside a pill, the outline drawn around to the charge level
class BatteryW : public ui::Widget {
public:
    double level = 0.8;     // 0..1
    bool charging = false;
    ui::Size sizeHint(double, double) override { return {40, 22}; }
    void paint(ui::Painter &p) override;
};

// three bouncing bars while music plays
class MusicBars : public ui::Widget {
public:
    MusicBars();
    ~MusicBars() override;
    bool active = false;
    void setActive(bool a);
    ui::Size sizeHint(double, double) override { return {16, 14}; }
    void paint(ui::Painter &p) override;
    bool tickAnims(int64_t now) override;
private:
    int64_t t0_ = 0;
};

// Beat visualizer (Cava while drawn): 1 Bars · 2 Wave line · 3 Filled wave · 4 LED matrix ·
// 5 Peak caps · 6 Mountains · 7 Pills. `mini` = the tiny bars next to the clock.
class Visualizer : public ui::Widget {
public:
    Visualizer();
    ~Visualizer() override;
    int style = 0;           // 0 = the style chosen in Settings
    bool mini = false;
    double opacityK = 1;
    void paint(ui::Painter &p) override;
private:
    int conn_ = 0;
    bool registered_ = false;
    int64_t lastPaint_ = 0;
    std::vector<double> peaks_;
    ui::Timer idle_;
};

// Synced lyrics in one of six styles (Settings > Music & lyrics):
// 1 Fade stack · 2 Karaoke sweep · 3 Terminal · 4 Word bloom · 5 Accent rail · 6 Outline
// The part of the current line already sung is in the accent colour in every style.
class LyricsView : public ui::Widget {
public:
    LyricsView();
    ~LyricsView() override;
    double scaleK = 1;           // multiplied by the lyricsSize setting
    bool center = true;
    bool shadowText = false;     // on the desktop: a soft dark copy under the text
    ui::Color textColor{0, 0, 0, 0};   // default theme text
    ui::Size sizeHint(double availW, double availH) override;
    void paint(ui::Painter &p) override;
private:
    int conn_ = 0, lastI_ = -2, lastSung_ = -1;
    ui::Timer tick_;
};

// a heading row with an icon: "Notifications", "What's new"
ui::Box *heading(ui::Widget *parent, const std::string &icon, const std::string &text);

// a labelled toggle row
ui::Box *toggleRow(ui::Widget *parent, const std::string &label, bool on, std::function<void(bool)> fn);

}  // namespace nova
