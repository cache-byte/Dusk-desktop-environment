#include "apps.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "ui/sys.hpp"
#include "ui/wayland.hpp"

#include "ext-idle-notify-v1-client-protocol.h"
#include "wlr-foreign-toplevel-management-unstable-v1-client-protocol.h"

#include <wayland-client.h>

#include <fcntl.h>
#include <filesystem>
#include <poll.h>
#include <pwd.h>
#include <security/pam_appl.h>
#include <sys/wait.h>
#include <unistd.h>

namespace fs = std::filesystem;

namespace nova {

using ui::Loop;
using ui::Process;

// ====================================================================== Apps ==
Apps &Apps::get() { static Apps a; return a; }

bool App::isGame() const {
    std::string i = ui::lower(id);
    if (std::find(categories.begin(), categories.end(), "Game") != categories.end()) return true;
    for (const char *k : {"steam", "heroic", "lutris", "bottles", "prismlauncher"}) if (i.find(k) != std::string::npos) return true;
    return false;
}

static std::vector<std::string> appDirs() {
    std::vector<std::string> d;
    const char *xdh = getenv("XDG_DATA_HOME");
    d.push_back(std::string(xdh && *xdh ? xdh : (ui::homeDir() + "/.local/share")) + "/applications");
    d.push_back(ui::homeDir() + "/.local/share/flatpak/exports/share/applications");
    d.push_back("/var/lib/flatpak/exports/share/applications");
    const char *xdd = getenv("XDG_DATA_DIRS");
    for (auto &p : ui::split(xdd && *xdd ? xdd : "/usr/local/share:/usr/share", ':'))
        if (!p.empty()) d.push_back(p + "/applications");
    return d;
}

// one [Desktop Entry] group, localised keys ignored except the plain ones
static bool parseDesktop(const std::string &path, const std::string &id, App &a) {
    bool ok = false;
    std::string text = ui::readFile(path, &ok);
    if (!ok) return false;
    bool inEntry = false, hidden = false;
    std::string type, onlyShowIn, notShowIn;
    for (auto &raw : ui::split(text, '\n')) {
        std::string l = ui::trim(raw);
        if (l.empty() || l[0] == '#') continue;
        if (l[0] == '[') { inEntry = l == "[Desktop Entry]"; continue; }
        if (!inEntry) continue;
        auto eq = l.find('=');
        if (eq == std::string::npos) continue;
        std::string k = ui::trim(l.substr(0, eq)), v = ui::trim(l.substr(eq + 1));
        if (k == "Name") a.name = v;
        else if (k == "GenericName") a.genericName = v;
        else if (k == "Comment") a.comment = v;
        else if (k == "Icon") a.icon = v;
        else if (k == "Exec") a.exec = v;
        else if (k == "Path") a.path = v;
        else if (k == "Terminal") a.terminal = v == "true";
        else if (k == "NoDisplay") a.noDisplay = v == "true";
        else if (k == "Hidden") hidden = v == "true";
        else if (k == "Type") type = v;
        else if (k == "OnlyShowIn") onlyShowIn = v;
        else if (k == "NotShowIn") notShowIn = v;
        else if (k == "Keywords") { for (auto &x : ui::split(v, ';')) if (!x.empty()) a.keywords.push_back(x); }
        else if (k == "Categories") { for (auto &x : ui::split(v, ';')) if (!x.empty()) a.categories.push_back(x); }
    }
    if (hidden || (type != "Application" && !type.empty()) || a.name.empty()) return false;
    auto inList = [](const std::string &list, const char *de) {
        for (auto &x : ui::split(list, ';')) if (x == de) return true;
        return false;
    };
    if (!onlyShowIn.empty() && !inList(onlyShowIn, "Nova") && !inList(onlyShowIn, "GNOME")) a.noDisplay = true;
    if (inList(notShowIn, "Nova")) a.noDisplay = true;
    a.id = id;
    return true;
}

void Apps::start() {
    scan();
    // new apps appear in the launcher without restarting the shell
    for (auto &d : appDirs())
        if (fs::is_directory(d)) ui::FileWatch::watch(d, [this] { scan(); changed.emit(); });
}
void Apps::scan() {
    apps_.clear();
    std::vector<std::string> seen;
    for (auto &dir : appDirs()) {
        std::error_code ec;
        if (!fs::is_directory(dir, ec)) continue;
        for (auto it = fs::recursive_directory_iterator(dir, ec); it != fs::recursive_directory_iterator(); it.increment(ec)) {
            if (ec) break;
            if (!it->is_regular_file(ec) || it->path().extension() != ".desktop") continue;
            // desktop file id: path relative to the dir, '/' -> '-', without .desktop
            std::string rel = fs::relative(it->path(), dir, ec).string();
            std::string id = ui::replaceAll(rel.substr(0, rel.size() - 8), "/", "-");
            if (std::find(seen.begin(), seen.end(), id) != seen.end()) continue;   // earlier dirs win
            seen.push_back(id);
            App a;
            if (parseDesktop(it->path().string(), id, a)) apps_.push_back(std::move(a));
        }
    }
    std::sort(apps_.begin(), apps_.end(), [](const App &a, const App &b) { return ui::lower(a.name) < ui::lower(b.name); });
}
const App *Apps::byId(const std::string &id) const {
    for (auto &a : apps_) if (a.id == id) return &a;
    return nullptr;
}
const App *Apps::lookup(const std::string &appId) const {
    if (appId.empty()) return nullptr;
    std::string q = ui::lower(appId);
    if (ui::endsWith(q, ".desktop")) q = q.substr(0, q.size() - 8);
    for (auto &a : apps_) if (ui::lower(a.id) == q) return &a;
    for (auto &a : apps_) {   // org.gnome.Nautilus vs nautilus, firefox vs org.mozilla.firefox
        std::string i = ui::lower(a.id);
        if (ui::endsWith(i, "." + q) || ui::endsWith(q, "." + i)) return &a;
    }
    for (auto &a : apps_) {
        // StartupWMClass-less apps: match the exec name or the app name
        std::string exe = a.exec.substr(0, a.exec.find(' '));
        exe = exe.substr(exe.rfind('/') + 1);
        if (ui::lower(exe) == q || ui::lower(a.name) == q || ui::lower(a.icon) == q) return &a;
    }
    return nullptr;
}

// Exec line -> argv: drop field codes (%f %u %F %U %i %c %k), honour quotes
static std::vector<std::string> execArgs(const App &a) {
    std::vector<std::string> out;
    std::string cur;
    bool q = false, any = false;
    const std::string &e = a.exec;
    for (size_t i = 0; i < e.size(); i++) {
        char c = e[i];
        if (q) {
            if (c == '\\' && i + 1 < e.size()) { cur += e[++i]; continue; }
            if (c == '"') { q = false; continue; }
            cur += c;
            continue;
        }
        if (c == '"') { q = true; any = true; continue; }
        if (c == ' ' || c == '\t') { if (!cur.empty() || any) out.push_back(cur); cur.clear(); any = false; continue; }
        if (c == '%' && i + 1 < e.size()) {
            char f = e[++i];
            if (f == '%') cur += '%';
            else if (f == 'c') cur += a.name;
            else if (f == 'i' && !a.icon.empty()) { out.push_back("--icon"); cur += a.icon; }
            continue;   // file / url codes: nothing to pass
        }
        cur += c;
    }
    if (!cur.empty() || any) out.push_back(cur);
    return out;
}
void Apps::launch(const App &a, bool onDedicatedGpu) {
    std::vector<std::string> argv = execArgs(a);
    if (argv.empty()) return;
    if (a.terminal) {
        std::string term = "ptyxis";
        argv.insert(argv.begin(), {term, "--"});
    }
    // games on the dedicated GPU, with GameMode and MangoHud as set in Settings > Gaming
    if (onDedicatedGpu) {
        std::vector<std::string> pre = {"nova-gpu", "run"};
        if (cfg().b("gameModeAuto", true) && ui::haveProgram("gamemoderun")) pre.push_back("gamemoderun");
        argv.insert(argv.begin(), pre.begin(), pre.end());
        if (cfg().b("mangohud", false)) argv.insert(argv.begin(), {"env", "MANGOHUD=1"});
    }
    std::string dir = a.path.empty() ? ui::homeDir() : a.path;
    std::string cmd = "cd " + ui::shellQuote(dir) + " && exec";
    for (auto &x : argv) cmd += " " + ui::shellQuote(x);
    ui::spawnShell(cmd);
}

std::vector<const App *> Apps::search(const std::string &query) const {
    std::string q = ui::lower(ui::trim(query));
    std::vector<std::pair<int, const App *>> scored;
    auto words = [](const std::string &s) {
        std::vector<std::string> w;
        std::string cur;
        for (char c : s) {
            if (c == ' ' || c == '-' || c == '_' || c == '.') { if (!cur.empty()) w.push_back(cur); cur.clear(); }
            else cur += c;
        }
        if (!cur.empty()) w.push_back(cur);
        return w;
    };
    for (auto &a : apps_) {
        if (a.noDisplay) continue;
        if (q.empty()) { scored.push_back({0, &a}); continue; }
        std::string n = ui::lower(a.name), g = ui::lower(a.genericName);
        int s = -1;
        if (n == q) s = 0;
        else if (ui::startsWith(n, q)) s = 1;
        else if (std::any_of(words(n).begin(), words(n).end(), [&](auto &w) { return ui::startsWith(w, q); })) s = 2;
        else if (n.find(q) != std::string::npos) s = 3;
        else if (ui::startsWith(g, q) || std::any_of(words(g).begin(), words(g).end(), [&](auto &w) { return ui::startsWith(w, q); })) s = 4;
        else if (std::any_of(a.keywords.begin(), a.keywords.end(), [&](auto &k) { return ui::startsWith(ui::lower(k), q); })) s = 5;
        else if (g.find(q) != std::string::npos || std::any_of(a.keywords.begin(), a.keywords.end(), [&](auto &k) { return ui::lower(k).find(q) != std::string::npos; })) s = 6;
        else if (ui::lower(a.comment).find(q) != std::string::npos) s = 7;
        if (s >= 0) scored.push_back({s, &a});
    }
    std::stable_sort(scored.begin(), scored.end(), [](auto &x, auto &y) {
        if (x.first != y.first) return x.first < y.first;
        if (x.second->name.size() != y.second->name.size() && x.first > 0) return x.second->name.size() < y.second->name.size();
        return ui::lower(x.second->name) < ui::lower(y.second->name);
    });
    std::vector<const App *> out;
    for (auto &p : scored) out.push_back(p.second);
    return out;
}

// ================================================================ Toplevels ==
Toplevels &Toplevels::get() { static Toplevels t; return t; }

static void tl_title(void *d, zwlr_foreign_toplevel_handle_v1 *, const char *t) { static_cast<Toplevel *>(d)->title = t ? t : ""; }
static void tl_appid(void *d, zwlr_foreign_toplevel_handle_v1 *, const char *t) { static_cast<Toplevel *>(d)->appId = t ? t : ""; }
static void tl_out_enter(void *, zwlr_foreign_toplevel_handle_v1 *, wl_output *) {}
static void tl_out_leave(void *, zwlr_foreign_toplevel_handle_v1 *, wl_output *) {}
static void tl_state(void *d, zwlr_foreign_toplevel_handle_v1 *, wl_array *states) {
    auto *t = static_cast<Toplevel *>(d);
    t->activated = t->minimized = t->maximized = t->fullscreen = false;
    for (uint32_t *s = (uint32_t *)states->data; (char *)s < (char *)states->data + states->size; s++) {
        if (*s == ZWLR_FOREIGN_TOPLEVEL_HANDLE_V1_STATE_ACTIVATED) t->activated = true;
        if (*s == ZWLR_FOREIGN_TOPLEVEL_HANDLE_V1_STATE_MINIMIZED) t->minimized = true;
        if (*s == ZWLR_FOREIGN_TOPLEVEL_HANDLE_V1_STATE_MAXIMIZED) t->maximized = true;
        if (*s == ZWLR_FOREIGN_TOPLEVEL_HANDLE_V1_STATE_FULLSCREEN) t->fullscreen = true;
    }
}
static void tl_done(void *d, zwlr_foreign_toplevel_handle_v1 *) {
    static_cast<Toplevel *>(d)->done = true;
    Toplevels::get().changed.emit();
}
static void tl_closed(void *d, zwlr_foreign_toplevel_handle_v1 *h) {
    auto &tl = Toplevels::get();
    std::erase_if(tl.list, [d](auto &t) { return t.get() == d; });
    zwlr_foreign_toplevel_handle_v1_destroy(h);
    tl.changed.emit();
}
static void tl_parent(void *, zwlr_foreign_toplevel_handle_v1 *, zwlr_foreign_toplevel_handle_v1 *) {}
static const zwlr_foreign_toplevel_handle_v1_listener handleListener = {tl_title, tl_appid, tl_out_enter, tl_out_leave, tl_state, tl_done, tl_closed, tl_parent};
static void mgr_toplevel(void *, zwlr_foreign_toplevel_manager_v1 *, zwlr_foreign_toplevel_handle_v1 *h) {
    auto t = std::make_unique<Toplevel>();
    t->handle = h;
    zwlr_foreign_toplevel_handle_v1_add_listener(h, &handleListener, t.get());
    Toplevels::get().list.push_back(std::move(t));
}
static void mgr_finished(void *, zwlr_foreign_toplevel_manager_v1 *) {}
static const zwlr_foreign_toplevel_manager_v1_listener managerListener = {mgr_toplevel, mgr_finished};

void Toplevels::start() {
    auto &wl = ui::Wayland::get();
    for (auto &g : wl.globals)
        if (g.interface == zwlr_foreign_toplevel_manager_v1_interface.name) {
            auto *m = (zwlr_foreign_toplevel_manager_v1 *)wl.bind(g, &zwlr_foreign_toplevel_manager_v1_interface, 3);
            zwlr_foreign_toplevel_manager_v1_add_listener(m, &managerListener, nullptr);
        }
}
void Toplevel::activate() {
    zwlr_foreign_toplevel_handle_v1_activate(handle, ui::Wayland::get().seat);
    ui::Wayland::get().flush();
}
void Toplevel::setMinimized(bool m) {
    if (m) zwlr_foreign_toplevel_handle_v1_set_minimized(handle);
    else zwlr_foreign_toplevel_handle_v1_unset_minimized(handle);
    ui::Wayland::get().flush();
}
void Toplevel::close() {
    zwlr_foreign_toplevel_handle_v1_close(handle);
    ui::Wayland::get().flush();
}
std::vector<Toplevel *> Toplevels::forApp(const std::string &appId) const {
    std::vector<Toplevel *> out;
    std::string m = ui::lower(appId);
    const App *entry = Apps::get().lookup(appId);
    for (auto &t : list) {
        std::string a = ui::lower(t->appId);
        if (a.empty()) continue;
        if (a == m || ui::endsWith(m, "." + a) || ui::endsWith(a, "." + m) || (entry && Apps::get().lookup(t->appId) == entry))
            out.push_back(t.get());
    }
    return out;
}

// ===================================================================== Idle ==
Idle &Idle::get() { static Idle i; return i; }
static ext_idle_notifier_v1 *g_idleNotifier = nullptr;
struct IdleCtx { int which; };
static IdleCtx g_ctx[3] = {{0}, {1}, {2}};
static void idle_idled(void *d, ext_idle_notification_v1 *) { Idle::get().idled(static_cast<IdleCtx *>(d)->which); }
static void idle_resumed(void *d, ext_idle_notification_v1 *) { Idle::get().resumed(static_cast<IdleCtx *>(d)->which); }
static const ext_idle_notification_v1_listener idleListener = {idle_idled, idle_resumed};

void Idle::start() {
    auto &wl = ui::Wayland::get();
    for (auto &g : wl.globals)
        if (g.interface == ext_idle_notifier_v1_interface.name) g_idleNotifier = (ext_idle_notifier_v1 *)wl.bind(g, &ext_idle_notifier_v1_interface, 1);
    apply();
    cfg().changed.connect([this] { apply(); });
    Battery::get().changed.connect([this] { apply(); });
}
void Idle::setCaffeine(bool on) {
    caffeine = on;
    apply();
    changed.emit();
}
void Idle::apply() {
    bool bat = Battery::get().onBattery;
    int m[3] = {cfg().i(bat ? "idleDimBattery" : "idleDimAc", 5), cfg().i(bat ? "idleLockBattery" : "idleLockAc", 6),
                cfg().i(bat ? "idleSleepBattery" : "idleSleepAc", bat ? 15 : 0)};
    if (caffeine) m[0] = m[1] = m[2] = 0;
    if (m[0] && !Brightness::get().available()) m[0] = 0;
    for (int i = 0; i < 3; i++) {
        if (m[i] == mins_[i] && (n_[i] != nullptr) == (m[i] > 0)) continue;
        mins_[i] = m[i];
        if (n_[i]) { ext_idle_notification_v1_destroy(n_[i]); n_[i] = nullptr; }
        // these respect idle inhibitors (videos, fullscreen games)
        if (m[i] > 0 && g_idleNotifier) {
            n_[i] = ext_idle_notifier_v1_get_idle_notification(g_idleNotifier, (uint32_t)m[i] * 60000, ui::Wayland::get().seat);
            ext_idle_notification_v1_add_listener(n_[i], &idleListener, &g_ctx[i]);
        }
    }
    ui::Wayland::get().flush();
}
void Idle::idled(int which) {
    if (which == 0) {
        savedBrightness_ = Brightness::get().value;
        Brightness::get().set(std::min(Brightness::get().value, 0.25));
    } else if (which == 1) {
        ipc().lockRequested.emit();
    } else if (which == 2) {
        ui::spawn({"systemctl", "suspend"});
    }
}
void Idle::resumed(int which) {
    if (which == 0 && savedBrightness_ > 0) {
        Brightness::get().set(savedBrightness_);
        savedBrightness_ = -1;
    }
}

// ================================================================ clipboard ==
ClipHistory &ClipHistory::get() { static ClipHistory c; return c; }
void ClipHistory::refresh(std::function<void()> done) {
    Process::run({"cliphist", "list"}, [this, done](int, const std::string &out) {
        items.clear();
        int max = cfg().i("clipboardMax", 200);
        for (auto &l : ui::split(out, '\n')) {
            if (l.empty()) continue;
            auto tab = l.find('\t');
            ClipItem it;
            it.id = l;
            it.preview = tab == std::string::npos ? l : l.substr(tab + 1);
            it.image = ui::startsWith(it.preview, "[[ binary data");
            items.push_back(it);
            if ((int)items.size() >= max) break;
        }
        if (done) done();
    });
}
void ClipHistory::copy(const ClipItem &i) {
    ui::spawnShell("printf '%s' " + ui::shellQuote(i.id) + " | cliphist decode | wl-copy");
}
void ClipHistory::remove(const ClipItem &i) {
    Process::run({"cliphist", "delete"}, nullptr, i.id + "\n");
    std::erase_if(items, [&](const ClipItem &x) { return x.id == i.id; });
}
void ClipHistory::wipe() {
    ui::spawn({"cliphist", "wipe"});
    items.clear();
}

// ===================================================================== PAM ==
static int pamConv(int n, const pam_message **msg, pam_response **resp, void *data) {
    auto *r = (pam_response *)calloc(n, sizeof(pam_response));
    if (!r) return PAM_BUF_ERR;
    for (int i = 0; i < n; i++)
        if (msg[i]->msg_style == PAM_PROMPT_ECHO_OFF || msg[i]->msg_style == PAM_PROMPT_ECHO_ON)
            r[i].resp = strdup((const char *)data);
    *resp = r;
    return PAM_SUCCESS;
}
void checkPassword(const std::string &password, std::function<void(bool, const std::string &)> done) {
    int p[2];
    if (pipe2(p, O_CLOEXEC) < 0) { done(false, "Couldn't check the password"); return; }
    pid_t pid = fork();
    if (pid == 0) {
        close(p[0]);
        passwd *pw = getpwuid(getuid());
        pam_conv conv{pamConv, (void *)password.c_str()};
        pam_handle_t *h = nullptr;
        int r = pam_start("nova-lock", pw ? pw->pw_name : nullptr, &conv, &h);
        if (r == PAM_SUCCESS) r = pam_authenticate(h, 0);
        if (r == PAM_SUCCESS) r = pam_acct_mgmt(h, 0);
        if (r == PAM_SUCCESS) pam_setcred(h, PAM_REFRESH_CRED);   // keyring stays unlocked
        char c = r == PAM_SUCCESS ? 1 : 0;
        ssize_t w = write(p[1], &c, 1);
        (void)w;
        if (h) pam_end(h, r);
        _exit(0);
    }
    close(p[1]);
    if (pid < 0) { close(p[0]); done(false, "Couldn't check the password"); return; }
    auto id = std::make_shared<int>(0);
    *id = Loop::get().addFd(p[0], POLLIN, [id, pid, done](int fd, short) {
        char c = 0;
        ssize_t n = read(fd, &c, 1);
        Loop::get().removeFd(*id);
        close(fd);
        waitpid(pid, nullptr, 0);
        if (n == 1 && c == 1) done(true, "");
        else done(false, "Wrong password");
    });
}

}  // namespace nova
