#include "common.hpp"
#include "services.hpp"

#include <cairo.h>
#include <filesystem>

namespace nova {

using namespace ui;

// ------------------------------------------------------------------- wallpaper --
std::string wallpaperPath() {
    std::string w = cfg().s("wallpaper", "");
    if (ui::startsWith(w, "file://")) w = w.substr(7);
    if (!w.empty() && std::filesystem::exists(w)) return w;
    std::string dir = "/usr/share/nova/shell/assets/wallpapers/";
    if (const char *d = getenv("NOVA_ASSETS"); d && *d) dir = std::string(d) + "/wallpapers/";
    return dir + (theme().dark ? "nova-dark.jpg" : "nova-light.jpg");
}
bool wallpaperIsVideo() {
    std::string p = ui::lower(wallpaperPath());
    for (const char *e : {".mp4", ".webm", ".mkv", ".mov"}) if (ui::endsWith(p, e)) return true;
    return false;
}
struct WpCache {
    std::string path;
    Size size;
    std::shared_ptr<Image> sharp, blurred;
    double blurStrength = -1;
};
static WpCache &wpCache() { static WpCache c; return c; }
static void ensureWallpaper(Size screen) {
    WpCache &c = wpCache();
    std::string p = wallpaperPath();
    if (wallpaperIsVideo()) {
        // video wallpapers aren't drawn by the C++ shell yet: use the theme's still image
        p = "/usr/share/nova/shell/assets/wallpapers/" + std::string(theme().dark ? "nova-dark.jpg" : "nova-light.jpg");
    }
    if (c.path == p && c.size.w >= screen.w && c.size.h >= screen.h && c.sharp) return;
    c.path = p;
    c.size = screen;
    // decode at (roughly) screen size, covering it
    c.sharp = std::make_shared<Image>(p, (int)screen.w, (int)screen.h);
    c.blurred.reset();
}
std::shared_ptr<Image> wallpaperImage(Size screen) {
    ensureWallpaper(screen);
    return wpCache().sharp;
}
std::shared_ptr<Image> blurredWallpaper(Size screen) {
    ensureWallpaper(screen);
    WpCache &c = wpCache();
    double s = theme().blurUi;
    if (!c.blurred || c.blurStrength != s) {
        c.blurStrength = s;
        c.blurred = std::make_shared<Image>(c.sharp && c.sharp->valid() ? c.sharp->blurred((int)std::lround(8 + s * 40), 1.15) : Image());
    }
    return c.blurred;
}
void setBackdrop(Window &w, Size screen, Rect screenRect) {
    if (theme().realBlur) { w.backdrop.reset(); return; }
    w.backdrop = blurredWallpaper(screen);
    w.screenSize = screen;
    w.screenRect = screenRect;
}

// ---------------------------------------------------------------- panel bits --
PanelButton::PanelButton() : Button(Dir::Row, 0) {
    fixedW = fixedH = 38;
    radius = 12;
    justify = Justify::Center;
}
Pill::Pill() : Button(Dir::Row, 11) {
    fixedH = 36;
    radius = 12;
    padding(12, 0);
}
void Pill::paint(Painter &p) {
    const Theme &t = theme();
    Color b = highlighted ? t.accentSoft : pressed ? t.surface3.mix(t.text.alpha(0.1), 0.5) : hovered ? t.surface3 : t.surface2;
    p.fill(geom, b, radius);
    if (highlighted) p.stroke(geom, t.accentLine, 1, radius);
}

void BatteryW::paint(Painter &p) {
    const Theme &t = theme();
    Color col = level <= 0.15 ? t.danger : level <= 0.30 ? t.warn : t.accentBright;
    Rect r{std::round(geom.x), std::round(geom.center().y - 11), 40, 22};
    p.fill(r, Color{1, 1, 1, t.dark ? 0.06 : 0.0}.mix(t.surface3, t.dark ? 0 : 1), 11);
    p.stroke(r, t.text.alpha(0.16), 1.5, 11);
    // the outline from top-centre, clockwise, cut at the charge level
    cairo_t *cr = p.cr();
    double f = std::clamp(level, 0.02, 1.0);
    const double rr = 10, segs[5] = {9, M_PI * rr, 18, M_PI * rr, 9};
    double total = 0;
    for (double s : segs) total += s;
    double left = f * total;
    auto take = [&](double len) { double x = std::min(left, len); left -= x; return x; };
    cairo_save(cr);
    cairo_translate(cr, r.x, r.y);
    cairo_new_path(cr);
    cairo_move_to(cr, 20, 1);
    double d = take(segs[0]);
    cairo_line_to(cr, 20 + d, 1);
    if (left > 0) { d = take(segs[1]); cairo_arc(cr, 29, 11, rr, -M_PI / 2, -M_PI / 2 + d / rr); }
    if (left > 0) { d = take(segs[2]); cairo_line_to(cr, 29 - d, 21); }
    if (left > 0) { d = take(segs[3]); cairo_arc(cr, 11, 11, rr, M_PI / 2, M_PI / 2 + d / rr); }
    if (left > 0) { d = take(segs[4]); cairo_line_to(cr, 11 + d, 1); }
    cairo_set_source_rgba(cr, col.r, col.g, col.b, col.a);
    cairo_set_line_width(cr, 2.2);
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
    cairo_stroke(cr);
    cairo_restore(cr);
    std::string s = (charging ? "⚡" : "") + std::to_string((int)std::lround(level * 100));
    Text tx(s, {.size = 11.5, .weight = Weight::Bold});
    p.textIn(tx, r, col, Align::Center, Align::Center);
}

MusicBars::MusicBars() = default;
MusicBars::~MusicBars() = default;
void MusicBars::setActive(bool a) {
    if (a == active) return;
    active = a;
    if (a) {
        t0_ = nowMs();
        if (Window *w = window()) w->requestFrames(this);
    }
    update();
}
bool MusicBars::tickAnims(int64_t now) {
    bool base = Widget::tickAnims(now);
    return active || base;
}
void MusicBars::paint(Painter &p) {
    const Theme &t = theme();
    double tt = (nowMs() - t0_) / 1000.0;
    for (int i = 0; i < 3; i++) {
        double h = active ? 4 + 9 * (0.5 + 0.5 * std::sin(tt * (5.5 + i * 1.7) + i * 1.3)) : 4;
        Rect r{geom.x + i * 5.5, geom.center().y + 7 - h, 3, h};
        p.fill(r, t.accent, 1.5);
    }
    if (active) if (Window *w = window()) w->requestFrames(this);
}

Visualizer::Visualizer() {
    conn_ = Cava::get().frame.connect([this] { if (visible) update(); });
    // stop Cava when this visualizer hasn't been drawn for a while (hidden / closed)
    idle_.setup(1500, [this] {
        if (registered_ && nowMs() - lastPaint_ > 1200) { registered_ = false; Cava::get().use(-1); }
    }, true);
    idle_.start();
}
Visualizer::~Visualizer() {
    Cava::get().frame.disconnect(conn_);
    if (registered_) Cava::get().use(-1);
}

static Color vizColour(int i, int n, double a) {
    const Theme &t = theme();
    std::string c = cfg().s("vizColour", "accent");
    if (c == "rainbow") {
        // hsl(i/n, 0.65, 0.6)
        double h = (double)i / std::max(1, n) * 6, s = 0.65, l = 0.6;
        double ch = (1 - std::fabs(2 * l - 1)) * s, x = ch * (1 - std::fabs(std::fmod(h, 2) - 1)), m = l - ch / 2;
        double r = 0, g = 0, b = 0;
        int k = (int)h % 6;
        if (k == 0) { r = ch; g = x; } else if (k == 1) { r = x; g = ch; } else if (k == 2) { g = ch; b = x; }
        else if (k == 3) { g = x; b = ch; } else if (k == 4) { r = x; b = ch; } else { r = ch; b = x; }
        return {r + m, g + m, b + m, a};
    }
    if (c == "text") return t.text.withAlpha(a);
    return (c == "art" ? t.accentBright : t.accent).withAlpha(a);
}

static void smoothPath(cairo_t *cr, const std::vector<Point> &pts) {
    cairo_move_to(cr, pts[0].x, pts[0].y);
    for (size_t i = 0; i + 1 < pts.size(); i++) {
        const Point &p0 = i ? pts[i - 1] : pts[i], &p1 = pts[i], &p2 = pts[i + 1], &p3 = i + 2 < pts.size() ? pts[i + 2] : p2;
        cairo_curve_to(cr, p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
    }
}

void Visualizer::paint(Painter &p) {
    lastPaint_ = nowMs();
    if (!registered_) { registered_ = true; Cava::get().use(1); }
    std::vector<double> v = Cava::get().values;
    int n = (int)v.size();
    if (!n) { n = 24; v.resize(n); for (int i = 0; i < n; i++) v[i] = 0.05 + 0.04 * std::sin(i / 2.0); }   // idle shape
    for (auto &x : v) x = std::clamp(x, 0.0, 1.0);
    double W = geom.w, H = geom.h, X = geom.x, Y = geom.y;
    if (W <= 0 || H <= 0) return;
    cairo_t *cr = p.cr();
    if (mini) {
        // a handful of bars, averaged
        int m = 5;
        double gap = 2, bw = (W - gap * (m - 1)) / m;
        for (int i = 0; i < m; i++) {
            double a = 0;
            int from = i * n / m, to = std::max(from + 1, (i + 1) * n / m);
            for (int k = from; k < to; k++) a += v[k];
            a /= (to - from);
            double h = std::max(2.0, a * H);
            p.fill({X + i * (bw + gap), Y + (H - h) / 2, bw, h}, theme().accent.withAlpha(opacityK), bw / 2);
        }
        return;
    }
    int st = style ? style : cfg().i("vizStyle", 1);
    double gap = std::max(1.0, W * 0.006), bw = (W - gap * (n - 1)) / n;
    if (st == 1 || st == 7) {
        for (int i = 0; i < n; i++) {
            double h = std::max(bw, v[i] * H * (st == 7 ? 0.8 : 1));
            double y = st == 7 ? (H - h) / 2 : H - h;
            p.fill({X + i * (bw + gap), Y + y, bw, h}, vizColour(i, n, (st == 7 ? 0.85 : 0.6 + 0.4 * v[i]) * opacityK), bw / 2);
        }
    } else if (st == 2 || st == 3 || st == 6) {
        int layers = st == 6 ? 3 : 1;
        for (int l = layers - 1; l >= 0; l--) {
            std::vector<Point> pts;
            for (int i = 0; i < n; i++)
                pts.push_back({X + (double)i / std::max(1, n - 1) * W, Y + H - std::min(1.0, v[i] * (1 - l * 0.22)) * H * 0.9 - H * 0.04});
            cairo_new_path(cr);
            smoothPath(cr, pts);
            if (st != 2) {
                cairo_line_to(cr, X + W, Y + H);
                cairo_line_to(cr, X, Y + H);
                cairo_close_path(cr);
                Color f = vizColour(l * 3, 9, (st == 6 ? 0.25 + l * 0.2 : 0.35) * opacityK);
                cairo_set_source_rgba(cr, f.r, f.g, f.b, f.a);
                cairo_fill_preserve(cr);
            }
            Color s = vizColour(0, n, 0.95 * opacityK);
            cairo_set_source_rgba(cr, s.r, s.g, s.b, s.a);
            cairo_set_line_width(cr, st == 2 ? 3 : 2);
            cairo_stroke(cr);
        }
    } else if (st == 4) {
        int rows = 14;
        double ch = H / rows;
        for (int i = 0; i < n; i++) {
            int lit = (int)std::lround(v[i] * rows);
            for (int r = 0; r < rows; r++)
                p.fill({X + i * (bw + gap), Y + H - (r + 1) * ch + ch * 0.15, bw, ch * 0.7},
                       r < lit ? vizColour(i, n, (0.45 + (double)r / rows * 0.55) * opacityK) : Color{1, 1, 1, 0.05 * opacityK});
        }
    } else if (st == 5) {
        if ((int)peaks_.size() != n) peaks_.assign(n, 0);
        for (int i = 0; i < n; i++) {
            peaks_[i] = std::max(v[i], peaks_[i] - 0.012);
            double h = v[i] * H * 0.92;
            p.fill({X + i * (bw + gap), Y + H - h, bw, h}, vizColour(i, n, 0.7 * opacityK));
            p.fill({X + i * (bw + gap), Y + H - peaks_[i] * H * 0.92 - 4, bw, 3}, vizColour(i, n, opacityK));
        }
    }
}

Box *heading(Widget *parent, const std::string &icon, const std::string &text) {
    auto *r = row(parent, 10);
    if (!icon.empty()) r->add<IconW>(icon, 18, Role::AccentBright);
    r->add<Label>(text, 15, Weight::DemiBold);
    return r;
}
Box *toggleRow(Widget *parent, const std::string &label, bool on, std::function<void(bool)> fn) {
    auto *r = row(parent, 12);
    r->add<Label>(label, 13.5, Weight::Normal, Role::Text2)->grow = 1;
    auto *t = r->add<Toggle>(on);
    t->onToggled = std::move(fn);
    return r;
}

}  // namespace nova

// ------------------------------------------------------------------ lyrics --
namespace nova {

static std::string esc(const std::string &s) {
    std::string o;
    for (char c : s) {
        if (c == '&') o += "&amp;";
        else if (c == '<') o += "&lt;";
        else if (c == '>') o += "&gt;";
        else o += c;
    }
    return o;
}

LyricsView::LyricsView() {
    conn_ = Lyrics::get().changed.connect([this] { relayout(); });
    // the current line / sung words move with the song: check a few times a second
    tick_.setup(120, [this] {
        auto &l = Lyrics::get();
        if (!l.synced() || !visible) return;
        int i = l.current();
        auto words = split(l.line(i), ' ');
        int sung = (int)std::lround(l.progress() * words.size());
        if (i != lastI_ || sung != lastSung_) { lastI_ = i; lastSung_ = sung; update(); }
    }, true);
    tick_.start();
}
LyricsView::~LyricsView() { Lyrics::get().changed.disconnect(conn_); }

Size LyricsView::sizeHint(double availW, double) {
    double k = scaleK * (std::map<std::string, double>{{"S", 0.8}, {"M", 1}, {"L", 1.25}, {"XL", 1.55}}[cfg().s("lyricsSize", "M")]);
    if (k <= 0) k = scaleK;
    int style = cfg().i("lyricsStyle", 1);
    double h = style == 3 ? 3 * 22 * k : style == 1 || style == 5 ? (34 + 3 * 24) * k + 24 * k : 110 * k;
    return {std::min(availW, 560.0), h};
}

void LyricsView::paint(Painter &p) {
    auto &L = Lyrics::get();
    const Theme &t = theme();
    Color tc = textColor.a > 0 ? textColor : t.text;
    double k = scaleK;
    if (auto s = cfg().s("lyricsSize", "M"); s == "S") k *= 0.8; else if (s == "L") k *= 1.25; else if (s == "XL") k *= 1.55;
    int style = cfg().i("lyricsStyle", 1);
    Font f;
    f.size = 13 * k;
    if (!L.synced()) {
        Text tx(L.loading ? "Finding lyrics…" : !L.plain.empty() ? "Only unsynced lyrics found" : "No lyrics for this song", f, geom.w);
        p.textIn(tx, geom, t.text3, Align::Center);
        return;
    }
    int i = L.current();
    std::string cur = L.line(i);
    auto words = split(cur, ' ');
    int sung = (int)std::lround(L.progress() * words.size());
    std::string acc = t.accent.toHex();
    auto rich = [&](bool bloom) {
        std::string o;
        for (size_t w = 0; w < words.size(); w++) {
            if (w) o += " ";
            if (bloom) {
                if ((int)w == sung - 1) o += "<span foreground=\"" + acc + "\" size=\"" + std::to_string((int)(30 * k * 1024 * 0.75)) + "\">" + esc(words[w]) + "</span>";
                else if ((int)w < sung) o += esc(words[w]);
                else o += "<span alpha=\"50%\">" + esc(words[w]) + "</span>";
            } else {
                o += (int)w < sung ? "<span foreground=\"" + acc + "\">" + esc(words[w]) + "</span>" : esc(words[w]);
            }
        }
        return o;
    };
    struct Row { std::string s; Font f; double op; bool markup; bool rail; };
    std::vector<Row> rows;
    Align h = center && style != 3 && style != 5 ? Align::Center : Align::Start;
    auto mk = [&](double size, Weight w, bool mono = false) { Font x; x.size = size * k; x.weight = w; x.mono = mono; return x; };
    if (style == 1 || style == 5) {
        for (int d : {-1, 0, 1, 2}) {
            if (d == 0) rows.push_back({rich(false), mk(24, Weight::Bold), 1, true, style == 5});
            else rows.push_back({esc(L.line(i + d)), mk(16, Weight::DemiBold), d == 1 ? 0.45 : d < 0 ? 0.3 : 0.22, true, false});
        }
    } else if (style == 3) {
        for (int d : {-1, 0, 1}) {
            int j = i + d;
            if (j < 0 || j >= (int)L.lines.size()) { rows.push_back({"", mk(14, Weight::Normal, true), 0, false, false}); continue; }
            double ts = L.lines[j].first;
            char b[32];
            snprintf(b, sizeof b, "[%02d:%05.2f] ", (int)(ts / 60), fmod(ts, 60));
            std::string s = esc(b) + (d == 0 ? rich(false) + "<span background=\"" + acc + "\"> </span>" : esc(L.line(j)));
            rows.push_back({s, mk(14, Weight::Normal, true), d == 0 ? 1 : 0.5, true, false});
        }
    } else {
        rows.push_back({rich(style == 4), mk(26, style == 6 ? Weight::Bold : Weight::Bold), 1, true, false});
        if (style == 2) rows.push_back({esc(L.line(i + 1)), mk(15, Weight::Normal), 0.5, true, false});
    }
    // lay out, centre the block vertically
    std::vector<Text> texts;
    double total = 0, gap = 8 * k, railW = style == 5 ? 14 : 0;
    for (auto &r : rows) {
        texts.emplace_back(r.s, r.f, geom.w - railW, Elide::End, 2, r.markup);
        total += texts.back().size().h + gap;
    }
    total -= gap;
    double y = geom.y + std::max(0.0, (geom.h - total) / 2);
    p.save();
    p.clip(geom);
    for (size_t r = 0; r < rows.size(); r++) {
        Size s = texts[r].size();
        Rect box{geom.x + railW, y, geom.w - railW, s.h};
        if (rows[r].rail) p.fill({geom.x, y + 2, 4, s.h - 4}, t.accent, 2);
        if (shadowText) p.textIn(texts[r], box.translated(0, 2), Color{0, 0, 0, 0.45 * rows[r].op}, h);
        if (style == 6 && r == 0) {
            // outline: a light copy offset around the text
            for (auto [dx, dy] : std::vector<std::pair<double, double>>{{-1, 0}, {1, 0}, {0, -1}, {0, 1}})
                p.textIn(texts[r], box.translated(dx, dy), Color{1, 1, 1, 0.85}, h);
        }
        p.textIn(texts[r], box, tc.withAlpha(rows[r].op), h);
        y += s.h + gap;
    }
    p.restore();
}

}  // namespace nova
