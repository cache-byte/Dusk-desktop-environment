// nova-shell: panel, pop-ups, notifications, indicators, lock screen and wallpaper for the
// Nova compositor (any wlroots compositor with layer-shell works for the basics).
//
//   nova-shell                 run the shell
//   nova-shell toggle NAME     launcher | controlcentre | notifications | clipboard | capture | gameoverlay | overview
//   nova-shell close | lock | quit
//   nova-shell toast TEXT [ICON]
//   nova-shell --version
#include "apps.hpp"
#include "dbus.hpp"
#include "notifications.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "tray.hpp"
#include "windows.hpp"

#include <csignal>
#include <fcntl.h>
#include <poll.h>
#include <cstring>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#ifndef NOVA_VERSION
#define NOVA_VERSION "dev"
#endif

using namespace nova;
using namespace ui;

static std::string socketPath() { return runtimeDir() + "/nova-shell.sock"; }

// ---- talking to a running shell ----
static int sendCommand(const std::vector<std::string> &args) {
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, socketPath().c_str(), sizeof a.sun_path - 1);
    if (fd < 0 || connect(fd, (sockaddr *)&a, sizeof a) < 0) {
        fprintf(stderr, "nova-shell: the shell isn't running\n");
        return 1;
    }
    json j = args;
    std::string line = j.dump() + "\n";
    ssize_t n = write(fd, line.data(), line.size());
    close(fd);
    return n == (ssize_t)line.size() ? 0 : 1;
}

static void runCommand(const json &a) {
    if (!a.is_array() || a.empty() || !a[0].is_string()) return;
    std::string cmd = a[0];
    std::string arg = a.size() > 1 && a[1].is_string() ? a[1].get<std::string>() : "";
    if (cmd == "toggle") shell().action(arg);
    else if (cmd == "close") shell().close();
    else if (cmd == "lock") LockScreen::get().lock();
    else if (cmd == "toast") broadcastToast(arg, a.size() > 2 && a[2].is_string() ? a[2].get<std::string>() : "check");
    else if (cmd == "reload") cfg().load();
    else if (cmd == "quit") Loop::get().quit();
}

static void listen() {
    std::string path = socketPath();
    unlink(path.c_str());
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, path.c_str(), sizeof a.sun_path - 1);
    if (fd < 0 || bind(fd, (sockaddr *)&a, sizeof a) < 0 || ::listen(fd, 8) < 0) {
        fprintf(stderr, "nova-shell: can't listen on %s: %s\n", path.c_str(), strerror(errno));
        return;
    }
    Loop::get().addFd(fd, POLLIN, [](int lfd, short) {
        int c = accept4(lfd, nullptr, nullptr, SOCK_CLOEXEC | SOCK_NONBLOCK);
        if (c < 0) return;
        auto buf = std::make_shared<std::string>();
        auto id = std::make_shared<int>(0);
        *id = Loop::get().addFd(c, POLLIN, [buf, id](int cfd, short) {
            char b[4096];
            ssize_t n = read(cfd, b, sizeof b);
            if (n > 0) { buf->append(b, n); return; }
            if (n < 0 && errno == EAGAIN) return;
            Loop::get().removeFd(*id);
            close(cfd);
            for (auto &line : split(*buf, '\n')) {
                if (trim(line).empty()) continue;
                try { runCommand(json::parse(line)); } catch (...) {}
            }
        });
    });
}

// ---- screens follow the outputs ----
static void addScreen(Output *o) {
    for (auto &s : shell().screens) if (s->output == o) return;
    shell().screens.push_back(std::make_unique<Screen>(o));
}
static void removeScreen(Output *o) {
    auto &v = shell().screens;
    v.erase(std::remove_if(v.begin(), v.end(), [o](auto &s) { return s->output == o; }), v.end());
}

int main(int argc, char **argv) {
    if (argc > 1) {
        std::string a = argv[1];
        if (a == "--version" || a == "-v") { printf("nova-shell %s\n", NOVA_VERSION); return 0; }
        if (a == "--help" || a == "-h") {
            printf("usage: nova-shell [toggle NAME | close | lock | toast TEXT [ICON] | reload | quit]\n");
            return 0;
        }
        std::vector<std::string> args(argv + 1, argv + argc);
        return sendCommand(args);
    }

    // one shell per session
    std::string lockPath = runtimeDir() + "/nova-shell.lock";
    int lockFd = open(lockPath.c_str(), O_CREAT | O_RDWR | O_CLOEXEC, 0600);
    if (lockFd < 0 || flock(lockFd, LOCK_EX | LOCK_NB) < 0) {
        fprintf(stderr, "nova-shell: already running\n");
        return 1;
    }

    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_DFL);

    auto &wl = Wayland::get();
    if (!wl.connect()) {
        fprintf(stderr, "nova-shell: can't connect to a Wayland compositor (WAYLAND_DISPLAY=%s)\n", getenv("WAYLAND_DISPLAY") ? getenv("WAYLAND_DISPLAY") : "");
        return 1;
    }
    if (!wl.layerShell) {
        fprintf(stderr, "nova-shell: the compositor has no wlr-layer-shell; the shell needs it\n");
        return 1;
    }

    std::string assets = "/usr/share/nova/shell";
    if (const char *d = getenv("NOVA_ASSETS"); d && *d) assets = d;
    setIconSearchPath(assets + "/icons");
    cfg().load();

    // services
    NovaIpc::get().connect();
    Apps::get().start();
    Toplevels::get().start();
    Idle::get().start();
    Notifications::get().start();
    Tray::get().start();
    Audio::get().start();
    Brightness::get().start();
    Net::get().start();
    Battery::get().start();
    Bluetooth::get().start();
    Power::get().start();
    Media::get().start();
    Lyrics::get().start();
    Recorder::get().start();
    Replay::get().start();
    Gaming::get().start();

    // the compositor's blur follows Settings
    auto pushBlur = [] {
        if (theme().realBlur) ipc().dispatch("blur " + std::to_string(cfg().d("blurUi", 0.8)));
    };
    pushBlur();

    for (auto &o : wl.outputs) addScreen(o.get());
    wl.outputAdded.connect([](Output *o) { Loop::get().defer([o] { addScreen(o); }); });
    wl.outputRemoved.connect([](Output *o) { removeScreen(o); });

    auto syncAll = [] { for (auto &s : shell().screens) s->sync(); };
    shell().changed.connect(syncAll);
    cfg().changed.connect([syncAll, pushBlur] { syncAll(); pushBlur(); });
    Media::get().changed.connect(syncAll);
    ipc().shellAction.connect([](const std::string &a) { shell().action(a); });
    ipc().lockRequested.connect([] { LockScreen::get().lock(); });
    ipc().activeOutputChanged.connect([syncAll](const std::string &) { syncAll(); });

    listen();
    Loop::get().run();

    shell().screens.clear();
    unlink(socketPath().c_str());
    return 0;
}
