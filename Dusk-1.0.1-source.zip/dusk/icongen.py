import json, os, shutil
S='/tmp/claude-0/-home-claude/57b23e1e-2467-52d4-bb1f-41244e871ad0/scratchpad/mock/icons.js'
s=open(S).read(); L=json.loads(s[s.index('{'):s.rindex('}')+1])
def P(*ds): return ''.join(f'<path d="{d}"/>' for d in ds)
X = {
 'globe': '<circle cx="12" cy="12" r="10"/>'+P('M2 12h20','M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z'),
 'compass': '<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>',
 'music': P('M9 18V5l12-2v13')+'<circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
 'mail': '<rect x="2" y="4" width="20" height="16" rx="2"/>'+P('m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7'),
 'calendar': '<rect x="3" y="4" width="18" height="18" rx="2"/>'+P('M16 2v4','M8 2v4','M3 10h18'),
 'map': P('M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z','M15 5.764v15','M9 3.236v15'),
 'code': P('m16 18 6-6-6-6','m8 6-6 6 6 6'),
 'file-text': P('M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z','M14 2v4a2 2 0 0 0 2 2h4','M10 9H8','M16 13H8','M16 17H8'),
 'book-open': P('M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z','M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z'),
 'calculator': '<rect x="4" y="2" width="16" height="20" rx="2"/>'+P('M8 6h8','M16 14v4','M16 10h.01','M12 10h.01','M8 10h.01','M12 14h.01','M8 14h.01','M12 18h.01','M8 18h.01'),
 'bag': P('M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z','M3 6h18','M16 10a4 4 0 0 1-8 0'),
 'activity': P('M22 12h-4l-3 9L9 3l-3 9H2'),
 'users': P('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2','M22 21v-2a4 4 0 0 0-3-3.87','M16 3.13a4 4 0 0 1 0 7.75')+'<circle cx="9" cy="7" r="4"/>',
 'type': P('M4 7V4h16v3','M9 20h6','M12 4v16'),
 'brush': P('m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08','M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z'),
 'send': P('m22 2-7 20-4-9-9-4Z','M22 2 11 13'),
 'pie': P('M21.21 15.89A10 10 0 1 1 8 2.83','M22 12A10 10 0 0 0 12 2v10z'),
 'present': '<rect x="2" y="3" width="20" height="14" rx="2"/>'+P('M8 21h8','M12 17v4'),
 'sheet': '<rect x="3" y="3" width="18" height="18" rx="2"/>'+P('M3 9h18','M3 15h18','M9 3v18'),
 'play-circle': '<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/>',
 'chat': P('M7.9 20A9 9 0 1 0 4 16.1L2 22Z'),
 'cloud-sun': P('M12 2v2','m4.93 4.93 1.41 1.41','M20 12h2','m19.07 4.93-1.41 1.41','M15.947 12.65a4 4 0 0 0-5.925-4.128','M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z'),
 'cpu': '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/>'+P('M15 2v2','M15 20v2','M2 15h2','M2 9h2','M20 15h2','M20 9h2','M9 2v2','M9 20v2'),
 'puzzle': P('M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z'),
 'notebook': P('M2 6h4','M2 10h4','M2 14h4','M2 18h4','M16 2v20')+'<rect x="4" y="2" width="16" height="20" rx="2"/>',
 'archive': '<rect x="2" y="3" width="20" height="5" rx="1"/>'+P('M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8','M10 12h4'),
 'printer': P('M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2','M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6')+'<rect x="6" y="14" width="12" height="8" rx="1"/>',
}
G = dict(L); G.update(X)
C = dict(blue='#3b82f6', red='#e5484d', orange='#f97316', amber='#eab308', green='#22c55e', teal='#14b8a6', sky='#0ea5e9',
	indigo='#6366f1', violet='#8b5cf6', pink='#ec4899', slate='#4b5563', steel='#64748b', dark='#1f2937', navy='#1b2838', emerald='#10b981', rose='#f43f5e')
# icon names (what .desktop files ask for) -> (glyph, colour)
APPS = {
 ('org.gnome.Nautilus','system-file-manager','org.kde.dolphin','nemo','thunar'): ('folder','blue'),
 ('firefox','org.mozilla.firefox'): ('globe','orange'),
 ('vivaldi','vivaldi-stable','com.vivaldi.Vivaldi'): ('compass','red'),
 ('chromium','chromium-browser','org.chromium.Chromium','google-chrome','com.google.Chrome','brave-browser','com.brave.Browser','org.gnome.Epiphany','microsoft-edge'): ('globe','sky'),
 ('org.gnome.Ptyxis','org.gnome.Console','org.gnome.Terminal','utilities-terminal','org.kde.konsole','kitty','Alacritty','com.mitchellh.ghostty','foot'): ('square-terminal','slate'),
 ('org.gnome.Settings','gnome-control-center','preferences-system','systemsettings','org.dusk.Settings','preferences-desktop'): ('settings','steel'),
 ('steam','com.valvesoftware.Steam'): ('gamepad-2','navy'),
 ('com.heroicgameslauncher.hgl','heroic'): ('rocket','sky'),
 ('net.lutris.Lutris','lutris','com.usebottles.bottles','org.prismlauncher.PrismLauncher','io.github.prateekmedia.appimagepool'): ('gamepad-2','violet'),
 ('spotify','spotify-client','com.spotify.Client','org.gnome.Rhythmbox3','org.gnome.Music','io.bassi.Amberol','elisa','org.kde.elisa'): ('music','green'),
 ('org.gnome.Calendar','evolution-calendar','org.kde.merkuro.calendar'): ('calendar','amber'),
 ('org.gnome.Snapshot','org.gnome.Cheese','cheese','camera'): ('camera','violet'),
 ('org.gnome.Calculator','accessories-calculator','org.kde.kcalc','gnome-calculator'): ('calculator','green'),
 ('org.gnome.Software','system-software-install','org.kde.discover','plasmadiscover','com.mattjakeman.ExtensionManager-software'): ('bag','blue'),
 ('org.gnome.clocks','gnome-clocks','org.kde.kclock'): ('clock','steel'),
 ('org.gnome.TextEditor','accessories-text-editor','org.kde.kate','org.kde.kwrite','gedit'): ('file-text','amber'),
 ('org.gnome.Boxes','virt-manager','org.virt_manager.virt-manager'): ('package','indigo'),
 ('discord','com.discordapp.Discord','dev.vencord.Vesktop','vesktop'): ('chat','indigo'),
 ('org.telegram.desktop','telegram','io.github.nicodemos.whatsapp','whatsapp','com.rtosta.zapzap','zapzap','signal-desktop','org.signal.Signal'): ('message-square','emerald'),
 ('com.obsproject.Studio','obs'): ('circle-dot','dark'),
 ('vlc','org.videolan.VLC','mpv','io.mpv.Mpv','org.gnome.Totem','org.gnome.Showtime','com.github.rafostar.Clapper','org.kde.haruna'): ('play-circle','orange'),
 ('org.gimp.GIMP','gimp','org.kde.krita','krita','org.inkscape.Inkscape','inkscape'): ('brush','pink'),
 ('blender','org.blender.Blender'): ('blend','orange'),
 ('code','com.visualstudio.code','visual-studio-code','code-oss','com.vscodium.codium','vscodium','dev.zed.Zed','zed'): ('code','blue'),
 ('libreoffice-writer','org.libreoffice.LibreOffice.writer'): ('file-text','blue'),
 ('libreoffice-calc','org.libreoffice.LibreOffice.calc'): ('sheet','green'),
 ('libreoffice-impress','org.libreoffice.LibreOffice.impress'): ('present','orange'),
 ('libreoffice-startcenter','org.libreoffice.LibreOffice'): ('file','teal'),
 ('org.kde.spectacle','org.gnome.Screenshot','applets-screenshooter'): ('scan','pink'),
 ('org.kde.kdeconnect.app','kdeconnect','org.kde.kdeconnect','org.kde.kdeconnect-settings'): ('smartphone','teal'),
 ('org.localsend.localsend_app','localsend'): ('send','teal'),
 ('org.gnome.Loupe','eog','org.gnome.eog','org.kde.gwenview','image-viewer'): ('image','sky'),
 ('org.gnome.Papers','org.gnome.Evince','evince','org.kde.okular','okular'): ('book-open','red'),
 ('org.gnome.SystemMonitor','gnome-system-monitor','utilities-system-monitor','org.kde.plasma-systemmonitor','io.missioncenter.MissionCenter'): ('activity','green'),
 ('org.gnome.Weather','weather','org.kde.kweather'): ('cloud-sun','sky'),
 ('org.gnome.Maps','maps','org.kde.marble'): ('map','green'),
 ('org.gnome.Contacts','contacts','org.kde.kaddressbook'): ('users','steel'),
 ('org.gnome.Characters','gnome-characters'): ('type','violet'),
 ('org.gnome.font-viewer','preferences-desktop-font'): ('type','slate'),
 ('org.gnome.DiskUtility','gnome-disks','org.kde.partitionmanager'): ('hard-drive','steel'),
 ('org.gnome.baobab','baobab','org.kde.filelight'): ('pie','amber'),
 ('org.gnome.Extensions','com.mattjakeman.ExtensionManager'): ('puzzle','blue'),
 ('thunderbird','org.mozilla.Thunderbird','net.thunderbird.Thunderbird','org.gnome.Evolution','evolution','org.gnome.Geary'): ('mail','sky'),
 ('org.gnome.Tour','org.gnome.Yelp','help-browser','yelp'): ('info','indigo'),
 ('org.gnome.FileRoller','file-roller','org.kde.ark','ark'): ('archive','amber'),
 ('org.gnome.SoundRecorder','gnome-sound-recorder'): ('mic','red'),
 ('pavucontrol','org.pulseaudio.pavucontrol','com.saivert.pwvucontrol'): ('sliders-horizontal','teal'),
 ('org.gnome.Notes','org.kde.knotes','com.github.flxzt.rnote','md.obsidian.Obsidian','obsidian'): ('notebook','violet'),
 ('system-config-printer','printer'): ('printer','slate'),
 ('org.gnome.Settings-power-panel','gnome-power-statistics','org.gnome.PowerStats'): ('battery','green'),
 ('org.gnome.tweaks','org.gnome.Tweaks'): ('sliders-horizontal','steel'),
 ('nvidia-settings',): ('cpu','green'),
 ('org.gnome.seahorse.Application','seahorse'): ('lock','amber'),
 ('org.gnome.Connections','org.remmina.Remmina'): ('monitor','indigo'),
 ('org.gnome.Logs','gnome-logs'): ('file-text','slate'),
 ('org.gnome.Firmware','org.gnome.Firmware'): ('cpu','steel'),
 ('dusk','org.dusk.Dusk'): ('sparkles','blue'),
 ('wine','winecfg','wine-winecfg'): ('app-window','red'),
 ('com.github.tchx84.Flatseal','flatseal'): ('shield','blue'),
 ('io.github.ilya_zlobintsev.LACT','lact'): ('gauge','red'),
}
PLACES = {
 ('folder','inode-directory'): None, ('user-home','folder-home'): 'house', ('folder-documents','user-documents'): 'file-text',
 ('folder-download','user-download','folder-downloads'): 'download', ('folder-pictures','user-pictures'): 'image',
 ('folder-music','user-music'): 'music', ('folder-videos','user-videos'): 'video', ('user-desktop','folder-desktop'): 'monitor',
 ('folder-publicshare','user-share'): 'users', ('folder-templates','user-templates'): 'layout-template',
 ('folder-games',): 'gamepad-2', ('folder-code','folder-development'): 'code', ('folder-cloud','folder-remote'): 'cloud-sun',
}
def glyph(name, x, y, size, colour='#fff', width=2):
	k = size / 24
	return (f'<g transform="translate({x} {y}) scale({k:.4f})" fill="none" stroke="{colour}" stroke-width="{width}" '
		f'stroke-linecap="round" stroke-linejoin="round">{G[name]}</g>')
def app_svg(g, c):
	return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">'
		f'<rect x="4" y="4" width="56" height="56" rx="16" fill="{C[c]}"/>'
		f'<rect x="4.5" y="4.5" width="55" height="55" rx="15.5" fill="none" stroke="#000" stroke-opacity=".10"/>'
		+ glyph(g, 17, 17, 30) + '</svg>')
def folder_svg(g, back='#2563eb', front='#3b82f6'):
	body = (f'<path d="M6 16a5 5 0 0 1 5-5h13l5 5h24a5 5 0 0 1 5 5v28a5 5 0 0 1-5 5H11a5 5 0 0 1-5-5z" fill="{back}"/>'
		f'<rect x="6" y="21" width="52" height="33" rx="5" fill="{front}"/>')
	return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">' + body +
		(glyph(g, 23, 28, 18, '#fff', 2.2) if g else '') + '</svg>')
def trash_svg(full):
	return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">'
		'<rect x="4" y="4" width="56" height="56" rx="16" fill="#64748b"/>' + glyph('trash', 17, 17, 30) +
		('<circle cx="49" cy="15" r="7" fill="#e5484d"/>' if full else '') + '</svg>')

def build(out='Dusk'):
	shutil.rmtree(out, ignore_errors=True)
	for d in ('scalable/apps', 'scalable/places'):
		os.makedirs(f'{out}/{d}')
	n = 0
	for names, (g, c) in APPS.items():
		assert g in G, g
		for nm in names:
			open(f'{out}/scalable/apps/{nm}.svg', 'w').write(app_svg(g, c)); n += 1
	for names, g in PLACES.items():
		for nm in names:
			open(f'{out}/scalable/places/{nm}.svg', 'w').write(folder_svg(g)); n += 1
	open(f'{out}/scalable/places/user-trash.svg', 'w').write(trash_svg(False))
	open(f'{out}/scalable/places/user-trash-full.svg', 'w').write(trash_svg(True))
	open(f'{out}/index.theme', 'w').write('''[Icon Theme]
	Name=Dusk
	Comment=Flat rounded app icons in Dusk's style; everything else from Papirus or Adwaita
	Inherits=Papirus-Dark,Papirus,Adwaita,hicolor
	Example=folder
	Directories=scalable/apps,scalable/places

	[scalable/apps]
	Size=64
	MinSize=8
	MaxSize=512
	Type=Scalable
	Context=Applications

	[scalable/places]
	Size=64
	MinSize=8
	MaxSize=512
	Type=Scalable
	Context=Places
	''')
	print(n + 2, 'icons')
	# preview: one per app family
	prev = [(names[0], app_svg(g, c)) for names, (g, c) in APPS.items()] + [(names[0], folder_svg(g)) for names, g in PLACES.items()] + [('user-trash', trash_svg(True))]
	html = '<html><body style="margin:0;background:#222226;font-family:Inter;color:#ddd"><div style="display:grid;grid-template-columns:repeat(12,120px);gap:6px;padding:24px">'
	for nm, svg in prev:
		html += f'<div style="display:flex;flex-direction:column;align-items:center;gap:6px;font-size:10px;text-align:center;word-break:break-all"><div style="width:64px;height:64px">{svg}</div>{nm}</div>'
	open('preview.html', 'w').write(html + '</div></body></html>')

if __name__ == '__main__':
	build()
