// Dusk's panel: one bar along the bottom, floating. The app menu, the
// overview, your apps; the tray, the Control Centre and the clock.
var panel = new Panel;
panel.location = "bottom";
panel.height = 2 * Math.round(gridUnit * 2.6 / 2);
try { panel.floating = true; } catch (e) {}

var menu = panel.addWidget("org.kde.plasma.kickoff");
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "dusk");
menu.currentConfigGroup = ["Shortcuts"];
menu.writeConfig("global", "Alt+F1");

try { panel.addWidget("org.kde.plasma.showdesktop"); } catch (e) {}

var tasks = panel.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", ["preferred://filemanager", "preferred://browser", "applications:org.kde.konsole.desktop",
	"applications:steam.desktop", "applications:org.kde.discover.desktop"]);

panel.addWidget("org.kde.plasma.panelspacer");
try {
	var pager = panel.addWidget("org.kde.plasma.pager");
	pager.currentConfigGroup = ["General"];
	pager.writeConfig("displayedText", "None");
	pager.writeConfig("showWindowIcons", false);
} catch (e) {}
panel.addWidget("org.kde.plasma.panelspacer");

// The tray: apps' icons and Plasma's notifications; Wi-Fi, sound, battery
// and the rest live in Dusk's Control Centre next to it.
var tray = panel.addWidget("org.kde.plasma.systemtray");
try {
	var trayId = tray.readConfig("SystrayContainmentId");
	if (trayId) {
		var inner = desktopById(trayId);
		inner.currentConfigGroup = ["General"];
		inner.writeConfig("hiddenItems", ["org.kde.plasma.networkmanagement", "org.kde.plasma.volume", "org.kde.plasma.battery",
			"org.kde.plasma.bluetooth", "org.kde.plasma.mediacontroller", "org.kde.plasma.brightness",
			"org.kde.plasma.keyboardindicator", "org.kde.plasma.manage-inputmethod"]);
	}
} catch (e) {}

panel.addWidget("org.dusk.controlcentre");

var clock = panel.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", true);
clock.writeConfig("dateDisplayFormat", "BelowTime");
clock.writeConfig("dateFormat", "shortDate");
