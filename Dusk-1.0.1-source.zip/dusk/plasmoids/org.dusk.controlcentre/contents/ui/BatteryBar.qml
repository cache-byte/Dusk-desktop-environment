// The charge as a bar filling the pill, in the power mode's colour, with the
// three power modes at the end.
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: b
    property var pal
    property int level: -1
    property string batState: ""
    property string profile: ""
    property string timeLeft: ""
    signal pick(string profile)
    implicitHeight: 56
    radius: height / 2
    readonly property color mode: level >= 0 && level <= 15 && batState === "Discharging" ? "#e5484d"
        : profile === "performance" ? "#f08c3a" : profile === "power-saver" ? "#3fa77c" : pal.accent
    color: Qt.rgba(mode.r, mode.g, mode.b, 0.18)
    clip: true
    Rectangle {
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        width: parent.width * Math.max(0, b.level) / 100
        color: Qt.rgba(b.mode.r, b.mode.g, b.mode.b, 0.34)
        Behavior on width { NumberAnimation { duration: 300 } }
    }
    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 20
        anchors.rightMargin: 8
        ColumnLayout {
            spacing: 0
            Layout.fillWidth: true
            RowLayout {
                spacing: 6
                Text { text: b.level >= 0 ? b.level + "%" : "Power mode"; color: b.pal.text; font.bold: true; font.pixelSize: 15 }
                Glyph { name: "zap"; tint: b.pal.text; visible: b.batState === "Charging"; implicitWidth: 14; implicitHeight: 14 }
            }
            Text {
                text: (b.profile === "performance" ? "Performance" : b.profile === "power-saver" ? "Power saver" : "Balanced")
                    + (b.batState === "Charging" ? " · charging" : b.batState === "Full" ? " · full" : "")
                color: b.pal.dim
                font.pixelSize: 12
            }
        }
        Rectangle {
            visible: b.profile !== ""
            implicitWidth: row.implicitWidth + 8
            implicitHeight: 42
            radius: 21
            color: Qt.rgba(0, 0, 0, 0.22)
            Row {
                id: row
                anchors.centerIn: parent
                spacing: 3
                Repeater {
                    model: [["power-saver", "leaf"], ["balanced", "gauge"], ["performance", "zap"]]
                    delegate: Rectangle {
                        required property var modelData
                        width: 36; height: 36; radius: 18
                        color: b.profile === modelData[0] ? b.mode : "transparent"
                        Behavior on color { ColorAnimation { duration: 160 } }
                        Glyph {
                            anchors.centerIn: parent
                            name: modelData[1]
                            implicitWidth: 17; implicitHeight: 17
                            tint: b.profile === modelData[0] ? "white" : b.pal.dim
                        }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: b.pick(modelData[0]) }
                    }
                }
            }
        }
    }
}
