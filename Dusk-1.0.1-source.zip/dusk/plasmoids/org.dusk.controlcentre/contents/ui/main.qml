// Dusk's Control Centre, as a Plasma widget: a status pill in the panel
// (Wi-Fi, Bluetooth, volume, battery) that opens the Control Centre.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    Palette { id: duskPal }
    Sys { id: duskSys }

    preferredRepresentation: compactRepresentation
    toolTipMainText: "Control centre"
    toolTipSubText: (duskSys.wifiOn && duskSys.wifiName ? duskSys.wifiName + " · " : "") + "volume " + duskSys.volume + "%" +
        (duskSys.battery >= 0 ? " · battery " + duskSys.battery + "%" : "")

    // Fresh numbers often while it's open, now and then for the pill.
    Timer {
        interval: root.expanded ? 2000 : 20000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: duskSys.refresh()
    }
    onExpandedChanged: if (expanded) duskSys.refresh()

    // ---- in the panel: the status pill ---------------------------------------------------
    compactRepresentation: MouseArea {
        id: pill
        Layout.minimumWidth: row.implicitWidth + 24
        Layout.preferredWidth: row.implicitWidth + 24
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.MiddleButton
        onClicked: mouse => {
            if (mouse.button === Qt.MiddleButton) duskSys.toggleMute()
            else root.expanded = !root.expanded
        }
        // Scrolling over it changes the volume.
        onWheel: wheel => duskSys.setVolume(Math.max(0, Math.min(100, duskSys.volume + (wheel.angleDelta.y > 0 ? 5 : -5))))
        Rectangle {
            anchors.centerIn: parent
            width: row.implicitWidth + 24
            height: Math.min(parent.height - 6, 36)
            radius: height / 2
            color: root.expanded ? Qt.rgba(duskPal.text.r, duskPal.text.g, duskPal.text.b, 0.16)
                 : pill.containsMouse ? Qt.rgba(duskPal.text.r, duskPal.text.g, duskPal.text.b, 0.12) : duskPal.soft
            Behavior on color { ColorAnimation { duration: 140 } }
        }
        RowLayout {
            id: row
            anchors.centerIn: parent
            spacing: 11
            Glyph { name: duskSys.wifiOn ? "wifi" : "wifi-off"; tint: duskPal.text; implicitWidth: 17; implicitHeight: 17; visible: duskSys.hasWifi }
            Glyph { name: duskSys.btOn ? "bluetooth" : "bluetooth-off"; tint: duskPal.text; implicitWidth: 17; implicitHeight: 17; visible: duskSys.hasBt }
            Glyph { name: duskSys.volumeMuted ? "volume-x" : "volume-2"; tint: duskPal.text; implicitWidth: 17; implicitHeight: 17 }
            RowLayout {
                visible: duskSys.battery >= 0
                spacing: 5
                Glyph { name: duskSys.batteryState === "Charging" ? "battery-charging" : "battery"; implicitWidth: 18; implicitHeight: 18
                    tint: duskSys.battery <= 15 && duskSys.batteryState === "Discharging" ? "#e5484d" : duskPal.text }
                Text { text: duskSys.battery + "%"; color: duskPal.text; font.bold: true; font.pixelSize: 13 }
            }
        }
    }

    // ---- opened: the Control Centre -----------------------------------------------------
    fullRepresentation: Item {
        Layout.preferredWidth: 412
        Layout.minimumWidth: 412
        Layout.preferredHeight: main.implicitHeight + 8
        Layout.minimumHeight: main.implicitHeight + 8

        ColumnLayout {
            id: main
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 4
            spacing: 12

            // The day and date; edit, Settings and power.
            RowLayout {
                Layout.fillWidth: true
                ColumnLayout {
                    spacing: 0
                    Layout.fillWidth: true
                    Text { text: Qt.formatDate(new Date(), "dddd"); color: duskPal.text; font.pixelSize: 20; font.bold: true }
                    Text { text: Qt.formatDate(new Date(), "d MMMM"); color: duskPal.dim; font.pixelSize: 12.5 }
                }
                RoundButton { pal: duskPal; icon: "lock"; implicitWidth: 42; implicitHeight: 42; onClicked: { root.expanded = false; duskSys.open("loginctl lock-session") } }
                RoundButton { pal: duskPal; icon: "settings"; implicitWidth: 42; implicitHeight: 42; onClicked: { root.expanded = false; duskSys.open("systemsettings") } }
                RoundButton { pal: duskPal; icon: "power"; implicitWidth: 42; implicitHeight: 42
                    onClicked: { root.expanded = false; duskSys.open("dbus-send --session --type=method_call --dest=org.kde.LogoutPrompt /LogoutPrompt org.kde.LogoutPrompt.promptAll") } }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 12
                // Left: the connections, then the toggles three by two.
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignTop
                    spacing: 10
                    Pill {
                        Layout.fillWidth: true
                        pal: duskPal
                        icactive: duskSys.wifiOn ? "wifi" : "wifi-off"
                        title: "Wi-Fi"
                        subtitle: !duskSys.hasWifi ? "Not available" : !duskSys.wifiOn ? "Off" : (duskSys.wifiName || "Not connected")
                        active: duskSys.wifiOn
                        onToggled: duskSys.toggleWifi()
                        onMore: { root.expanded = false; duskSys.open("systemsettings kcm_networkmanagement") }
                    }
                    Pill {
                        Layout.fillWidth: true
                        pal: duskPal
                        icactive: duskSys.btOn ? "bluetooth" : "bluetooth-off"
                        title: "Bluetooth"
                        subtitle: !duskSys.hasBt ? "Not available" : !duskSys.btOn ? "Off" : (duskSys.btName || "On")
                        active: duskSys.btOn
                        onToggled: duskSys.toggleBt()
                        onMore: { root.expanded = false; duskSys.open("systemsettings kcm_bluetooth") }
                    }
                    GridLayout {
                        Layout.fillWidth: true
                        Layout.topMargin: 4
                        columns: 3
                        rowSpacing: 12
                        columnSpacing: 0
                        Repeater {
                            model: [
                                { icon: "plane", tip: "Airplane mode", key: "airplane" },
                                { icon: "moon", tip: "Dark mode", key: "dark" },
                                { icon: "moon-star", tip: "Night light", key: "night" },
                                { icon: "bell-off", tip: "Do not disturb", key: "dnd" },
                                { icon: "coffee", tip: "Stay awake", key: "caffeine" },
                                { icon: "scan", tip: "Screenshot", key: "shot" }
                            ]
                            delegate: Item {
                                required property var modelData
                                Layout.fillWidth: true
                                implicitHeight: 52
                                RoundButton {
                                    anchors.centerIn: parent
                                    pal: duskPal
                                    icon: modelData.icon
                                    lit: modelData.key === "airplane" ? duskSys.airplane : modelData.key === "dark" ? duskSys.dark
                                       : modelData.key === "night" ? duskSys.nightLight : modelData.key === "dnd" ? duskSys.dnd
                                       : modelData.key === "caffeine" ? duskSys.caffeine : false
                                    onClicked: {
                                        const k = modelData.key
                                        if (k === "airplane") duskSys.toggleAirplane()
                                        else if (k === "dark") duskSys.toggleDark()
                                        else if (k === "night") duskSys.toggleNightLight()
                                        else if (k === "dnd") duskSys.toggleDnd()
                                        else if (k === "caffeine") duskSys.toggleCaffeine()
                                        else { root.expanded = false; duskSys.open("spectacle -r") }
                                    }
                                }
                                PlasmaCore.ToolTipArea { anchors.fill: parent; mainText: modelData.tip; z: -1 }
                            }
                        }
                    }
                }
                // Right: brightness, volume and the microphone, tall.
                Row {
                    Layout.alignment: Qt.AlignTop
                    spacing: 10
                    VSlider { pal: duskPal; icon: "sun"; value: Math.max(0, duskSys.brightness); available: duskSys.brightness >= 0
                        onMoved: v => duskSys.setBrightness(v) }
                    VSlider { pal: duskPal; icon: duskSys.volumeMuted ? "volume-x" : "volume-2"; value: duskSys.volume; muted: duskSys.volumeMuted
                        onMoved: v => duskSys.setVolume(v); onIconClicked: duskSys.toggleMute() }
                    VSlider { pal: duskPal; icon: duskSys.micMuted ? "mic-off" : "mic"; value: duskSys.mic; muted: duskSys.micMuted; available: duskSys.hasMic
                        onMoved: v => duskSys.setMic(v); onIconClicked: duskSys.toggleMic() }
                }
            }

            BatteryBar {
                Layout.fillWidth: true
                visible: duskSys.battery >= 0 || duskSys.profile !== ""
                pal: duskPal
                level: duskSys.battery
                batState: duskSys.batteryState
                profile: duskSys.profile
                onPick: p => duskSys.setProfile(p)
            }

            MediaCard {
                Layout.fillWidth: true
                visible: duskSys.mediaStatus !== ""
                pal: duskPal
                sys: duskSys
            }
        }
    }
}
