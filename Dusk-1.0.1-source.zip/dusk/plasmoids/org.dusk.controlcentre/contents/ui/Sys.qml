// What the Control Centre shows, and the things its buttons do.
//
// Read with one short script (every couple of seconds while it's open, every
// 20 s for the panel's status pill), changed with the usual tools: wpctl
// (PipeWire), brightnessctl, nmcli, bluetoothctl, rfkill, the power-modes service (busctl),
// playerctl, and KDE's own settings for night light, dark mode and Do not
// disturb. Any that's missing just leaves its control greyed out.
import QtQuick
import org.kde.plasma.plasma5support as P5

Item {
    id: sys

    property int volume: 0
    property bool volumeMuted: false
    property int mic: 0
    property bool micMuted: false
    property bool hasMic: false
    property int brightness: -1          // -1: no brightness control here
    property bool wifiOn: false
    property bool hasWifi: false
    property string wifiName: ""
    property bool btOn: false
    property bool hasBt: false
    property string btName: ""
    property bool airplane: false
    property int battery: -1             // -1: no battery
    property string batteryState: ""     // Charging, Discharging, Full, Not charging
    property string profile: ""          // power-saver, balanced, performance ("" = none)
    property bool nightLight: false
    property bool dark: true
    property bool dnd: false
    property bool caffeine: false
    property string mediaStatus: ""      // Playing, Paused ("" = nothing)
    property string mediaTitle: ""
    property string mediaArtist: ""
    property string mediaArt: ""
    property string mediaPlayer: ""
    property real mediaPosition: 0       // seconds
    property real mediaLength: 0

    property int _n: 0
    property var _callbacks: ({})

    P5.DataSource {
        id: exec
        engine: "executable"
        connectedSources: []
        onNewData: (source, data) => {
            const out = data["stdout"] || ""
            disconnectSource(source)
            const cb = sys._callbacks[source]
            delete sys._callbacks[source]
            if (cb) cb(out)
        }
    }

    // Runs a shell command; `done` gets what it printed.
    function run(cmd, done) {
        _n += 1
        const key = cmd + " #" + _n      // (each run its own, even the same command twice)
        _callbacks[key] = done || null
        exec.connectSource(key)
    }

    readonly property string _probe: [
        "echo \"vol=$(wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null)\"",
        "echo \"mic=$(wpctl get-volume @DEFAULT_AUDIO_SOURCE@ 2>/dev/null)\"",
        "echo \"bri=$(brightnessctl -m 2>/dev/null | head -1 | cut -d, -f4)\"",
        "echo \"wifi=$(nmcli -t -f WIFI-HW,WIFI radio 2>/dev/null)\"",
        "echo \"ssid=$(nmcli -t -f active,ssid dev wifi 2>/dev/null | grep '^yes' | head -1 | cut -d: -f2-)\"",
        "echo \"bt=$(bluetoothctl show 2>/dev/null | grep -m1 Powered: | awk '{print $2}')\"",
        "echo \"btdev=$(bluetoothctl devices Connected 2>/dev/null | head -1 | cut -d' ' -f3-)\"",
        "echo \"air=$(rfkill -n -o SOFT 2>/dev/null | sort -u | tr '\\n' ' ')\"",
        "echo \"bat=$(cat /sys/class/power_supply/BAT*/capacity 2>/dev/null | head -1)\"",
        "echo \"batst=$(cat /sys/class/power_supply/BAT*/status 2>/dev/null | head -1)\"",
        "echo \"prof=$(busctl get-property org.freedesktop.UPower.PowerProfiles /org/freedesktop/UPower/PowerProfiles org.freedesktop.UPower.PowerProfiles ActiveProfile 2>/dev/null | awk '{print $2}' | tr -dc 'a-z-')\"",
        "echo \"night=$(kreadconfig6 --file kwinrc --group NightColor --key Active 2>/dev/null)\"",
        "echo \"scheme=$(kreadconfig6 --group General --key ColorScheme 2>/dev/null)\"",
        "echo \"dnd=$(kreadconfig6 --file plasmanotifyrc --group DoNotDisturb --key Until 2>/dev/null)\"",
        "echo \"caf=$(pgrep -f dusk-caffeine >/dev/null && echo yes)\"",
        "echo \"media=$(playerctl metadata --format '{{status}}|~|{{title}}|~|{{artist}}|~|{{mpris:artUrl}}|~|{{position}}|~|{{mpris:length}}|~|{{playerName}}' 2>/dev/null | head -1)\""
    ].join("; ")

    function refresh() {
        run(_probe, out => {
            const v = {}
            for (const line of out.split("\n")) {
                const i = line.indexOf("=")
                if (i > 0) v[line.slice(0, i)] = line.slice(i + 1).trim()
            }
            // "Volume: 0.55 [MUTED]"
            const vol = /([0-9.]+)/.exec(v.vol || "")
            volume = vol ? Math.round(parseFloat(vol[1]) * 100) : 0
            volumeMuted = (v.vol || "").indexOf("MUTED") >= 0
            const m = /([0-9.]+)/.exec(v.mic || "")
            hasMic = !!m
            mic = m ? Math.round(parseFloat(m[1]) * 100) : 0
            micMuted = (v.mic || "").indexOf("MUTED") >= 0
            brightness = v.bri ? parseInt(v.bri) : -1
            hasWifi = !!v.wifi
            wifiOn = (v.wifi || "").split(":")[1] === "enabled"
            wifiName = v.ssid || ""
            hasBt = v.bt === "yes" || v.bt === "no"
            btOn = v.bt === "yes"
            btName = v.btdev || ""
            airplane = (v.air || "").trim() === "blocked"
            battery = v.bat ? parseInt(v.bat) : -1
            batteryState = v.batst || ""
            profile = v.prof || ""
            nightLight = v.night === "true"
            dark = (v.scheme || "").indexOf("Light") < 0
            dnd = !!v.dnd && new Date(v.dnd) > new Date()
            caffeine = v.caf === "yes"
            const parts = (v.media || "").split("|~|")
            mediaStatus = parts.length >= 7 && (parts[0] === "Playing" || parts[0] === "Paused") ? parts[0] : ""
            mediaTitle = parts[1] || ""
            mediaArtist = parts[2] || ""
            mediaArt = parts[3] || ""
            mediaPosition = (parseInt(parts[4]) || 0) / 1000000
            mediaLength = (parseInt(parts[5]) || 0) / 1000000
            mediaPlayer = parts[6] || ""
        })
    }

    // ---- what the buttons do -------------------------------------------------------------

    function setVolume(p) { volume = p; run("wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ " + (p / 100).toFixed(2)) }
    function toggleMute() { volumeMuted = !volumeMuted; run("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle") }
    function setMic(p) { mic = p; run("wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SOURCE@ " + (p / 100).toFixed(2)) }
    function toggleMic() { micMuted = !micMuted; run("wpctl set-mute @DEFAULT_AUDIO_SOURCE@ toggle") }
    function setBrightness(p) { brightness = p; run("brightnessctl -q set " + Math.max(1, p) + "%") }
    function toggleWifi() { wifiOn = !wifiOn; run("nmcli radio wifi " + (wifiOn ? "on" : "off"), refresh) }
    function toggleBt() {
        btOn = !btOn
        run(btOn ? "rfkill unblock bluetooth; sleep 0.3; bluetoothctl power on" : "bluetoothctl power off", refresh)
    }
    function toggleAirplane() {
        airplane = !airplane
        run("rfkill " + (airplane ? "block" : "unblock") + " all", refresh)
    }
    function toggleNightLight() {
        nightLight = !nightLight
        run("kwriteconfig6 --file kwinrc --group NightColor --key Active " + nightLight +
            "; dbus-send --session --type=method_call --dest=org.kde.KWin /KWin org.kde.KWin.reconfigure")
    }
    function toggleDark() {
        dark = !dark
        run("plasma-apply-colorscheme " + (dark ? "DuskDark" : "DuskLight"))
    }
    function toggleDnd() {
        dnd = !dnd
        run(dnd ? "kwriteconfig6 --file plasmanotifyrc --group DoNotDisturb --key Until \"$(date -d '+10 years' +%Y-%m-%dT%H:%M:%S)\""
                : "kwriteconfig6 --file plasmanotifyrc --group DoNotDisturb --key Until --delete")
    }
    function toggleCaffeine() {
        caffeine = !caffeine
        run(caffeine ? "setsid -f systemd-inhibit --what=idle:sleep --who=Dusk --why=Caffeine bash -c 'exec -a dusk-caffeine sleep infinity'"
                     : "pkill -f dusk-caffeine")
    }
    function setProfile(p) { profile = p; run("busctl set-property org.freedesktop.UPower.PowerProfiles /org/freedesktop/UPower/PowerProfiles org.freedesktop.UPower.PowerProfiles ActiveProfile s " + p) }
    function mediaCommand(c) { run("playerctl " + c, () => refresh()) }
    function open(cmd) { run("setsid -f " + cmd + " >/dev/null 2>&1") }
}
