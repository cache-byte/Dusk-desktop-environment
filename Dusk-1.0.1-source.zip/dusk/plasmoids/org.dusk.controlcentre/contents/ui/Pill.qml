// Wi-Fi and Bluetooth: the round button switches it, the rest opens its settings.
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: p
    property var pal
    property string icon
    property string title
    property string subtitle
    property bool active: false
    signal toggled()
    signal more()
    implicitHeight: 56
    radius: height / 2
    color: active ? pal.tint : (area.containsMouse ? Qt.rgba(pal.text.r, pal.text.g, pal.text.b, 0.12) : pal.soft)
    Behavior on color { ColorAnimation { duration: 140 } }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: p.more()
    }
    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 6
        anchors.rightMargin: 12
        spacing: 10
        RoundButton {
            pal: p.pal
            icon: p.icon
            lit: p.active
            implicitWidth: 44
            implicitHeight: 44
            onClicked: p.toggled()
        }
        ColumnLayout {
            spacing: 0
            Layout.fillWidth: true
            Text { text: p.title; color: p.pal.text; font.bold: true; font.pixelSize: 14; elide: Text.ElideRight; Layout.fillWidth: true }
            Text { text: p.subtitle; color: p.pal.dim; font.pixelSize: 12; elide: Text.ElideRight; Layout.fillWidth: true; visible: text !== "" }
        }
        Glyph { name: "chevron-right"; tint: p.pal.dim; implicitWidth: 16; implicitHeight: 16 }
    }
}
