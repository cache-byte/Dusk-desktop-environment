// Dusk's colours, from the Plasma colour scheme (so they follow dark and
// light, and the accent, which can come from the wallpaper).
import QtQuick
import org.kde.kirigami as Kirigami

Item {
    visible: false
    readonly property color text: Kirigami.Theme.textColor
    readonly property color dim: Qt.rgba(text.r, text.g, text.b, 0.62)
    readonly property color accent: Kirigami.Theme.highlightColor
    readonly property color onAccent: Kirigami.Theme.highlightedTextColor
    readonly property color soft: Qt.rgba(text.r, text.g, text.b, 0.09)     // round buttons, tracks
    readonly property color card: Qt.rgba(text.r, text.g, text.b, 0.06)     // the media card
    readonly property color line: Qt.rgba(text.r, text.g, text.b, 0.08)
    readonly property color tint: Qt.rgba(accent.r, accent.g, accent.b, 0.22) // a pill that's on
    readonly property color good: "#3fa77c"
}
