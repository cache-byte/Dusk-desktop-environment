// One of the Control Centre's line icons, in any colour.
import QtQuick
import org.kde.kirigami as Kirigami

Kirigami.Icon {
    property string name
    property color tint: "white"
    implicitWidth: 20
    implicitHeight: 20
    source: Qt.resolvedUrl("../icons/" + name + ".svg")
    isMask: true
    color: tint
}
