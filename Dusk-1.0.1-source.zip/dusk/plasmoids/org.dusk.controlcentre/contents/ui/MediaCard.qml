// What's playing: the player and the sound output, the cover, title and
// artist, the progress, and the controls with an accent play / pause.
import QtQuick
import QtQuick.Layouts

Rectangle {
    id: m
    property var pal
    property var sys
    radius: 24
    color: pal.card
    implicitHeight: col.implicitHeight + 28
    function clock(s) { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2) }
    // Between refreshes the position moves on by itself while it plays.
    property real pos: sys.mediaPosition
    Connections { target: m.sys; function onMediaPositionChanged() { m.pos = m.sys.mediaPosition } }
    Timer { interval: 1000; repeat: true; running: m.sys.mediaStatus === "Playing" && m.visible; onTriggered: m.pos += 1 }
    ColumnLayout {
        id: col
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 14
        spacing: 10
        RowLayout {
            Rectangle {
                implicitHeight: 30; implicitWidth: pl.implicitWidth + 24; radius: 15; color: m.pal.soft
                Text { id: pl; anchors.centerIn: parent; color: m.pal.text; font.pixelSize: 12.5
                    text: m.sys.mediaPlayer ? m.sys.mediaPlayer.charAt(0).toUpperCase() + m.sys.mediaPlayer.slice(1).split(".")[0] : "Media" }
            }
            Item { Layout.fillWidth: true }
            Rectangle {
                implicitHeight: 30; implicitWidth: out.implicitWidth + 40; radius: 15; color: m.pal.soft
                Row { anchors.centerIn: parent; spacing: 6
                    Glyph { name: "speaker"; tint: m.pal.text; width: 15; height: 15 }
                    Text { id: out; text: "Media output"; color: m.pal.text; font.pixelSize: 12.5 } }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: m.sys.open("systemsettings kcm_pulseaudio") }
            }
        }
        RowLayout {
            spacing: 12
            Rectangle {
                implicitWidth: 56; implicitHeight: 56; radius: 12; color: m.pal.soft; clip: true
                Image { anchors.fill: parent; source: m.sys.mediaArt; fillMode: Image.PreserveAspectCrop; asynchronous: true; visible: status === Image.Ready }
                Glyph { anchors.centerIn: parent; name: "disc-3"; tint: m.pal.dim; visible: !m.sys.mediaArt }
            }
            ColumnLayout {
                spacing: 2
                Layout.fillWidth: true
                Text { text: m.sys.mediaTitle || "Nothing playing"; color: m.pal.text; font.bold: true; font.pixelSize: 15; elide: Text.ElideRight; Layout.fillWidth: true }
                Text { text: m.sys.mediaArtist; color: m.pal.dim; font.pixelSize: 12.5; elide: Text.ElideRight; Layout.fillWidth: true; visible: text !== "" }
            }
        }
        ColumnLayout {
            visible: m.sys.mediaLength > 0
            spacing: 4
            Layout.fillWidth: true
            Rectangle {
                Layout.fillWidth: true; implicitHeight: 4; radius: 2; color: m.pal.soft
                Rectangle { height: parent.height; radius: 2; color: m.pal.accent
                    width: parent.width * Math.min(1, m.pos / Math.max(1, m.sys.mediaLength)) }
                MouseArea { anchors.fill: parent; anchors.margins: -8; cursorShape: Qt.PointingHandCursor
                    onClicked: mouse => m.sys.mediaCommand("position " + Math.round(m.sys.mediaLength * mouse.x / width)) }
            }
            RowLayout {
                Text { text: m.clock(m.pos); color: m.pal.dim; font.pixelSize: 11.5 }
                Item { Layout.fillWidth: true }
                Text { text: m.clock(m.sys.mediaLength); color: m.pal.dim; font.pixelSize: 11.5 }
            }
        }
        Row {
            visible: m.sys.mediaStatus !== ""
            Layout.alignment: Qt.AlignHCenter
            spacing: 26
            RoundButton { pal: m.pal; icon: "skip-back"; width: 44; height: 44; color: "transparent"; anchors.verticalCenter: parent.verticalCenter; onClicked: m.sys.mediaCommand("previous") }
            RoundButton { pal: m.pal; icon: m.sys.mediaStatus === "Playing" ? "pause" : "play"; lit: true; width: 52; height: 52; onClicked: m.sys.mediaCommand("play-pause") }
            RoundButton { pal: m.pal; icon: "skip-forward"; width: 44; height: 44; color: "transparent"; anchors.verticalCenter: parent.verticalCenter; onClicked: m.sys.mediaCommand("next") }
        }
    }
}
