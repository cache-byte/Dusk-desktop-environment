// A round button with an icon: the toggles, and the buttons in the header.
import QtQuick

Rectangle {
    id: b
    property var pal
    property string icon
    property bool lit: false
    property bool enabledLook: true
    property string tip: ""
    signal clicked()
    implicitWidth: 52
    implicitHeight: 52
    radius: width / 2
    color: lit ? pal.accent : (area.containsMouse ? Qt.rgba(pal.text.r, pal.text.g, pal.text.b, 0.14) : pal.soft)
    opacity: enabledLook ? 1 : 0.45
    scale: area.pressed ? 0.94 : 1
    Behavior on color { ColorAnimation { duration: 140 } }
    Behavior on scale { NumberAnimation { duration: 90 } }
    Glyph {
        anchors.centerIn: parent
        name: b.icon
        width: Math.round(b.width * 0.42)
        height: width
        tint: b.lit ? b.pal.onAccent : b.pal.text
    }
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: b.clicked()
    }
}
