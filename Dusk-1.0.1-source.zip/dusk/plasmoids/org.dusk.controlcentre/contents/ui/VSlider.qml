// A tall slider filling from the bottom: its number on top, its icon at the
// bottom (click the icon to mute, where that applies).
import QtQuick

Rectangle {
    id: s
    property var pal
    property string icon
    property int value: 0           // 0..100
    property bool muted: false
    property bool available: true
    signal moved(int value)
    signal iconClicked()
    implicitWidth: 56
    implicitHeight: 248
    radius: width / 2
    color: pal.soft
    opacity: available ? 1 : 0.4
    clip: true
    property int shown: drag.pressed ? drag.live : value
    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: Math.max(s.width, s.height * s.shown / 100)
        radius: s.radius
        color: s.muted ? s.pal.dim : s.pal.accent
        Behavior on height { enabled: !drag.pressed; NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 12
        text: s.available ? s.shown : "–"
        color: s.shown > 88 ? s.pal.onAccent : s.pal.dim
        font.pixelSize: 12
        font.bold: drag.pressed
    }
    MouseArea {
        id: drag
        anchors.fill: parent
        enabled: s.available
        cursorShape: Qt.PointingHandCursor
        property int live: 0
        // Changes go out a few times a second while dragging, and once at the end.
        Timer { id: send; interval: 90; onTriggered: s.moved(drag.live) }
        function at(y) { return Math.max(0, Math.min(100, Math.round((1 - y / s.height) * 100))) }
        onPressed: mouse => { live = at(mouse.y); send.restart() }
        onPositionChanged: mouse => { if (pressed) { live = at(mouse.y); if (!send.running) send.start() } }
        onReleased: { send.stop(); s.moved(live) }
        onWheel: wheel => s.moved(Math.max(0, Math.min(100, s.value + (wheel.angleDelta.y > 0 ? 5 : -5))))
    }
    Glyph {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 16
        name: s.icon
        tint: s.shown > 8 && !s.muted ? s.pal.onAccent : s.pal.text
        MouseArea { anchors.fill: parent; anchors.margins: -8; onClicked: s.iconClicked(); cursorShape: Qt.PointingHandCursor }
    }
}
