// Super+Tab: blurred wallpaper, workspaces along the top (x to close, + to add), a window
// search, and every window on the current workspace as a card (app icon bottom-left, close
// button top-right). Minimised windows on the right.
// Drag a window card onto a workspace (or onto +) to move it there.
//
// OverviewView is the whole page; OverviewWindow is just the layer surface that shows it
// (so the view can also be driven offscreen in tests).
#include "apps.hpp"
#include "novaipc.hpp"
#include "windows.hpp"

namespace nova {

using namespace ui;

// rows that wrap, centred (window cards)
class Flow : public Widget {
public:
    double spacing = 48;
    Size sizeHint(double aw, double) override {
        double x = 0, y = 0, rowH = 0, maxW = 0;
        for (auto &c : children_) {
            if (!c->visible) continue;
            Size s = c->hint(aw, kInf);
            if (x > 0 && x + s.w > aw) { y += rowH + spacing; x = 0; rowH = 0; }
            x += s.w + spacing;
            maxW = std::max(maxW, x - spacing);
            rowH = std::max(rowH, s.h);
        }
        return {std::min(aw, maxW), y + rowH};
    }
    void arrange() override {
        std::vector<std::vector<std::pair<Widget *, Size>>> rows(1);
        double x = 0;
        for (auto &c : children_) {
            if (!c->visible) continue;
            Size s = c->hint(geom.w, kInf);
            if (x > 0 && x + s.w > geom.w) { rows.emplace_back(); x = 0; }
            rows.back().push_back({c.get(), s});
            x += s.w + spacing;
        }
        double total = 0;
        std::vector<double> heights;
        for (auto &r : rows) {
            double h = 0;
            for (auto &[w, s] : r) h = std::max(h, s.h);
            heights.push_back(h);
            total += h + spacing;
        }
        total -= spacing;
        double y = geom.y + std::max(0.0, (geom.h - total) / 2);
        for (size_t i = 0; i < rows.size(); i++) {
            double rw = -spacing;
            for (auto &[w, s] : rows[i]) rw += s.w + spacing;
            double xx = geom.x + (geom.w - rw) / 2;
            for (auto &[w, s] : rows[i]) { w->setGeometry({xx, y, s.w, s.h}); xx += s.w + spacing; }
            y += heights[i] + spacing;
        }
    }
};

static int wsOf(const json &w) {
    if (w.contains("index") && w["index"].is_number()) return w["index"].get<int>();
    return w.value("workspace", 1);
}
// window ids are strings from the compositor ("0x55d0…"); be lenient
static std::string idOf(const json &w) {
    auto it = w.find("id");
    if (it == w.end()) return "";
    if (it->is_string()) return it->get<std::string>();
    if (it->is_number()) return std::to_string(it->get<long long>());
    return "";
}
static std::string str(const json &w, const char *k) {
    auto it = w.find(k);
    return it != w.end() && it->is_string() ? it->get<std::string>() : std::string();
}
static double num(const json &w, const char *k) {
    auto it = w.find(k);
    return it != w.end() && it->is_number() ? it->get<double>() : 0.0;
}
static bool flag(const json &w, const char *k) {
    auto it = w.find(k);
    return it != w.end() && it->is_boolean() && it->get<bool>();
}
static std::string iconFor(const std::string &app) {
    const App *a = Apps::get().lookup(app);
    return a && !a->icon.empty() ? a->icon : app;
}

// A workspace thumbnail: the wallpaper with the workspace's windows drawn to scale.
class MiniWs : public Widget {
public:
    std::shared_ptr<Image> wallpaper;
    Size screen{1920, 1080};
    Point origin;                                  // the output's top-left in layout coordinates
    struct Win { Rect r; bool focused; };
    std::vector<Win> wins;
    bool active = false, target = false;
    Size sizeHint(double, double) override { return {fixedW, fixedH}; }
    Rect mapped(const Rect &r) const {
        double sx = geom.w / std::max(1.0, screen.w), sy = geom.h / std::max(1.0, screen.h);
        Rect m{geom.x + (r.x - origin.x) * sx, geom.y + (r.y - origin.y) * sy, r.w * sx, r.h * sy};
        // keep it inside the thumbnail even when the numbers are odd
        m.w = std::clamp(m.w, 6.0, geom.w);
        m.h = std::clamp(m.h, 6.0, geom.h);
        m.x = std::clamp(m.x, geom.x, geom.right() - m.w);
        m.y = std::clamp(m.y, geom.y, geom.bottom() - m.h);
        return m;
    }
    void arrange() override {
        // children are the app icons, one per window, centred on the window
        for (size_t i = 0; i < children_.size() && i < wins.size(); i++) {
            Rect m = mapped(wins[i].r);
            double s = std::min({22.0, m.w - 4, m.h - 4});
            children_[i]->visible = s >= 10;
            children_[i]->setGeometry({m.x + (m.w - s) / 2, m.y + (m.h - s) / 2, std::max(0.0, s), std::max(0.0, s)});
        }
    }
    void paint(Painter &p) override {
        const Theme &t = theme();
        p.save();
        p.clip(geom, 12);
        p.fill(geom, t.surface);
        if (wallpaper && wallpaper->valid()) p.image(*wallpaper, geom, 12, true, 0.85);
        for (auto &w : wins) {
            Rect m = mapped(w.r);
            p.fill(m, Color{0.08, 0.075, 0.105, 0.88}, 4);
            p.stroke(m, w.focused ? t.accent : Color{1, 1, 1, 0.22}, 1, 4);
        }
        if (target) p.fill(geom, Color{t.accent.r, t.accent.g, t.accent.b, 0.22});
        p.restore();
        Color b = target ? t.accentBright : active ? t.accent : Color{1, 1, 1, 0.12};
        p.stroke(geom.inset(0.5), b, target || active ? 2.5 : 1, 12);
    }
};

// Paints the card being dragged under the pointer (last child of the page, takes no input)
class DragLayer : public Widget {
public:
    bool on = false;
    Point at;
    std::string icon, title;
    void paint(Painter &p) override {
        if (!on) return;
        const Theme &t = theme();
        Rect r{at.x - 80, at.y - 52, 160, 104};
        p.shadow(r, 14, 24, 8, Color{0, 0, 0, 0.45});
        p.fill(r, Color{0.08, 0.075, 0.105, 0.95}, 14);
        p.stroke(r, t.accent, 2, 14);
    }
};

class OverviewView;

// A window card that can be clicked (focus) or dragged (move to another workspace)
class WinCard : public Button {
public:
    WinCard(OverviewView *v, std::string id) : Button(Dir::Column, 0), view(v), id(std::move(id)) {}
    OverviewView *view;
    std::string id, icon, title;
    bool down = false, dragging = false;
    Point start;
    bool pointerPress(Point p, int button) override;
    void pointerMove(Point p) override;
    void pointerRelease(Point p, int button) override;
};

class OverviewView : public Stack {
public:
    OverviewView(std::string output, Size scr, Point origin) : output_(std::move(output)), scr_(scr), origin_(origin) {
        interactive = true;
        onClick = [] { shell().close(); };
        bgImg_ = blurredWallpaper(scr);
        wp_ = wallpaperImage(scr);
    }
    std::function<void()> requestReload;   // ask the compositor for the window list again

    void setWindows(json w) {
        windows_ = w.is_array() ? std::move(w) : json::array();
        conns_.later([this] { build(); });
    }

    void paint(Painter &p) override {
        p.fill(geom, Color{0.05, 0.05, 0.07, 1});
        if (bgImg_ && bgImg_->valid()) p.image(*bgImg_, geom);
        p.fill(geom, Color{0, 0, 0, 0.28});
    }

    // ---- drag & drop ----
    void dragMove(WinCard *c, Point p) {
        drag_->on = true;
        drag_->at = p;
        drag_->icon = c->icon;
        drag_->title = c->title;
        int t = targetAt(p);
        if (t != target_) {
            target_ = t;
            for (auto &[i, m] : thumbs_) m->target = i == t;
            if (add_) add_->active = t == addIndex_;
        }
        // the dragged icon follows the pointer
        dragIcon_->iconName = c->icon;
        dragIcon_->visible = true;
        dragIcon_->setGeometry({p.x - 28, p.y - 28, 56, 56});
        update();
    }
    void dragDrop(WinCard *c) {
        int t = target_;
        std::string id = c->id;
        endDrag();
        if (t <= 0 || id.empty()) return;
        ipc().dispatch("window-to-workspace " + id + " " + std::to_string(base_ + t - 1));
        reloadSoon();
    }
    void endDrag() {
        drag_->on = false;
        dragIcon_->visible = false;
        target_ = 0;
        for (auto &[i, m] : thumbs_) m->target = false;
        if (add_) add_->active = false;
        update();
    }

private:
    std::string output_;
    Size scr_;
    Point origin_;
    std::shared_ptr<Image> bgImg_, wp_;
    json windows_ = json::array();
    Connections conns_;
    std::string query_;
    int base_ = 1, target_ = 0, addIndex_ = 0;
    std::vector<std::pair<int, MiniWs *>> thumbs_;
    Button *add_ = nullptr;
    DragLayer *drag_ = nullptr;
    AppIconW *dragIcon_ = nullptr;
    TextInput *search_ = nullptr;

    void reloadSoon() {
        conns_.after(150, [this] { if (requestReload) requestReload(); });
    }
    int targetAt(Point p) const {
        for (auto &[i, m] : thumbs_) if (m->geom.inset(-8).contains(p)) return i;
        if (add_ && add_->geom.inset(-8).contains(p)) return addIndex_;
        return 0;
    }

    void build() {
        const Theme &t = theme();
        if (search_) query_ = search_->text();
        clear();
        thumbs_.clear();
        add_ = nullptr;
        search_ = nullptr;
        target_ = 0;

        OutputWs ws = ipc().wsFor(output_);
        base_ = ws.base;
        json mine = json::array(), wins = json::array(), minimized = json::array();
        for (auto &w : windows_) {
            if (!w.is_object()) continue;
            std::string o = str(w, "output");
            if (o.empty() || o == output_) mine.push_back(w);
        }
        std::string q = lower(query_);
        for (auto &w : q.empty() ? mine : windows_) {
            if (!w.is_object() || flag(w, "minimized")) continue;
            std::string hay = lower(str(w, "title") + " " + str(w, "app_id"));
            if (q.empty() ? wsOf(w) == ws.active : hay.find(q) != std::string::npos) wins.push_back(w);
        }
        for (auto &w : mine) if (flag(w, "minimized")) minimized.push_back(w);
        int n = std::max(1, ws.active);
        for (int o : ws.occupied) n = std::max(n, o);
        for (auto &w : mine) n = std::max(n, wsOf(w));
        n = std::clamp(n, 1, 9);

        auto *page = add<Box>(Dir::Column, 10);
        page->crossAlign = Align::Center;   // workspace strip and search centred; the body fills
        page->pt = 34;
        page->pb = 30;

        // ---- workspaces ----
        auto *wsRow = row(page, 16);
        wsRow->fill = false;
        wsRow->alignSelf = Align::Center;
        wsRow->crossAlign = Align::Start;
        // fit the strip on narrow screens
        double thumbW = std::clamp((scr_.w - 120 - 16.0 * n - 80) / std::max(1, n), 120.0, 220.0);
        double thumbH = thumbW * scr_.h / std::max(1.0, scr_.w);
        for (int i = 1; i <= n; i++) {
            auto *c = col(wsRow, 8);
            c->crossAlign = Align::Center;
            auto *thumb = c->add<Stack>();
            thumb->fixedW = thumbW;
            thumb->fixedH = thumbH;
            auto *frame = thumb->add<Button>(Dir::Column, 0);
            frame->bg = Color{0, 0, 0, 0};
            frame->hoverBg = Color{1, 1, 1, 0.04};
            frame->radius = 12;
            frame->onClick = [i] { ipc().dispatch("workspace " + std::to_string(i)); };
            auto *mini = frame->add<MiniWs>();
            mini->fixedW = thumbW;
            mini->fixedH = thumbH;
            mini->grow = 1;
            mini->wallpaper = wp_;
            mini->screen = scr_;
            mini->origin = origin_;
            mini->active = i == ws.active;
            int count = 0;
            for (auto &w : mine) {
                if (wsOf(w) != i || flag(w, "minimized")) continue;
                count++;
                mini->wins.push_back({{num(w, "x"), num(w, "y"), num(w, "w"), num(w, "h")}, flag(w, "focused")});
                mini->add<AppIconW>(iconFor(str(w, "app_id")), 22);
            }
            thumbs_.push_back({i, mini});
            if (n > 1) {
                auto *x = thumb->add<IconButton>("x", 22, 12);
                x->bg = t.danger;
                x->hoverBg = t.danger.lighter(0.1);
                x->icon->role = Role::Custom;
                x->icon->color = Color{1, 1, 1, 1};
                x->fill = false;
                x->alignSelf = Align::End;
                x->mt = 6;
                x->mr = 6;
                int base = ws.base;
                x->onClick = [this, i, base] {
                    ipc().dispatch("close-workspace " + std::to_string(base + i - 1));
                    reloadSoon();
                };
            }
            std::string label = "Workspace " + std::to_string(i);
            if (count) label += "  ·  " + std::to_string(count);
            auto *lbl = c->add<Label>(label, 13, i == ws.active ? Weight::DemiBold : Weight::Normal,
                                      i == ws.active ? Role::AccentBright : Role::Text2);
            lbl->fill = false;
        }
        if (n < 9) {
            addIndex_ = n + 1;
            add_ = wsRow->add<Button>(Dir::Row, 0);
            add_->fixedW = 64;
            add_->fixedH = thumbH;
            add_->radius = 14;
            add_->border = t.accentLine;
            add_->borderWidth = 1.5;
            add_->activeBg = t.accentSoft;
            add_->activeBorder = t.accentBright;
            add_->justify = Justify::Center;
            add_->add<IconW>("plus", 20, Role::AccentBright)->fill = false;
            add_->onClick = [n] { ipc().dispatch("workspace " + std::to_string(n + 1)); };
        } else addIndex_ = 0;

        // ---- search ----
        auto *sb = page->add<Card>(Dir::Row, 12);
        sb->fill = false;
        sb->alignSelf = Align::Center;
        sb->fixedW = std::min(440.0, scr_.w - 80);
        sb->fixedH = 46;
        sb->radius = 23;
        sb->padding(18, 0);
        sb->shadow = false;
        search_ = sb->add<TextInput>();
        search_->framed = false;
        search_->leadingIcon = "search";
        search_->placeholder = "Search windows";
        search_->fontSize = 15;
        search_->grow = 1;
        search_->setText(query_);
        search_->onChanged = [this](const std::string &s) { query_ = s; conns_.later([this] { build(); }); };
        std::string first = wins.empty() ? "" : idOf(wins[0]);
        search_->onSubmit = [first](const std::string &) {
            if (first.empty()) return;
            ipc().dispatch("focus-window " + first);
            shell().close();
        };

        // ---- windows + minimised ----
        auto *body = row(page, 40);
        body->grow = 1;
        body->crossAlign = Align::Start;
        body->mt = 30;
        double side = scr_.w < 1400 ? 24 : 150;
        body->pl = side;
        body->pr = scr_.w < 1400 ? 24 : 52;
        auto *stage = body->add<Box>(Dir::Column);
        stage->grow = 1;
        stage->radius = 28;
        stage->bg = Color{1, 1, 1, 0.035};
        stage->border = Color{1, 1, 1, 0.06};
        stage->padding(scr_.w < 1400 ? 20 : 40);
        stage->justify = Justify::Center;
        if (wins.empty()) {
            auto *l = stage->add<Label>(query_.empty() ? "No windows on this workspace" : "No matching windows", 14, Weight::Normal, Role::Text3);
            l->hAlign = Align::Center;
        } else {
            auto *flow = stage->add<Flow>();
            double cw = scr_.w < 1400 ? 240 : 320, ch = cw * 210 / 320;
            flow->spacing = scr_.w < 1400 ? 28 : 48;
            for (auto &w : wins) {
                std::string app = str(w, "app_id"), title = str(w, "title"), id = idOf(w);
                std::string icon = iconFor(app);
                auto *wc = flow->add<Box>(Dir::Column, 14);
                wc->fixedW = cw;
                auto *cardS = wc->add<Stack>();
                cardS->fixedH = ch;
                auto *card = cardS->add<WinCard>(this, id);
                card->icon = icon;
                card->title = title.empty() ? app : title;
                card->radius = 14;
                card->bg = Color{0.08, 0.075, 0.105, 0.95};
                card->hoverBg = card->bg;
                card->border = flag(w, "focused") ? t.accentLine : Color{1, 1, 1, 0.08};
                card->activeBorder = t.accent;
                card->justify = Justify::Center;
                card->crossAlign = Align::Center;
                card->cursor = Cursor::Grab;
                auto *big = card->add<AppIconW>(icon, cw < 300 ? 56 : 72);
                big->fill = false;
                big->alignSelf = Align::Center;
                card->onHover = [card](bool h) { card->borderWidth = h ? 2 : 1; card->update(); };
                card->onClick = [id] { ipc().dispatch("focus-window " + id); shell().close(); };
                auto *x = cardS->add<IconButton>("x", 28, 14);
                x->bg = t.danger;
                x->hoverBg = t.danger.lighter(0.1);
                x->icon->role = Role::Custom;
                x->icon->color = Color{1, 1, 1, 1};
                x->fill = false;
                x->alignSelf = Align::End;
                x->mt = 6;
                x->mr = 6;
                x->onClick = [this, id] {
                    ipc().dispatch("close-window " + id);
                    reloadSoon();
                };
                auto *badge = cardS->add<AppIconW>(icon, 40);
                badge->fill = false;
                badge->alignSelf = Align::Start;
                badge->ml = 8;
                badge->mt = ch - 40 - 8;
                badge->fixedW = 40;
                auto *tl = wc->add<Label>(title.empty() ? app : title, 13, Weight::Normal, Role::Text2);
                tl->hAlign = Align::Center;
            }
        }
        if (!minimized.empty()) {
            auto *mc = col(body, 12);
            mc->fixedW = 190;
            auto *h = mc->add<Label>("MINIMIZED", 12, Weight::DemiBold, Role::Text3);
            h->font.letterSpacing = 0.7;
            for (auto &w : minimized) {
                std::string app = str(w, "app_id"), id = idOf(w);
                auto *b = mc->add<Button>(Dir::Column, 0);
                b->fixedH = 118;
                b->radius = 14;
                b->bg = t.surface;
                b->justify = Justify::Center;
                b->crossAlign = Align::Center;
                auto *ic = b->add<AppIconW>(iconFor(app), 48);
                ic->fill = false;
                ic->alignSelf = Align::Center;
                b->onClick = [id] { ipc().dispatch("focus-window " + id); shell().close(); };
                mc->add<Label>(str(w, "title"), 12, Weight::Normal, Role::Text3);
            }
        }

        // drag feedback on top of everything
        auto *dl = add<Stack>();
        dl->manual = true;
        drag_ = dl->add<DragLayer>();
        dragIcon_ = dl->add<AppIconW>("", 56);
        dragIcon_->visible = false;
        if (Window *win = window()) win->setFocus(search_);
        relayout();
    }
    friend class WinCard;
};

bool WinCard::pointerPress(Point p, int button) {
    if (button == 1) { down = true; dragging = false; start = p; }
    return Button::pointerPress(p, button);
}
void WinCard::pointerMove(Point p) {
    if (!down) return;
    if (!dragging && std::hypot(p.x - start.x, p.y - start.y) > 8) dragging = true;
    if (dragging) view->dragMove(this, p);
}
void WinCard::pointerRelease(Point p, int button) {
    bool wasDrag = dragging && button == 1;
    if (button == 1) { down = false; dragging = false; }
    if (wasDrag) {
        pressed = false;
        update();
        // the drop may rebuild the overview (and delete this card): do it last, after a turn
        OverviewView *v = view;
        v->dragDrop(this);
        return;
    }
    Button::pointerRelease(p, button);
}

std::unique_ptr<Widget> makeOverviewView(const std::string &output, Size scr, Point origin, const json &windows) {
    auto v = std::make_unique<OverviewView>(output, scr, origin);
    v->setWindows(windows);
    return v;
}

OverviewWindow::OverviewWindow(Screen *s) : LayerWindow("nova-overview", Layer::Overlay, s->output), screen(s) {
    setAnchors(AnchorTop | AnchorBottom | AnchorLeft | AnchorRight);
    setMargins(0, 0, (int)theme().panelHeight, 0);
    setExclusiveZone(-1);
    setKeyboard(KeyboardMode::Exclusive);
    wantBlur = false;
    onKey = [](const KeyEvent &e) {
        if (e.pressed && e.sym == key::Escape) { shell().close(); return true; }
        return false;
    };
    Size scr = s->output ? s->output->logical() : Size{1920, 1080};
    Point origin = s->output ? Point{(double)s->output->x, (double)s->output->y} : Point{};
    auto *v = setRoot<OverviewView>(s->name(), scr, origin);
    v->requestReload = [this] { reload(); };
    conns_.on(ipc().workspacesChanged, [this] { reload(); });
    show();
    reload();
}
OverviewWindow::~OverviewWindow() = default;

void OverviewWindow::reload() {
    ipc().request("get windows", [this, alive = conns_.token()](const json &r) {
        if (!*alive) return;
        json w = r.is_object() && r.contains("windows") ? r["windows"] : json::array();
        if (auto *v = dynamic_cast<OverviewView *>(root())) v->setWindows(std::move(w));
    });
}

}  // namespace nova
