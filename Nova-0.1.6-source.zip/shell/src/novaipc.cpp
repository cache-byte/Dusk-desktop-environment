#include "novaipc.hpp"
#include "ui/sys.hpp"

#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

namespace nova {

NovaIpc &NovaIpc::get() {
    static NovaIpc n;
    return n;
}

static std::string socketPath() {
    if (const char *s = getenv("NOVA_SOCK"); s && *s) return s;
    const char *wd = getenv("WAYLAND_DISPLAY");
    return ui::runtimeDir() + "/nova-" + (wd && *wd ? wd : "wayland-0") + ".sock";
}

void NovaIpc::connect() {
    if (fd_ >= 0) return;
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    std::string p = socketPath();
    strncpy(a.sun_path, p.c_str(), sizeof a.sun_path - 1);
    if (::connect(fd, (sockaddr *)&a, sizeof a) < 0 && errno != EINPROGRESS) {
        close(fd);
        lost();
        return;
    }
    fd_ = fd;
    watch_ = ui::Loop::get().addFd(fd_, POLLIN, [this](int, short ev) {
        char tmp[8192];
        for (;;) {
            ssize_t n = read(fd_, tmp, sizeof tmp);
            if (n > 0) { buf_.append(tmp, n); continue; }
            if (n < 0 && (errno == EAGAIN || errno == EINTR)) break;
            lost();
            return;
        }
        size_t pos;
        while ((pos = buf_.find('\n')) != std::string::npos) {
            std::string line = buf_.substr(0, pos);
            buf_.erase(0, pos + 1);
            handle(line);
        }
        (void)ev;
    });
    const char *sub = "subscribe\n";
    if (::send(fd_, sub, strlen(sub), MSG_NOSIGNAL) < 0) lost();
}

void NovaIpc::lost() {
    if (watch_) ui::Loop::get().removeFd(watch_);
    watch_ = 0;
    if (fd_ >= 0) close(fd_);
    fd_ = -1;
    buf_.clear();
    if (!reconnectTimer_ || !ui::Loop::get().timerActive(reconnectTimer_))
        reconnectTimer_ = ui::Loop::get().addTimer(1000, [this] { connect(); });
}

void NovaIpc::handle(const std::string &line) {
    try { handleEvent(line); }
    catch (const std::exception &ex) { fprintf(stderr, "nova-shell: bad event from the compositor (%s): %s\n", ex.what(), line.c_str()); }
}

void NovaIpc::handleEvent(const std::string &line) {
    json e;
    try { e = json::parse(line); } catch (...) { return; }
    std::string ev = e.value("event", "");
    if (ev == "workspaces") {
        activeWorkspace = e.value("active", 1);
        occupied = e.value("occupied", std::vector<int>{});
        outputs.clear();
        if (e.contains("outputs"))
            for (auto &o : e["outputs"]) {
                OutputWs w;
                w.name = o.value("name", "");
                w.active = o.value("active", 1);
                w.base = o.value("base", 1);
                w.occupied = o.value("occupied", std::vector<int>{});
                outputs[w.name] = w;
            }
        workspacesChanged.emit();
    } else if (ev == "leds") {
        bool c = e.value("caps", false), n = e.value("num", false);
        if (ledsKnown && c != capsLock) ledToggled.emit("caps", c);
        if (ledsKnown && n != numLock) ledToggled.emit("num", n);
        capsLock = c;
        numLock = n;
        ledsKnown = true;
        ledsChanged.emit();
    } else if (ev == "output") {
        activeOutput = e.value("name", "");
        activeOutputChanged.emit(activeOutput);
    } else if (ev == "fullscreen") {
        fullscreen = e.value("active", false);
        fullscreenChanged.emit(fullscreen);
    } else if (ev == "shell") {
        shellAction.emit(e.value("action", ""));
    } else if (ev == "press") {
        pressed.emit(e.value("layer", ""));
    } else if (ev == "lock") {
        lockRequested.emit();
    } else if (ev == "reload") {
        Config::get().load();
        Config::get().changed.emit();
    }
}

OutputWs NovaIpc::wsFor(const std::string &output) const {
    if (auto it = outputs.find(output); it != outputs.end()) return it->second;
    OutputWs w;
    w.name = output;
    w.active = activeWorkspace;
    w.occupied = occupied;
    return w;
}

void NovaIpc::dispatch(const std::string &action) {
    // a short-lived connection keeps replies off the event stream
    request("dispatch " + action, nullptr);
}

void NovaIpc::request(const std::string &line, std::function<void(const json &)> reply) {
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    std::string p = socketPath();
    strncpy(a.sun_path, p.c_str(), sizeof a.sun_path - 1);
    if (::connect(fd, (sockaddr *)&a, sizeof a) < 0) {
        close(fd);
        if (reply) reply(json());
        return;
    }
    std::string msg = line + "\n";
    if (::send(fd, msg.data(), msg.size(), MSG_NOSIGNAL) < 0) {
        close(fd);
        if (reply) reply(json());
        return;
    }
    fcntl(fd, F_SETFL, O_NONBLOCK);
    auto buf = std::make_shared<std::string>();
    auto id = std::make_shared<int>(0);
    *id = ui::Loop::get().addFd(fd, POLLIN, [fd, buf, id, reply](int, short) {
        char tmp[16384];
        ssize_t n;
        while ((n = read(fd, tmp, sizeof tmp)) > 0) buf->append(tmp, n);
        if (n < 0 && errno == EAGAIN && buf->find('\n') == std::string::npos) return;
        ui::Loop::get().removeFd(*id);
        close(fd);
        if (!reply) return;
        json j;
        try { j = json::parse(buf->substr(0, buf->find('\n'))); } catch (...) {}
        reply(j);
    });
}

}  // namespace nova
