#include <chrono>
#include "shell.hpp"
#include "apps.hpp"
#include "novaipc.hpp"
#include "panel.hpp"
#include "services.hpp"
#include "windows.hpp"

#include <cairo.h>
#include <cmath>

namespace nova {

using namespace ui;

// ================================================================== Shell ==
Shell &Shell::get() { static Shell s; return s; }

Shell::Shell() {
    countTimer_.setup(1000, [this] {
        countdown--;
        if (countdown <= 0) { countdown = 0; countTimer_.stop(); }
        changed.emit();
    }, true);
}

bool Shell::isPopoutScreen(const std::string &output) const {
    if (!popoutOutput.empty()) {
        for (auto &s : screens) if (s->name() == popoutOutput) return output == popoutOutput;
    }
    return !screens.empty() && screens[0]->name() == output;
}

Screen *Shell::screenFor(const std::string &output) {
    for (auto &s : screens) if (s->name() == output) return s.get();
    return screens.empty() ? nullptr : screens[0].get();
}

void Shell::toggle(const std::string &name, const std::string &output) {
    if (!output.empty()) popoutOutput = output;
    if (name == "overview") {
        overview = !overview;
        popout.clear();
        ccEditing = false;
        changed.emit();
        return;
    }
    overview = false;
    popout = popout == name ? "" : name;
    if (popout != "controlcentre") ccEditing = false;
    changed.emit();
}

void Shell::close() {
    if (popout.empty() && !overview && !ccEditing) return;
    popout.clear();
    overview = false;
    ccEditing = false;
    changed.emit();
}

void Shell::action(const std::string &a) {
    // open on the monitor under the pointer
    if (!ipc().activeOutput.empty()) popoutOutput = ipc().activeOutput;
    if (a == "close") close();
    else if (a == "overview-open") { if (!overview) toggle("overview"); }
    else if (a == "lock") LockScreen::get().lock();
    // Print while a pop-up is open: capture the screen as it is, pop-up included,
    // instead of swapping the pop-up for the capture bar
    else if (a == "capture" && !popout.empty() && popout != "capture") spawn({"nova-record", "shot", "screen"});
    else if (a == "replay-save") Replay::get().save();
    else toggle(a);
}

void Shell::captureCountdown(int s) {
    countdown = s;
    if (s > 0) countTimer_.start();
    else countTimer_.stop();
    changed.emit();
}

bool indicatorOnScreen(const std::string &output) {
    if (cfg().s("osdScreen", "active") == "all") return true;
    const std::string &a = ipc().activeOutput;
    if (!a.empty() && shell().screenFor(a) && shell().screenFor(a)->name() == a) return a == output;
    return !shell().screens.empty() && shell().screens[0]->name() == output;
}

// ============================================================== placement ==
//   pos 0 1 2 / 3 4 5 / 6 7 8  — row 0 = top edge, row 2 = bottom edge (above the panel)
Placement placementFor(const json &o, double panelHeight, int edge) {
    Placement p;
    int pos = o.value("pos", 8);
    int r = pos / 3, c = pos % 3;
    int dx = (int)o.value("dx", 0.0), dy = (int)o.value("dy", 0.0);
    if (r == 0) p.anchors |= AnchorTop;
    if (r == 2) p.anchors |= AnchorBottom;
    if (c == 0) p.anchors |= AnchorLeft;
    if (c == 2) p.anchors |= AnchorRight;
    p.mt = edge + std::max(0, dy);
    p.mb = edge + (int)panelHeight + std::max(0, -dy);
    p.ml = edge + std::max(0, dx);
    p.mr = edge + std::max(0, -dx);
    // centred rows / columns: a nudge moves the card off the centre line
    if (r == 1) { p.mt = std::max(0, dy) * 2; p.mb = std::max(0, -dy) * 2 + (int)panelHeight; }
    if (c == 1) { p.ml = std::max(0, dx) * 2; p.mr = std::max(0, -dx) * 2; }
    p.vertical = o.value("dir", std::string("up")) == "up";
    return p;
}

// ================================================================= Screen ==
Screen::Screen(Output *o) : output(o) {
    wallpaper = std::make_unique<Wallpaper>(this);
    panel = std::make_unique<Panel>(this);
    popout = std::make_unique<PopoutWindow>(this);
    osd = std::make_unique<Osd>(this);
    sync();
}
Screen::~Screen() = default;

// Rounded screen corners: four tiny click-through windows above everything, black outside
// a quarter circle.
class CornerWindow : public LayerWindow {
public:
    CornerWindow(Output *o, uint32_t anchors, int r) : LayerWindow("nova-corner", Layer::Overlay, o), anchors_(anchors), r_(r) {
        wantBlur = false;
        setAnchors(anchors);
        setExclusiveZone(-1);
        setRequestedSize(r, r);
        setInputRegion({});
        auto *w = setRoot<Widget>();
        (void)w;
    }
    void paintCorner(cairo_t *cr) {
        double r = r_;
        // centre of the circle is the corner of the screen's inner rounded rectangle
        double cx = (anchors_ & AnchorLeft) ? r : 0, cy = (anchors_ & AnchorTop) ? r : 0;
        cairo_save(cr);
        cairo_rectangle(cr, 0, 0, r, r);
        cairo_clip(cr);
        cairo_set_source_rgba(cr, 0, 0, 0, 1);
        cairo_rectangle(cr, 0, 0, r, r);
        cairo_new_sub_path(cr);
        cairo_arc(cr, cx, cy, r, 0, 2 * M_PI);
        cairo_set_fill_rule(cr, CAIRO_FILL_RULE_EVEN_ODD);
        cairo_fill(cr);
        cairo_restore(cr);
    }
    uint32_t anchors_;
    int r_;
};
class CornerPainter : public Widget {
public:
    CornerWindow *win = nullptr;
    void paint(Painter &p) override { win->paintCorner(p.cr()); }
};

// Hot corner: a tiny invisible window in the top-left corner that runs an action on entry.
class HotCornerWindow : public LayerWindow {
public:
    HotCornerWindow(Output *o, std::string screen) : LayerWindow("nova-hotcorner", Layer::Overlay, o), screen_(std::move(screen)) {
        wantBlur = false;
        setAnchors(AnchorTop | AnchorLeft);
        setExclusiveZone(-1);
        setRequestedSize(2, 2);
        setRoot<Widget>();
        pointerInside.connect([this](bool in) {
            if (!in) return;
            auto now = std::chrono::steady_clock::now();
            if (now - last_ < std::chrono::milliseconds(600)) return;
            last_ = now;
            std::string a = cfg().s("hotCorner", "overview");
            if (a.empty() || a == "none") return;
            std::string scr = screen_;
            ui::Loop::get().defer([a, scr] { shell().toggle(a, scr); });
        });
    }
private:
    std::string screen_;
    std::chrono::steady_clock::time_point last_{};
};

void Screen::syncHotCorner() {
    std::string a = cfg().s("hotCorner", "overview");
    bool want = !a.empty() && a != "none";
    if (want && !hotCorner) {
        hotCorner = std::make_unique<HotCornerWindow>(output, name());
        hotCorner->show();
    } else if (!want && hotCorner) hotCorner.reset();
}

void Screen::syncCorners() {
    int r = cfg().i("screenCorners", 12);
    if (r == (corners.empty() ? 0 : ((CornerWindow *)corners[0].get())->r_)) return;
    corners.clear();
    if (r <= 0) return;
    for (uint32_t a : {AnchorTop | AnchorLeft, AnchorTop | AnchorRight, AnchorBottom | AnchorLeft, AnchorBottom | AnchorRight}) {
        auto w = std::make_unique<CornerWindow>(output, a, r);
        auto *cp = w->setRoot<CornerPainter>();
        cp->win = w.get();
        w->show();
        corners.push_back(std::move(w));
    }
}

void Screen::sync() {
    syncCorners();
    syncHotCorner();
    popout->sync();
    auto &sh = shell();
    // overview
    bool ov = sh.overview && sh.isPopoutScreen(name());
    if (ov && !overview) overview = std::make_unique<OverviewWindow>(this);
    else if (!ov && overview) overview.reset();
    // notification toasts live as long as there is something to show
    if (!notifications) notifications = std::make_unique<NotificationsWindow>(this);
    notifications->sync();
    // desktop lyrics / visualizer
    bool wantLyrics = cfg().b("lyricsDesktop", false);
    if (wantLyrics && !lyrics) lyrics = std::make_unique<DesktopLyricsWindow>(this);
    else if (!wantLyrics && lyrics) lyrics.reset();
    auto places = cfg().j("vizPlaces");
    bool wantViz = places.is_array() && std::find(places.begin(), places.end(), "desktop") != places.end();
    if (wantViz && !visualizer) visualizer = std::make_unique<DesktopVisualizerWindow>(this);
    else if (!wantViz && visualizer) visualizer.reset();
}

// ============================================================== FitWindow ==
// The window is the card plus a margin on every side for its shadow; the card sits
// where the caller asks (layer margins are the card's, minus the shadow margin).
class FitFrame : public Box {
public:
    explicit FitFrame(double m) : Box(Dir::Column, 0) { padding(m); }
};

FitWindow::FitWindow(const std::string &ns, Layer layer, Output *out, double m) : LayerWindow(ns, layer, out), margin(m) {
    setRoot<FitFrame>(m);
    setExclusiveZone(-1);
    resized.connect([this](Size) { updateInput(); });
}

void FitWindow::fit(bool relayoutNow) {
    Widget *r = root();
    if (!r) return;
    bumpLayoutGeneration();
    Size out = targetOutput() ? targetOutput()->logical() : Size{1920, 1080};
    // never larger than the room left between the margins (keeps cards on screen at any scale)
    double m = margin;
    double availW = out.w - ((anchorsSet_ & AnchorLeft) ? std::max(0.0, pm_[3] - m) : 0) - ((anchorsSet_ & AnchorRight) ? std::max(0.0, pm_[1] - m) : 0);
    double availH = out.h - ((anchorsSet_ & AnchorTop) ? std::max(0.0, pm_[0] - m) : 0) - ((anchorsSet_ & AnchorBottom) ? std::max(0.0, pm_[2] - m) : 0);
    availW = std::max(availW, 50.0);
    availH = std::max(availH, 50.0);
    Size h = r->hint(availW, availH);
    int w = (int)std::ceil(std::min(h.w, availW)), hh = (int)std::ceil(std::min(h.h, availH));
    if (w != lastW_ || hh != lastH_) {
        lastW_ = w;
        lastH_ = hh;
        setRequestedSize(w, hh);
        if (relayoutNow && shown() && configured()) relayout();
    }
    updateInput();
}

void FitWindow::place(uint32_t anchors, int mt, int mr, int mb, int ml) {
    int m = (int)margin;
    anchorsSet_ = anchors;
    pm_[0] = mt; pm_[1] = mr; pm_[2] = mb; pm_[3] = ml;
    setAnchors(anchors);
    setMargins(std::max(0, mt - m), std::max(0, mr - m), std::max(0, mb - m), std::max(0, ml - m));
}

Rect FitWindow::cardRect() const {
    Size s = size();
    return {margin, margin, std::max(0.0, s.w - 2 * margin), std::max(0.0, s.h - 2 * margin)};
}

void FitWindow::updateInput() {
    if (clickThrough) setInputRegion({});
    else setInputRegion({cardRect()});
}

// ============================================================ PopoutWindow ==
PopoutWindow::PopoutWindow(Screen *s) : screen(s) {}
PopoutWindow::~PopoutWindow() = default;

void PopoutWindow::sync() {
    std::string want = shell().isPopoutScreen(screen->name()) ? shell().popout : "";
    if (want == which_) return;
    if (want.empty() || want == "traymenu") {
        if (want.empty()) closeAll();
        which_ = want;
        return;
    }
    open(want);
}

void PopoutWindow::closeAll() {
    card_.reset();
    which_.clear();
}

void PopoutWindow::open(const std::string &name) {
    std::unique_ptr<Widget> content;
    if (name == "launcher") content = makeLauncher(screen);
    else if (name == "controlcentre") content = makeControlCentre(screen);
    else if (name == "notifications") content = makeNotificationCentre(screen);
    else if (name == "clipboard") content = makeClipboard(screen);
    else if (name == "capture") content = makeCapture(screen);
    else if (name == "gameoverlay") content = makeGameOverlay(screen);
    else if (name == "nowplaying") content = makeNowPlaying(screen);
    if (!content) { closeAll(); shell().close(); return; }
    const Theme &t = theme();
    int g = (int)t.gap, ph = (int)t.panelHeight;
    if (name == "launcher") present(name, std::move(content), AnchorBottom | AnchorLeft, 0, 0, ph + g, g);
    else if (name == "controlcentre" || name == "notifications") present(name, std::move(content), AnchorBottom | AnchorRight, 0, g, ph + g, 0);
    else if (name == "clipboard") present(name, std::move(content), AnchorBottom | AnchorRight, 0, 330, ph + g, 0);
    else if (name == "capture") present(name, std::move(content), AnchorBottom, 0, 0, ph + 2 * g, 0);
    else if (name == "nowplaying") present(name, std::move(content), AnchorBottom | AnchorRight, 0, std::max(g, (int)shell().mediaRightGap), ph + 6, 0);
    else present(name, std::move(content), AnchorTop, 40, 0, 0, 0);
}

void PopoutWindow::openCustom(const std::string &name, std::unique_ptr<Widget> content, double x) {
    Size o = screen->output ? screen->output->logical() : Size{1920, 1080};
    Size h = content->hint(o.w, o.h);
    int left = (int)std::clamp(x - h.w / 2, theme().gap, o.w - h.w - theme().gap);
    present(name, std::move(content), AnchorBottom | AnchorLeft, 0, 0, (int)(theme().panelHeight + 6), left);
}

void PopoutWindow::present(const std::string &name, std::unique_ptr<Widget> content, uint32_t a, int mt, int mr, int mb, int ml) {
    which_ = name;
    card_ = std::make_unique<FitWindow>("nova-popout", Layer::Overlay, screen->output);
    bool typing = name == "launcher" || name == "clipboard" || name == "capture" || name == "gameoverlay";
    card_->setKeyboard(typing ? KeyboardMode::Exclusive : KeyboardMode::OnDemand);
    Widget *c = card_->root()->adopt(std::move(content));
    card_->place(a, mt, mr, mb, ml);
    card_->onKey = [](const KeyEvent &e) {
        if (e.sym == key::Escape && e.pressed) { shell().close(); return true; }
        return false;
    };
    // the card grows from its anchor
    c->opacity.set(0);
    c->ty.set((a & AnchorTop) ? -14 : 14);
    card_->fit();
    FitWindow *w = card_.get();
    Output *out = screen->output;
    card_->resized.connect([w, out, a, mt, mr, mb, ml](Size sz) {
        if (!out) return;
        Size o = out->logical();
        double m = w->margin;
        double x = (a & AnchorLeft) ? ml - m : (a & AnchorRight) ? o.w - sz.w - (mr - m) : (o.w - sz.w) / 2;
        double y = (a & AnchorTop) ? mt - m : (a & AnchorBottom) ? o.h - sz.h - (mb - m) : (o.h - sz.h) / 2;
        setBackdrop(*w, o, {x, y, sz.w, sz.h});
    });
    card_->show();
    c->startAnim(c->opacity, 1, theme().ms(160));
    c->startAnim(c->ty, 0, theme().ms(220));
    // content that changes size (search results, edit mode) is re-fitted on every layout pass
}

}  // namespace nova
