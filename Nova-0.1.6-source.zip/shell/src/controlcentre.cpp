// Control centre. Tiles live on a 6 × 10 grid stored in settings.json (ccLayout).
// Pencil -> edit mode: drag to move (snaps to cells), drag the corner to resize,
// the red badge removes, chips at the bottom add tiles.
#include "apps.hpp"
#include "services.hpp"
#include "windows.hpp"

#include <ctime>

namespace nova {

using namespace ui;

struct TileMeta { std::string icon, label; int minW, minH, maxW, maxH; };
static const std::vector<std::pair<std::string, TileMeta>> &catalog() {
    static const std::vector<std::pair<std::string, TileMeta>> c = {
        {"wifi", {"wifi", "Wi-Fi", 2, 1, 6, 1}}, {"bluetooth", {"bt", "Bluetooth", 2, 1, 6, 1}},
        {"brightness", {"sun", "Brightness", 1, 2, 6, 5}}, {"volume", {"volume", "Volume", 1, 2, 6, 5}},
        {"micvol", {"mic", "Microphone", 1, 2, 6, 5}}, {"dnd", {"moon", "Do not disturb", 1, 1, 3, 1}},
        {"nightlight", {"sunset", "Night light", 1, 1, 3, 1}}, {"airplane", {"plane", "Airplane", 1, 1, 3, 1}},
        {"darkmode", {"contrast", "Dark mode", 1, 1, 3, 1}}, {"mic", {"mic", "Mic mute", 1, 1, 3, 1}},
        {"screenshot", {"shot", "Screenshot", 1, 1, 3, 1}}, {"caffeine", {"coffee", "Keep awake", 1, 1, 3, 1}},
        {"record", {"record", "Screen record", 1, 1, 3, 1}}, {"hotspot", {"hotspot", "Hotspot", 1, 1, 3, 1}},
        {"kbl", {"kbl", "Keyboard light", 1, 1, 3, 1}}, {"power", {"gauge", "Power mode", 4, 1, 6, 1}}};
    return c;
}
static TileMeta metaFor(const std::string &id) {
    for (auto &[k, m] : catalog()) if (k == id) return m;
    return {"square", id, 1, 1, 4, 4};
}

struct Tile { std::string id; int x = 0, y = 0, w = 1, h = 1; };

static bool nightOn = false;

static bool isOn(const std::string &id) {
    if (id == "wifi") return Net::get().wifiEnabled;
    if (id == "bluetooth") return Bluetooth::get().powered;
    if (id == "dnd") return cfg().b("dnd", false);
    if (id == "nightlight") return nightOn;
    if (id == "airplane") return Net::get().airplane || (!Net::get().wifiEnabled && !Bluetooth::get().powered);
    if (id == "darkmode") return cfg().s("mode", "dark") != "light";
    if (id == "mic") return !Audio::get().micMuted;
    if (id == "caffeine") return Idle::get().caffeine;
    if (id == "record") return Recorder::get().recording;
    if (id == "kbl") return Brightness::get().kbdLevel > 0;
    return false;
}
static std::string subtitle(const std::string &id) {
    if (id == "wifi") {
        auto &n = Net::get();
        return n.wired ? "Wired" : !n.ssid.empty() ? n.ssid : n.wifiEnabled ? "Not connected" : "Off";
    }
    if (id == "bluetooth") {
        auto &b = Bluetooth::get();
        return !b.powered ? "Off" : !b.connectedName.empty() ? b.connectedName : "On";
    }
    return "";
}
static void press(const std::string &id) {
    if (id == "wifi") Net::get().setWifi(!Net::get().wifiEnabled);
    else if (id == "bluetooth") Bluetooth::get().setPowered(!Bluetooth::get().powered);
    else if (id == "dnd") cfg().set("dnd", !cfg().b("dnd", false));
    else if (id == "nightlight") {
        nightOn = !nightOn;
        spawnShell(nightOn ? "pkill gammastep; gammastep -O 4200 >/dev/null 2>&1 &" : "pkill gammastep");
    } else if (id == "airplane") {
        bool on = !isOn("airplane");
        Net::get().setAirplane(on);
        Bluetooth::get().setPowered(!on);
    } else if (id == "darkmode") {
        std::string m = cfg().s("mode", "dark") == "light" ? "dark" : "light";
        cfg().set("mode", m);
        spawn({"nova-theme", m});
    } else if (id == "mic") Audio::get().toggleMic();
    else if (id == "screenshot") { shell().close(); spawnShell("sleep 0.3; nova-record shot edit"); }
    else if (id == "caffeine") Idle::get().setCaffeine(!Idle::get().caffeine);
    else if (id == "record") {
        bool rec = Recorder::get().recording;
        shell().close();
        spawnShell(rec ? "nova-record stop" : "sleep 0.3; nova-record start screen");
    } else if (id == "hotspot") spawn({"nmcli", "dev", "wifi", "hotspot"});
    else if (id == "kbl") {
        auto &b = Brightness::get();
        int mx = std::max(1, b.kbdMax);
        b.setKbd((b.kbdLevel + 1) % (mx + 1));
    }
}

// The tile grid. Tiles are placed by hand (cells); in edit mode the grid itself handles
// dragging, resizing, removing, and paints the empty cells and the snap ghost.
class CcGrid : public Widget {
public:
    std::vector<Tile> layout;
    bool editing = false;
    std::function<void()> changed;     // layout edited (rebuild tiles)
    const Theme &t = theme();
    double cell() const { return t.gridCell; }
    double gap() const { return t.gridGap; }
    int cols() const { return t.gridCols; }
    int maxRows() const { return t.gridRows; }
    int rows() const {
        int r = 1;
        for (auto &x : layout) r = std::max(r, x.y + x.h);
        return std::min(maxRows(), r + (editing ? 1 : 0));
    }
    Rect cellRect(int x, int y, int w, int h) const {
        double s = cell() + gap();
        return {geom.x + x * s, geom.y + y * s, w * cell() + (w - 1) * gap(), h * cell() + (h - 1) * gap()};
    }
    bool overlaps(const Tile &a, int skip) const {
        if (a.x < 0 || a.y < 0 || a.x + a.w > cols() || a.y + a.h > maxRows()) return true;
        for (size_t i = 0; i < layout.size(); i++) {
            if ((int)i == skip) continue;
            auto &b = layout[i];
            if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) return true;
        }
        return false;
    }
    Size sizeHint(double, double) override {
        int r = rows();
        return {cols() * cell() + (cols() - 1) * gap(), r * cell() + (r - 1) * gap()};
    }
    void arrange() override {
        for (size_t i = 0; i < children_.size() && i < layout.size(); i++) {
            auto &L = layout[i];
            Rect r = cellRect(L.x, L.y, L.w, L.h);
            if ((int)i == drag_) r = r.translated(dragOff_.x, dragOff_.y);
            if ((int)i == resize_) { r.w = std::max(cell(), r.w + dragOff_.x); r.h = std::max(cell(), r.h + dragOff_.y); }
            children_[i]->setGeometry(r);
        }
    }
    // ---- edit mode: the grid takes the pointer instead of the tiles ----
    Widget *hitTest(Point p) override {
        if (!editing) return Widget::hitTest(p);
        return geom.contains(p) || hitBadge(p) >= 0 ? this : nullptr;
    }
    int hitBadge(Point p) const {
        for (size_t i = 0; i < layout.size(); i++) {
            Rect r = cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
            if (std::hypot(p.x - (r.right() - 4), p.y - (r.y + 4)) <= 13) return (int)i;
        }
        return -1;
    }
    int hitTile(Point p) const {
        for (size_t i = 0; i < layout.size(); i++)
            if (cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h).contains(p)) return (int)i;
        return -1;
    }
    bool pointerPress(Point p, int button) override {
        if (!editing || button != 1) return false;
        if (int b = hitBadge(p); b >= 0) {
            layout.erase(layout.begin() + b);
            if (changed) changed();
            return true;
        }
        int i = hitTile(p);
        if (i < 0) return true;
        Rect r = cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
        start_ = p;
        dragOff_ = {0, 0};
        if (p.x > r.right() - 26 && p.y > r.bottom() - 26) resize_ = i; else drag_ = i;
        window()->setCursor(resize_ >= 0 ? Cursor::ResizeNWSE : Cursor::Grabbing);
        return true;
    }
    void pointerMove(Point p) override {
        if (drag_ < 0 && resize_ < 0) {
            if (editing && window()) {
                int i = hitTile(p);
                Cursor c = Cursor::Default;
                if (hitBadge(p) >= 0) c = Cursor::Pointer;
                else if (i >= 0) {
                    Rect r = cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
                    c = p.x > r.right() - 26 && p.y > r.bottom() - 26 ? Cursor::ResizeNWSE : Cursor::Grab;
                }
                window()->setCursor(c);
            }
            return;
        }
        dragOff_ = {p.x - start_.x, p.y - start_.y};
        arrange();
        update();
    }
    Tile target() const {
        double s = cell() + gap();
        if (drag_ >= 0) {
            Tile t = layout[drag_];
            t.x = std::clamp((int)std::lround(t.x + dragOff_.x / s), 0, cols() - t.w);
            t.y = std::clamp((int)std::lround(t.y + dragOff_.y / s), 0, maxRows() - t.h);
            return t;
        }
        Tile t = layout[resize_];
        TileMeta m = metaFor(t.id);
        t.w = std::clamp(t.w + (int)std::lround(dragOff_.x / s), m.minW, m.maxW);
        t.h = std::clamp(t.h + (int)std::lround(dragOff_.y / s), m.minH, m.maxH);
        return t;
    }
    void pointerRelease(Point, int) override {
        if (drag_ < 0 && resize_ < 0) return;
        Tile t = target();
        int i = drag_ >= 0 ? drag_ : resize_;
        if (!overlaps(t, i)) layout[i] = t;    // else it snaps back
        drag_ = resize_ = -1;
        dragOff_ = {0, 0};
        if (changed) changed();
    }
    void paint(Painter &p) override {
        if (!editing) return;
        // empty cells
        for (int y = 0; y < rows(); y++)
            for (int x = 0; x < cols(); x++) {
                bool used = false;
                for (auto &L : layout) if (x >= L.x && x < L.x + L.w && y >= L.y && y < L.y + L.h) used = true;
                if (used) continue;
                Rect r = cellRect(x, y, 1, 1);
                p.stroke(r.inset(0.75), Color{1, 1, 1, 0.14}, 1.5, 16);
                p.icon("plus", r.center(), 18, t.text3);
            }
        // snap ghost
        if (drag_ >= 0 || resize_ >= 0) {
            Tile g = target();
            if (!overlaps(g, drag_ >= 0 ? drag_ : resize_)) {
                Rect r = cellRect(g.x, g.y, g.w, g.h);
                p.fill(r, t.accentSoft, 16);
                p.stroke(r.inset(1), t.accent, 2, 16);
            }
        }
    }
    void paintOver(Painter &p) override {
        if (!editing) return;
        for (size_t i = 0; i < layout.size(); i++) {
            Rect r = children_.size() > i ? children_[i]->geom : cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
            bool active = (int)i == drag_ || (int)i == resize_;
            p.stroke(r.inset(0.75), active ? t.accent : Color{1, 1, 1, 0.22}, 1.5, 16);
            p.fillCircle({r.right() - 4, r.y + 4}, 11, t.danger);
            p.icon("minus", Point{r.right() - 4, r.y + 4}, 13, Color{1, 1, 1, 1});
            p.icon("resize", Point{r.right() - 12, r.bottom() - 12}, 14, t.accent);
        }
    }
private:
    int drag_ = -1, resize_ = -1;
    Point start_, dragOff_;
};

class ControlCentre : public Card {
public:
    explicit ControlCentre(Screen *s) : Card(Dir::Column, 14), screen(s) {
        const Theme &t = theme();
        fixedW = t.gridWidth();
        padding(t.gridPad);
        radius = t.radius;
        load();
        for (auto *sig : {&Net::get().changed, &Bluetooth::get().changed, &Brightness::get().kbdChanged, &Recorder::get().changed,
                          &Idle::get().changed, &Power::get().changed})
            conns.on(*sig, [this] { conns.later([this] { refresh(); }); });
        // sliders follow the value without a rebuild (a rebuild would drop the slider being dragged)
        conns.on(Audio::get().changed, [this](const std::string &) {
            conns.later([this] {
                refreshSliders();
                if (Audio::get().micMuted != lastMicMuted) { lastMicMuted = Audio::get().micMuted; refresh(); }
            });
        });
        lastMicMuted = Audio::get().micMuted;
        conns.on(Brightness::get().changed, [this] { conns.later([this] { refreshSliders(); }); });
        conns.on(cfg().changed, [this] { conns.later([this] { if (!shell().ccEditing) { load(); build(); } else refresh(); }); });
        conns.on(shell().changed, [this] { if (editing != shell().ccEditing) conns.later([this] { editing = shell().ccEditing; build(); }); });
        editing = shell().ccEditing;
        build();
    }
    Screen *screen;
    std::vector<Tile> layout;
    bool editing = false, lastMicMuted = false;
    Connections conns;
    CcGrid *grid = nullptr;
    std::vector<std::pair<std::string, Slider *>> sliders;

    void load() {
        layout.clear();
        json l = cfg().j("ccLayout");
        if (!l.is_array()) l = cfg().defaultValue("ccLayout");
        if (!l.is_array()) return;
        for (auto &o : l)
            if (o.is_object()) layout.push_back({o.value("id", std::string()), o.value("x", 0), o.value("y", 0), o.value("w", 1), o.value("h", 1)});
    }
    void save() {
        json a = json::array();
        for (auto &t : layout) a.push_back({{"id", t.id}, {"x", t.x}, {"y", t.y}, {"w", t.w}, {"h", t.h}});
        cfg().set("ccLayout", a);
    }
    void refreshSliders() {
        for (auto &[id, s] : sliders) {
            auto &a = Audio::get();
            if (id == "brightness") s->setValue(Brightness::get().value);
            else if (id == "volume") { s->maxValue = a.maxVolume(); s->setValue(a.volume); s->iconName = a.muted ? "mute" : "volume"; }
            else s->setValue(a.micVolume);
        }
    }
    // tiles change colour / text without rebuilding the grid (keeps sliders being dragged alive)
    void refresh() { build(); }

    void build() {
        const Theme &t = theme();
        clear();
        sliders.clear();
        // ---- header ----
        auto *head = row(this, 8);
        auto *hc = col(head, 2);
        hc->grow = 1;
        time_t now = time(nullptr);
        tm lt;
        localtime_r(&now, &lt);
        char day[32], date[32];
        strftime(day, sizeof day, "%A", &lt);
        strftime(date, sizeof date, "%e %B", &lt);
        hc->add<Label>(editing ? "Drag to move · corner to resize" : day, 13, Weight::Normal, Role::Text2);
        hc->add<Label>(editing ? "Edit controls" : trim(date), 24, Weight::DemiBold);
        if (!editing) {
            auto *pen = head->add<IconButton>("pencil", 36, 17);
            pen->onClick = [] { shell().ccEditing = true; shell().changed.emit(); };
        } else {
            auto *reset = head->add<TextButton>("Reset");
            reset->fixedH = 34;
            reset->radius = 11;
            reset->bg = t.surface3;
            reset->onClick = [this] {
                json d = cfg().defaultValue("ccLayout");
                layout.clear();
                if (d.is_array())
                    for (auto &o : d) layout.push_back({o.value("id", std::string()), o.value("x", 0), o.value("y", 0), o.value("w", 1), o.value("h", 1)});
                conns.later([this] { build(); });
            };
            auto *done = head->add<TextButton>("Done", "check", true);
            done->fixedH = 34;
            done->radius = 11;
            done->onClick = [this] { save(); shell().ccEditing = false; shell().changed.emit(); };
        }

        // ---- tiles ----
        grid = add<CcGrid>();
        grid->fill = false;
        grid->layout = layout;
        grid->editing = editing;
        grid->changed = [this] { layout = grid->layout; conns.later([this] { build(); }); };
        for (auto &L : layout) buildTile(grid, L);

        // ---- add-tile drawer ----
        if (editing) {
            add<Separator>();
            auto *h = add<Label>("ADD CONTROLS", 12, Weight::DemiBold, Role::Text3);
            h->font.letterSpacing = 0.7;
            Box *line = nullptr;
            double used = 0, avail = t.gridWidth() - 2 * t.gridPad;
            for (auto &[id, m] : catalog()) {
                if (std::any_of(layout.begin(), layout.end(), [&](const Tile &x) { return x.id == id; })) continue;
                double w = measureText(m.label, Font{"", 13}).w + 15 + 7 + 24;
                if (!line || used + w > avail) { line = row(this, 8); used = 0; }
                used += w + 8;
                auto *chip = line->add<Button>(Dir::Row, 7);
                chip->fixedH = 34;
                chip->radius = 17;
                chip->padding(12, 0);
                chip->bg = t.surface3;
                chip->fill = false;
                chip->add<IconW>(m.icon, 15);
                chip->add<Label>(m.label, 13)->fill = false;
                std::string idc = id;
                TileMeta mc = m;
                chip->onClick = [this, idc, mc] {
                    for (int y = 0; y <= theme().gridRows - mc.minH; y++)
                        for (int x = 0; x <= theme().gridCols - mc.minW; x++) {
                            Tile nt{idc, x, y, mc.minW, mc.minH};
                            if (!grid->overlaps(nt, -1)) {
                                layout.push_back(nt);
                                conns.later([this] { build(); });
                                return;
                            }
                        }
                };
            }
        }
        relayout();
    }

    void buildTile(Widget *parent, const Tile &L) {
        const Theme &t = theme();
        TileMeta m = metaFor(L.id);
        bool on = isOn(L.id);
        std::string id = L.id;
        if (id == "brightness" || id == "volume" || id == "micvol") {
            auto *s = parent->add<Slider>(L.h >= L.w);
            s->thick = true;
            s->interactive = !editing;
            auto &a = Audio::get();
            s->iconName = id == "brightness" ? "sun" : id == "volume" ? (a.muted ? "mute" : "volume") : "mic";
            if (id == "volume") s->maxValue = a.maxVolume();
            s->setValue(id == "brightness" ? Brightness::get().value : id == "volume" ? a.volume : a.micVolume);
            s->onChanged = [id](double v) {
                if (id == "brightness") Brightness::get().set(v);
                else if (id == "volume") Audio::get().setVolume(v);
                else Audio::get().setMicVolume(v);
            };
            sliders.push_back({id, s});
            return;
        }
        if (id == "power") {
            auto *b = parent->add<Box>(Dir::Row, 4);
            b->radius = 16;
            b->bg = t.surface2;
            b->padding(4);
            double w = L.w * t.gridCell + (L.w - 1) * t.gridGap;
            for (auto [prof, icon, label] : std::vector<std::tuple<std::string, std::string, std::string>>{
                     {"power-saver", "leaf", "Saver"}, {"balanced", "gauge", "Balanced"}, {"performance", "bolt", "Performance"}}) {
                bool sel = Power::get().profile == prof;
                auto *o = b->add<Button>(Dir::Row, 7);
                o->grow = 1;
                o->radius = 12;
                o->justify = Justify::Center;
                o->bg = sel ? t.accent : Color{0, 0, 0, 0};
                o->hoverBg = sel ? t.accentBright : t.surface3;
                o->add<IconW>(icon, 16, sel ? Role::OnAccent : Role::Text2);
                if (w > 300) o->add<Label>(label, 13, sel ? Weight::DemiBold : Weight::Normal, sel ? Role::OnAccent : Role::Text2)->fill = false;
                std::string p = prof;
                o->onClick = [p] { Power::get().set(p); };
            }
            return;
        }
        if (L.w >= 2) {
            auto *b = parent->add<Button>(Dir::Row, 12);
            b->radius = 16;
            b->bg = t.surface2;
            b->hoverBg = t.surface3;
            b->pl = 14;
            b->pr = 12;
            auto *ic = b->add<Box>(Dir::Row);
            ic->fixedW = ic->fixedH = 36;
            ic->radius = 12;
            ic->bg = on ? t.accent : t.surface3;
            ic->justify = Justify::Center;
            ic->fill = false;
            ic->add<IconW>(m.icon, 19, on ? Role::OnAccent : Role::Text)->fill = false;
            auto *tc = col(b, 1);
            tc->grow = 1;
            tc->justify = Justify::Center;
            tc->add<Label>(m.label, 14, Weight::DemiBold);
            std::string sub = subtitle(id);
            if (!sub.empty()) tc->add<Label>(sub, 12, Weight::Normal, Role::Text2);
            if (id == "wifi" || id == "bluetooth") {
                auto *more = b->add<IconButton>("chevr", 28, 16);
                more->bg = Color{0, 0, 0, 0};
                more->icon->role = Role::Text3;
                more->onClick = [] { spawn({"nova-settings", "--page", "Connections"}); shell().close(); };
            }
            b->onClick = [id] { press(id); };
            return;
        }
        auto *b = parent->add<Button>(Dir::Row, 0);
        b->radius = 16;
        b->bg = on ? t.accent : t.surface2;
        b->hoverBg = on ? t.accentBright : t.surface3;
        b->justify = Justify::Center;
        b->tooltip = m.label;
        b->add<IconW>(m.icon, 20, on ? Role::OnAccent : Role::Text)->fill = false;
        b->onClick = [id] { press(id); };
    }
};

std::unique_ptr<Widget> makeControlCentre(Screen *s) { return std::make_unique<ControlCentre>(s); }

}  // namespace nova
