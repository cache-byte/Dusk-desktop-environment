// Smaller pop-up cards: clipboard history, the capture bar (Print), the game overlay (Super+G)
// and tray context menus.
#include "apps.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "tray.hpp"
#include "windows.hpp"

namespace nova {

using namespace ui;

// ============================================================= clipboard ==
class ClipboardCard : public Card {
public:
    ClipboardCard() : Card(Dir::Column, 12) {
        const Theme &t = theme();
        fixedW = 420;
        fixedH = 520;
        padding(16);
        radius = t.radius;
        auto *head = row(this, 8);
        head->add<Label>("Clipboard", 18, Weight::DemiBold)->grow = 1;
        auto *clr = head->add<TextButton>("Clear");
        clr->fixedH = 30;
        clr->radius = 10;
        clr->bg = t.surface3;
        clr->onClick = [this] { ClipHistory::get().wipe(); conns.later([this] { fill(); }); };
        field = add<TextInput>();
        field->leadingIcon = "search";
        field->placeholder = "Search";
        field->fixedH = 40;
        field->onChanged = [this](const std::string &) { conns.later([this] { fill(); }); };
        field->onSubmit = [this](const std::string &) {
            auto f = filtered();
            if (!f.empty()) pick(*f[0]);
        };
        auto *sv = add<ScrollView>();
        sv->grow = 1;
        list = sv->add<Box>(Dir::Column, 4);
        ClipHistory::get().refresh([this, alive = conns.token()] { if (*alive) fill(); });
        conns.later([this] { if (window()) window()->setFocus(field); });
    }
    TextInput *field;
    Box *list;
    Connections conns;
    std::vector<const ClipItem *> filtered() const {
        std::vector<const ClipItem *> out;
        std::string q = lower(field->text());
        for (auto &i : ClipHistory::get().items)
            if (q.empty() || lower(i.preview).find(q) != std::string::npos) out.push_back(&i);
        if (out.size() > 100) out.resize(100);
        return out;
    }
    void pick(const ClipItem &i) {
        ClipHistory::get().copy(i);
        shell().close();
    }
    void fill() {
        const Theme &t = theme();
        list->clear();
        auto f = filtered();
        if (f.empty()) {
            auto *l = list->add<Label>(ClipHistory::get().items.empty() ? "Nothing copied yet" : "No matches", 13, Weight::Normal, Role::Text3);
            l->hAlign = Align::Center;
            l->mt = 30;
        }
        for (auto *i : f) {
            auto *b = list->add<Button>(Dir::Row, 10);
            b->fixedH = 46;
            b->radius = 11;
            b->padding(12, 0);
            b->bg = t.surface2;
            b->hoverBg = t.accentSoft;
            if (i->image) b->add<IconW>("image", 16, Role::Text2);
            std::string text = i->preview;
            for (auto &c : text) if (c == '\n' || c == '\t' || c == '\r') c = ' ';
            b->add<Label>(text, 13)->grow = 1;
            ClipItem copy = *i;
            b->onClick = [this, copy] { pick(copy); };
            auto *x = b->add<IconButton>("x", 26, 14);
            x->bg = Color{0, 0, 0, 0};
            x->icon->role = Role::Text3;
            x->onClick = [this, copy] { ClipHistory::get().remove(copy); conns.after(150, [this] { ClipHistory::get().refresh([this, alive = conns.token()] { if (*alive) fill(); }); }); };
        }
        relayout();
    }
};
std::unique_ptr<Widget> makeClipboard(Screen *) { return std::make_unique<ClipboardCard>(); }

// =========================================================== capture bar ==
static Box *vsep(Widget *parent) {
    auto *s = parent->add<Box>();
    s->fixedW = 1;
    s->fixedH = 30;
    s->bg = theme().border;
    s->fill = false;
    return s;
}

class CaptureBar : public Card {
public:
    explicit CaptureBar(bool compact) : Card(Dir::Row, compact ? 6 : 10), compact(compact) {
        radius = 22;
        padding(14);
        fixedH = 76;
        edit = cfg().b("captureEdit", false);
        build();
        onKeyHook();
    }
    bool compact = false;      // narrow or scaled screen: icons without words
    std::string mode = "shot", area = "region";
    int delay = 0;
    bool edit = false;
    Connections conns;

    void onKeyHook() {
        conns.later([this] {
            if (!window()) return;
            auto prev = window()->onKey;
            window()->onKey = [this, prev](const KeyEvent &e) {
                if (e.pressed && (e.sym == key::Return || e.sym == key::KP_Enter)) { go(); return true; }
                return prev ? prev(e) : false;
            };
        });
    }
    Segmented *seg(const std::vector<Segmented::Option> &opts, const std::string &value, std::function<void(const std::string &)> fn) {
        auto *s = add<Segmented>();
        s->options = opts;
        s->value = value;
        s->onPicked = [this, fn](const std::string &v) { fn(v); conns.later([this] { build(); }); };
        s->fill = false;
        return s;
    }
    Button *chip(const std::string &icon, const std::string &label, bool on, std::function<void()> fn) {
        const Theme &t = theme();
        auto *c = add<Button>(Dir::Row, 7);
        c->fixedH = 46;
        c->radius = 14;
        c->padding(13, 0);
        c->bg = on ? t.accentSoft : t.surface2;
        c->hoverBg = on ? t.accentSoft : t.surface3;
        c->border = on ? t.accentLine : Color{0, 0, 0, 0};
        c->fill = false;
        c->add<IconW>(icon, 16, on ? Role::AccentBright : Role::Text3);
        if (!compact) c->add<Label>(label, 13, Weight::Normal, on ? Role::Text : Role::Text3)->fill = false;
        c->tooltip = label;
        c->onClick = [this, fn] { fn(); conns.later([this] { build(); }); };
        return c;
    }
    void build() {
        const Theme &t = theme();
        clear();
        auto L = [this](const char *s) { return compact ? std::string() : std::string(s); };
        seg({{"shot", L("Screenshot"), "shot"}, {"record", L("Record"), "record"}}, mode, [this](const std::string &v) { mode = v; })->tooltip = "Screenshot or record";
        vsep(this);
        seg({{"region", L("Region"), "frame"}, {"window", L("Window"), "square"}, {"screen", L("Screen"), "monitor"}}, area,
            [this](const std::string &v) { area = v; })->tooltip = "Region, window or whole screen";
        vsep(this);
        // delay: time to open a menu or another pop-up so it's in the shot
        std::string ci = compact ? "" : "clock";
        seg({{"0", "Now", ci}, {"3", "3 s", ci}, {"5", "5 s", ci}, {"10", "10 s", ci}}, std::to_string(delay),
            [this](const std::string &v) { delay = atoi(v.c_str()); })->tooltip = "Delay";
        vsep(this);
        if (mode == "shot") {
            chip("pencil", "Draw", edit, [this] { edit = !edit; cfg().set("captureEdit", edit); });
        } else {
            chip("volume", "Sound", cfg().b("recordSystemAudio", true), [] { cfg().set("recordSystemAudio", !cfg().b("recordSystemAudio", true)); });
            chip("mic", "Microphone", cfg().b("recordMic", false), [] { cfg().set("recordMic", !cfg().b("recordMic", false)); });
        }
        auto *go = add<TextButton>(mode == "shot" ? "Capture" : "Start", mode == "shot" ? "shot" : "record", true);
        go->fixedW = compact ? 104 : 120;
        go->fixedH = 46;
        go->radius = 14;
        go->justify = Justify::Center;
        go->onClick = [this] { this->go(); };
        auto *x = add<IconButton>("x", 46, 18);
        x->radius = 14;
        x->onClick = [] { shell().close(); };
        (void)t;
        relayout();
    }
    void go() {
        std::vector<std::string> args;
        if (mode == "shot") {
            args = {"nova-record", "shot", area};
            if (edit) args.push_back("--edit");
        } else {
            args = {"nova-record", "start", area, cfg().b("recordSystemAudio", true) ? "--audio" : "--no-audio", cfg().b("recordMic", false) ? "--mic" : "--no-mic"};
        }
        int d = delay;
        shell().close();
        if (d > 0) shell().captureCountdown(d);
        // give the bar time to disappear so it isn't in the picture (plus the chosen delay)
        std::vector<std::string> cmd = {"sh", "-c", "sleep " + (d > 0 ? std::to_string(d) : std::string("0.35")) + "; exec \"$@\"", "sh"};
        cmd.insert(cmd.end(), args.begin(), args.end());
        spawn(cmd);
    }
};
std::unique_ptr<Widget> makeCapture(Screen *s) {
    // the full bar is ~1200 px wide: on smaller (or scaled-up) screens show icons only
    bool compact = s && s->output && s->output->logical().w < 1400;
    return std::make_unique<CaptureBar>(compact);
}

// ========================================================== game overlay ==
class GameOverlay : public Card {
public:
    GameOverlay() : Card(Dir::Column, 14) {
        fixedW = 760;
        radius = 24;
        padding(18);
        for (auto *sig : {&Gaming::get().changed, &Recorder::get().changed, &Power::get().changed, &cfg().changed})
            conns.on(*sig, [this] { conns.later([this] { build(); }); });
        conns.on(Audio::get().changed, [this](const std::string &) { conns.later([this] { syncAudio(); }); });
        build();
    }
    Connections conns;
    Slider *vol = nullptr;
    Label *volL = nullptr;
    IconButton *muteB = nullptr, *micB = nullptr;

    void syncAudio() {
        if (!vol) return;
        auto &a = Audio::get();
        vol->maxValue = a.maxVolume();
        vol->setValue(a.volume);
        volL->setText(std::to_string((int)std::lround(a.volume * 100)) + "%");
        muteB->icon->iconName = a.muted ? "mute" : "volume";
        micB->icon->role = a.micMuted ? Role::Danger : Role::Text;
        update();
    }
    void tile(Box *r, const std::string &icon, const std::string &label, const std::string &sub, bool on, bool enabled, std::function<void()> fn) {
        const Theme &t = theme();
        auto *b = r->add<Button>(Dir::Column, 4);
        b->grow = 1;
        b->fixedH = 74;
        b->radius = 16;
        b->bg = on ? t.accent : t.surface2;
        b->hoverBg = on ? t.accentBright : t.surface3;
        b->justify = Justify::Center;
        b->crossAlign = Align::Center;
        b->opacity.set(enabled ? 1 : 0.4);
        b->add<IconW>(icon, 20, on ? Role::OnAccent : Role::Text)->fill = false;
        b->add<Label>(label, 13, Weight::DemiBold, on ? Role::OnAccent : Role::Text)->fill = false;
        if (!sub.empty()) b->add<Label>(sub, 11, Weight::Normal, on ? Role::OnAccent : Role::Text3)->fill = false;
        if (enabled) b->onClick = fn;
    }
    void build() {
        const Theme &t = theme();
        clear();
        auto *head = row(this, 10);
        head->add<IconW>("game", 20, Role::Accent);
        head->add<Label>(std::string("Game mode ") + (Gaming::get().active ? "on" : ipc().fullscreen ? "waiting for the game" : "off"), 15, Weight::DemiBold)->grow = 1;
        head->add<Label>("Esc to close", 12, Weight::Normal, Role::Text3)->fill = false;

        auto *tiles = row(this, 8);
        bool rec = Recorder::get().recording, replay = cfg().b("replayEnabled", false);
        tile(tiles, "gauge", "FPS overlay", "next game launch", cfg().b("mangohud", false), true, [] { cfg().set("mangohud", !cfg().b("mangohud", false)); });
        tile(tiles, "record", rec ? "Stop" : "Record", "whole screen", rec, true, [rec] {
            shell().close();
            spawn({"nova-record", rec ? "stop" : "start", "screen"});
        });
        tile(tiles, "restart", "Save replay", replay ? "last " + std::to_string(cfg().i("replaySeconds", 30)) + " s" : "replay is off", false, replay,
             [] { Replay::get().save(); });
        tile(tiles, "video", "Instant replay", replay ? "on" : "off", replay, true, [] { cfg().set("replayEnabled", !cfg().b("replayEnabled", false)); });
        tile(tiles, "shot", "Screenshot", "whole screen", false, true, [] { shell().close(); spawnShell("sleep 0.3; nova-record shot screen"); });
        tile(tiles, "moon", "Do not disturb", cfg().b("autoDnd", true) ? "auto in fullscreen" : "", cfg().b("dnd", false), true,
             [] { cfg().set("dnd", !cfg().b("dnd", false)); });

        auto *prof = row(this, 6);
        for (auto [p, icon, label] : std::vector<std::tuple<std::string, std::string, std::string>>{
                 {"power-saver", "leaf", "Saver"}, {"balanced", "gauge", "Balanced"}, {"performance", "bolt", "Performance"}}) {
            bool on = Power::get().profile == p;
            auto *b = prof->add<Button>(Dir::Row, 7);
            b->grow = 1;
            b->fixedH = 42;
            b->radius = 13;
            b->justify = Justify::Center;
            b->bg = on ? t.accent : t.surface2;
            b->hoverBg = on ? t.accentBright : t.surface3;
            b->add<IconW>(icon, 15, on ? Role::OnAccent : Role::Text2);
            b->add<Label>(label, 13, on ? Weight::DemiBold : Weight::Normal, on ? Role::OnAccent : Role::Text2)->fill = false;
            std::string pc = p;
            b->onClick = [pc] { Power::get().set(pc); };
        }

        auto *ar = row(this, 12);
        muteB = ar->add<IconButton>("volume");
        muteB->onClick = [] { Audio::get().toggleMute(); };
        vol = ar->add<Slider>();
        vol->thick = false;
        vol->grow = 1;
        vol->onChanged = [](double v) { Audio::get().setVolume(v); };
        volL = ar->add<Label>("", 13, Weight::Normal, Role::Text2);
        volL->fixedW = 40;
        micB = ar->add<IconButton>("mic");
        micB->onClick = [] { Audio::get().toggleMic(); };
        syncAudio();
        relayout();
    }
};
std::unique_ptr<Widget> makeGameOverlay(Screen *) { return std::make_unique<GameOverlay>(); }

// ============================================================ tray menus ==
class TrayMenu : public Card {
public:
    TrayMenu(const TrayMenuItem &root, std::function<TrayItem *()> item) : Card(Dir::Column, 2), item(std::move(item)) {
        padding(6);
        radius = 14;
        minW = 200;
        maxW = 360;
        stack.push_back(root);
        build();
    }
    std::function<TrayItem *()> item;
    std::vector<TrayMenuItem> stack;    // submenus: the last one is shown
    Connections conns;
    void build() {
        const Theme &t = theme();
        clear();
        const TrayMenuItem &m = stack.back();
        if (stack.size() > 1) {
            auto *back = add<Button>(Dir::Row, 8);
            back->fixedH = 32;
            back->radius = 9;
            back->padding(10, 0);
            auto *ic = back->add<IconW>("chevr", 14, Role::Text2);
            ic->rotation.set(180);
            back->add<Label>(m.label, 13, Weight::DemiBold)->grow = 1;
            back->onClick = [this] { stack.pop_back(); conns.later([this] { build(); }); };
            add<Separator>();
        }
        for (auto &c : m.children) {
            if (!c.visible) continue;
            if (c.type == "separator") { auto *s = add<Separator>(); s->mt = s->mb = 3; continue; }
            auto *b = add<Button>(Dir::Row, 8);
            b->fixedH = 32;
            b->radius = 9;
            b->padding(10, 0);
            b->hoverBg = t.accentSoft;
            b->opacity.set(c.enabled ? 1 : 0.45);
            if (!c.toggleType.empty()) {
                auto *box = b->add<IconW>(c.checked ? "check" : "", 14, Role::AccentBright);
                box->fixedW = 14;
            }
            std::string label = replaceAll(c.label, "__", "\x01");
            label.erase(std::remove(label.begin(), label.end(), '_'), label.end());   // mnemonics
            label = replaceAll(label, "\x01", "_");
            b->add<Label>(label, 13)->grow = 1;
            if (!c.children.empty()) b->add<IconW>("chevr", 14, Role::Text3);
            if (!c.enabled) continue;
            TrayMenuItem copy = c;
            b->onClick = [this, copy] {
                if (!copy.children.empty()) { stack.push_back(copy); conns.later([this] { build(); }); return; }
                if (TrayItem *it = item()) it->menuClicked(copy.id);
                shell().close();
            };
        }
        relayout();
    }
};
std::unique_ptr<Widget> makeTrayMenu(const TrayMenuItem &root, std::function<TrayItem *()> item) {
    return std::make_unique<TrayMenu>(root, std::move(item));
}

void showTrayMenu(Screen *s, const TrayMenuItem &root, std::function<TrayItem *()> item, double x) {
    if (!s || !s->popout) return;
    s->popout->openCustom("traymenu", makeTrayMenu(root, std::move(item)), x);
    shell().popout = "traymenu";
    shell().popoutOutput = s->name();
    shell().changed.emit();
}

}  // namespace nova
