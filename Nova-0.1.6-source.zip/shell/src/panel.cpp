#include "panel.hpp"
#include "apps.hpp"
#include "notifications.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "tray.hpp"
#include "windows.hpp"

#include <ctime>

namespace nova {

using namespace ui;

// The panel's background: translucent colour over blur (real or the wallpaper stand-in)
class PanelBg : public Card {
public:
    PanelBg() : Card(Dir::Row, 0) {
        radius = 0;
        shadow = false;
        padding(12, 0);
        useTint = true;
    }
    void paint(Painter &p) override {
        tint = theme().panel;
        Card::paint(p);
        p.fill({geom.x, geom.y, geom.w, 1}, theme().border);
    }
};

Panel::Panel(Screen *s) : LayerWindow("nova-panel", Layer::Top, s->output), screen(s) {
    setAnchors(AnchorBottom | AnchorLeft | AnchorRight);
    setRequestedSize(0, (int)theme().panelHeight);
    setExclusiveZone((int)theme().panelHeight);
    build();
    resized.connect([this](Size sz) {
        if (screen->output) setBackdrop(*this, screen->output->logical(), {0, screen->output->logical().h - sz.h, sz.w, sz.h});
    });
    conns_.on(Toplevels::get().changed, [this] { rebuildApps(); });
    conns_.on(Apps::get().changed, [this] { appsKey_.clear(); rebuildApps(); });
    conns_.on(cfg().changed, [this] { appsKey_.clear(); rebuildApps(); refresh(); });
    conns_.on(Tray::get().changed, [this] { rebuildTray(); });
    conns_.on(Net::get().changed, [this] { refresh(); });
    conns_.on(Audio::get().changed, [this](const std::string &) { refresh(); });
    conns_.on(Battery::get().changed, [this] { refresh(); });
    conns_.on(Notifications::get().changed, [this] { refresh(); });
    conns_.on(Media::get().changed, [this] { refresh(); });
    conns_.on(Recorder::get().changed, [this] { refresh(); });
    conns_.on(ipc().ledsChanged, [this] { refresh(); });
    conns_.on(shell().changed, [this] { refresh(); });
    // the clock ticks on the minute
    clockTimer_ = Loop::get().addTimer(1000, [this] { refreshClock(); }, true);
    show();
}
Panel::~Panel() {
    Loop::get().removeTimer(clockTimer_);
}

Rect Panel::clockRect() const { return clock_ ? clock_->geom : Rect{}; }

void Panel::build() {
    auto *bg = setRoot<PanelBg>();
    const Theme &t = theme();

    // ---- left: launcher + apps ----
    launcherBtn_ = bg->add<PanelButton>();
    launcherBtn_->add<IconW>("nova", 22, Role::Accent);
    launcherBtn_->onClick = [this] { shell().toggle("launcher", screen->name()); };
    auto *sep = bg->add<Separator>(true, 0);
    sep->fixedH = 22;
    sep->ml = sep->mr = 6;
    sep->fill = false;
    apps_ = row(bg, 6);
    rebuildApps();
    stretch(bg);

    // ---- right ----
    right_ = row(bg, 6);
    countdown_ = right_->add<Pill>();
    countdown_->highlighted = true;
    countdown_->add<IconW>("shot", 16, Role::AccentBright);
    countdownL_ = countdown_->add<Label>("3", 13, Weight::DemiBold);

    clipBtn_ = right_->add<PanelButton>();
    clipBtn_->add<IconW>("clip", 20);
    clipBtn_->onClick = [this] { shell().toggle("clipboard", screen->name()); };

    locks_ = right_->add<Pill>();
    locks_->highlighted = true;
    capsI_ = locks_->add<IconW>("caps", 16, Role::AccentBright);
    numI_ = locks_->add<IconW>("hash", 16, Role::AccentBright);

    tray_ = right_->add<Pill>();
    tray_->interactive = false;
    rebuildTray();

    // media: a small visualizer; click opens Now Playing
    media_ = right_->add<Pill>();
    media_->onClick = [this] {
        shell().mediaRightGap = size().w - media_->geom.right();
        shell().toggle("nowplaying", screen->name());
    };
    bars_ = media_->add<MusicBars>();
    viz_ = media_->add<Visualizer>();
    viz_->fixedW = 34;
    viz_->fixedH = 16;
    viz_->mini = true;

    status_ = right_->add<Pill>();
    netI_ = status_->add<IconW>("wifi", 18);
    volI_ = status_->add<IconW>("volume", 18);
    battery_ = status_->add<BatteryW>();
    status_->onClick = [this] { shell().toggle("controlcentre", screen->name()); };
    status_->onRightClick = status_->onClick;

    clock_ = right_->add<Pill>();
    clock_->onClick = [this] { shell().toggle("notifications", screen->name()); };
    // recording: red pill, click to stop
    rec_ = clock_->add<Box>(Dir::Row, 6);
    rec_->bg = Color{0.9, 0.3, 0.3, 0.2};
    rec_->radius = 12;
    rec_->padding(8, 0);
    rec_->fixedH = 24;
    rec_->interactive = true;
    rec_->cursor = Cursor::Pointer;
    rec_->onClick = [] { Recorder::get().stop(); };
    auto *dot = rec_->add<Box>();
    dot->fixedW = dot->fixedH = 8;
    dot->radius = 4;
    dot->bg = t.danger;
    rec_->add<Label>("Stop", 12, Weight::DemiBold);
    auto *times = col(clock_, 0);
    times->crossAlign = Align::End;
    time_ = times->add<Label>("", 13, Weight::DemiBold);
    time_->fill = false;
    time_->alignSelf = Align::End;
    date_ = times->add<Label>("", 11, Weight::Normal, Role::Text2);
    date_->fill = false;
    date_->alignSelf = Align::End;
    badge_ = clock_->add<Box>(Dir::Row);
    badge_->fixedH = 20;
    badge_->minW = 20;
    badge_->radius = 10;
    badge_->padding(6, 0);
    badge_->justify = Justify::Center;
    badgeL_ = badge_->add<Label>("", 11, Weight::Bold, Role::OnAccent);
    refresh();
    refreshClock();
}

void Panel::refreshClock() {
    time_t now = time(nullptr);
    tm lt;
    localtime_r(&now, &lt);
    char tb[32], db[32];
    strftime(tb, sizeof tb, cfg().b("clock24", true) ? "%H:%M" : "%l:%M %p", &lt);
    strftime(db, sizeof db, "%a %e %b", &lt);
    std::string ts = trim(tb), ds = replaceAll(db, "  ", " ");
    if (ts != time_->text() || ds != date_->text()) {
        time_->setText(ts);
        date_->setText(ds);
    }
}

void Panel::refresh() {
    const Theme &t = theme();
    std::string me = screen->name();
    bool popHere = shell().isPopoutScreen(me);
    launcherBtn_->active = shell().popout == "launcher" && popHere;
    clipBtn_->active = shell().popout == "clipboard" && popHere;
    status_->highlighted = shell().popout == "controlcentre" && popHere;
    clock_->highlighted = shell().popout == "notifications" && popHere;
    media_->highlighted = shell().popout == "nowplaying" && popHere;

    countdown_->visible = shell().countdown > 0;
    countdownL_->setText(std::to_string(shell().countdown));

    auto &n = ipc();
    locks_->visible = cfg().b("lockInPanel", true) && (n.capsLock || n.numLock);
    capsI_->visible = n.capsLock;
    numI_->visible = n.numLock;

    auto &net = Net::get();
    netI_->iconName = net.wired ? "net" : "wifi";
    netI_->role = net.wired || !net.ssid.empty() ? Role::Text : Role::Text3;
    auto &a = Audio::get();
    volI_->iconName = a.muted ? "mute" : a.volume < 0.34 ? "volumelow" : "volume";
    auto &b = Battery::get();
    battery_->visible = b.present;
    battery_->level = b.percentage / 100.0;
    battery_->charging = b.charging || (!b.onBattery && b.present);

    rec_->visible = Recorder::get().recording;
    bool hasPlayer = Media::get().player() != nullptr;
    bool playing = Media::get().playing();
    auto places = cfg().j("vizPlaces");
    bool vizPanel = places.is_array() && (std::find(places.begin(), places.end(), "clock") != places.end() ||
                                          std::find(places.begin(), places.end(), "panel") != places.end());
    media_->visible = hasPlayer && cfg().b("mediaInPanel", true);
    bars_->visible = media_->visible && !(vizPanel && playing);
    bars_->setActive(playing && !vizPanel);
    viz_->visible = media_->visible && vizPanel && playing;

    int count = (int)Notifications::get().all().size();
    badge_->visible = count > 0;
    badge_->bg = cfg().b("dnd", false) ? t.surface3 : t.accent;
    badgeL_->role = cfg().b("dnd", false) ? Role::Text2 : Role::OnAccent;
    badgeL_->setText(std::to_string(count));
    relayout();
}

void Panel::rebuildApps() {
    if (!apps_) return;
    // only the set of apps and which one is focused / open matter here (titles don't)
    std::string key = cfg().j("pinned").dump() + "|";
    for (auto &tl : Toplevels::get().list) key += tl->appId + (tl->activated ? "*" : "") + ",";
    if (key == appsKey_) return;
    appsKey_ = key;
    apps_->clear();
    // pinned apps first, then running apps that aren't pinned
    std::vector<std::string> ids;
    auto pinned = cfg().j("pinned");
    if (pinned.is_array()) for (auto &p : pinned) if (p.is_string()) ids.push_back(p.get<std::string>());
    for (auto &tl : Toplevels::get().list) {
        if (tl->appId.empty()) continue;
        bool known = false;
        for (auto &id : ids) {
            std::string a = lower(id), b = lower(tl->appId);
            if (a == b || endsWith(a, "." + b) || endsWith(b, "." + a) ||
                (Apps::get().lookup(id) && Apps::get().lookup(id) == Apps::get().lookup(tl->appId))) known = true;
        }
        if (!known) ids.push_back(tl->appId);
    }
    for (auto &id : ids) {
        auto wins = Toplevels::get().forApp(id);
        const App *app = Apps::get().lookup(id);
        bool focused = std::any_of(wins.begin(), wins.end(), [](Toplevel *t) { return t->activated; });
        auto *b = apps_->add<PanelButton>();
        b->active = focused;
        b->tooltip = app ? app->name : id;
        b->add<AppIconW>(app && !app->icon.empty() ? app->icon : id, 26);
        // open / focused indicator under the icon
        class Dot : public Widget {
        public:
            int count = 0;
            bool focused = false;
            Size sizeHint(double, double) override { return {0, 0}; }
            void paint(Painter &p) override {
                if (!count) return;
                double w = focused ? 16 : 5;
                Rect pr = parent()->geom;
                p.fill({pr.center().x - w / 2, pr.bottom() - 5, w, 3}, focused ? theme().accent : theme().text3, 1.5);
            }
        };
        auto *dot = b->add<Dot>();
        dot->count = (int)wins.size();
        dot->focused = focused;
        std::string idc = id;
        b->onClick = [idc] {
            auto w = Toplevels::get().forApp(idc);
            if (w.empty()) {
                if (const App *a = Apps::get().lookup(idc)) Apps::get().launch(*a, cfg().b("gamesOnDedicatedGpu", true) && a->isGame());
                return;
            }
            for (auto *t : w)
                if (t->activated) { t->setMinimized(true); return; }   // click the focused app: minimise
            w[0]->activate();
        };
        b->onRightClick = [idc] {
            if (const App *a = Apps::get().lookup(idc)) Apps::get().launch(*a);   // another window
        };
    }
    relayout();
}

void Panel::rebuildTray() {
    if (!tray_) return;
    tray_->clear();
    auto &items = Tray::get().items;
    tray_->visible = !items.empty();
    for (size_t i = 0; i < items.size(); i++) {
        TrayItem &it = items[i];
        Widget *icon;
        if (it.pixmap && it.iconName.empty()) {
            auto *iw = tray_->add<ImageW>();
            iw->image = it.pixmap;
            iw->fixedW = iw->fixedH = 18;
            iw->cover = false;
            icon = iw;
        } else {
            icon = tray_->add<AppIconW>(it.iconName.empty() ? it.id : it.iconName, 18);
        }
        icon->interactive = true;
        icon->cursor = Cursor::Pointer;
        icon->tooltip = it.title;
        std::string svc = it.service, path = it.path;
        auto findItem = [svc, path]() -> TrayItem * {
            for (auto &x : Tray::get().items) if (x.service == svc && x.path == path) return &x;
            return nullptr;
        };
        icon->onClick = [findItem, this, icon] {
            TrayItem *x = findItem();
            if (!x) return;
            if (x->itemIsMenu) icon->onRightClick();
            else x->activate((int)icon->geom.center().x, (int)(screen->output ? screen->output->logical().h : 0));
        };
        icon->onRightClick = [findItem, this, icon] {
            TrayItem *x = findItem();
            if (!x) return;
            x->menu([this, findItem, icon](const TrayMenuItem &root) {
                // the menu opens in the pop-up layer above the panel
                showTrayMenu(screen, root, findItem, icon->geom.center().x);
            });
        };
    }
    relayout();
}

}  // namespace nova
