// Connection to the Nova compositor ($NOVA_SOCK): workspaces, lock keys, fullscreen state,
// shell actions (Super, Print, Super+Tab…) and dispatching compositor actions.
#pragma once
#include "config.hpp"

namespace nova {

struct OutputWs {
    std::string name;
    int active = 1, base = 1;
    std::vector<int> occupied;
};

class NovaIpc {
public:
    static NovaIpc &get();
    void connect();
    bool connected() const { return fd_ >= 0; }
    void dispatch(const std::string &action);                 // "workspace 2", "exec foot"…
    void request(const std::string &line, std::function<void(const json &)> reply);   // "get windows"

    // state
    int activeWorkspace = 1;
    std::vector<int> occupied;
    std::map<std::string, OutputWs> outputs;
    OutputWs wsFor(const std::string &output) const;
    bool capsLock = false, numLock = false, ledsKnown = false;
    bool fullscreen = false;
    std::string activeOutput;

    ui::Signal<> workspacesChanged;
    ui::Signal<std::string, bool> ledToggled;   // "caps" / "num", on
    ui::Signal<> ledsChanged;
    ui::Signal<bool> fullscreenChanged;
    ui::Signal<std::string> shellAction;        // "launcher", "controlcentre", "capture"…
    ui::Signal<> lockRequested;
    ui::Signal<std::string> pressed;           // a click anywhere: the layer it landed on ("window", "" = desktop)
    ui::Signal<std::string> activeOutputChanged;
private:
    int fd_ = -1, watch_ = 0, reconnectTimer_ = 0;
    std::string buf_;
    void handle(const std::string &line);
    void handleEvent(const std::string &line);
    void lost();
};

inline NovaIpc &ipc() { return NovaIpc::get(); }

}  // namespace nova
