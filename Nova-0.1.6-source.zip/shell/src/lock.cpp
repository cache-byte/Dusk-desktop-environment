// Lock screen (ext-session-lock), in two stages:
//   glance: sharp wallpaper, big clock, date in accent, media, status
//   auth:   blurred wallpaper, avatar, password, "Caps Lock is on" below it
#include "apps.hpp"
#include "notifications.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "windows.hpp"

#include <ctime>
#include <filesystem>

namespace nova {

using namespace ui;

struct LockScreen::Impl {
    bool auth = false, checking = false, showPass = false;
    std::string error, typed;
    std::vector<std::unique_ptr<LockWindow>> windows;
    std::shared_ptr<Image> sharp, blurred, face;
    Connections conns;
    Timer clock;
    std::function<void()> rebuildAll;
    std::function<void()> finish;
};

class LockView : public Stack {
public:
    LockView(LockScreen::Impl *d, Size scr) : d(d), scr(scr) {}
    LockScreen::Impl *d;
    Size scr;
    Anim blur{0};
    void paint(Painter &p) override {
        p.fill(geom, Color{0, 0, 0, 1});
        if (d->sharp && d->sharp->valid()) p.image(*d->sharp, geom);
        if (blur > 0.001 && d->blurred && d->blurred->valid()) p.image(*d->blurred, geom, 0, true, blur);
        if (blur > 0.001) p.fill(geom, Color{0, 0, 0, 0.25 * blur});
    }
};

// round avatar: ~/.face, or the first letter on a warm gradient
class Avatar : public Widget {
public:
    std::shared_ptr<Image> face;
    std::string letter;
    Size sizeHint(double, double) override { return {132, 132}; }
    void paint(Painter &p) override {
        Rect r = geom;
        p.save();
        p.clip(r, r.w / 2);
        p.gradient(r, Color::hex("#d9925a"), Color::hex("#7d3f6b"));
        Font f;
        f.size = 52;
        f.weight = Weight::DemiBold;
        Text t(letter, f);
        p.textIn(t, r, Color{1, 1, 1, 1}, Align::Center);
        if (face && face->valid()) p.image(*face, r.inset(4), r.w / 2);
        p.restore();
        p.strokeCircle(r.center(), r.w / 2 - 2, Color{1, 1, 1, 0.12}, 4);
    }
};

static std::string userName() {
    const char *u = getenv("USER");
    return u && *u ? u : "user";
}

static void submit(LockScreen::Impl *d, const std::string &pass) {
    if (d->checking) return;
    d->error.clear();
    d->checking = true;
    d->rebuildAll();
    checkPassword(pass, [d](bool ok, const std::string &) {
        d->checking = false;
        if (ok) { d->finish(); return; }
        d->error = "Wrong password";
        d->rebuildAll();
    });
}

static void buildView(LockWindow *w, LockScreen::Impl *d, Output *out) {
    const Theme &t = theme();
    Size scr = out ? out->logical() : Size{1920, 1080};
    auto *v = w->setRoot<LockView>(d, scr);
    v->blur.set(d->auth ? 1 : 0);
    v->interactive = true;
    v->onClick = [d] { if (!d->auth) { d->auth = true; d->rebuildAll(); } };
    TextInput *pass = nullptr;

    if (!d->auth) {
        // ---- glance ----
        auto *c = v->add<Box>(Dir::Column, 10);
        c->pt = scr.h * 0.23;
        c->crossAlign = Align::Center;
        time_t now = time(nullptr);
        tm lt;
        localtime_r(&now, &lt);
        char tb[16], db[64];
        strftime(tb, sizeof tb, cfg().b("clock24", true) ? "%H:%M" : "%l:%M", &lt);
        strftime(db, sizeof db, "%A %e %B", &lt);
        auto *time = c->add<Label>(trim(tb), 176, Weight::Normal);
        time->font.letterSpacing = -6;
        time->role = Role::Custom;
        time->color = Color{1, 1, 1, 1};
        time->fill = false;
        auto *date = c->add<Label>(replaceAll(db, "  ", " "), 28, Weight::Medium, Role::AccentBright);
        date->fill = false;
        if (Player *pl = Media::get().player()) {
            auto *m = c->add<Card>(Dir::Row, 16);
            m->fill = false;
            m->mt = 90;
            m->fixedW = 460;
            m->fixedH = 92;
            m->radius = 22;
            m->padding(14);
            auto *art = m->add<ImageW>();
            art->fixedW = art->fixedH = 64;
            art->radius = 12;
            art->image = Media::get().art;
            art->placeholder = t.surface3;
            art->placeholderIcon = "music";
            auto *txt = col(m, 2);
            txt->grow = 1;
            txt->justify = Justify::Center;
            txt->add<Label>(pl->title, 15, Weight::DemiBold);
            txt->add<Label>(pl->artist, 13, Weight::Normal, Role::Text2);
            auto *prev = m->add<IconButton>("prev", 34, 18);
            prev->bg = Color{0, 0, 0, 0};
            prev->onClick = [] { Media::get().previous(); };
            auto *play = m->add<IconButton>(pl->playing ? "pause" : "play", 36, 16);
            play->radius = 18;
            play->bg = t.text;
            play->icon->role = Role::Custom;
            play->icon->color = Color::hex("#15141b");
            play->onClick = [] { Media::get().playPause(); };
            auto *next = m->add<IconButton>("next", 34, 18);
            next->bg = Color{0, 0, 0, 0};
            next->onClick = [] { Media::get().next(); };
            auto places = cfg().j("vizPlaces");
            if (pl->playing && places.is_array() && std::find(places.begin(), places.end(), "lock") != places.end()) {
                auto *viz = c->add<Visualizer>();
                viz->fill = false;
                viz->fixedW = 460;
                viz->fixedH = 60;
                viz->mt = 14;
            }
        }
        stretch(c);
        auto *hint = c->add<Label>("Press any key or click to unlock", 14);
        hint->role = Role::Custom;
        hint->color = Color{1, 1, 1, 0.62};
        hint->fill = false;
        hint->mb = 44;
    } else {
        // ---- auth ----
        auto *c = v->add<Box>(Dir::Column, 18);
        c->justify = Justify::Center;
        c->crossAlign = Align::Center;
        auto *av = c->add<Avatar>();
        av->fill = false;
        av->face = d->face;
        std::string u = userName();
        av->letter = std::string(1, (char)toupper(u[0]));
        auto *name = c->add<Label>(u, 26, Weight::DemiBold);
        name->role = Role::Custom;
        name->color = Color{1, 1, 1, 1};
        name->fill = false;
        auto *field = c->add<Card>(Dir::Row, 10);
        field->fill = false;
        field->fixedW = 380;
        field->fixedH = 54;
        field->radius = 27;
        field->pl = 22;
        field->pr = 6;
        field->shadow = false;
        pass = field->add<TextInput>();
        pass->framed = false;
        pass->password = !d->showPass;
        pass->fontSize = d->showPass ? 16 : 22;
        pass->grow = 1;
        pass->onSubmit = [d, pass](const std::string &s) { std::string x = s; pass->setText(""); submit(d, x); };
        pass->onKeyFirst = [d](const KeyEvent &e) {
            if (e.pressed && e.sym == key::Escape) { d->auth = false; d->error.clear(); d->rebuildAll(); return true; }
            return false;
        };
        auto *eye = field->add<IconButton>("eye", 30, 18);
        eye->bg = Color{0, 0, 0, 0};
        if (d->showPass) eye->icon->role = Role::AccentBright;
        eye->onClick = [d] { d->showPass = !d->showPass; d->rebuildAll(); };
        auto *go = field->add<IconButton>("arrow", 42, 18);
        go->radius = 21;
        go->bg = t.accent;
        go->hoverBg = t.accentBright;
        go->icon->role = Role::OnAccent;
        go->onClick = [d, pass] { std::string x = pass->text(); pass->setText(""); submit(d, x); };
        std::string msg = !d->error.empty() ? d->error : ipc().capsLock || Wayland::get().capsLock ? "Caps Lock is on" : d->checking ? "Checking…" : "";
        auto *m = c->add<Label>(msg.empty() ? " " : msg, 13);
        m->role = Role::Custom;
        m->color = d->error.empty() ? t.accentBright : Color::hex("#ff8a7a");
        m->fill = false;
        if (!d->error.empty()) {
            // shake the field
            field->tx.set(-12);
            field->startAnim(field->tx, 0, 260, Ease::OutBack);
        }
    }

    // ---- status corners ----
    auto *corners = v->add<Box>(Dir::Row, 0);
    corners->padding(28);
    corners->crossAlign = Align::End;
    auto *status = corners->add<Card>(Dir::Row, 16);
    status->fill = false;
    status->alignSelf = Align::End;
    status->fixedH = 44;
    status->radius = 22;
    status->padding(16, 0);
    status->shadow = false;
    if (Battery::get().present) {
        auto *b = status->add<BatteryW>();
        b->level = Battery::get().percentage / 100;
        b->charging = !Battery::get().onBattery;
    }
    status->add<IconW>("wifi", 18, Net::get().ssid.empty() && !Net::get().wired ? Role::Text3 : Role::Text);
    if (!d->auth) {
        status->add<IconW>("bell", 18);
        status->add<Label>(std::to_string(Notifications::get().all().size()), 13)->fill = false;
    }
    stretch(corners);
    auto *power = corners->add<Card>(Dir::Row, 2);
    power->fill = false;
    power->alignSelf = Align::End;
    power->fixedH = 44;
    power->radius = 22;
    power->padding(6, 0);
    power->shadow = false;
    for (auto [icon, cmd] : std::vector<std::pair<std::string, std::string>>{{"moon", "suspend"}, {"restart", "reboot"}, {"power", "poweroff"}}) {
        auto *b = power->add<IconButton>(icon, 34, 18);
        b->bg = Color{0, 0, 0, 0};
        std::string c = cmd;
        b->onClick = [c] { spawn({"systemctl", c}); };
    }
    if (d->auth) {
        auto *lv = v;
        lv->blur.set(0);
        lv->startAnim(lv->blur, 1, theme().ms(260));
    }

    w->onKey = [d, pass](const KeyEvent &e) {
        if (!e.pressed) return false;
        if (!d->auth) {
            // any key opens the password field; a typed character goes into it
            d->auth = true;
            d->typed = e.text;
            d->rebuildAll();
            return true;
        }
        (void)pass;
        return false;
    };
    if (pass) {
        if (!d->typed.empty()) { pass->setText(d->typed); }
        w->setFocus(pass);
    }
    w->relayout();
}

LockScreen &LockScreen::get() { static LockScreen l; return l; }

void LockScreen::lock() {
    if (active_) return;
    auto &sl = SessionLock::get();
    if (!sl.lock()) return;
    active_ = true;
    d = std::make_shared<Impl>();
    Impl *I = d.get();
    Size big{0, 0};
    for (auto &o : Wayland::get().outputs) big = {std::max(big.w, o->logical().w), std::max(big.h, o->logical().h)};
    if (big.w <= 0) big = {1920, 1080};
    I->sharp = wallpaperImage(big);
    if (I->sharp && I->sharp->valid()) I->blurred = std::make_shared<Image>(I->sharp->blurred(48, 0.9));
    std::string face = homeDir() + "/.face";
    if (std::filesystem::exists(face)) I->face = std::make_shared<Image>(face, 256, 256);
    I->rebuildAll = [this, I] {
        // not while an event for the old widgets is being delivered
        Loop::get().defer([this, I, keep = d] {
            if (!active_ || d.get() != I) return;
                for (auto &w : I->windows) buildView(w.get(), I, w->lockOutput());
            I->typed.clear();
        });
    };
    I->finish = [this] {
        Loop::get().defer([this] {
            SessionLock::get().unlock();
            if (d) d->windows.clear();
            Wayland::get().flush();
            active_ = false;
            d.reset();
        });
    };
    for (auto &o : Wayland::get().outputs) {
        auto w = std::make_unique<LockWindow>(o.get());
        buildView(w.get(), I, o.get());
        w->show();
        I->windows.push_back(std::move(w));
    }
    // minute clock, caps lock hint, media
    I->clock.setup(1000 * 30, [I] { if (!I->auth) I->rebuildAll(); }, true);
    I->clock.start();
    I->conns.on(ipc().ledsChanged, [I] { if (I->auth) I->rebuildAll(); });
    I->conns.on(Wayland::get().locksChanged, [I] { if (I->auth) I->rebuildAll(); });
    I->conns.on(Media::get().changed, [I] { if (!I->auth) I->rebuildAll(); });
    I->conns.on(sl.finished, [this] {
        // the compositor refused or ended the lock
        Loop::get().defer([this] {
            if (d) d->windows.clear();
            active_ = false;
            d.reset();
        });
    });
}

}  // namespace nova
