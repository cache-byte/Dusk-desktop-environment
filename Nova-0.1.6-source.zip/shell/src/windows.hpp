// The shell's surfaces, one set per monitor (see Screen in shell.hpp).
#pragma once
#include "common.hpp"
#include "shell.hpp"
#include "ui/wayland.hpp"

namespace nova {

// A layer window that sizes itself to its content (cards with a drop shadow around them).
// `margin` leaves room for the shadow; input only lands on the card itself.
class FitWindow : public ui::LayerWindow {
public:
    FitWindow(const std::string &ns, ui::Layer layer, ui::Output *out, double margin = 28);
    double margin;
    void fit(bool relayoutNow = true);  // re-measure the root and ask for that size
    void place(uint32_t anchors, int mt, int mr, int mb, int ml);   // margins of the card, not the window
    bool clickThrough = false;          // indicators: no input at all
    ui::Rect cardRect() const;
protected:
    void beforeLayout() override { fit(false); }
    int lastW_ = 0, lastH_ = 0;
    uint32_t anchorsSet_ = 0;
    int pm_[4] = {0, 0, 0, 0};
    void updateInput();
};

// Wallpaper (Background layer) and desktop icons
class Wallpaper : public ui::LayerWindow {
public:
    explicit Wallpaper(Screen *s);
    ~Wallpaper() override;
    Screen *screen;
    void reload();
private:
    Connections conns_;
    std::string shownPath_;
    int selected_ = -1;
    int deskWatch_ = 0;
    void build();
    void buildIcons(ui::Widget *layer);
};

// The pop-up area: a transparent full-screen click-catcher (closes on click outside)
// plus the card window holding the launcher / control centre / calendar / clipboard / capture bar.
class PopoutWindow {
public:
    explicit PopoutWindow(Screen *s);
    ~PopoutWindow();
    Screen *screen;
    void sync();                         // match Shell::popout
    std::string which() const { return which_; }
    // a card that isn't one of the named pop-ups (tray menus), centred on x above the panel
    void openCustom(const std::string &name, std::unique_ptr<ui::Widget> content, double x);
private:
    void present(const std::string &name, std::unique_ptr<ui::Widget> content, uint32_t anchors, int mt, int mr, int mb, int ml);
    std::string which_;
    std::unique_ptr<FitWindow> card_;
    void open(const std::string &name);
    void closeAll();
};

// Tray context menus (dbusmenu) share the pop-up area
struct TrayMenuItem;
struct TrayItem;
std::unique_ptr<ui::Widget> makeTrayMenu(const TrayMenuItem &root, std::function<TrayItem *()> item);
void showTrayMenu(Screen *s, const TrayMenuItem &root, std::function<TrayItem *()> item, double x);

// Cards shown inside the pop-up window
std::unique_ptr<ui::Widget> makeLauncher(Screen *s);
std::unique_ptr<ui::Widget> makeControlCentre(Screen *s);
std::unique_ptr<ui::Widget> makeNotificationCentre(Screen *s);
std::unique_ptr<ui::Widget> makeClipboard(Screen *s);
std::unique_ptr<ui::Widget> makeCapture(Screen *s);
std::unique_ptr<ui::Widget> makeGameOverlay(Screen *s);

// Now playing: opens from the music pill on the panel
std::unique_ptr<ui::Widget> makeNowPlaying(Screen *s);

// Notification pop-ups (toasts)
class NotificationsWindow : public FitWindow {
public:
    explicit NotificationsWindow(Screen *s);
    ~NotificationsWindow() override;
    Screen *screen;
    void sync();
private:
    Connections conns_;
    void rebuild();
};
// one notification card (toasts and the notification centre)
struct Notification;
ui::Widget *notificationCard(ui::Widget *parent, const Notification &n, bool toast);

// On-screen indicators: volume / brightness slider and lock / power / message toasts
class Osd {
public:
    explicit Osd(Screen *s);
    ~Osd();
    Screen *screen;
    void toast(const std::string &slot, const std::string &icon, const std::string &text, bool on);
    void showSlider(const std::string &kind);
private:
    struct Impl;
    std::unique_ptr<Impl> d;
};
// `nova-shell toast "Copied" clip` and friends reach every screen's Osd
void broadcastToast(const std::string &text, const std::string &icon);

// Workspace overview (Super+Tab): workspaces with their windows, drag to move
class OverviewWindow : public ui::LayerWindow {
public:
    explicit OverviewWindow(Screen *s);
    ~OverviewWindow() override;
    Screen *screen;
    void reload();
private:
    Connections conns_;
};
// the overview page itself (also used offscreen by tests)
std::unique_ptr<ui::Widget> makeOverviewView(const std::string &output, ui::Size scr, ui::Point origin, const json &windows);

// Lyrics on the desktop (under windows)
class DesktopLyricsWindow : public FitWindow {
public:
    explicit DesktopLyricsWindow(Screen *s);
    ~DesktopLyricsWindow() override;
    Screen *screen;
private:
    Connections conns_;
    void refresh();
    ui::Label *prev_ = nullptr, *cur_ = nullptr, *next_ = nullptr;
};

// Audio visualizer on the desktop
class DesktopVisualizerWindow : public ui::LayerWindow {
public:
    explicit DesktopVisualizerWindow(Screen *s);
    ~DesktopVisualizerWindow() override;
    Screen *screen;
private:
    Connections conns_;
};

// Lock screen: one LockWindow per output, PAM check, caps-lock hint
class LockScreen {
public:
    static LockScreen &get();
    void lock();
    bool locked() const { return active_; }
    struct Impl;
private:
    bool active_ = false;
    std::shared_ptr<Impl> d;
};

}  // namespace nova
