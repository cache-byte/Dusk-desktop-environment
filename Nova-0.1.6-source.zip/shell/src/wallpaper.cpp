// Background layer: the wallpaper and desktop icons from ~/Desktop.
// Video wallpapers play through mpvpaper when it is installed (the still frame is the fallback).
#include "ui/sys.hpp"
#include "windows.hpp"

#include <algorithm>
#include <filesystem>

namespace nova {

using namespace ui;
namespace fs = std::filesystem;

class WallpaperView : public Widget {
public:
    Screen *screen = nullptr;
    void paint(Painter &p) override {
        p.fill(geom, Color{0, 0, 0, 1});
        if (wallpaperIsVideo() && video) return;      // mpvpaper draws underneath; we stay transparent
        auto img = wallpaperImage({geom.w, geom.h});
        if (!img || !img->valid()) return;
        std::string fill = cfg().s("wallpaperFill", "fill");
        if (fill == "center") {
            Rect r{geom.center().x - img->width() / 2.0, geom.center().y - img->height() / 2.0, (double)img->width(), (double)img->height()};
            p.image(*img, r, 0, false);
        } else {
            p.image(*img, geom, 0, fill != "fit");
        }
    }
    bool video = false;
};

// one icon on the desktop
class DeskIcon : public Box {
public:
    DeskIcon(const fs::path &path, bool dir) : Box(Dir::Column, 8), path(path) {
        fixedW = 96;
        fixedH = 102;
        radius = 12;
        interactive = true;
        cursor = Cursor::Pointer;
        justify = Justify::Center;
        std::string n = path.filename().string(), ln = lower(n);
        std::string icon = dir ? "folder"
            : (endsWith(ln, ".png") || endsWith(ln, ".jpg") || endsWith(ln, ".jpeg") || endsWith(ln, ".webp") || endsWith(ln, ".svg")) ? "image-x-generic"
            : endsWith(ln, ".desktop") ? "application-x-executable" : "text-x-generic";
        auto *ic = add<AppIconW>(icon, 48);
        ic->fill = false;
        ic->alignSelf = Align::Center;
        if (endsWith(ln, ".desktop")) n = n.substr(0, n.size() - 8);
        label = add<Label>(n, 13);
        label->elide = Elide::Middle;
        label->hAlign = Align::Center;
        label->color = Color{1, 1, 1, 1};
        label->role = Role::Custom;
        label->fixedW = 90;
        label->fill = false;
        label->alignSelf = Align::Center;
    }
    fs::path path;
    Label *label;
    bool selected = false;
    int64_t lastClick = 0;
    void paint(Painter &p) override {
        if (selected) {
            p.fill(geom, theme().accentSoft, radius);
            p.stroke(geom, theme().accentLine, 1, radius);
        } else if (hovered) {
            p.fill(geom, Color{1, 1, 1, 0.08}, radius);
        }
        // a dark copy of the name under it, so it reads on any wallpaper
        Text t(label->text(), label->font, label->geom.w, Elide::Middle);
        p.textIn(t, label->geom.translated(0, 1), Color{0, 0, 0, 0.7}, Align::Center);
    }
};

Wallpaper::Wallpaper(Screen *s) : LayerWindow("nova-wallpaper", Layer::Background, s->output), screen(s) {
    setAnchors(AnchorTop | AnchorBottom | AnchorLeft | AnchorRight);
    setExclusiveZone(-1);
    wantBlur = false;
    build();
    conns_.on(cfg().changed, [this] { reload(); });
    std::string desk = homeDir() + "/Desktop";
    deskWatch_ = FileWatch::watch(desk, [this] { build(); });
    show();
    reload();
}

static std::map<std::string, std::shared_ptr<Process>> &videoProcs() {
    static std::map<std::string, std::shared_ptr<Process>> m;
    return m;
}

Wallpaper::~Wallpaper() {
    FileWatch::unwatch(deskWatch_);
    auto &vp = videoProcs();
    if (auto it = vp.find(screen->name()); it != vp.end()) { if (it->second) it->second->kill(); vp.erase(it); }
}

void Wallpaper::reload() {
    std::string p = wallpaperPath() + "|" + cfg().s("wallpaperFill", "fill") + "|" + (cfg().b("showDesktopIcons", false) ? "1" : "0");
    if (p == shownPath_) return;
    shownPath_ = p;
    // video: hand the screen to mpvpaper and draw nothing over it
    auto &vp = videoProcs();
    auto it = vp.find(screen->name());
    if (it != vp.end()) { if (it->second) it->second->kill(); vp.erase(it); }
    bool video = wallpaperIsVideo() && haveProgram("mpvpaper");
    if (video)
        vp[screen->name()] = Process::run({"mpvpaper", "-l", "background", "-o", "no-audio loop panscan=1.0 hwdec=auto", screen->name(), wallpaperPath()});
    if (auto *v = dynamic_cast<WallpaperView *>(root()->children().empty() ? nullptr : root()->children()[0].get())) v->video = video;
    clearColor = video ? Color{0, 0, 0, 0} : Color{0, 0, 0, 1};
    build();
}

void Wallpaper::build() {
    auto *st = setRoot<Stack>();
    auto *view = st->add<WallpaperView>();
    view->screen = screen;
    view->video = wallpaperIsVideo() && haveProgram("mpvpaper");
    view->interactive = true;
    view->onClick = [this] {
        if (selected_ < 0) return;
        selected_ = -1;
        Loop::get().defer([this, alive = aliveToken()] { if (*alive) build(); });     // not while the click is still being delivered
    };
    if (cfg().b("showDesktopIcons", false)) buildIcons(st);
    update();
}

void Wallpaper::buildIcons(Widget *layer) {
    std::vector<std::pair<fs::path, bool>> entries;
    std::error_code ec;
    for (auto &e : fs::directory_iterator(homeDir() + "/Desktop", ec)) {
        std::string n = e.path().filename().string();
        if (n.empty() || n[0] == '.') continue;
        entries.push_back({e.path(), e.is_directory(ec)});
    }
    // folders first, then by name
    std::sort(entries.begin(), entries.end(), [](auto &a, auto &b) {
        if (a.second != b.second) return a.second;
        return lower(a.first.filename().string()) < lower(b.first.filename().string());
    });
    // columns top to bottom
    Size sz = screen->output ? screen->output->logical() : Size{1920, 1080};
    int rows = std::max(1, (int)((sz.h - theme().panelHeight - 56) / 108));
    auto *grid = layer->add<Box>(Dir::Row, 6);
    grid->fill = false;
    grid->alignSelf = Align::Start;
    grid->ml = grid->mt = 28;
    grid->crossAlign = Align::Start;
    Box *column = nullptr;
    for (size_t i = 0; i < entries.size(); i++) {
        if (i % rows == 0) {
            column = grid->add<Box>(Dir::Column, 6);
            column->fill = false;
            column->alignSelf = Align::Start;
        }
        auto *ic = column->add<DeskIcon>(entries[i].first, entries[i].second);
        ic->selected = (int)i == selected_;
        int idx = (int)i;
        ic->onClick = [this, ic, idx] {
            int64_t now = nowMs();
            if (now - ic->lastClick < 400) { spawn({"xdg-open", ic->path.string()}); ic->lastClick = 0; return; }
            ic->lastClick = now;
            selected_ = idx;
            for (auto &c : ic->parent()->parent()->children())
                for (auto &w : c->children())
                    if (auto *d = dynamic_cast<DeskIcon *>(w.get())) { d->selected = d == ic; d->update(); }
        };
    }
}

}  // namespace nova
