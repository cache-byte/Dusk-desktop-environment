#include "backend.hpp"
#include "ui/paint.hpp"

#include <cairo.h>
#include <cerrno>
#include <cmath>
#include <csignal>
#include <ctime>
#include <fcntl.h>
#include <filesystem>
#include <poll.h>
#include <regex>
#include <set>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef NOVA_VERSION
#define NOVA_VERSION "dev"
#endif

namespace settings {

using namespace ui;
namespace fs = std::filesystem;

static std::string cfgDir() { return configDir() + "/nova"; }

Backend &Backend::get() {
    static Backend b;
    static bool once = false;
    if (!once) { once = true; b.load(); }
    return b;
}

std::string Backend::settingsPath() const { return cfgDir() + "/settings.json"; }
std::string Backend::confPath() const { return cfgDir() + "/nova.conf"; }

void Backend::load() {
    std::error_code ec;
    fs::create_directories(cfgDir(), ec);
    if (defaults_.empty()) {
        for (const char *p : {"/usr/share/nova/defaults.json", "/usr/local/share/nova/defaults.json"}) {
            bool ok = false;
            std::string t = readFile(p, &ok);
            if (!ok) continue;
            try {
                json d = json::parse(t);
                defaults_ = d.value("values", json::object());
                groups_ = d.value("groups", json::object());
                confGroups_ = d.value("confGroups", json::object());
                break;
            } catch (...) {}
        }
    }
    bool ok = false;
    std::string t = readFile(settingsPath(), &ok);
    settings_ = json::object();
    if (ok) try { settings_ = json::parse(t); } catch (...) {}
    if (!settings_.is_object()) settings_ = json::object();
    if (!watch_) {
        // the shell (or an editor) changed settings.json
        watch_ = FileWatch::watch(settingsPath(), [this] {
            if (nowMs() - ownWrite_ < 400) return;
            load();
            changed.emit();
        });
    }
}

json Backend::value(const std::string &key) const {
    auto it = settings_.find(key);
    if (it != settings_.end() && !it->is_null()) return *it;
    return defaultValue(key);
}
json Backend::defaultValue(const std::string &key) const {
    auto it = defaults_.find(key);
    return it == defaults_.end() ? json() : *it;
}
void Backend::set(const std::string &key, const json &v) {
    settings_[key] = v;
    writeSettings();
}
void Backend::writeSettings() {
    ownWrite_ = nowMs();
    writeFile(settingsPath(), settings_.dump(2) + "\n");
    changed.emit();
}
bool Backend::isDefault(const std::string &key) const {
    if (!settings_.contains(key) || !defaults_.contains(key)) return true;
    return settings_[key] == defaults_[key];
}
void Backend::reset(const std::string &key) {
    if (!defaults_.contains(key)) return;
    settings_[key] = defaults_[key];
    writeSettings();
    if (groups_.contains("appearance") && groups_["appearance"].is_array())
        for (auto &k : groups_["appearance"]) if (k == key) { applyDesktopTheme(); break; }
    reloadPage.emit();
}

// ---------------------------------------------------------------- nova.conf --
static std::string iniValue(const std::string &text, const std::string &section, const std::string &key, bool *found = nullptr) {
    std::string cur;
    if (found) *found = false;
    for (auto &raw : split(text, '\n')) {
        std::string l = trim(raw);
        if (l.size() > 1 && l.front() == '[' && l.back() == ']') { cur = l.substr(1, l.size() - 2); continue; }
        if (cur != section || l.empty() || l[0] == '#') continue;
        auto eq = l.find('=');
        if (eq != std::string::npos && eq > 0 && trim(l.substr(0, eq)) == key) {
            if (found) *found = true;
            return trim(l.substr(eq + 1));
        }
    }
    return "";
}

std::string Backend::conf(const std::string &section, const std::string &key, const std::string &fallback) const {
    bool found = false;
    std::string v = iniValue(readFile(confPath()), section, key, &found);
    return found ? v : fallback;
}

void Backend::setConf(const std::string &section, const std::string &key, const std::string &value) {
    setConfQuiet(section, key, value);
    runDetached({"novactl", "dispatch", "reload"});
    changed.emit();
}

void Backend::setConfQuiet(const std::string &section, const std::string &key, const std::string &value) {
    bool ok = false;
    std::string text = readFile(confPath(), &ok);
    std::vector<std::string> lines = ok ? split(text, '\n') : std::vector<std::string>{};
    std::string cur;
    int sectionEnd = -1;
    bool done = false;
    for (size_t i = 0; i < lines.size() && !done; i++) {
        std::string t = trim(lines[i]);
        if (t.size() > 1 && t.front() == '[' && t.back() == ']') { cur = t.substr(1, t.size() - 2); continue; }
        if (cur != section) continue;
        sectionEnd = (int)i;
        auto eq = t.find('=');
        if (eq != std::string::npos && eq > 0 && t[0] != '#' && trim(t.substr(0, eq)) == key) { lines[i] = key + " = " + value; done = true; }
    }
    if (!done) {
        if (sectionEnd >= 0) lines.insert(lines.begin() + sectionEnd + 1, key + " = " + value);
        else { lines.push_back(""); lines.push_back("[" + section + "]"); lines.push_back(key + " = " + value); }
    }
    std::string out;
    for (size_t i = 0; i < lines.size(); i++) out += lines[i] + (i + 1 < lines.size() ? "\n" : "");
    writeFile(confPath(), out);
}

// the compositor prints its built-in nova.conf with `nova -c`
static const std::string &defaultConfText() {
    static std::string cached;
    if (cached.empty()) cached = Backend::run({"nova", "-c"}, 3000);
    return cached;
}
std::string Backend::confDefault(const std::string &section, const std::string &key) const {
    return iniValue(defaultConfText(), section, key);
}
bool Backend::isConfDefault(const std::string &section, const std::string &key) const {
    std::string d = confDefault(section, key);
    return conf(section, key, d) == d;
}
void Backend::resetConf(const std::string &section, const std::string &key) {
    setConf(section, key, confDefault(section, key));
    reloadPage.emit();
}

// ---------------------------------------------------------------- processes --
RunResult Backend::runFull(const std::vector<std::string> &argv, int timeoutMs) {
    RunResult r;
    if (argv.empty()) return r;
    int out[2], err[2];
    if (pipe2(out, O_CLOEXEC) < 0) return r;
    if (pipe2(err, O_CLOEXEC) < 0) { close(out[0]); close(out[1]); return r; }
    pid_t pid = fork();
    if (pid == 0) {
        setpgid(0, 0);
        dup2(out[1], 1);
        dup2(err[1], 2);
        int nul = open("/dev/null", O_RDONLY);
        if (nul >= 0) dup2(nul, 0);
        std::vector<char *> a;
        for (auto &s : argv) a.push_back(const_cast<char *>(s.c_str()));
        a.push_back(nullptr);
        execvp(a[0], a.data());
        _exit(127);
    }
    close(out[1]);
    close(err[1]);
    if (pid < 0) { close(out[0]); close(err[0]); return r; }
    int64_t deadline = nowMs() + timeoutMs;
    pollfd fds[2] = {{out[0], POLLIN, 0}, {err[0], POLLIN, 0}};
    int open_ = 2;
    char buf[8192];
    while (open_ > 0) {
        int left = (int)(deadline - nowMs());
        if (left <= 0) break;
        int n = poll(fds, 2, left);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        for (int i = 0; i < 2; i++) {
            if (fds[i].fd < 0 || !(fds[i].revents & (POLLIN | POLLHUP | POLLERR))) continue;
            ssize_t k = read(fds[i].fd, buf, sizeof buf);
            if (k > 0) (i ? r.err : r.out).append(buf, k);
            else { fds[i].fd = -1; open_--; }
        }
    }
    close(out[0]);
    close(err[0]);
    int st = 0;
    if (open_ > 0) {   // timed out
        kill(-pid, SIGKILL);
        waitpid(pid, &st, 0);
        r.code = -1;
        return r;
    }
    waitpid(pid, &st, 0);
    r.code = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    return r;
}

void Backend::runAsync(const std::vector<std::string> &argv, std::function<void(const std::string &)> done) {
    Process::run(argv, [done](int, const std::string &out) { if (done) done(out); });
}

// ---------------------------------------------------------------- appearance --
static std::vector<std::string> iconDirs() {
    return {homeDir() + "/.local/share/icons", homeDir() + "/.icons", "/usr/share/icons"};
}
static std::vector<std::string> sortedUnique(std::vector<std::string> v) {
    std::sort(v.begin(), v.end(), [](const std::string &a, const std::string &b) { return lower(a) < lower(b); });
    v.erase(std::unique(v.begin(), v.end()), v.end());
    return v;
}
std::vector<std::string> Backend::iconThemes() const {
    std::vector<std::string> out;
    std::error_code ec;
    for (auto &d : iconDirs())
        for (auto &e : fs::directory_iterator(d, ec)) {
            std::string t = e.path().filename().string();
            if (t == "default" || t == "hicolor" || t == "locolor") continue;
            if (fs::exists(e.path() / "index.theme") && !fs::exists(e.path() / "cursors")) out.push_back(t);
        }
    return sortedUnique(out);
}
std::vector<std::string> Backend::cursorThemes() const {
    std::vector<std::string> out;
    std::error_code ec;
    for (auto &d : iconDirs())
        for (auto &e : fs::directory_iterator(d, ec))
            if (fs::exists(e.path() / "cursors")) out.push_back(e.path().filename().string());
    return sortedUnique(out);
}
std::vector<std::string> Backend::fonts(bool monospace) const {
    std::string all = run({"fc-list", monospace ? ":spacing=mono" : ":", "family"}, 5000);
    if (!monospace) {
        // everything that isn't monospace
        std::set<std::string> mono;
        for (auto &l : split(run({"fc-list", ":spacing=mono", "family"}, 5000), '\n')) mono.insert(trim(split(l, ',')[0]));
        std::vector<std::string> out;
        for (auto &l : split(all, '\n')) {
            std::string f = trim(split(l, ',')[0]);
            if (!f.empty() && !mono.count(f)) out.push_back(f);
        }
        return sortedUnique(out);
    }
    std::vector<std::string> out;
    for (auto &l : split(all, '\n')) { std::string f = trim(split(l, ',')[0]); if (!f.empty()) out.push_back(f); }
    return sortedUnique(out);
}
std::string Backend::wallpaperDir() const {
    std::string pics = trim(run({"xdg-user-dir", "PICTURES"}, 2000));
    if (pics.empty() || pics == homeDir()) pics = homeDir() + "/Pictures";
    return pics + "/Wallpapers";
}
json Backend::wallpapers() const {
    json out = json::array();
    std::error_code ec;
    std::vector<fs::path> bundled;
    for (auto &e : fs::directory_iterator("/usr/share/nova/shell/assets/wallpapers", ec)) bundled.push_back(e.path());
    std::sort(bundled.begin(), bundled.end());
    for (auto &p : bundled) {
        std::string l = lower(p.string());
        if (endsWith(l, ".jpg") || endsWith(l, ".png")) out.push_back({{"path", p.string()}, {"video", false}, {"bundled", true}});
    }
    std::vector<fs::path> mine;
    for (auto it = fs::recursive_directory_iterator(wallpaperDir(), ec); !ec && it != fs::recursive_directory_iterator(); it.increment(ec))
        if (it->is_regular_file(ec)) mine.push_back(it->path());
    std::sort(mine.begin(), mine.end());
    for (auto &p : mine) {
        std::string l = lower(p.string());
        bool img = endsWith(l, ".png") || endsWith(l, ".jpg") || endsWith(l, ".jpeg") || endsWith(l, ".webp") || endsWith(l, ".bmp");
        bool vid = endsWith(l, ".mp4") || endsWith(l, ".webm") || endsWith(l, ".mkv") || endsWith(l, ".mov");
        if (img || vid) out.push_back({{"path", p.string()}, {"video", vid}});
    }
    return out;
}

// Most "colourful" frequent hue in the image, nudged to a usable accent.
std::string Backend::accentFromImage(const std::string &path) const {
    Image im(path, 96, 96);
    if (!im.valid()) return "";
    cairo_surface_flush(im.surface());
    unsigned char *data = cairo_image_surface_get_data(im.surface());
    int w = im.width(), h = im.height(), stride = cairo_image_surface_get_stride(im.surface());
    double bins[36] = {}, sat[36] = {}, val[36] = {};
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            uint32_t px = *(uint32_t *)(data + y * stride + x * 4);
            double r = ((px >> 16) & 255) / 255.0, g = ((px >> 8) & 255) / 255.0, b = (px & 255) / 255.0;
            double mx = std::max({r, g, b}), mn = std::min({r, g, b}), dl = mx - mn;
            double s = mx > 0 ? dl / mx : 0, v = mx;
            if (s < 0.25 || v < 0.25 || dl <= 0) continue;
            double hh = mx == r ? std::fmod((g - b) / dl, 6.0) : mx == g ? (b - r) / dl + 2 : (r - g) / dl + 4;
            hh /= 6;
            if (hh < 0) hh += 1;
            int bi = std::min(35, (int)(hh * 36));
            double wt = s * v;
            bins[bi] += wt;
            sat[bi] += s * wt;
            val[bi] += v * wt;
        }
    int best = 0;
    for (int i = 1; i < 36; i++) if (bins[i] > bins[best]) best = i;
    if (bins[best] <= 0) return "#c8b64a";
    double H = (best + 0.5) / 36.0, S = std::clamp(sat[best] / bins[best], 0.45, 0.75), V = std::clamp(val[best] / bins[best], 0.70, 0.88);
    // hsv -> rgb
    double c = V * S, x = c * (1 - std::fabs(std::fmod(H * 6, 2) - 1)), m = V - c;
    double r = 0, g = 0, b = 0;
    int k = (int)(H * 6) % 6;
    if (k == 0) { r = c; g = x; } else if (k == 1) { r = x; g = c; } else if (k == 2) { g = c; b = x; }
    else if (k == 3) { g = x; b = c; } else if (k == 4) { r = x; b = c; } else { r = c; b = x; }
    return Color{r + m, g + m, b + m, 1}.toHex();
}

void Backend::applyDesktopTheme() {
    auto gs = [](const std::string &k, const std::string &v) { runDetached({"gsettings", "set", "org.gnome.desktop.interface", k, v}); };
    std::string icon = s("iconTheme", "Papirus-Dark"), cursor = s("cursorTheme", "Bibata-Modern-Classic");
    int csize = (int)d("cursorSize", 24), fsize = (int)d("fontSize", 14);
    std::string font = s("font", "Inter"), mono = s("monoFont", "JetBrains Mono"), mode = s("mode", "dark");
    gs("icon-theme", icon);
    gs("cursor-theme", cursor);
    gs("cursor-size", std::to_string(csize));
    // gsettings wants points; the UI shows px (1pt = 4/3 px at 96 dpi)
    gs("font-name", font + " " + std::to_string(std::lround(fsize * 0.75)));
    gs("monospace-font-name", mono + " " + std::to_string(std::lround(fsize * 0.75)));
    gs("color-scheme", mode == "light" ? "prefer-light" : "prefer-dark");
    gs("accent-color", "yellow");
    runDetached({"novactl", "dispatch", "cursor", cursor, std::to_string(csize)});
    runDetached({"nova-theme", "apply"});
    setConfQuiet("cursor", "theme", cursor);
    setConf("cursor", "size", std::to_string(csize));
}

// --------------------------------------------------------------- connections --
static std::vector<std::string> splitTerse(const std::string &line) {
    // nmcli -t escapes ':' as '\:'
    std::vector<std::string> out;
    std::string cur;
    for (size_t i = 0; i < line.size(); i++) {
        if (line[i] == '\\' && i + 1 < line.size()) { cur += line[++i]; continue; }
        if (line[i] == ':') { out.push_back(cur); cur.clear(); continue; }
        cur += line[i];
    }
    out.push_back(cur);
    return out;
}
json Backend::wifiNetworks(bool rescan) const {
    json out = json::array();
    std::set<std::string> seen;
    std::string txt = run({"nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", rescan ? "yes" : "auto"}, 8000);
    for (auto &l : split(txt, '\n')) {
        auto p = splitTerse(l);
        if (p.size() < 4 || p[1].empty() || seen.count(p[1])) continue;
        seen.insert(p[1]);
        out.push_back({{"active", p[0] == "*"}, {"ssid", p[1]}, {"signal", atoi(p[2].c_str())}, {"secure", !p[3].empty() && p[3] != "--"}});
    }
    return out;
}
bool Backend::wifiEnabled() const { return trim(run({"nmcli", "radio", "wifi"})) == "enabled"; }
std::string Backend::wifiConnect(const std::string &ssid, const std::string &password) const {
    std::vector<std::string> cmd = {"nmcli", "dev", "wifi", "connect", ssid};
    if (!password.empty()) { cmd.push_back("password"); cmd.push_back(password); }
    RunResult r = runFull(cmd, 20000);
    return r.code == 0 ? "" : trim(r.err.empty() ? "Couldn't connect" : r.err);
}
json Backend::bluetoothDevices() const {
    json out = json::array();
    std::string list = run({"bluetoothctl", "devices"}), paired = run({"bluetoothctl", "devices", "Paired"});
    static const std::regex bat("Battery Percentage: 0x[0-9a-fA-F]+ \\((\\d+)\\)"), icon("Icon: (\\S+)");
    for (auto &l : split(list, '\n')) {
        auto p = split(trim(l), ' ');
        if (p.size() < 3 || p[0] != "Device") continue;
        std::string mac = p[1], name;
        for (size_t i = 2; i < p.size(); i++) name += (i > 2 ? " " : "") + p[i];
        std::string info = run({"bluetoothctl", "info", mac}, 2000);
        std::smatch bm, im;
        bool hb = std::regex_search(info, bm, bat), hi = std::regex_search(info, im, icon);
        out.push_back({{"mac", mac}, {"name", name}, {"paired", paired.find(mac) != std::string::npos},
                       {"connected", info.find("Connected: yes") != std::string::npos},
                       {"battery", hb ? atoi(bm[1].str().c_str()) : -1}, {"icon", hi ? im[1].str() : "bluetooth"}});
    }
    return out;
}
bool Backend::bluetoothPowered() const { return run({"bluetoothctl", "show"}).find("Powered: yes") != std::string::npos; }
json Backend::vpnConnections() const {
    json out = json::array();
    for (auto &l : split(run({"nmcli", "-t", "-f", "NAME,TYPE,ACTIVE", "con", "show"}), '\n')) {
        auto p = splitTerse(l);
        if (p.size() >= 3 && (p[1] == "vpn" || p[1] == "wireguard")) out.push_back({{"name", p[0]}, {"type", p[1]}, {"active", p[2] == "yes"}});
    }
    return out;
}
json Backend::wiredStatus() const {
    for (auto &l : split(run({"nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "dev"}), '\n')) {
        auto p = splitTerse(l);
        if (p.size() >= 4 && p[1] == "ethernet") return {{"device", p[0]}, {"connected", p[2] == "connected"}, {"state", p[2]}, {"connection", p[3]}};
    }
    return {{"device", ""}, {"connected", false}, {"state", "unavailable"}, {"connection", ""}};
}

// ------------------------------------------------------------------ displays --
json Backend::displays() const {
    json out = json::array();
    json doc;
    try { doc = json::parse(run({"wlr-randr", "--json"})); } catch (...) { return out; }
    if (!doc.is_array()) return out;
    for (auto &o : doc) {
        json d;
        d["name"] = o.value("name", "");
        d["description"] = o.value("description", "");
        d["make"] = o.value("make", "");
        d["model"] = o.value("model", "");
        d["enabled"] = o.value("enabled", false);
        d["scale"] = o.value("scale", 1.0);
        d["transform"] = o.value("transform", std::string("normal"));
        json pos = o.value("position", json::object());
        d["x"] = pos.value("x", 0);
        d["y"] = pos.value("y", 0);
        d["adaptiveSync"] = o.value("adaptive_sync", false);
        json phys = o.value("physical_size", json::object());
        double diag = std::hypot(phys.value("width", 0.0), phys.value("height", 0.0)) / 25.4;
        char b[16];
        snprintf(b, sizeof b, "%.1f", diag);
        d["inches"] = diag > 1 ? std::string(b) : "";
        std::string n = d["name"];
        d["builtin"] = startsWith(n, "eDP") || startsWith(n, "LVDS");
        json modes = json::array();
        for (auto &m : o.value("modes", json::array())) {
            json mm = {{"width", m.value("width", 0)}, {"height", m.value("height", 0)}, {"refresh", m.value("refresh", 0.0)},
                       {"preferred", m.value("preferred", false)}, {"current", m.value("current", false)}};
            modes.push_back(mm);
            if (mm["current"]) d["mode"] = mm;
        }
        d["modes"] = modes;
        out.push_back(d);
    }
    return out;
}
std::string Backend::applyDisplay(const json &d) {
    std::string name = d.value("name", "");
    std::vector<std::string> cmd = {"wlr-randr", "--output", name};
    char b[64];
    double scale = std::clamp(d.value("scale", 1.0), 1.0, 2.0);   // Nova caps scale at 200 %
    if (!d.value("enabled", true)) cmd.push_back("--off");
    else {
        cmd.push_back("--on");
        if (d.contains("mode") && d["mode"].is_object()) {
            const json &m = d["mode"];
            snprintf(b, sizeof b, "%dx%d@%.3fHz", m.value("width", 0), m.value("height", 0), m.value("refresh", 60.0));
            cmd.push_back("--mode");
            cmd.push_back(b);
        }
        snprintf(b, sizeof b, "%.2f", scale);
        cmd.insert(cmd.end(), {"--scale", b, "--transform", d.value("transform", std::string("normal")),
                               "--pos", std::to_string(d.value("x", 0)) + "," + std::to_string(d.value("y", 0))});
        if (d.value("adaptiveSync", false)) cmd.insert(cmd.end(), {"--adaptive-sync", "enabled"});
    }
    RunResult r = runFull(cmd, 5000);
    if (r.code != 0) return trim(r.err.empty() ? "wlr-randr failed" : r.err);
    // remember it for the next login ([output NAME] in nova.conf)
    if (d.value("enabled", true)) {
        std::string sec = "output " + name;
        if (d.contains("mode") && d["mode"].is_object()) {
            const json &m = d["mode"];
            snprintf(b, sizeof b, "%dx%d@%.3f", m.value("width", 0), m.value("height", 0), m.value("refresh", 60.0));
            setConfQuiet(sec, "mode", b);
        }
        snprintf(b, sizeof b, "%.2f", scale);
        setConfQuiet(sec, "scale", b);
        setConfQuiet(sec, "position", std::to_string(d.value("x", 0)) + "," + std::to_string(d.value("y", 0)));
        setConfQuiet(sec, "transform", d.value("transform", std::string("normal")));
    }
    return "";
}

json Backend::systemInfo() const {
    json m;
    std::string osr = readFile("/etc/os-release");
    std::string pretty = "Linux";
    for (auto &l : split(osr, '\n'))
        if (startsWith(l, "PRETTY_NAME=")) { pretty = l.substr(12); if (pretty.size() > 1 && pretty[0] == '"') pretty = pretty.substr(1, pretty.size() - 2); }
    m["os"] = pretty;
    utsname u{};
    uname(&u);
    m["kernel"] = u.release;
    m["host"] = u.nodename;
    int cores = 0;
    std::string cpu;
    for (auto &l : split(readFile("/proc/cpuinfo"), '\n')) {
        if (startsWith(l, "model name") && cpu.empty()) cpu = trim(l.substr(l.find(':') + 1));
        if (startsWith(l, "processor")) cores++;
    }
    m["cpu"] = cpu;
    m["cores"] = cores;
    std::string mem = split(readFile("/proc/meminfo"), '\n')[0];
    double kb = atof(trim(mem.substr(mem.find(':') + 1)).c_str());
    char b[32];
    snprintf(b, sizeof b, "%.1f GB", kb / 1048576.0);
    m["memory"] = b;
    std::string gpu = trim(run({"sh", "-c", "lspci 2>/dev/null | grep -Ei 'vga|3d|display' | cut -d: -f3 | sed 's/^ *//' | paste -sd'+' | sed 's/+/  +  /g'"}));
    m["gpu"] = gpu.empty() ? "Unknown" : gpu;
    m["desktop"] = "Nova " + installedVersion() + " (Wayland)";
    return m;
}

// --------------------------------------------------------------------- reset --
json Backend::resetGroups() const {
    static const std::vector<std::array<std::string, 3>> rows = {
        {"appearance", "Appearance", "Theme, accent, wallpaper, fonts, icons, cursor"},
        {"panel", "Panel & launcher", "Pinned apps, clock, desktop icons"},
        {"controlcentre", "Control centre layout", "Tile positions and sizes"},
        {"popups", "Popups & indicators", "Where OSDs and pop-ups appear"},
        {"notifications", "Notifications", "Do not disturb, grouping, timing"},
        {"sound", "Sound", "Volume above 100 %"},
        {"power", "Power & idle", "Dim, lock and sleep times, GPU choice"},
        {"music", "Music & lyrics", "Lyric and visualizer styles"},
        {"gaming", "Gaming & capture", "Game mode, replay, recording"},
        {"clipboard", "Clipboard", "History size and keeping it"},
        {"keyboard", "Keyboard, mouse & touchpad", "Layout, repeat, scrolling, tap to click, gestures"},
        {"shortcuts", "Keyboard shortcuts", "Every key binding"},
        {"windows", "Windows & tiling", "Gaps, focus, snapping"},
        {"updates", "Update channel", "Release or latest"}};
    json out = json::array();
    for (auto &r : rows) out.push_back({{"id", r[0]}, {"label", r[1]}, {"hint", r[2]}});
    return out;
}

static std::string stamp() {
    time_t t = time(nullptr);
    tm lt;
    localtime_r(&t, &lt);
    char b[32];
    strftime(b, sizeof b, "%Y-%m-%d_%H-%M-%S", &lt);
    return b;
}

std::string Backend::resetSelected(const std::vector<std::string> &groups) {
    std::string dir = cfgDir() + "/backup/reset-" + stamp();
    std::error_code ec;
    fs::create_directories(dir, ec);
    fs::copy_file(settingsPath(), dir + "/settings.json", ec);
    fs::copy_file(confPath(), dir + "/nova.conf", ec);
    bool appearance = false;
    for (auto &g : groups) {
        if (groups_.contains(g) && groups_[g].is_array())
            for (auto &k : groups_[g])
                if (k.is_string() && defaults_.contains(k.get<std::string>())) settings_[k.get<std::string>()] = defaults_[k.get<std::string>()];
        if (g == "appearance") appearance = true;
    }
    writeSettings();
    std::set<std::string> sections;
    for (auto &g : groups)
        if (confGroups_.contains(g) && confGroups_[g].is_array())
            for (auto &s : confGroups_[g]) sections.insert(s.get<std::string>());
    if (!sections.empty()) {
        std::vector<std::string> kept;
        std::string cur;
        for (auto &raw : split(readFile(confPath()), '\n')) {
            std::string t = trim(raw);
            if (t.size() > 1 && t.front() == '[' && t.back() == ']') cur = t.substr(1, t.size() - 2);
            if (!sections.count(cur)) kept.push_back(raw);
        }
        for (auto &raw : split(defaultConfText(), '\n')) {
            std::string t = trim(raw);
            if (t.size() > 1 && t.front() == '[' && t.back() == ']') cur = t.substr(1, t.size() - 2);
            if (sections.count(cur)) kept.push_back(raw);
        }
        std::string out;
        for (auto &l : kept) out += l + "\n";
        writeFile(confPath(), out);
        runDetached({"novactl", "dispatch", "reload"});
    }
    if (appearance) applyDesktopTheme();
    reloadPage.emit();
    return dir;
}
std::vector<std::string> Backend::resetBackups() const {
    std::vector<std::string> out;
    std::error_code ec;
    for (auto &e : fs::directory_iterator(cfgDir() + "/backup", ec))
        if (startsWith(e.path().filename().string(), "reset-")) out.push_back(e.path().string());
    std::sort(out.rbegin(), out.rend());
    return out;
}
void Backend::restoreBackup(const std::string &dir) {
    std::error_code ec;
    if (fs::exists(dir + "/settings.json")) {
        fs::copy_file(dir + "/settings.json", settingsPath(), fs::copy_options::overwrite_existing, ec);
        load();
    }
    if (fs::exists(dir + "/nova.conf")) {
        fs::copy_file(dir + "/nova.conf", confPath(), fs::copy_options::overwrite_existing, ec);
        runDetached({"novactl", "dispatch", "reload"});
    }
    applyDesktopTheme();
    changed.emit();
    reloadPage.emit();
}

// ------------------------------------------------------------------- updates --
std::string Backend::installedVersion() const {
    bool ok = false;
    std::string v = trim(readFile("/usr/share/nova/VERSION", &ok));
    return ok && !v.empty() ? v : NOVA_VERSION;
}
void Backend::openInTerminal(const std::string &shellCommand) const {
    std::string term = conf("general", "terminal", "ptyxis");
    std::string cmd = shellCommand + "; echo; read -r -p 'Press Enter to close' _";
    if (term == "ptyxis" || term == "gnome-terminal" || term == "kgx" || term == "kitty") runDetached({term, "--", "sh", "-c", cmd});
    else runDetached({term, "-e", "sh", "-c", cmd});
}
// `nova-update --gui` prints "::step 2 8 Title", "::task Label", "::ok Label", "::fail Label",
// "::warn Text", "::notes JSON", "::done Title"; the polkit dialog asks for the password.
bool Backend::startUpdate(bool force, std::function<void(const std::string &)> line, std::function<void(int)> finished) {
    if (update_) return false;
    std::vector<std::string> argv = {"sh", "-c", "exec nova-update --gui \"$@\" 2>&1", "sh"};
    if (force) argv.push_back("--force");
    update_ = Process::lines(argv, line, [this, finished](int code, const std::string &) {
        update_.reset();
        if (finished) finished(code);
    });
    return update_ != nullptr;
}
void Backend::cancelUpdate() { if (update_) update_->kill(); }
void Backend::uninstall(bool removeDeps, bool purge) const {
    std::string c = "nova-uninstall";
    if (removeDeps) c += " --remove-deps";
    if (purge) c += " --purge";
    openInTerminal(c);
}

// ------------------------------------------------------------------ shortcuts --
std::string Backend::normalizeCombo(const std::string &combo) {
    // "shift+super+a" -> "Super+Shift+A": fixed modifier order so duplicates are easy to spot
    static const std::vector<std::string> order = {"Super", "Ctrl", "Alt", "Shift"};
    std::vector<std::string> parts;
    for (auto &p : split(combo, '+')) if (!trim(p).empty()) parts.push_back(trim(p));
    if (parts.empty()) return "";
    std::string key = parts.back();
    parts.pop_back();
    if (parts.empty() && lower(key) == "super") return "Super";
    std::vector<std::string> mods;
    for (auto &m : order)
        for (auto &p : parts) {
            std::string l = lower(p);
            std::string canon = (l == "mod4" || l == "logo" || l == "win") ? "super" : l == "control" ? "ctrl" : l == "mod1" ? "alt" : l;
            if (canon == lower(m) && std::find(mods.begin(), mods.end(), m) == mods.end()) mods.push_back(m);
        }
    if (key.size() == 1) key[0] = (char)toupper(key[0]);
    mods.push_back(key);
    std::string out;
    for (size_t i = 0; i < mods.size(); i++) out += (i ? "+" : "") + mods[i];
    return out;
}
static std::vector<std::pair<std::string, std::string>> parseBindings(const std::string &text) {
    std::vector<std::pair<std::string, std::string>> out;
    std::string cur;
    for (auto &raw : split(text, '\n')) {
        std::string l = trim(raw);
        if (l.size() > 1 && l.front() == '[' && l.back() == ']') { cur = l.substr(1, l.size() - 2); continue; }
        if (cur != "bindings" || l.empty() || l[0] == '#') continue;
        auto eq = l.find('=');
        if (eq != std::string::npos && eq > 0) out.push_back({trim(l.substr(0, eq)), trim(l.substr(eq + 1))});
    }
    return out;
}
std::vector<Backend::Binding> Backend::defaultBindings() const {
    std::vector<Binding> out;
    for (auto &[c, a] : parseBindings(defaultConfText())) out.push_back({normalizeCombo(c), a, true});
    return out;
}
std::vector<Backend::Binding> Backend::bindings() const {
    std::string text = readFile(confPath());
    if (text.find("[bindings]") == std::string::npos) text = defaultConfText();
    std::set<std::string> defs;
    for (auto &[c, a] : parseBindings(defaultConfText())) defs.insert(normalizeCombo(c) + "=" + a);
    std::vector<Binding> out;
    for (auto &[c, a] : parseBindings(text)) {
        std::string n = normalizeCombo(c);
        out.push_back({n, a, defs.count(n + "=" + a) > 0});
    }
    return out;
}
// rewrites the [bindings] section of nova.conf line by line, keeping comments
static void editBindings(const std::string &path, const std::function<void(std::vector<std::string> &, int, int)> &fn) {
    std::vector<std::string> lines = split(readFile(path), '\n');
    int start = -1, end = (int)lines.size();
    for (int i = 0; i < (int)lines.size(); i++) {
        std::string t = trim(lines[i]);
        if (t == "[bindings]") start = i;
        else if (start >= 0 && t.size() > 1 && t.front() == '[' && t.back() == ']') { end = i; break; }
    }
    if (start < 0) { lines.push_back(""); lines.push_back("[bindings]"); start = (int)lines.size() - 1; end = (int)lines.size(); }
    fn(lines, start, end);
    std::string out;
    for (size_t i = 0; i < lines.size(); i++) out += lines[i] + (i + 1 < lines.size() ? "\n" : "");
    writeFile(path, out);
}
static std::string padTo(std::string s, size_t n) { while (s.size() < n) s += ' '; return s; }

std::string Backend::setBinding(const std::string &oldCombo, const std::string &newCombo, const std::string &action) {
    std::string nc = normalizeCombo(newCombo), oc = normalizeCombo(oldCombo);
    if (nc.empty() || trim(action).empty()) return "Pick a key and an action";
    for (auto &b : bindings())
        if (b.combo == nc && nc != oc) return nc + " is already used for “" + b.action + "”";
    // nova.conf may not have a [bindings] section yet: start from the defaults
    std::string text = readFile(confPath());
    if (text.find("[bindings]") == std::string::npos) {
        std::string sect;
        bool in = false;
        for (auto &raw : split(defaultConfText(), '\n')) {
            std::string t = trim(raw);
            if (t.size() > 1 && t.front() == '[' && t.back() == ']') in = t == "[bindings]";
            if (in) sect += raw + "\n";
        }
        writeFile(confPath(), text + "\n" + sect);
    }
    editBindings(confPath(), [&](std::vector<std::string> &lines, int start, int end) {
        for (int i = start + 1; i < end; i++) {
            std::string t = trim(lines[i]);
            auto eq = t.find('=');
            if (eq != std::string::npos && eq > 0 && t[0] != '#' && !oc.empty() && normalizeCombo(t.substr(0, eq)) == oc) {
                lines[i] = padTo(nc, 23) + " = " + trim(action);
                return;
            }
        }
        lines.insert(lines.begin() + end, padTo(nc, 23) + " = " + trim(action));
    });
    runDetached({"novactl", "dispatch", "reload"});
    changed.emit();
    return "";
}
void Backend::removeBinding(const std::string &combo) {
    std::string c = normalizeCombo(combo);
    editBindings(confPath(), [&](std::vector<std::string> &lines, int start, int end) {
        for (int i = end - 1; i > start; i--) {
            std::string t = trim(lines[i]);
            auto eq = t.find('=');
            if (eq != std::string::npos && eq > 0 && t[0] != '#' && normalizeCombo(t.substr(0, eq)) == c) lines.erase(lines.begin() + i);
        }
    });
    runDetached({"novactl", "dispatch", "reload"});
    changed.emit();
}

// ----------------------------------------------------------------------- trim --
std::string Backend::trimVideo(const std::string &file, double start, double end, bool replace) const {
    fs::path p(file);
    std::string out = (p.parent_path() / (p.stem().string() + "-trimmed" + p.extension().string())).string();
    char a[32], b[32];
    snprintf(a, sizeof a, "%.3f", start);
    snprintf(b, sizeof b, "%.3f", end);
    RunResult r = runFull({"ffmpeg", "-y", "-loglevel", "error", "-ss", a, "-to", b, "-i", file, "-c", "copy", "-avoid_negative_ts", "make_zero", out}, 120000);
    if (r.code != 0 || !fs::exists(out)) return "";
    if (replace) {
        std::error_code ec;
        fs::rename(out, file, ec);
        return ec ? out : file;
    }
    return out;
}

}  // namespace settings
