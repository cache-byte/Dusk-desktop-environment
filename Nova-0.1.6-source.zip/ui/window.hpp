// A window: a root widget, input routing, focus, animations and painting into a buffer.
// The Wayland backend (layer surface / toplevel / lock surface) and the offscreen backend
// (PNG) both derive from this.
#pragma once
#include "widget.hpp"

namespace ui {

class Window {
public:
    Window();
    virtual ~Window();
    // false once the window is gone: capture it in deferred calls and timers
    std::shared_ptr<bool> aliveToken() const { return alive_; }

    Widget *root() const { return root_.get(); }
    template <typename T, typename... A> T *setRoot(A &&...a) {
        auto w = std::make_unique<T>(std::forward<A>(a)...);
        T *p = w.get();
        setRootWidget(std::move(w));
        return p;
    }
    void setRootWidget(std::unique_ptr<Widget> w);

    Size size() const { return size_; }
    double scale() const { return scale_; }
    Color clearColor{0, 0, 0, 0};

    // layout + paint (backends call paintTo with a cairo context of size × scale pixels)
    void layoutNow();
    void paintTo(cairo_t *cr);
    bool needsLayout() const { return needLayout_; }

    // ---- requests from widgets ----
    void update();                      // repaint soon
    void relayout();                    // re-measure, then repaint
    void requestFrames(Widget *w);      // a widget is animating: keep frames coming
    void setFocus(Widget *w);
    Widget *focus() const { return focus_; }
    virtual void setCursor(Cursor) {}
    virtual void setClipboard(const std::string &) {}
    virtual void readClipboard(std::function<void(const std::string &)> cb) { cb(""); }
    virtual void close() {}

    // ---- popups inside the window (dropdown lists, menus, tooltips) ----
    Widget *overlay() const { return overlay_.get(); }
    void showOverlay(std::unique_ptr<Widget> w, std::function<void()> onDismiss = {});
    void dismissOverlay();

    // ---- input from the backend (window coordinates) ----
    void pointerMotion(Point p);
    void pointerButton(int button, bool pressed);
    void pointerAxis(double dx, double dy, bool discrete);
    void pointerLeft();
    void keyEvent(const KeyEvent &e);
    void keyboardLeft();
    std::function<bool(const KeyEvent &)> onKey;   // window-wide shortcuts (Esc closes…)

    // ---- frame clock ----
    bool tickAnimations(int64_t now);   // true while something still moves
    // Regions that want the compositor's blur (cards with blurBehind), window coordinates
    std::vector<std::pair<Rect, double>> blurRegions() const;
    // extra areas to blur behind (a whole app window), on top of the Cards that ask for it
    std::function<std::vector<std::pair<Rect, double>>()> blurProvider;

    // fake blur: a blurred wallpaper, and where this window sits on its screen
    std::shared_ptr<Image> backdrop;
    Rect screenRect;                    // the window's rectangle in screen coordinates
    Size screenSize;

    Signal<> painted;
    Signal<bool> pointerInside;         // the pointer entered / left the window
    Signal<Size> resized;

protected:
    virtual void scheduleRedraw() = 0;   // backend: ask for a frame callback
    virtual void beforeLayout() {}       // e.g. resize to the content first
    void setSize(Size s, double scale);
    Size size_;
    double scale_ = 1;
    std::unique_ptr<Widget> root_;
    std::unique_ptr<Widget> overlay_;
    std::function<void()> overlayDismiss_;
    Widget *hover_ = nullptr, *press_ = nullptr, *focus_ = nullptr;
    int pressButton_ = 0;
    Point pointer_{-1, -1};
    bool pointerInside_ = false;
    bool needLayout_ = true, needPaint_ = true;
    std::vector<Widget *> animating_;
    int themeConn_ = 0;
    std::shared_ptr<bool> alive_ = std::make_shared<bool>(true);
    void forget(Widget *w);              // a widget is being destroyed
    void updateHover();
    friend class Widget;
};

// Renders a window to a PNG (screenshots of the UI for checking layouts)
class OffscreenWindow : public Window {
public:
    OffscreenWindow(Size s, double scale = 1) { setSize(s, scale); }
    bool savePng(const std::string &path, int settleMs = 2000);   // runs animations to the end first
protected:
    void scheduleRedraw() override {}
};

}  // namespace ui
