#include "widget.hpp"
#include "window.hpp"

#include <cairo.h>

namespace ui {

// ===================================================================== Widget ==
Widget::~Widget() {
    if (Window *w = window()) w->forget(this);
}
Widget *Widget::adopt(std::unique_ptr<Widget> w, int index) {
    w->parent_ = this;
    Widget *p = w.get();
    if (index < 0 || index >= (int)children_.size()) children_.push_back(std::move(w));
    else children_.insert(children_.begin() + index, std::move(w));
    relayout();
    return p;
}
void Widget::remove(Widget *w) {
    for (auto it = children_.begin(); it != children_.end(); ++it)
        if (it->get() == w) { children_.erase(it); relayout(); return; }
}
void Widget::clear() {
    children_.clear();
    relayout();
}
Window *Widget::window() const {
    const Widget *w = this;
    while (w->parent_) w = w->parent_;
    return w->window_;
}

Size Widget::sizeHint(double availW, double availH) {
    // default: the union of the children (stacked)
    Size s;
    for (auto &c : children_) {
        if (!c->visible) continue;
        Size h = c->hint(availW, availH);
        s.w = std::max(s.w, h.w + c->ml + c->mr);
        s.h = std::max(s.h, h.h + c->mt + c->mb);
    }
    return s;
}
Size Widget::hint(double availW, double availH) {
    if (!visible) return {0, 0};
    uint64_t gen = layoutGeneration();
    for (auto &c : hc_)
        if (c.gen == gen && c.w == availW && c.h == availH) return c.s;
    Size s = sizeHint(fixedW >= 0 ? fixedW : availW, fixedH >= 0 ? fixedH : availH);
    if (fixedW >= 0) s.w = fixedW;
    if (fixedH >= 0) s.h = fixedH;
    s.w = std::clamp(s.w, minW, std::max(minW, maxW));
    s.h = std::clamp(s.h, minH, std::max(minH, maxH));
    HintCache &slot = hc_[hcNext_];
    hcNext_ = (hcNext_ + 1) % 2;
    slot = {gen, availW, availH, s};
    return s;
}
void Widget::arrange() {
    // stacked children fill the widget; one with fill = false keeps its own size, sits at the
    // top (after its top margin) and goes left / centre / right by alignSelf
    for (auto &c : children_) {
        if (!c->visible) continue;
        Rect area = geom.inset(c->ml, c->mt, c->mr, c->mb);
        if (c->fill) { c->setGeometry(area); continue; }
        Size h = c->hint(std::max(0.0, area.w), std::max(0.0, area.h));
        double w = std::min(h.w, std::max(0.0, area.w)), hh = std::min(h.h, std::max(0.0, area.h));
        double x = c->alignSelf == Align::Start ? area.x : c->alignSelf == Align::End ? area.right() - w : area.x + (area.w - w) / 2;
        c->setGeometry({x, area.y, w, hh});
    }
}

void Widget::paint(Painter &) {}
void Widget::render(Painter &p) {
    if (!visible || opacity.value() <= 0.001) return;
    bool group = opacity.value() < 0.999;
    p.save();
    if (tx.value() != 0 || ty.value() != 0) p.translate(tx.value(), ty.value());
    if (scaleA.value() != 1) {
        Point c = geom.center();
        p.translate(c.x, c.y);
        p.scale(scaleA.value());
        p.translate(-c.x, -c.y);
    }
    if (group) p.setOpacityGroup();
    paint(p);
    if (clip) { p.save(); p.clip(geom, clipRadius); }
    for (auto &c : children_) c->render(p);
    if (clip) p.restore();
    paintOver(p);
    if (group) p.endOpacityGroup(opacity.value());
    p.restore();
}

Widget *Widget::hitTest(Point p) {
    if (!visible || opacity.target() <= 0.01) return nullptr;
    if (clip && !geom.contains(p)) return nullptr;
    for (auto it = children_.rbegin(); it != children_.rend(); ++it)
        if (Widget *h = (*it)->hitTest(p)) return h;
    return interactive && geom.contains(p) ? this : nullptr;
}
bool Widget::pointerPress(Point, int button) {
    if (!interactive) return false;
    if (button == 1 || button == 3) { pressed = true; update(); return true; }
    return false;
}
void Widget::pointerRelease(Point p, int button) {
    bool was = pressed;
    pressed = false;
    update();
    if (!was || !geom.contains(p)) return;
    if (button == 1 && onClick) onClick();
    else if (button == 3 && onRightClick) onRightClick();
}
void Widget::grabFocus() {
    if (Window *w = window()) w->setFocus(this);
}
void Widget::update() {
    if (Window *w = window()) w->update();
}
void Widget::relayout() {
    if (Window *w = window()) w->relayout();
}
void Widget::startAnim(Anim &a, double to, int ms, Ease e) {
    a.animate(to, ms, e);
    if (!a.running()) { update(); return; }
    if (std::find(running_.begin(), running_.end(), &a) == running_.end()) running_.push_back(&a);
    if (Window *w = window()) w->requestFrames(this);
}
bool Widget::tickAnims(int64_t now) {
    for (Anim *a : running_) a->tick(now);
    std::erase_if(running_, [](Anim *a) { return !a->running(); });
    return !running_.empty();
}

// ======================================================================== Box ==
Size Box::sizeHint(double availW, double availH) {
    bool rowd = dir == Dir::Row;
    double innerW = availW - pl - pr, innerH = availH - pt - pb;
    double main = 0, cross = 0;
    int n = 0;
    for (auto &c : children_) {
        if (!c->visible) continue;
        Size h = c->hint(std::max(0.0, innerW - c->ml - c->mr), std::max(0.0, innerH - c->mt - c->mb));
        double cm = rowd ? h.w + c->ml + c->mr : h.h + c->mt + c->mb;
        double cc = rowd ? h.h + c->mt + c->mb : h.w + c->ml + c->mr;
        main += cm;
        cross = std::max(cross, cc);
        n++;
    }
    if (n > 1) main += spacing * (n - 1);
    return rowd ? Size{main + pl + pr, cross + pt + pb} : Size{cross + pl + pr, main + pt + pb};
}

void Box::arrange() {
    bool rowd = dir == Dir::Row;
    Rect in = geom.inset(pl, pt, pr, pb);
    std::vector<Widget *> kids;
    for (auto &c : children_) if (c->visible) kids.push_back(c.get());
    if (kids.empty()) return;
    double avMain = rowd ? in.w : in.h;
    std::vector<double> sz(kids.size()), cr(kids.size());
    double total = spacing * (kids.size() - 1);
    int grows = 0;
    for (size_t i = 0; i < kids.size(); i++) {
        Widget *c = kids[i];
        Size h = c->hint(std::max(0.0, in.w - c->ml - c->mr), std::max(0.0, in.h - c->mt - c->mb));
        sz[i] = rowd ? h.w : h.h;
        cr[i] = rowd ? h.h : h.w;
        total += sz[i] + (rowd ? c->ml + c->mr : c->mt + c->mb);
        grows += c->grow;
    }
    double free = avMain - total;
    if (free > 0 && grows > 0) {
        for (size_t i = 0; i < kids.size(); i++)
            if (kids[i]->grow > 0) sz[i] += free * kids[i]->grow / grows;
        free = 0;
    } else if (free < 0) {
        // too little room: shrink the flexible children first, then everything that isn't fixed
        auto shrink = [&](auto pick) {
            double pool = 0;
            for (size_t i = 0; i < kids.size(); i++) if (pick(kids[i])) pool += sz[i];
            if (pool <= 0) return;
            double take = std::min(-free, pool);
            for (size_t i = 0; i < kids.size(); i++)
                if (pick(kids[i])) sz[i] = std::max(rowd ? kids[i]->minW : kids[i]->minH, sz[i] - take * sz[i] / pool);
            free += take;
        };
        shrink([](Widget *w) { return w->grow > 0; });
        if (free < 0) shrink([rowd](Widget *w) { return (rowd ? w->fixedW : w->fixedH) < 0; });
        free = 0;
    }
    double pos = rowd ? in.x : in.y, gap = spacing;
    if (free > 0) {
        if (justify == Justify::Center) pos += free / 2;
        else if (justify == Justify::End) pos += free;
        else if (justify == Justify::SpaceBetween && kids.size() > 1) gap += free / (kids.size() - 1);
    }
    for (size_t i = 0; i < kids.size(); i++) {
        Widget *c = kids[i];
        Rect r;
        if (rowd) {
            double availCross = in.h - c->mt - c->mb;
            bool stretch = crossStretch && c->fill && c->fixedH < 0;
            double h = stretch ? availCross : std::min(cr[i], availCross);
            Align a = crossAlign;
            double y = a == Align::Start ? in.y + c->mt : a == Align::End ? in.bottom() - c->mb - h : in.y + c->mt + (availCross - h) / 2;
            r = {pos + c->ml, y, sz[i], h};
            pos += c->ml + sz[i] + c->mr + gap;
        } else {
            double availCross = in.w - c->ml - c->mr;
            bool stretch = crossStretch && c->fill && c->fixedW < 0;
            double w = stretch ? availCross : std::min(cr[i], availCross);
            Align a = stretch ? Align::Start : (c->alignSelf != Align::Center ? c->alignSelf : crossAlign);
            double x = a == Align::Start ? in.x + c->ml : a == Align::End ? in.right() - c->mr - w : in.x + c->ml + (availCross - w) / 2;
            r = {x, pos + c->mt, w, sz[i]};
            pos += c->mt + sz[i] + c->mb + gap;
        }
        r.x = std::round(r.x); r.y = std::round(r.y);
        r.w = std::round(r.w); r.h = std::round(r.h);
        c->setGeometry(r);
    }
}

void Box::paint(Painter &p) {
    Color b = bg;
    if (pressed && pressBg.a > 0) b = pressBg;
    else if (hovered && hoverBg.a > 0) b = hoverBg;
    p.fill(geom, b, radius);
    if (border.a > 0) p.stroke(geom, border, borderWidth, radius);
}

// ====================================================================== Stack ==
Size Stack::sizeHint(double availW, double availH) {
    if (manual) return {fixedW >= 0 ? fixedW : availW, fixedH >= 0 ? fixedH : 0};
    return Widget::sizeHint(availW, availH);
}
void Stack::arrange() {
    if (manual) return;   // the owner positions the children
    Widget::arrange();
}

void Separator::paint(Painter &p) {
    Rect r = vertical ? Rect{geom.x, geom.y + inset, 1, geom.h - 2 * inset} : Rect{geom.x + inset, geom.y, geom.w - 2 * inset, 1};
    p.fill(r, theme().border);
}

// ===================================================================== basics ==
Color roleColor(Role r, Color custom) {
    const Theme &t = theme();
    switch (r) {
    case Role::Text: return t.text;
    case Role::Text2: return t.text2;
    case Role::Text3: return t.text3;
    case Role::Accent: return t.accent;
    case Role::AccentBright: return t.accentBright;
    case Role::OnAccent: return t.onAccent;
    case Role::Danger: return t.danger;
    case Role::Custom: return custom;
    }
    return t.text;
}

Label::Label(const std::string &s, double size, Weight w, Role r) : role(r), text_(s) {
    font.size = size;
    font.weight = w;
}
Size Label::sizeHint(double availW, double) {
    if (text_.empty()) return {0, std::ceil(font.size * 1.25)};
    measure_.set(text_, font, maxLines == 1 ? -1 : std::max(1.0, availW), elide, maxLines == 0 ? 0 : maxLines, markup);
    Size s = measure_.size();
    s.w = std::min(std::ceil(s.w), availW);
    s.h = std::ceil(s.h);
    return s;
}
void Label::paint(Painter &p) {
    if (text_.empty()) return;
    layout_.set(text_, font, geom.w + 0.5, elide, maxLines == 0 ? 0 : maxLines, markup);
    p.textIn(layout_, geom, roleColor(role, color), hAlign, Align::Center);
}

void IconW::paint(Painter &p) {
    if (iconName.empty()) return;
    Color c = roleColor(role, color);
    if (rotation.value() != 0) {
        p.save();
        Point ctr = geom.center();
        p.translate(ctr.x, ctr.y);
        cairo_rotate(p.cr(), rotation.value() * M_PI / 180);
        p.icon(iconName, {-size / 2, -size / 2, size, size}, c);
        p.restore();
        return;
    }
    p.icon(iconName, {std::round(geom.center().x - size / 2), std::round(geom.center().y - size / 2), size, size}, c);
}
void AppIconW::paint(Painter &p) {
    p.appIcon(iconName, {std::round(geom.center().x - size / 2), std::round(geom.center().y - size / 2), size, size});
}
void ImageW::paint(Painter &p) {
    if (image && image->valid()) { p.image(*image, geom, radius, cover); return; }
    if (placeholder.a > 0) p.fill(geom, placeholder, radius);
    if (!placeholderIcon.empty()) p.icon(placeholderIcon, geom.center(), std::min(geom.w, geom.h) * 0.4, theme().text3);
}

// =================================================================== controls ==
Button::Button(Dir d, double spacing) : Box(d, spacing) {
    interactive = true;
    cursor = Cursor::Pointer;
    radius = 12;
}
void Button::paint(Painter &p) {
    const Theme &t = theme();
    Color b = bg;
    if (active) b = activeBg.a > 0 ? activeBg : t.accentSoft;
    else if (pressed) b = pressBg.a > 0 ? pressBg : t.surface3.mix(t.text.alpha(0.12), 0.5);
    else if (hovered && enabledB) b = hoverBg.a > 0 ? hoverBg : t.surface3;
    p.fill(geom, enabledB ? b : b.withAlpha(0.5), radius);
    Color br = active ? (activeBorder.a > 0 ? activeBorder : t.accentLine) : border;
    if (br.a > 0) p.stroke(geom, br, borderWidth, radius);
}
bool Button::pointerPress(Point p, int button) {
    if (!enabledB) return true;   // swallow, do nothing
    return Widget::pointerPress(p, button);
}

TextButton::TextButton(const std::string &text, const std::string &iconName, bool accent) : Button(Dir::Row, 8), accent(accent) {
    padding(16, 0);
    fixedH = 36;
    radius = 11;
    if (!iconName.empty()) icon = add<IconW>(iconName, 16, accent ? Role::OnAccent : Role::Text);
    label = add<Label>(text, 13.5, Weight::DemiBold, accent ? Role::OnAccent : Role::Text);
    setAccent(accent);
}
void TextButton::setAccent(bool a) {
    accent = a;
    if (label) label->role = a ? Role::OnAccent : Role::Text;
    if (icon) icon->role = a ? Role::OnAccent : Role::Text;
    update();
}
void TextButton::paint(Painter &p) {
    const Theme &t = theme();
    if (accent) {
        Color b = pressed ? t.accent.darker(1.15) : hovered ? t.accent.lighter(1.08) : t.accent;
        p.fill(geom, enabledB ? b : b.withAlpha(0.45), radius);
        return;
    }
    if (bg.a <= 0) bg = t.surface3;
    Button::paint(p);
}

IconButton::IconButton(const std::string &iconName, double size, double iconSize) : Button(Dir::Row, 0) {
    fixedW = fixedH = size;
    radius = std::round(size * 0.3);
    justify = Justify::Center;
    icon = add<IconW>(iconName, iconSize, Role::Text2);
}

// ---- toggle ----
Toggle::Toggle(bool on) : on_(on), knob_(on ? 1 : 0) {
    interactive = true;
    cursor = Cursor::Pointer;
}
void Toggle::setOn(bool v, bool animate) {
    if (v == on_) return;
    on_ = v;
    if (animate) startAnim(knob_, on_ ? 1 : 0, theme().ms(180));
    else { knob_.set(on_ ? 1 : 0); update(); }
}
void Toggle::paint(Painter &p) {
    const Theme &t = theme();
    Rect r{geom.x, geom.center().y - 13, 46, 26};
    double k = knob_.value();
    Color track = t.surface3.mix(t.accent, k);
    p.fill(r, track, 13);
    if (k < 0.5) p.stroke(r, t.text.alpha(0.18 * (1 - k * 2)), 1.5, 13);
    double d = 18 + 2 * k;    // knob grows a little when on
    double x = r.x + 4 + (r.w - 8 - d) * k;
    Color knob = Color{1, 1, 1, 1}.mix(t.text2, (1 - k) * (t.dark ? 0.35 : 0.0));
    p.shadow({x, r.y + (r.h - d) / 2, d, d}, d / 2, 4, 1, {0, 0, 0, 0.25});
    p.fillCircle({x + d / 2, r.center().y}, d / 2, knob);
}
bool Toggle::pointerPress(Point p, int button) {
    if (button != 1) return false;
    setOn(!on_);
    if (onToggled) onToggled(on_);
    return true;
}

void Checkbox::paint(Painter &p) {
    const Theme &t = theme();
    Rect r{geom.x, geom.center().y - 10, 20, 20};
    if (checked) {
        p.fill(r, t.accent, 6);
        p.icon("check", r.inset(3), t.onAccent);
    } else {
        p.fill(r, hovered ? t.surface3 : t.surface2, 6);
        p.stroke(r, t.text.alpha(0.25), 1.5, 6);
    }
}
bool Checkbox::pointerPress(Point, int button) {
    if (button != 1) return false;
    checked = !checked;
    update();
    if (onToggled) onToggled(checked);
    return true;
}

// ---- slider ----
void Slider::setValue(double v) {
    v = std::clamp(v, 0.0, maxValue);
    if (v == value_) return;
    value_ = v;
    update();
}
Size Slider::sizeHint(double availW, double availH) {
    if (vertical) return {thick ? 52.0 : 24.0, std::min(availH, 160.0)};
    return {std::min(availW, 240.0), thick ? 44.0 : 24.0};
}
void Slider::paint(Painter &p) {
    const Theme &t = theme();
    double f = std::clamp(value_ / maxValue, 0.0, 1.0);
    if (thick) {
        double rad = std::min(geom.w, geom.h) / 2;
        rad = std::min(rad, 16.0);
        p.fill(geom, t.surface3, rad);
        p.save();
        p.clip(geom, rad);
        Rect fillR = vertical ? Rect{geom.x, geom.bottom() - geom.h * f, geom.w, geom.h * f} : Rect{geom.x, geom.y, geom.w * f, geom.h};
        p.fill(fillR, t.accent);
        // over 100 % (volume boost) the extra part is warmer
        if (maxValue > 1 && value_ > 1) {
            double f1 = 1.0 / maxValue;
            Rect extra = vertical ? Rect{geom.x, geom.bottom() - geom.h * f, geom.w, geom.h * (f - f1)}
                                  : Rect{geom.x + geom.w * f1, geom.y, geom.w * (f - f1), geom.h};
            p.fill(extra, t.warn);
        }
        p.restore();
        if (!iconName.empty()) {
            Point ic = vertical ? Point{geom.center().x, geom.bottom() - 22} : Point{geom.x + 22, geom.center().y};
            bool onFill = vertical ? (geom.bottom() - geom.h * f) < ic.y - 9 : (geom.x + geom.w * f) > ic.x + 9;
            p.icon(iconName, ic, 18, onFill ? t.onAccent : t.text2);
        }
        return;
    }
    // thin track with a knob (Settings)
    if (vertical) {
        Rect tr{geom.center().x - 3, geom.y + 9, 6, geom.h - 18};
        p.fill(tr, t.surface3, 3);
        p.fill({tr.x, tr.bottom() - tr.h * f, 6, tr.h * f}, t.accent, 3);
        Point k{tr.center().x, tr.bottom() - tr.h * f};
        p.fillCircle(k, 9, {1, 1, 1, 1});
        p.strokeCircle(k, 9, t.accent, 2);
    } else {
        Rect tr{geom.x + 9, geom.center().y - 3, geom.w - 18, 6};
        p.fill(tr, t.surface3, 3);
        p.fill({tr.x, tr.y, tr.w * f, 6}, t.accent, 3);
        Point k{tr.x + tr.w * f, tr.center().y};
        p.shadow({k.x - 9, k.y - 9, 18, 18}, 9, 4, 1, {0, 0, 0, 0.25});
        p.fillCircle(k, 9, {1, 1, 1, 1});
        p.strokeCircle(k, 9, t.accent, 2.5);
    }
}
void Slider::fromPoint(Point p) {
    double f;
    if (vertical) {
        double y0 = geom.y + (thick ? 0 : 9), h = geom.h - (thick ? 0 : 18);
        f = 1 - (p.y - y0) / std::max(1.0, h);
    } else {
        double x0 = geom.x + (thick ? 0 : 9), w = geom.w - (thick ? 0 : 18);
        f = (p.x - x0) / std::max(1.0, w);
    }
    double v = std::clamp(f, 0.0, 1.0) * maxValue;
    if (v != value_) {
        value_ = v;
        update();
        if (onChanged) onChanged(value_);
    }
}
bool Slider::pointerPress(Point p, int button) {
    if (button != 1) return false;
    dragging_ = true;
    pressed = true;
    fromPoint(p);
    return true;
}
void Slider::pointerMove(Point p) {
    if (dragging_) fromPoint(p);
}
void Slider::pointerRelease(Point, int) {
    if (dragging_ && onReleased) onReleased(value_);
    dragging_ = false;
    pressed = false;
}
bool Slider::scroll(double dx, double dy, bool discrete) {
    double d = discrete ? -dy * 0.05 : -dy * 0.004;
    if (!vertical && dy == 0) d = dx * (discrete ? 0.05 : 0.004);
    double v = std::clamp(value_ + d * maxValue, 0.0, maxValue);
    if (v != value_) {
        value_ = v;
        update();
        if (onChanged) onChanged(v);
        if (onReleased) onReleased(v);
    }
    return true;
}

// ---- segmented ----
void Segmented::measure() {
    boxes_.clear();
    double x = 4, h = small ? 28 : 34;
    for (auto &o : options) {
        double w = measureText(o.label, {.size = small ? 12.5 : 13.0, .weight = Weight::DemiBold}).w + (small ? 22 : 28);
        if (!o.icon.empty()) w += 16 + (o.label.empty() ? 0 : 7);
        boxes_.push_back({x, 4, std::ceil(w), h});
        x += std::ceil(w) + 2;
    }
}
Size Segmented::sizeHint(double, double) {
    measure();
    double w = boxes_.empty() ? 0 : boxes_.back().right() + 4;
    return {w, (small ? 28.0 : 34.0) + 8};
}
void Segmented::paint(Painter &p) {
    const Theme &t = theme();
    measure();
    p.fill(geom, t.surface2, small ? 11 : 13);
    for (size_t i = 0; i < options.size(); i++) {
        Rect b{geom.x + boxes_[i].x, geom.y + boxes_[i].y, boxes_[i].w, boxes_[i].h};
        bool on = options[i].value == value;
        if (on) p.fill(b, t.accent, small ? 8 : 10);
        else if ((int)i == hot_) p.fill(b, t.surface3, small ? 8 : 10);
        Color c = on ? t.onAccent : t.text2;
        Font f{.size = small ? 12.5 : 13.0, .weight = on ? Weight::DemiBold : Weight::Normal};
        Text tx(options[i].label, f);
        double cw = tx.size().w + (options[i].icon.empty() ? 0 : 16 + (options[i].label.empty() ? 0 : 7));
        double x = b.x + (b.w - cw) / 2;
        if (!options[i].icon.empty()) { p.icon(options[i].icon, {x, b.center().y - 8, 16, 16}, c); x += 23; }
        p.text(tx, {std::round(x), std::round(b.center().y - tx.size().h / 2)}, c);
    }
}
bool Segmented::pointerPress(Point p, int button) {
    if (button != 1) return false;
    for (size_t i = 0; i < boxes_.size(); i++) {
        Rect b{geom.x + boxes_[i].x, geom.y + boxes_[i].y, boxes_[i].w, boxes_[i].h};
        if (b.contains(p)) {
            value = options[i].value;
            update();
            if (onPicked) onPicked(value);
            return true;
        }
    }
    return true;
}
void Segmented::pointerMove(Point p) {
    int h = -1;
    for (size_t i = 0; i < boxes_.size(); i++)
        if (Rect{geom.x + boxes_[i].x, geom.y + boxes_[i].y, boxes_[i].w, boxes_[i].h}.contains(p)) h = (int)i;
    if (h != hot_) { hot_ = h; update(); }
}

// ---- stepper ----
void Stepper::paint(Painter &p) {
    const Theme &t = theme();
    p.fill(geom, t.surface3, 11);
    Rect l{geom.x, geom.y, 36, geom.h}, r{geom.right() - 36, geom.y, 36, geom.h};
    if (hovered && l.contains({hotX_, geom.center().y})) p.fill(l.inset(3), t.surface3, 9);
    if (hovered && r.contains({hotX_, geom.center().y})) p.fill(r.inset(3), t.surface3, 9);
    p.icon("minus", l.center(), 14, value <= min ? t.text3.withAlpha(0.5) : t.text2);
    p.icon("plus", r.center(), 14, value >= max ? t.text3.withAlpha(0.5) : t.text2);
    char buf[64];
    snprintf(buf, sizeof buf, "%.*f", decimals, value);
    Text tx(std::string(buf) + suffix, {.size = 13.5, .weight = Weight::Medium});
    p.textIn(tx, geom, t.text, Align::Center, Align::Center);
}
bool Stepper::pointerPress(Point p, int button) {
    if (button != 1) return false;
    double nv = value;
    if (p.x < geom.x + 36) nv = std::max(min, value - step);
    else if (p.x > geom.right() - 36) nv = std::min(max, value + step);
    if (nv != value) {
        value = nv;
        update();
        if (onChanged) onChanged(value);
    }
    return true;
}

// ---- text input ----
static int utf8Next(const std::string &s, int i) {
    if (i >= (int)s.size()) return (int)s.size();
    i++;
    while (i < (int)s.size() && ((unsigned char)s[i] & 0xC0) == 0x80) i++;
    return i;
}
static int utf8Prev(const std::string &s, int i) {
    if (i <= 0) return 0;
    i--;
    while (i > 0 && ((unsigned char)s[i] & 0xC0) == 0x80) i--;
    return i;
}
static int utf8Count(const std::string &s, int upto) {
    int n = 0;
    for (int i = 0; i < upto && i < (int)s.size(); i = utf8Next(s, i)) n++;
    return n;
}
static bool isWordChar(char c) { return std::isalnum((unsigned char)c) || (unsigned char)c >= 0x80 || c == '_'; }

TextInput::TextInput() {
    interactive = true;
    focusable = true;
    cursor = Cursor::Text;
}
void TextInput::setText(const std::string &s) {
    text_ = s;
    cursor_ = anchor_ = (int)s.size();
    update();
}
std::string TextInput::shown() const {
    if (!password) return text_;
    std::string out;
    int n = utf8Count(text_, (int)text_.size());
    for (int i = 0; i < n; i++) out += "•";
    return out;
}
int TextInput::shownIndex(int i) const {
    if (!password) return i;
    return utf8Count(text_, i) * 3;   // "•" is 3 bytes
}
int TextInput::textIndex(int si) const {
    if (!password) return si;
    int n = si / 3, i = 0;
    while (n-- > 0) i = utf8Next(text_, i);
    return i;
}
Rect TextInput::textRect() const {
    double left = framed ? 14 : 0;
    if (!leadingIcon.empty()) left += 26;
    return geom.inset(left, 0, framed ? 14 : 0, 0);
}
void TextInput::paint(Painter &p) {
    const Theme &t = theme();
    if (framed) {
        p.fill(geom, t.surface2, 13);
        p.stroke(geom, focused ? t.accentLine : t.border, focused ? 1.5 : 1, 13);
    }
    if (!leadingIcon.empty()) p.icon(leadingIcon, {geom.x + (framed ? 14 : 0) + 9, geom.center().y}, 18, t.text2);
    Rect tr = textRect();
    Font f{.size = fontSize};
    if (password && !text_.empty()) f.letterSpacing = 2;
    layout_.set(shown(), f);
    double cx = layout_.xForIndex(shownIndex(cursor_));
    // keep the caret visible
    if (cx - scrollX_ > tr.w - 2) scrollX_ = cx - tr.w + 2;
    if (cx - scrollX_ < 0) scrollX_ = cx;
    if (layout_.size().w < tr.w) scrollX_ = 0;
    p.save();
    p.clip(tr);
    double ty = std::round(tr.center().y - layout_.size().h / 2);
    if (text_.empty() && !placeholder.empty()) {
        Text ph(placeholder, {.size = fontSize});
        p.text(ph, {tr.x, std::round(tr.center().y - ph.size().h / 2)}, t.text3);
    }
    if (cursor_ != anchor_) {
        double a = layout_.xForIndex(shownIndex(std::min(cursor_, anchor_))), b = layout_.xForIndex(shownIndex(std::max(cursor_, anchor_)));
        p.fill({tr.x + a - scrollX_, ty, b - a, layout_.size().h}, t.accentLine.withAlpha(0.8), 3);
    }
    p.text(layout_, {tr.x - scrollX_, ty}, t.text);
    if (focused && caretOn_) p.fill({std::round(tr.x + cx - scrollX_), ty, 2, std::max(layout_.size().h, fontSize * 1.2)}, t.accent, 1);
    p.restore();
}
TextInput::~TextInput() {
    if (blinkTimer_) Loop::get().removeTimer(blinkTimer_);
}
void TextInput::focusIn() {
    Widget::focusIn();
    caretOn_ = true;
    if (!blinkTimer_) blinkTimer_ = Loop::get().addTimer(530, [this] { caretOn_ = !caretOn_; update(); }, true);
}
void TextInput::focusOut() {
    Widget::focusOut();
    if (blinkTimer_) { Loop::get().removeTimer(blinkTimer_); blinkTimer_ = 0; }
    anchor_ = cursor_;
}
void TextInput::selectAll() {
    anchor_ = 0;
    cursor_ = (int)text_.size();
    update();
}
bool TextInput::pointerPress(Point p, int button) {
    if (button != 1) return button == 3;
    grabFocus();
    Rect tr = textRect();
    int i = textIndex(layout_.indexForX(p.x - tr.x + scrollX_));
    moveCursor(i, false);
    selecting_ = true;
    pressed = true;
    return true;
}
void TextInput::pointerMove(Point p) {
    if (!selecting_) return;
    Rect tr = textRect();
    cursor_ = textIndex(layout_.indexForX(p.x - tr.x + scrollX_));
    update();
}
void TextInput::moveCursor(int to, bool select) {
    cursor_ = std::clamp(to, 0, (int)text_.size());
    if (!select) anchor_ = cursor_;
    caretOn_ = true;
    if (blinkTimer_) Loop::get().restartTimer(blinkTimer_);
    update();
}
void TextInput::eraseSelection() {
    int a = std::min(cursor_, anchor_), b = std::max(cursor_, anchor_);
    text_.erase(a, b - a);
    cursor_ = anchor_ = a;
}
void TextInput::insert(const std::string &s) {
    if (cursor_ != anchor_) eraseSelection();
    std::string clean;
    for (char c : s) if (c != '\n' && c != '\r') clean += c;
    text_.insert(cursor_, clean);
    cursor_ += (int)clean.size();
    anchor_ = cursor_;
    changed();
}
void TextInput::changed() {
    caretOn_ = true;
    update();
    if (onChanged) onChanged(text_);
}
bool TextInput::key(const KeyEvent &e) {
    if (!e.pressed) return false;
    if (onKeyFirst && onKeyFirst(e)) return true;
    bool sel = e.shift;
    auto wordLeft = [&](int i) { while (i > 0 && !isWordChar(text_[i - 1])) i--; while (i > 0 && isWordChar(text_[i - 1])) i--; return i; };
    auto wordRight = [&](int i) { int n = (int)text_.size(); while (i < n && !isWordChar(text_[i])) i++; while (i < n && isWordChar(text_[i])) i++; return i; };
    switch (e.sym) {
    case key::Left: moveCursor(e.ctrl ? wordLeft(cursor_) : (cursor_ != anchor_ && !sel ? std::min(cursor_, anchor_) : utf8Prev(text_, cursor_)), sel); return true;
    case key::Right: moveCursor(e.ctrl ? wordRight(cursor_) : (cursor_ != anchor_ && !sel ? std::max(cursor_, anchor_) : utf8Next(text_, cursor_)), sel); return true;
    case key::Home: moveCursor(0, sel); return true;
    case key::End: moveCursor((int)text_.size(), sel); return true;
    case key::BackSpace:
        if (cursor_ != anchor_) eraseSelection();
        else if (cursor_ > 0) { int s = e.ctrl ? wordLeft(cursor_) : utf8Prev(text_, cursor_); text_.erase(s, cursor_ - s); cursor_ = anchor_ = s; }
        changed();
        return true;
    case key::Delete:
        if (cursor_ != anchor_) eraseSelection();
        else if (cursor_ < (int)text_.size()) { int s = e.ctrl ? wordRight(cursor_) : utf8Next(text_, cursor_); text_.erase(cursor_, s - cursor_); }
        changed();
        return true;
    case key::Return:
    case key::KP_Enter:
        if (onSubmit) onSubmit(text_);
        return true;
    default: break;
    }
    if (e.ctrl) {
        uint32_t k = e.sym | 0x20;   // lower-case letters
        if (k == key::a) { selectAll(); return true; }
        if ((k == key::c || k == key::x) && cursor_ != anchor_ && !password) {
            int a = std::min(cursor_, anchor_), b = std::max(cursor_, anchor_);
            if (Window *w = window()) w->setClipboard(text_.substr(a, b - a));
            if (k == key::x) { eraseSelection(); changed(); }
            return true;
        }
        if (k == key::v) {
            if (Window *w = window()) w->readClipboard([this](const std::string &s) { insert(s); });
            return true;
        }
        return false;
    }
    if (!e.text.empty() && (unsigned char)e.text[0] >= 0x20 && e.text[0] != 0x7f) {
        insert(e.text);
        return true;
    }
    return false;
}

// ---- scroll view ----
Size ScrollView::sizeHint(double availW, double availH) {
    Widget *c = content();
    if (!c) return {0, 0};
    Size h = c->hint(availW, kInf);
    return {h.w, std::min(h.h, availH)};
}
void ScrollView::arrange() {
    Widget *c = content();
    if (!c) return;
    Size h = c->hint(geom.w, kInf);
    contentH_ = h.h;
    off_ = std::clamp(off_, 0.0, maxOff());
    c->setGeometry({geom.x, geom.y - std::round(off_), geom.w, std::max(contentH_, geom.h)});
}
void ScrollView::scrollTo(double y, bool anim) {
    y = std::clamp(y, 0.0, maxOff());
    if (!anim) { off_ = y; smooth_.set(y); arrange(); update(); return; }
    smooth_.set(off_);
    startAnim(smooth_, y, theme().ms(180));
}
void ScrollView::ensureVisible(const Rect &r) {
    double top = r.y - (geom.y - off_), bottom = top + r.h;
    if (top < off_) scrollTo(top);
    else if (bottom > off_ + geom.h) scrollTo(bottom - geom.h);
}
bool ScrollView::scroll(double, double dy, bool discrete) {
    if (maxOff() <= 0) return false;
    double target = (smooth_.running() ? smooth_.target() : off_) + (discrete ? dy * 64 : dy);
    target = std::clamp(target, 0.0, maxOff());
    if (discrete) {
        smooth_.set(off_);
        startAnim(smooth_, target, theme().ms(140));
    } else {
        off_ = target;
        arrange();
        update();
    }
    return true;
}
Widget *ScrollView::hitTest(Point p) {
    if (!visible || !geom.contains(p)) return nullptr;
    for (auto it = children_.rbegin(); it != children_.rend(); ++it)
        if (Widget *h = (*it)->hitTest(p)) return h;
    return this;
}
void ScrollView::paintOver(Painter &p) {
    if (smooth_.running() || std::abs(smooth_.value() - off_) > 0.5) {
        if (smooth_.running()) { off_ = smooth_.value(); arrange(); }
    }
    if (maxOff() <= 0) return;
    double h = std::max(30.0, geom.h * geom.h / contentH_);
    double y = geom.y + (geom.h - h) * (off_ / maxOff());
    p.fill({geom.right() - 5, y + 2, 3, h - 4}, theme().text.alpha(hovered ? 0.3 : 0.15), 1.5);
}

// ---- card ----
Card::Card(Dir d, double spacing) : Box(d, spacing) {
    radius = theme().radius;
    padding(16);
}
void Card::paint(Painter &p) {
    const Theme &t = theme();
    if (shadow) p.shadow(geom, radius, shadowBlur, shadowY, {0, 0, 0, t.dark ? 0.45 : 0.22}, -10);
    // fake blur: the blurred wallpaper, lined up with where this card is on the screen
    Window *w = window();
    if (blurBehind && !t.realBlur && w && w->backdrop && w->backdrop->valid()) {
        p.save();
        p.clip(geom, radius);
        Rect wp{-w->screenRect.x, -w->screenRect.y, w->screenSize.w, w->screenSize.h};
        p.image(*w->backdrop, wp, 0, true);
        p.restore();
    }
    p.fill(geom, useTint ? tint : t.surface, radius);
    p.stroke(geom, t.border, 1, radius);
}

// ---- dropdown ----
Dropdown::Dropdown() : Button(Dir::Row, 8) {
    fixedH = 38;
    radius = 11;
    padding(14, 0);
    onClick = [this] { open(); };
}
void Dropdown::setValue(const std::string &v) {
    value = v;
    update();
}
Size Dropdown::sizeHint(double availW, double) {
    double w = 0;
    for (auto &i : items) w = std::max(w, measureText(i.second, {.size = 14}).w);
    return {std::min(availW, w + 28 + 24), 38};
}
void Dropdown::paint(Painter &p) {
    const Theme &t = theme();
    if (bg.a <= 0) bg = t.surface3;
    Button::paint(p);
    std::string label = value;
    for (auto &i : items) if (i.first == value) label = i.second;
    Text tx(label, {.size = 14}, geom.w - pl - pr - 24);
    p.text(tx, {geom.x + pl, std::round(geom.center().y - tx.size().h / 2)}, t.text);
    p.icon("chevd", {geom.right() - pr - 9, geom.center().y}, 16, t.text2);
}
void Dropdown::open() {
    Window *w = window();
    if (!w) return;
    auto card = std::make_unique<Card>(Dir::Column, 2);
    card->padding(6);
    card->radius = 14;
    card->blurBehind = false;
    card->useTint = true;
    card->tint = theme().dark ? Color{0.11, 0.105, 0.145, 0.98} : Color{0.98, 0.975, 0.96, 0.98};
    auto *sv = card->add<ScrollView>();
    sv->grow = 1;
    auto *list = sv->add<Box>(Dir::Column, 2);
    for (auto &it : items) {
        auto *b = list->add<Button>(Dir::Row, 8);
        b->padding(12, 0);
        b->fixedH = 36;
        b->radius = 9;
        b->active = it.first == value;
        b->add<Label>(it.second, 14, it.first == value ? Weight::DemiBold : Weight::Normal)->grow = 1;
        std::string v = it.first;
        b->onClick = [this, v] {
            setValue(v);
            if (onPicked) onPicked(v);
            if (Window *ww = window()) ww->dismissOverlay();
        };
    }
    double h = std::min(320.0, items.size() * 38.0 + 12);
    double y = geom.bottom() + 6;
    if (y + h > w->size().h - 8) y = std::max(8.0, geom.y - 6 - h);
    card->geom = {geom.x, y, std::max(geom.w, 180.0), h};
    Card *cp = card.get();
    w->showOverlay(std::move(card));
    cp->arrange();
    // scroll so the current choice is visible
    for (auto &c : list->children())
        if (static_cast<Button *>(c.get())->active) sv->ensureVisible(c->geom);
}

}  // namespace ui
