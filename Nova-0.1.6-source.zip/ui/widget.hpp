// Widgets: a small retained tree with box layouts, pointer / keyboard input and animations.
#pragma once
#include "paint.hpp"

#include <limits>

namespace ui {

class Window;

enum class Cursor { Default, Pointer, Text, Move, ResizeNWSE, ResizeNESW, ResizeNS, ResizeEW, Grab, Grabbing, NotAllowed };

struct KeyEvent {
    uint32_t sym = 0;          // xkb keysym
    std::string text;          // UTF-8 produced by the key (empty for control keys)
    bool pressed = true, repeat = false;
    bool ctrl = false, shift = false, alt = false, super = false;
};

// keysyms used by widgets (subset of xkbcommon-keysyms.h, so headers don't need xkb)
namespace key {
constexpr uint32_t BackSpace = 0xff08, Tab = 0xff09, Return = 0xff0d, Escape = 0xff1b, Delete = 0xffff,
                   Home = 0xff50, Left = 0xff51, Up = 0xff52, Right = 0xff53, Down = 0xff54, PageUp = 0xff55,
                   PageDown = 0xff56, End = 0xff57, KP_Enter = 0xff8d, ISO_Left_Tab = 0xfe20,
                   a = 0x61, c = 0x63, v = 0x76, x = 0x78, z = 0x7a, space = 0x20;
}

constexpr double kInf = std::numeric_limits<double>::infinity();

class Widget {
public:
    Widget() = default;
    virtual ~Widget();
    Widget(const Widget &) = delete;
    Widget &operator=(const Widget &) = delete;

    // ---- tree ----
    template <typename T, typename... A> T *add(A &&...a) {
        auto w = std::make_unique<T>(std::forward<A>(a)...);
        T *p = w.get();
        adopt(std::move(w));
        return p;
    }
    Widget *adopt(std::unique_ptr<Widget> w, int index = -1);
    void remove(Widget *w);
    void clear();
    Widget *parent() const { return parent_; }
    const std::vector<std::unique_ptr<Widget>> &children() const { return children_; }
    Window *window() const;
    void setWindow(Window *w) { window_ = w; }

    // ---- layout properties ----
    double fixedW = -1, fixedH = -1;     // -1 = from content
    double minW = 0, minH = 0, maxW = kInf, maxH = kInf;
    int grow = 0;                         // share of spare space along a Box's direction
    bool fill = true;                     // stretch across the Box's direction
    Align alignSelf = Align::Center;      // when not filling across
    double ml = 0, mt = 0, mr = 0, mb = 0;  // margins
    void margins(double all) { ml = mt = mr = mb = all; }
    bool visible = true;
    bool clip = false;                    // clip children to geometry (radius = clipRadius)
    double clipRadius = 0;
    Anim opacity{1};
    Anim tx{0}, ty{0};                    // paint offset (slide animations)
    Anim scaleA{1};
    std::string name;                     // for debugging / lookups

    // geometry in window coordinates, set by the parent's layout
    Rect geom;
    // preferred size given the space available
    virtual Size sizeHint(double availW, double availH);
    Size hint(double availW, double availH);         // applies fixed / min / max (cached per layout pass)
    virtual void arrange();                          // place children inside geom
    void setGeometry(const Rect &r) { geom = r; arrange(); }

    // ---- painting ----
    virtual void paint(Painter &p);                  // this widget's own drawing
    virtual void paintOver(Painter &) {}             // after the children
    void render(Painter &p);                          // self + children, with opacity / offset

    // ---- input ----
    bool interactive = false;       // takes pointer events (hover / press)
    bool focusable = false;          // can hold keyboard focus
    Cursor cursor = Cursor::Default;
    std::string tooltip;
    bool hovered = false, pressed = false, focused = false;
    std::function<void()> onClick;
    std::function<void()> onRightClick;
    std::function<void(bool)> onHover;
    virtual Widget *hitTest(Point p);                // deepest interactive widget under p
    virtual void pointerEnter() { hovered = true; if (onHover) onHover(true); update(); }
    virtual void pointerLeave() { hovered = false; pressed = false; if (onHover) onHover(false); update(); }
    virtual void pointerMove(Point) {}
    virtual bool pointerPress(Point, int button);    // button: 1 left, 2 middle, 3 right
    virtual void pointerRelease(Point p, int button);
    virtual bool scroll(double dx, double dy, bool discrete) { return false; }
    virtual bool key(const KeyEvent &) { return false; }
    virtual void focusIn() { focused = true; update(); }
    virtual void focusOut() { focused = false; update(); }
    void grabFocus();

    // ---- updates ----
    void update();                   // repaint
    void relayout();                 // sizes changed
    void startAnim(Anim &a, double to, int ms, Ease e = Ease::OutCubic);   // animate + frames
    virtual bool tickAnims(int64_t now);   // advance running animations; true while any runs

protected:
    Widget *parent_ = nullptr;
    Window *window_ = nullptr;
    std::vector<std::unique_ptr<Widget>> children_;
    std::vector<Anim *> running_;
    struct HintCache { uint64_t gen = 0; double w = -1, h = -1; Size s; };
    HintCache hc_[2];
    int hcNext_ = 0;
    friend class Window;
};

// ------------------------------------------------------------------ layouts --
enum class Dir { Row, Column };
enum class Justify { Start, Center, End, SpaceBetween };

// A row or column, optionally with a background (then it doubles as a card)
class Box : public Widget {
public:
    explicit Box(Dir d = Dir::Column, double spacing = 0) : dir(d), spacing(spacing) {
        if (d == Dir::Row) crossAlign = Align::Center;
    }
    Dir dir;
    double spacing;
    double pl = 0, pt = 0, pr = 0, pb = 0;
    void padding(double all) { pl = pt = pr = pb = all; }
    void padding(double h, double v) { pl = pr = h; pt = pb = v; }
    Justify justify = Justify::Start;
    Align crossAlign = Align::Start;     // for children with fill = false
    bool crossStretch = true;            // children with fill = true stretch across
    // optional background
    Color bg{0, 0, 0, 0}, border{0, 0, 0, 0}, hoverBg{0, 0, 0, 0}, pressBg{0, 0, 0, 0};
    double radius = 0, borderWidth = 1;
    Size sizeHint(double availW, double availH) override;
    void arrange() override;
    void paint(Painter &p) override;
};
inline Box *row(Widget *parent, double spacing = 8) { return parent->add<Box>(Dir::Row, spacing); }
inline Box *col(Widget *parent, double spacing = 8) { return parent->add<Box>(Dir::Column, spacing); }

// Children on top of each other, all filling the stack (or placed by their own geometry)
class Stack : public Widget {
public:
    bool manual = false;    // children keep the geometry their owner sets (drag & drop)
    Size sizeHint(double availW, double availH) override;
    void arrange() override;
};

class Spacer : public Widget {
public:
    Spacer(double w = 0, double h = 0) { fixedW = w; fixedH = h; }
    Size sizeHint(double, double) override { return {std::max(0.0, fixedW), std::max(0.0, fixedH)}; }
};
inline Spacer *stretch(Widget *parent) { auto *s = parent->add<Spacer>(); s->grow = 1; return s; }

class Separator : public Widget {
public:
    explicit Separator(bool vertical = false, double inset = 0) : vertical(vertical), inset(inset) {}
    bool vertical;
    double inset;
    Size sizeHint(double, double) override { return vertical ? Size{1, 0} : Size{0, 1}; }
    void paint(Painter &p) override;
};

// ------------------------------------------------------------------- basics --
enum class Role { Text, Text2, Text3, Accent, AccentBright, OnAccent, Danger, Custom };
Color roleColor(Role r, Color custom = {});

class Label : public Widget {
public:
    Label(const std::string &s = "", double size = 14, Weight w = Weight::Normal, Role r = Role::Text);
    void setText(const std::string &s) { if (s != text_) { text_ = s; relayout(); } }
    const std::string &text() const { return text_; }
    Font font;
    Role role = Role::Text;
    Color color{0, 0, 0, 0};        // for Role::Custom
    Elide elide = Elide::End;
    int maxLines = 1;               // 0 = unlimited (wraps)
    Align hAlign = Align::Start;
    bool markup = false;
    Size sizeHint(double availW, double availH) override;
    void paint(Painter &p) override;
private:
    std::string text_;
    Text layout_, measure_;
};

class IconW : public Widget {
public:
    IconW(const std::string &n = "", double size = 20, Role r = Role::Text) : iconName(n), size(size), role(r) {}
    std::string iconName;
    double size;
    Role role;
    Color color{0, 0, 0, 0};
    Anim rotation{0};               // degrees (spinners)
    Size sizeHint(double, double) override { return {size, size}; }
    void paint(Painter &p) override;
};

class AppIconW : public Widget {
public:
    AppIconW(const std::string &n = "", double size = 32) : iconName(n), size(size) {}
    std::string iconName;
    double size;
    Size sizeHint(double, double) override { return {size, size}; }
    void paint(Painter &p) override;
};

class ImageW : public Widget {
public:
    std::shared_ptr<Image> image;
    double radius = 0;
    bool cover = true;
    Color placeholder{0, 0, 0, 0};
    std::string placeholderIcon;
    Size sizeHint(double, double) override { return {fixedW > 0 ? fixedW : 48, fixedH > 0 ? fixedH : 48}; }
    void paint(Painter &p) override;
};

// --------------------------------------------------------------- controls --
// Clickable box: background reacts to hover / press. Content goes inside like any Box.
class Button : public Box {
public:
    explicit Button(Dir d = Dir::Row, double spacing = 8);
    bool active = false;            // toggled-on look
    bool enabledB = true;
    Color activeBg{0, 0, 0, 0};      // when active (default: accentSoft)
    Color activeBorder{0, 0, 0, 0};
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
};

// Text button: "Reset", "Log out now"; accent = filled with the accent colour
class TextButton : public Button {
public:
    TextButton(const std::string &label, const std::string &icon = "", bool accent = false);
    Label *label = nullptr;
    IconW *icon = nullptr;
    bool accent;
    void setAccent(bool a);
    void paint(Painter &p) override;
};

class IconButton : public Button {
public:
    IconButton(const std::string &icon, double size = 36, double iconSize = 18);
    IconW *icon;
};

class Toggle : public Widget {
public:
    Toggle(bool on = false);
    bool on() const { return on_; }
    void setOn(bool v, bool animate = true);
    std::function<void(bool)> onToggled;
    Size sizeHint(double, double) override { return {46, 26}; }
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
private:
    bool on_;
    Anim knob_;
};

class Checkbox : public Widget {
public:
    bool checked = false;
    std::function<void(bool)> onToggled;
    Checkbox() { interactive = true; cursor = Cursor::Pointer; }
    Size sizeHint(double, double) override { return {20, 20}; }
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
};

// Horizontal or vertical pill slider with an optional icon inside (volume, brightness)
class Slider : public Widget {
public:
    Slider(bool vertical = false) : vertical(vertical) { interactive = true; cursor = Cursor::Pointer; }
    bool vertical;
    double value() const { return value_; }
    void setValue(double v);
    double maxValue = 1.0;           // 1.5 for over-amplified volume
    std::string iconName;
    bool thick = true;               // big pill (control centre) vs thin track (settings)
    std::function<void(double)> onChanged;    // while dragging
    std::function<void(double)> onReleased;
    Size sizeHint(double, double) override;
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
    void pointerMove(Point p) override;
    void pointerRelease(Point p, int button) override;
    bool scroll(double dx, double dy, bool discrete) override;
private:
    double value_ = 0;
    bool dragging_ = false;
    void fromPoint(Point p);
};

// One choice from a few: "Release | Latest", "S M L", "1 s 2 s 4 s"
class Segmented : public Widget {
public:
    struct Option { std::string value, label, icon; };
    std::vector<Option> options;
    std::string value;
    std::function<void(const std::string &)> onPicked;
    bool small = false;
    Segmented() { interactive = true; cursor = Cursor::Pointer; }
    Size sizeHint(double, double) override;
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
    void pointerMove(Point p) override;
    void pointerLeave() override { hot_ = -1; Widget::pointerLeave(); }
private:
    std::vector<Rect> boxes_;
    int hot_ = -1;
    void measure();
};

// [-]  24 px  [+]
class Stepper : public Widget {
public:
    double value = 0, min = 0, max = 100, step = 1;
    std::string suffix;
    int decimals = 0;
    std::function<void(double)> onChanged;
    Stepper() { interactive = true; }
    Size sizeHint(double, double) override { return {150, 36}; }
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
    void pointerMove(Point p) override { hotX_ = p.x; update(); }
private:
    double hotX_ = -1;
};

// Single-line text field
class TextInput : public Widget {
public:
    TextInput();
    ~TextInput() override;
    std::string text() const { return text_; }
    void setText(const std::string &s);
    std::string placeholder;
    std::string leadingIcon;          // "search"
    bool password = false;
    char32_t mask = U'•';
    double fontSize = 14;
    bool framed = true;               // rounded field background
    std::function<void(const std::string &)> onChanged;
    std::function<void(const std::string &)> onSubmit;
    std::function<bool(const KeyEvent &)> onKeyFirst;   // return true to swallow (up/down in lists)
    Size sizeHint(double availW, double) override { return {std::min(availW, 240.0), framed ? 42.0 : fontSize * 1.6}; }
    void paint(Painter &p) override;
    bool pointerPress(Point p, int button) override;
    void pointerMove(Point p) override;
    void pointerRelease(Point, int) override { selecting_ = false; }
    bool key(const KeyEvent &e) override;
    void focusIn() override;
    void focusOut() override;
    void selectAll();
private:
    std::string text_;
    int cursor_ = 0, anchor_ = 0;       // byte offsets; selection = [min, max)
    bool selecting_ = false;
    double scrollX_ = 0;
    int blinkTimer_ = 0;
    bool caretOn_ = true;
    Text layout_;
    std::string shown() const;
    int shownIndex(int i) const;        // byte index in text_ -> in shown()
    int textIndex(int i) const;
    Rect textRect() const;
    void insert(const std::string &s);
    void eraseSelection();
    void moveCursor(int to, bool select);
    void changed();
};

// Scrolls one child vertically (wheel, touchpad, dragging the bar)
class ScrollView : public Widget {
public:
    ScrollView() { clip = true; interactive = true; }
    Widget *content() const { return children_.empty() ? nullptr : children_[0].get(); }
    double offset() const { return off_; }
    void scrollTo(double y, bool animate = true);
    void ensureVisible(const Rect &r);
    Size sizeHint(double availW, double availH) override;
    void arrange() override;
    void paintOver(Painter &p) override;
    bool scroll(double dx, double dy, bool discrete) override;
    Widget *hitTest(Point p) override;
private:
    double off_ = 0, contentH_ = 0;
    Anim smooth_{0};
    double maxOff() const { return std::max(0.0, contentH_ - geom.h); }
};

// Frosted card. With real blur the compositor blurs what is behind it (blurBehind region);
// otherwise a blurred copy of the wallpaper lined up with the screen stands in.
class Card : public Box {
public:
    explicit Card(Dir d = Dir::Column, double spacing = 12);
    bool shadow = true;
    bool blurBehind = true;
    double shadowBlur = 36, shadowY = 14;
    Color tint{0, 0, 0, 0};             // default theme().surface
    bool useTint = false;
    void paint(Painter &p) override;
};

// ---------------------------------------------------------------- dropdown --
// Shows the current choice; opens a list on top of the window (Window::overlay)
class Dropdown : public Button {
public:
    Dropdown();
    std::vector<std::pair<std::string, std::string>> items;   // value, label
    std::string value;
    std::function<void(const std::string &)> onPicked;
    void setValue(const std::string &v);
    Size sizeHint(double availW, double availH) override;
    void paint(Painter &p) override;
private:
    void open();
};

}  // namespace ui
