# Nova

A desktop environment for Fedora: a **wlroots compositor in C++**, a **QtQuick shell on Quickshell**, a **Qt 6 / C++ Settings app** and a matching **SDDM login theme**.

```
nova/
├── compositor/   C++20 + wlroots: windows, workspaces, snapping, lock, IPC   → `nova`, `novactl`
├── shell/        QML on Quickshell: panel, launcher, control centre, now playing,
│                 notifications, OSD, clipboard, overview, lock screen, wallpaper
├── settings/     Qt 6 C++ backend + QML UI                                  → `nova-settings`
├── sddm/nova/    login screen (same look as the lock screen)
├── session/      nova-session, nova-shell, nova-doctor, wayland-session file, portal config
├── install.sh    dnf deps → build → install to /usr (+ update.sh, tools/, extras/)
└── nova.spec     RPM spec
```

## Install

Paste this in a terminal on Fedora 43 or newer. It finds the newest `Nova-*-source.zip` in the GitHub repo, downloads it, and runs the installer:

```sh
command -v unzip >/dev/null || sudo dnf install -y unzip; z=$(curl -fsSL https://api.github.com/repos/cache-byte/Nova-desktop-environment/contents | grep -oE 'Nova-[0-9.]+-source\.zip' | sort -uV | tail -1); d=$(mktemp -d); curl -fL -o "$d/nova.zip" "https://raw.githubusercontent.com/cache-byte/Nova-desktop-environment/main/$z" && unzip -q "$d/nova.zip" -d "$d/src" && bash "$d/src/install.sh"
```

Or from an unzipped copy: `./install.sh` (`--no-sddm` keeps your current login screen, `--deps` only installs packages).

The installer:

* installs packages with dnf (Quickshell and gpu-screen-recorder from COPR if Fedora doesn't have them, SongRec from Flathub),
* builds and installs Nova to `/usr`,
* switches the login screen to SDDM with the Nova theme (asks first) and unlocks your keyring at login,
* sets GTK, libadwaita/Flatpak and Qt apps up to follow Nova's light/dark mode (adw-gtk3, qt6ct),
* writes every change to `/var/lib/nova/manifest`.

Then reboot (if the login screen changed) and choose **Nova**. You can also try it inside your current desktop first: `nova -s nova-shell`.

**Update:** Settings → Updates (shows each step with a progress bar and asks for your password once), `nova-update` in a terminal, or `./update.sh`. It installs the zip with the highest version number in the repo (or, on the "Latest" channel, the zip from the newest commit).

**Remove:** `nova-uninstall`, or Settings → Updates → Uninstall. It undoes everything in the manifest, including the old login screen. `--remove-deps` also removes packages Nova added and `--purge` deletes your Nova settings.

**Making a release zip:** `tools/set-version.sh 0.0.2` then `tools/package.sh`. Upload `Nova-0.0.2-source.zip` to the repo root.

**Automatic builds on GitHub (optional, one time):** copy `extras/.github/workflows/build.yml` into the repo at `.github/workflows/build.yml`. Every push then unzips the newest zip and builds it on Fedora 43; results are in the Actions tab.

**Defaults:** Papirus-Dark icons, Bibata Modern Classic cursor, Inter font, accent `#C8B64A`, dark mode. Decisions behind everything are in `docs/DECISIONS.md`.

## How the pieces talk

| From → To | How |
|---|---|
| shell ↔ compositor | `$NOVA_SOCK` unix socket. The shell subscribes to workspace, Caps/Num Lock and keybind events. `novactl dispatch <action>` drives the compositor |
| taskbar | `wlr-foreign-toplevel-management` |
| lock screen | `ext-session-lock` + PAM (`/etc/pam.d/nova-lock`) |
| settings ↔ shell | `~/.config/nova/settings.json` (both sides watch it) |
| settings → compositor | `~/.config/nova/nova.conf` + `novactl dispatch reload` |
| GTK/libadwaita apps | `gsettings` (icons, cursor, fonts, colour scheme) |

## Control centre & indicators

* The control centre is a **6-column grid** with 52 px rows. Sliders default to 1 × 3 cells, and a slider turns horizontal on its own if you resize it wider than it is tall. Toggles take 1 cell, Wi-Fi and Bluetooth 3, power mode 6. An older layout is reset to the new default once.
* **Settings → Popups & indicators** places each popup on one of nine anchor points. The popups are volume/brightness/mic, lock keys, power mode, notifications, small messages and Now Playing. Each one runs **Up** (vertical) or **Across** (horizontal). Drag it on the preview to nudge it up to 200 px. You can also set hide-after (1/2/4 s), size (S/M/L), and whether it shows on the screen under the pointer or on all screens.
* Small messages from scripts: `qs ipc call toast show "Copied" clip`.
* The Super tap is set with a bare `Super = …` line under `[bindings]` (empty value turns it off); `super_tap_ms` under `[input]` sets how quick the tap must be (default 400).
* Caps/Num Lock state is restored after restart (`remember_locks` in nova.conf, state kept in `~/.local/state/nova/locks`).

## Keys (edit in `~/.config/nova/nova.conf`)

| Key | Action |
|---|---|
| Super (tap) | app launcher — press and release Super on its own; Super+Space also works |
| Super+A / Super+N / Super+V | control centre / notifications / clipboard |
| Super+Tab | overview |
| Super+Return / Super+E | terminal / files |
| Super+Q, Alt+F4 | close |
| Super+↑ ↓ ← → | maximise / restore-or-minimise / snap left / snap right |
| Super+F | fullscreen (hides the panel) |
| Super+1…9, Super+Shift+1…9 | switch workspace / move window there (on the monitor under the mouse) |
| Super+Ctrl+← →, 3-finger swipe | previous / next workspace |
| 3-finger swipe up | overview |
| Super+Shift+O | move window to the other monitor |
| Super+drag, Super+right-drag | move / resize any window |
| Drag a window to a screen edge | snap left/right half, top edge maximises |
| Super+L | lock |
| Print | capture bar: screenshot or record, region / window / screen |
| Alt+Print, Shift+Print | quick region / full-screen screenshot (clipboard + ~/Pictures/Screenshots) |
| Ctrl+Print, Super+Shift+S | region screenshot, draw on it before saving (Satty) |
| Super+Shift+R | start / stop screen recording (~/Videos/Recordings) |
| Super+Alt+R | save instant replay (when on in Settings → Gaming) |
| Super+G | game overlay |

## Status: read this before you build

* **Not compiled yet.** I wrote this without wlroots, Wayland or Qt dev headers available, so nothing except `novactl` has been built. Expect a handful of compile errors on first build. They'll mostly be small wlroots API differences. The compositor targets **wlroots 0.19**, with guards for 0.18. **0.20 is not supported yet** because wlroots breaks its API every release. The QML has only been checked for balanced brackets, not run.
* **Real blur, rounded window corners and compositor shadows** need [SceneFX](https://github.com/wlrfx/scenefx), a drop-in replacement for `wlr_scene`. Not added yet; the shell fakes blur from the wallpaper meanwhile.
* **Overview thumbnails:** wlroots 0.19 can't capture a single window for another client, so the overview shows each window's app icon instead of a live preview. Window capture arrives with wlroots 0.20 (`ext-image-capture-source` for toplevels).
* **Power profiles** use `tuned-ppd` (Fedora 41+), which provides the same `powerprofilesctl` interface.
* **Night light** uses `gammastep`. **Recording and instant replay** use `gpu-screen-recorder` (falls back to `wf-recorder` without replay).
* **Capture:** Print opens the capture bar (screenshot or record · region, window or screen · sound and mic · draw before saving with Satty). A finished recording's notification has a **Trim** button (`nova-settings --trim FILE`, uses ffmpeg, no re-encode). A red **Stop** pill sits on the panel while recording.
* **Game overlay:** Super+G, also on top of fullscreen games.
* **Shortcuts:** Settings → Keyboard → Shortcuts. Click one and press new keys; conflicts are refused; ↺ goes back to the default.
* **Blur** is faked: glass panels show a blurred copy of the wallpaper behind them (Settings → Appearance → Blur). It doesn't blur windows underneath; that needs SceneFX in the compositor.
* **Hybrid NVIDIA laptops:** the desktop runs on the integrated GPU (`nova-gpu order` sets `WLR_DRM_DEVICES`); games from the launcher start on NVIDIA with GameMode (`nova-gpu run`). Change it in Settings → Power → Graphics.

## Next steps

1. Get it compiling on Fedora 43 (the GitHub Actions build shows the errors).
2. Add SceneFX for blur, corner radius and shadows.
3. Port to wlroots 0.20 for live overview thumbnails and HDR.

## Lyrics lookup

1. A `.lrc` file next to the song.
2. LRCLIB search by title, artist and length.
3. If that finds nothing, SongRec listens to a few seconds of the audio to identify the song.
4. LRCLIB is searched again with SongRec's title and artist.

The current line is coloured with the accent as it is sung, in every lyric style. Lyrics are cached in `~/.cache/nova/lyrics`; misses are retried after a day.

Monitor scale is limited to 100–200 %.
