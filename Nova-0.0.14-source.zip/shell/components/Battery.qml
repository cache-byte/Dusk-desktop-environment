// Compact pill: number inside, level drawn as an arc around the outline.
import QtQuick
import QtQuick.Shapes
import qs.services

Item {
    id: root
    property real level: 0.82          // 0..1
    property bool charging: false
    readonly property color col: level <= 0.15 ? Theme.danger : level <= 0.30 ? Theme.warn : Theme.accentBright
    implicitWidth: 40
    implicitHeight: 22

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: Qt.rgba(1, 1, 1, 0.06)
        border.width: 1.5
        border.color: Qt.rgba(1, 1, 1, 0.16)
    }
    Shape {
        anchors.fill: parent
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            strokeColor: root.col
            strokeWidth: 2.2
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            // Pill outline starting at top-centre, clockwise; trimmed to the level.
            PathSvg { path: "M20 1H29A10 10 0 0 1 29 21H11A10 10 0 0 1 11 1Z" }
            trimPath.start: 0
            trimPath.end: Math.max(0.02, root.level)
        }
    }
    Text {
        anchors.centerIn: parent
        text: root.charging ? "⚡" + Math.round(root.level * 100) : Math.round(root.level * 100)
        color: root.col
        font.family: Theme.font; font.pixelSize: 12; font.weight: Font.Bold
    }
}
