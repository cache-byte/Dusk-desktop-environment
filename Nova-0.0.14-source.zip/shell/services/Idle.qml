// Dim, lock and sleep after inactivity. Separate times on battery and plugged in
// (Settings > Power; 0 = off). Nothing happens while an app inhibits idle
// (video players, browsers playing video) or while anything is fullscreen —
// the compositor treats fullscreen windows as an inhibitor — or with Caffeine on.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Wayland
import Quickshell.Services.UPower

Singleton {
    id: root
    property bool caffeine: false
    readonly property bool onBattery: UPower.onBattery
    readonly property int dimMin:   caffeine ? 0 : (onBattery ? Config.s.idleDimBattery   : Config.s.idleDimAc)
    readonly property int lockMin:  caffeine ? 0 : (onBattery ? Config.s.idleLockBattery  : Config.s.idleLockAc)
    readonly property int sleepMin: caffeine ? 0 : (onBattery ? Config.s.idleSleepBattery : Config.s.idleSleepAc)
    readonly property bool gameMode: Nova.fullscreen
    property real savedBrightness: -1

    IdleMonitor {
        enabled: root.dimMin > 0 && Brightness.available
        timeout: root.dimMin * 60
        respectInhibitors: true
        onIsIdleChanged: {
            if (isIdle) { root.savedBrightness = Brightness.value; Brightness.set(Math.min(Brightness.value, 0.25)) }
            else if (root.savedBrightness > 0) { Brightness.set(root.savedBrightness); root.savedBrightness = -1 }
        }
    }
    IdleMonitor {
        enabled: root.lockMin > 0
        timeout: root.lockMin * 60
        respectInhibitors: true
        onIsIdleChanged: if (isIdle) Nova.lockRequested()
    }
    IdleMonitor {
        enabled: root.sleepMin > 0
        timeout: root.sleepMin * 60
        respectInhibitors: true
        onIsIdleChanged: if (isIdle) Quickshell.execDetached(["systemctl", "suspend"])
    }
}
