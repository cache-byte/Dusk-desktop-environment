// Lock screen (ext-session-lock). Two stages, as sketched:
//   glance: sharp wallpaper, big clock, date in accent, media, status
//   auth:   blurred wallpaper, avatar, password, "Caps Lock is on" below it
import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Services.Pam
import Quickshell.Services.UPower
import qs.services
import qs.components

Scope {
    id: root
    property bool authStage: false
    property string error: ""

    function lock() { authStage = false; error = ""; sessionLock.locked = true }

    Connections { target: Nova; function onLockRequested() { root.lock() } }
    IpcHandler { target: "lock"; function lock(): void { root.lock() } }

    PamContext {
        id: pam
        config: "nova-lock"
        property string pending: ""
        onResponseRequiredChanged: if (responseRequired) { respond(pending); pending = "" }
        onCompleted: result => {
            if (result === PamResult.Success) { sessionLock.locked = false; root.authStage = false; root.error = "" }
            else root.error = "Wrong password";
        }
    }
    function submit(pass) { root.error = ""; pam.pending = pass; pam.start() }

    WlSessionLock {
        id: sessionLock
        locked: false

        WlSessionLockSurface {
            id: surf
            color: "black"

            Image {
                id: wp
                anchors.fill: parent
                source: !Theme.wallpaperIsVideo ? Theme.wallpaperUrl : "file://" + Theme.defaultWallpaper
                fillMode: Image.PreserveAspectCrop
            }
            MultiEffect {
                anchors.fill: parent; source: wp
                blurEnabled: true; blurMax: 64; blur: root.authStage ? 1.0 : 0.0
                brightness: root.authStage ? -0.25 : 0
                Behavior on blur { NumberAnimation { duration: Theme.ms(260) } }
                Behavior on brightness { NumberAnimation { duration: Theme.ms(260) } }
            }
            SystemClock { id: clock; precision: SystemClock.Seconds }

            // any key / click -> auth
            MouseArea { anchors.fill: parent; onClicked: { root.authStage = true; pass.forceActiveFocus() } }
            Item {
                anchors.fill: parent; focus: !root.authStage
                Keys.onPressed: e => { root.authStage = true; pass.forceActiveFocus(); if (e.text) pass.text += e.text }
            }

            // -------- glance --------
            ColumnLayout {
                visible: !root.authStage
                anchors.horizontalCenter: parent.horizontalCenter
                y: parent.height * 0.23
                spacing: 10
                Text { Layout.alignment: Qt.AlignHCenter; text: Qt.formatTime(clock.date, Config.s.clock24 ? "HH:mm" : "h:mm"); color: "white"; font.pixelSize: 176; font.weight: Font.ExtraLight; font.letterSpacing: -6 }
                Text { Layout.alignment: Qt.AlignHCenter; text: Qt.formatDate(clock.date, "dddd d MMMM"); color: Theme.accentBright; font.pixelSize: 28; font.weight: Font.Medium }
                Glass {
                    visible: Media.player !== null
                    Layout.alignment: Qt.AlignHCenter; Layout.topMargin: 90
                    implicitWidth: 460; implicitHeight: 92; radius: 22; padding: 14
                    RowLayout {
                        anchors.fill: parent; spacing: 16
                        Rectangle { implicitWidth: 64; implicitHeight: 64; radius: 12; clip: true; color: Theme.surface3
                            Image { anchors.fill: parent; source: Media.art; fillMode: Image.PreserveAspectCrop } }
                        ColumnLayout { Layout.fillWidth: true; spacing: 2
                            Text { Layout.fillWidth: true; text: Media.title; elide: Text.ElideRight; color: Theme.text; font.pixelSize: 15; font.weight: Font.DemiBold }
                            Text { Layout.fillWidth: true; text: Media.artist; elide: Text.ElideRight; color: Theme.text2; font.pixelSize: 13 } }
                        IconButton { icon: "prev"; color: "transparent"; onClicked: Media.player?.previous() }
                        Rectangle { implicitWidth: 36; implicitHeight: 36; radius: 18; color: Theme.text
                            Icon { anchors.centerIn: parent; name: Media.playing ? "pause" : "play"; size: 16; color: "#15141b" }
                            MouseArea { anchors.fill: parent; onClicked: Media.player?.togglePlaying() } }
                        IconButton { icon: "next"; color: "transparent"; onClicked: Media.player?.next() }
                    }
                }
                Visualizer {
                    visible: Media.playing && (Config.s.vizPlaces ?? []).includes("lock")
                    Layout.alignment: Qt.AlignHCenter; Layout.topMargin: 14
                    implicitWidth: 460; implicitHeight: 60
                }
            }
            Text {
                visible: !root.authStage
                anchors { bottom: parent.bottom; bottomMargin: 44; horizontalCenter: parent.horizontalCenter }
                text: "Press any key or click to unlock"; color: Qt.rgba(1, 1, 1, 0.62); font.pixelSize: 14
            }

            // -------- auth --------
            ColumnLayout {
                visible: root.authStage
                anchors.centerIn: parent
                spacing: 18
                Rectangle {
                    Layout.alignment: Qt.AlignHCenter
                    implicitWidth: 132; implicitHeight: 132; radius: 66; clip: true
                    border.width: 4; border.color: Qt.rgba(1, 1, 1, 0.12)
                    gradient: Gradient { GradientStop { position: 0; color: "#d9925a" } GradientStop { position: 1; color: "#7d3f6b" } }
                    Text { anchors.centerIn: parent; text: (Quickshell.env("USER") || "?")[0].toUpperCase(); color: "white"; font.pixelSize: 52; font.weight: Font.DemiBold }
                    Image { anchors.fill: parent; anchors.margins: 4; source: "file://" + Quickshell.env("HOME") + "/.face"; fillMode: Image.PreserveAspectCrop }
                }
                Text { Layout.alignment: Qt.AlignHCenter; text: Quickshell.env("USER"); color: "white"; font.pixelSize: 26; font.weight: Font.DemiBold }
                Glass {
                    id: field
                    Layout.alignment: Qt.AlignHCenter
                    implicitWidth: 380; implicitHeight: 54; radius: 27; padding: 0
                    RowLayout {
                        anchors.fill: parent; anchors.leftMargin: 22; anchors.rightMargin: 6; spacing: 10
                        TextInput {
                            id: pass
                            Layout.fillWidth: true
                            echoMode: showPass.on ? TextInput.Normal : TextInput.Password
                            passwordCharacter: "•"
                            color: Theme.text; font.pixelSize: showPass.on ? 16 : 22; font.letterSpacing: showPass.on ? 0 : 4
                            enabled: !pam.active
                            Keys.onReturnPressed: { root.submit(text); text = "" }
                            Keys.onEscapePressed: { text = ""; root.authStage = false }
                        }
                        Item {
                            id: showPass; property bool on: false
                            implicitWidth: 26; implicitHeight: 26
                            Icon { anchors.centerIn: parent; name: "eye"; color: showPass.on ? Theme.accentBright : Theme.text2 }
                            MouseArea { anchors.fill: parent; onClicked: showPass.on = !showPass.on }
                        }
                        Rectangle {
                            implicitWidth: 42; implicitHeight: 42; radius: 21; color: Theme.accent
                            Icon { anchors.centerIn: parent; name: "arrow"; color: Theme.onAccent }
                            MouseArea { anchors.fill: parent; onClicked: { root.submit(pass.text); pass.text = "" } }
                        }
                    }
                    SequentialAnimation on x {
                        id: shake; running: false
                        NumberAnimation { by: -12; duration: 50 } NumberAnimation { by: 24; duration: 80 } NumberAnimation { by: -12; duration: 50 }
                    }
                }
                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: root.error || (Nova.capsLock ? "Caps Lock is on" : pam.active ? "Checking…" : "")
                    color: root.error ? "#ff8a7a" : Theme.accentBright; font.pixelSize: 13
                    onTextChanged: if (root.error) shake.restart()
                }
            }

            // -------- status corners --------
            Glass {
                anchors { left: parent.left; bottom: parent.bottom; margins: 28 }
                implicitWidth: statusRow.implicitWidth + 32; implicitHeight: 44; radius: 22; padding: 0
                RowLayout {
                    id: statusRow; anchors.centerIn: parent; spacing: 16
                    Battery { visible: UPower.displayDevice?.isLaptopBattery ?? false; level: UPower.displayDevice?.percentage ?? 0; charging: !UPower.onBattery }
                    Icon { name: "wifi"; color: Net.ssid ? Theme.text : Theme.text3 }
                    RowLayout { visible: !root.authStage; spacing: 6; Icon { name: "bell"; color: Theme.text } Text { text: Notifs.count; color: Theme.text; font.pixelSize: 13 } }
                }
            }
            Glass {
                anchors { right: parent.right; bottom: parent.bottom; margins: 28 }
                implicitWidth: powerRow.implicitWidth + 12; implicitHeight: 44; radius: 22; padding: 0
                RowLayout {
                    id: powerRow; anchors.centerIn: parent; spacing: 2
                    IconButton { icon: "moon"; color: "transparent"; implicitWidth: 34; implicitHeight: 34; onClicked: Quickshell.execDetached(["systemctl", "suspend"]) }
                    IconButton { icon: "restart"; color: "transparent"; implicitWidth: 34; implicitHeight: 34; onClicked: Quickshell.execDetached(["systemctl", "reboot"]) }
                    IconButton { icon: "power"; color: "transparent"; implicitWidth: 34; implicitHeight: 34; onClicked: Quickshell.execDetached(["systemctl", "poweroff"]) }
                }
            }
        }
    }

}
