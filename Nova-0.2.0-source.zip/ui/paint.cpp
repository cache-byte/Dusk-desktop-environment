#include "paint.hpp"

#include <cairo.h>
#include <librsvg/rsvg.h>
#include <pango/pangocairo.h>

#include <cstring>
#include <filesystem>
#include <list>
#include <unordered_map>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_PSD
#define STBI_NO_HDR
#define STBI_NO_PIC
#define STBI_NO_PNM
#include "stb_image.h"

namespace fs = std::filesystem;

namespace ui {

// -------------------------------------------------------------------- text --
static PangoContext *pangoContext() {
    static PangoContext *ctx = [] {
        PangoFontMap *map = pango_cairo_font_map_get_default();
        PangoContext *c = pango_font_map_create_context(map);
        cairo_font_options_t *o = cairo_font_options_create();
        cairo_font_options_set_antialias(o, CAIRO_ANTIALIAS_GRAY);
        cairo_font_options_set_hint_style(o, CAIRO_HINT_STYLE_SLIGHT);
        cairo_font_options_set_hint_metrics(o, CAIRO_HINT_METRICS_OFF);
        pango_cairo_context_set_font_options(c, o);
        cairo_font_options_destroy(o);
        return c;
    }();
    return ctx;
}

static PangoFontDescription *makeFont(const Font &f) {
    PangoFontDescription *d = pango_font_description_new();
    std::string fam = !f.family.empty() ? f.family : (f.mono ? theme().mono : theme().font);
    pango_font_description_set_family(d, (fam + (f.mono ? ",monospace" : ",sans-serif")).c_str());
    pango_font_description_set_absolute_size(d, f.size * PANGO_SCALE);
    pango_font_description_set_weight(d, (PangoWeight)f.weight);
    if (f.italic) pango_font_description_set_style(d, PANGO_STYLE_ITALIC);
    return d;
}

Text::Text(const std::string &s, Font f, double maxWidth, Elide e, int maxLines, bool markup) {
    set(s, f, maxWidth, e, maxLines, markup);
}
Text::~Text() {
    if (layout_) g_object_unref(layout_);
}
Text::Text(Text &&o) noexcept { *this = std::move(o); }
Text &Text::operator=(Text &&o) noexcept {
    if (this != &o) {
        if (layout_) g_object_unref(layout_);
        layout_ = o.layout_; o.layout_ = nullptr;
        size_ = o.size_; baseline_ = o.baseline_; str_ = std::move(o.str_); font_ = o.font_;
        maxWidth_ = o.maxWidth_; elide_ = o.elide_; maxLines_ = o.maxLines_; markup_ = o.markup_;
    }
    return *this;
}
void Text::set(const std::string &s, Font f, double maxWidth, Elide e, int maxLines, bool markup) {
    if (layout_ && s == str_ && f.size == font_.size && f.weight == font_.weight && f.family == font_.family &&
        f.mono == font_.mono && maxWidth == maxWidth_ && e == elide_ && maxLines == maxLines_ && markup == markup_ &&
        f.letterSpacing == font_.letterSpacing && f.italic == font_.italic)
        return;
    str_ = s; font_ = f; maxWidth_ = maxWidth; elide_ = e; maxLines_ = maxLines; markup_ = markup;
    build();
}
void Text::build() {
    if (!layout_) layout_ = pango_layout_new(pangoContext());
    PangoFontDescription *d = makeFont(font_);
    pango_layout_set_font_description(layout_, d);
    pango_font_description_free(d);
    PangoAttrList *attrs = pango_attr_list_new();
    if (font_.letterSpacing != 0) pango_attr_list_insert(attrs, pango_attr_letter_spacing_new((int)(font_.letterSpacing * PANGO_SCALE)));
    pango_attr_list_insert(attrs, pango_attr_font_features_new("tnum=0"));
    if (markup_) pango_layout_set_markup(layout_, str_.c_str(), -1);
    else pango_layout_set_text(layout_, str_.c_str(), -1);
    pango_layout_set_attributes(layout_, attrs);
    pango_attr_list_unref(attrs);
    pango_layout_set_width(layout_, maxWidth_ > 0 ? (int)(maxWidth_ * PANGO_SCALE) : -1);
    pango_layout_set_wrap(layout_, PANGO_WRAP_WORD_CHAR);
    pango_layout_set_height(layout_, maxLines_ > 0 ? -maxLines_ : -1000);
    PangoEllipsizeMode em = PANGO_ELLIPSIZE_NONE;
    if (maxWidth_ > 0) {
        switch (elide_) {
        case Elide::End: em = PANGO_ELLIPSIZE_END; break;
        case Elide::Middle: em = PANGO_ELLIPSIZE_MIDDLE; break;
        case Elide::Start: em = PANGO_ELLIPSIZE_START; break;
        case Elide::None: em = PANGO_ELLIPSIZE_NONE; break;
        }
    }
    pango_layout_set_ellipsize(layout_, em);
    int w, h;
    pango_layout_get_pixel_size(layout_, &w, &h);
    size_ = {(double)w, (double)h};
    baseline_ = pango_layout_get_baseline(layout_) / (double)PANGO_SCALE;
}
double Text::xForIndex(int index) const {
    if (!layout_) return 0;
    PangoRectangle pos;
    pango_layout_index_to_pos(layout_, std::clamp(index, 0, (int)str_.size()), &pos);
    return pos.x / (double)PANGO_SCALE;
}
int Text::indexForX(double x) const {
    if (!layout_) return 0;
    int index = 0, trailing = 0;
    pango_layout_xy_to_index(layout_, (int)(x * PANGO_SCALE), 0, &index, &trailing);
    // move past the character when the click was on its right half
    const char *s = str_.c_str();
    while (trailing-- > 0 && index < (int)str_.size()) index = (int)(g_utf8_next_char(s + index) - s);
    return index;
}
Size measureText(const std::string &s, const Font &f, double maxWidth, int maxLines) {
    Text t(s, f, maxWidth, Elide::End, maxLines);
    return t.size();
}

// ------------------------------------------------------------------ painter --
void Painter::save() { cairo_save(cr_); }
void Painter::restore() { cairo_restore(cr_); }
void Painter::translate(double x, double y) { cairo_translate(cr_, x, y); }
void Painter::scale(double s) { cairo_scale(cr_, s, s); }
void Painter::setOpacityGroup() { cairo_push_group(cr_); }
void Painter::endOpacityGroup(double a) {
    cairo_pop_group_to_source(cr_);
    cairo_paint_with_alpha(cr_, std::clamp(a, 0.0, 1.0));
}
void Painter::roundRectPath(const Rect &r, double radius) { roundRectPath(r, radius, radius, radius, radius); }
void Painter::roundRectPath(const Rect &r, double tl, double tr, double br, double bl) {
    double m = std::min(r.w, r.h) / 2;
    tl = std::clamp(tl, 0.0, m); tr = std::clamp(tr, 0.0, m); br = std::clamp(br, 0.0, m); bl = std::clamp(bl, 0.0, m);
    cairo_new_sub_path(cr_);
    if (tr > 0) cairo_arc(cr_, r.x + r.w - tr, r.y + tr, tr, -M_PI / 2, 0); else cairo_move_to(cr_, r.x + r.w, r.y);
    if (br > 0) cairo_arc(cr_, r.x + r.w - br, r.y + r.h - br, br, 0, M_PI / 2); else cairo_line_to(cr_, r.x + r.w, r.y + r.h);
    if (bl > 0) cairo_arc(cr_, r.x + bl, r.y + r.h - bl, bl, M_PI / 2, M_PI); else cairo_line_to(cr_, r.x, r.y + r.h);
    if (tl > 0) cairo_arc(cr_, r.x + tl, r.y + tl, tl, M_PI, 3 * M_PI / 2); else cairo_line_to(cr_, r.x, r.y);
    cairo_close_path(cr_);
}
void Painter::clip(const Rect &r, double radius) {
    if (radius > 0) roundRectPath(r, radius);
    else cairo_rectangle(cr_, r.x, r.y, r.w, r.h);
    cairo_clip(cr_);
}
static void src(cairo_t *cr, Color c) { cairo_set_source_rgba(cr, c.r, c.g, c.b, c.a); }
void Painter::fill(const Rect &r, Color c, double radius) {
    if (c.a <= 0 || r.empty()) return;
    src(cr_, c);
    if (radius > 0) roundRectPath(r, radius);
    else cairo_rectangle(cr_, r.x, r.y, r.w, r.h);
    cairo_fill(cr_);
}
void Painter::stroke(const Rect &r, Color c, double width, double radius) {
    if (c.a <= 0 || width <= 0) return;
    src(cr_, c);
    cairo_set_line_width(cr_, width);
    Rect in = r.inset(width / 2);
    if (radius > 0) roundRectPath(in, std::max(0.0, radius - width / 2));
    else cairo_rectangle(cr_, in.x, in.y, in.w, in.h);
    cairo_stroke(cr_);
}
void Painter::fillCircle(Point c, double r, Color col) {
    src(cr_, col);
    cairo_new_sub_path(cr_);
    cairo_arc(cr_, c.x, c.y, r, 0, 2 * M_PI);
    cairo_fill(cr_);
}
void Painter::strokeCircle(Point c, double r, Color col, double width) {
    src(cr_, col);
    cairo_set_line_width(cr_, width);
    cairo_new_sub_path(cr_);
    cairo_arc(cr_, c.x, c.y, r, 0, 2 * M_PI);
    cairo_stroke(cr_);
}
void Painter::line(Point a, Point b, Color c, double width, bool round) {
    src(cr_, c);
    cairo_set_line_width(cr_, width);
    cairo_set_line_cap(cr_, round ? CAIRO_LINE_CAP_ROUND : CAIRO_LINE_CAP_BUTT);
    cairo_move_to(cr_, a.x, a.y);
    cairo_line_to(cr_, b.x, b.y);
    cairo_stroke(cr_);
}
void Painter::arc(Point c, double r, double a0, double a1, Color col, double width) {
    src(cr_, col);
    cairo_set_line_width(cr_, width);
    cairo_set_line_cap(cr_, CAIRO_LINE_CAP_ROUND);
    cairo_new_sub_path(cr_);
    cairo_arc(cr_, c.x, c.y, r, a0, a1);
    cairo_stroke(cr_);
}
void Painter::gradient(const Rect &r, Color top, Color bottom, double radius, bool horizontal) {
    cairo_pattern_t *p = horizontal ? cairo_pattern_create_linear(r.x, 0, r.right(), 0) : cairo_pattern_create_linear(0, r.y, 0, r.bottom());
    cairo_pattern_add_color_stop_rgba(p, 0, top.r, top.g, top.b, top.a);
    cairo_pattern_add_color_stop_rgba(p, 1, bottom.r, bottom.g, bottom.b, bottom.a);
    cairo_set_source(cr_, p);
    if (radius > 0) roundRectPath(r, radius);
    else cairo_rectangle(cr_, r.x, r.y, r.w, r.h);
    cairo_fill(cr_);
    cairo_pattern_destroy(p);
}

// ---- box blur on an A8 / ARGB32 surface (3 passes ~ gaussian) ----
static void boxBlurChannel(uint8_t *data, int w, int h, int stride, int bpp, int ch, int radius) {
    if (radius < 1) return;
    std::vector<uint8_t> tmp(std::max(w, h));
    for (int pass = 0; pass < 3; pass++) {
        for (int y = 0; y < h; y++) {      // horizontal
            uint8_t *row = data + y * stride;
            int sum = 0, n = 0;
            for (int x = -radius; x <= radius; x++) if (x >= 0 && x < w) { sum += row[x * bpp + ch]; n++; }
            for (int x = 0; x < w; x++) {
                tmp[x] = (uint8_t)(sum / std::max(1, n));
                int out = x - radius, in = x + radius + 1;
                if (out >= 0) { sum -= row[out * bpp + ch]; n--; }
                if (in < w) { sum += row[in * bpp + ch]; n++; }
            }
            for (int x = 0; x < w; x++) row[x * bpp + ch] = tmp[x];
        }
        for (int x = 0; x < w; x++) {      // vertical
            int sum = 0, n = 0;
            for (int y = -radius; y <= radius; y++) if (y >= 0 && y < h) { sum += data[y * stride + x * bpp + ch]; n++; }
            for (int y = 0; y < h; y++) {
                tmp[y] = (uint8_t)(sum / std::max(1, n));
                int out = y - radius, in = y + radius + 1;
                if (out >= 0) { sum -= data[out * stride + x * bpp + ch]; n--; }
                if (in < h) { sum += data[in * stride + x * bpp + ch]; n++; }
            }
            for (int y = 0; y < h; y++) data[y * stride + x * bpp + ch] = tmp[y];
        }
    }
}

struct ShadowKey {
    int w, h, r, blur, spread;
    bool operator==(const ShadowKey &o) const { return w == o.w && h == o.h && r == o.r && blur == o.blur && spread == o.spread; }
};
struct ShadowKeyHash {
    size_t operator()(const ShadowKey &k) const { return ((size_t)k.w * 73856093) ^ ((size_t)k.h * 19349663) ^ (k.r * 83492791) ^ (k.blur * 31) ^ k.spread; }
};
void Painter::shadow(const Rect &r, double radius, double blur, double offsetY, Color c, double spread) {
    if (c.a <= 0 || r.empty()) return;
    // the mask is cached per size: cards re-use it every frame
    static std::unordered_map<ShadowKey, cairo_surface_t *, ShadowKeyHash> cache;
    int pad = (int)std::ceil(blur) + 2;
    ShadowKey k{(int)r.w, (int)r.h, (int)radius, (int)blur, (int)spread};
    cairo_surface_t *mask;
    if (auto it = cache.find(k); it != cache.end()) mask = it->second;
    else {
        if (cache.size() > 64) { for (auto &e : cache) cairo_surface_destroy(e.second); cache.clear(); }
        int mw = k.w + 2 * pad + 2 * k.spread, mh = k.h + 2 * pad + 2 * k.spread;
        mask = cairo_image_surface_create(CAIRO_FORMAT_A8, std::max(1, mw), std::max(1, mh));
        cairo_t *m = cairo_create(mask);
        Painter mp(m);
        mp.fill({(double)pad, (double)pad, (double)k.w + 2 * k.spread, (double)k.h + 2 * k.spread}, {0, 0, 0, 1}, radius + k.spread);
        cairo_destroy(m);
        cairo_surface_flush(mask);
        boxBlurChannel(cairo_image_surface_get_data(mask), mw, mh, cairo_image_surface_get_stride(mask), 1, 0, std::max(1, (int)(blur / 2)));
        cairo_surface_mark_dirty(mask);
        cache[k] = mask;
    }
    src(cr_, c);
    cairo_mask_surface(cr_, mask, r.x - pad - spread, r.y - pad - spread + offsetY);
}

// ---- text drawing ----
void Painter::text(const Text &t, Point at, Color c) {
    if (!t.layout() || c.a <= 0) return;
    src(cr_, c);
    cairo_move_to(cr_, at.x, at.y);
    pango_cairo_update_layout(cr_, t.layout());
    pango_cairo_show_layout(cr_, t.layout());
}
void Painter::textIn(const Text &t, const Rect &box, Color c, Align h, Align v) {
    Size s = t.size();
    double x = h == Align::Start ? box.x : h == Align::Center ? box.x + (box.w - s.w) / 2 : box.right() - s.w;
    double y = v == Align::Start ? box.y : v == Align::Center ? box.y + (box.h - s.h) / 2 : box.bottom() - s.h;
    text(t, {std::round(x), std::round(y)}, c);
}
void Painter::textAt(const std::string &s, const Font &f, Point at, Color c) {
    Text t(s, f);
    text(t, at, c);
}

// -------------------------------------------------------------------- icons --
static std::string g_iconDir = "/usr/share/nova/icons";
static std::string g_iconTheme = "Papirus-Dark";
void setIconSearchPath(const std::string &dir) { g_iconDir = dir; }
void setIconTheme(const std::string &t) { g_iconTheme = t; }

// rendered icon masks / images, keyed by "path@WxH"
struct SurfCache {
    std::unordered_map<std::string, cairo_surface_t *> map;
    std::list<std::string> order;
    cairo_surface_t *get(const std::string &k) {
        auto it = map.find(k);
        return it == map.end() ? nullptr : it->second;
    }
    void put(const std::string &k, cairo_surface_t *s) {
        if (map.size() > 400) {
            for (int i = 0; i < 100 && !order.empty(); i++) {
                auto o = order.front(); order.pop_front();
                if (auto it = map.find(o); it != map.end()) { if (it->second) cairo_surface_destroy(it->second); map.erase(it); }
            }
        }
        map[k] = s;
        order.push_back(k);
    }
};
static SurfCache &iconCache() { static SurfCache c; return c; }

static double deviceScale(cairo_t *cr) {
    double sx = 1, sy = 1;
    cairo_surface_get_device_scale(cairo_get_target(cr), &sx, &sy);
    double ux = 1, uy = 0;
    cairo_user_to_device_distance(cr, &ux, &uy);   // includes any painter scale()
    return std::max(sx, std::hypot(ux, uy));
}

// render an SVG file to an ARGB surface of pw × ph device pixels
static cairo_surface_t *renderSvg(const std::string &path, int pw, int ph) {
    GError *err = nullptr;
    RsvgHandle *h = rsvg_handle_new_from_file(path.c_str(), &err);
    if (!h) { if (err) g_error_free(err); return nullptr; }
    cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, pw, ph);
    cairo_t *c = cairo_create(s);
    RsvgRectangle vp{0, 0, (double)pw, (double)ph};
    rsvg_handle_render_document(h, c, &vp, &err);
    if (err) g_error_free(err);
    cairo_destroy(c);
    g_object_unref(h);
    return s;
}

void Painter::icon(const std::string &name, const Rect &r, Color c) {
    if (name.empty() || c.a <= 0) return;
    double ds = deviceScale(cr_);
    int pw = std::max(1, (int)std::lround(r.w * ds)), ph = std::max(1, (int)std::lround(r.h * ds));
    std::string path = name[0] == '/' ? name : g_iconDir + "/" + name + ".svg";
    std::string key = path + "@" + std::to_string(pw) + "x" + std::to_string(ph);
    cairo_surface_t *s = iconCache().get(key);
    if (!s) {
        s = renderSvg(path, pw, ph);
        iconCache().put(key, s);
    }
    if (!s) return;
    // the icon's alpha is the mask; any colour can be painted through it
    cairo_save(cr_);
    cairo_translate(cr_, r.x, r.y);
    cairo_scale(cr_, r.w / pw, r.h / ph);
    src(cr_, c);
    cairo_mask_surface(cr_, s, 0, 0);
    cairo_restore(cr_);
}
void Painter::icon(const std::string &name, Point center, double size, Color c) {
    icon(name, {center.x - size / 2, center.y - size / 2, size, size}, c);
}

// --- app icon theme lookup (XDG icon theme spec, simplified) ---
static std::vector<std::string> iconBaseDirs() {
    std::vector<std::string> d = {homeDir() + "/.local/share/icons", homeDir() + "/.icons"};
    const char *xdd = getenv("XDG_DATA_DIRS");
    std::string dirs = xdd && *xdd ? xdd : "/usr/local/share:/usr/share";
    for (auto &p : split(dirs, ':')) if (!p.empty()) d.push_back(p + "/icons");
    d.push_back(homeDir() + "/.local/share/flatpak/exports/share/icons");
    d.push_back("/var/lib/flatpak/exports/share/icons");
    return d;
}
std::string findAppIcon(const std::string &name, int size) {
    if (name.empty()) return "";
    if (name[0] == '/') return fs::exists(name) ? name : "";
    static std::unordered_map<std::string, std::string> memo;
    std::string key = g_iconTheme + "/" + name + "@" + std::to_string(size);
    if (auto it = memo.find(key); it != memo.end()) return it->second;
    std::string found;
    std::vector<std::string> themes = {g_iconTheme};
    // Papirus-Dark inherits Papirus; everything falls back to hicolor
    if (endsWith(g_iconTheme, "-Dark") || endsWith(g_iconTheme, "-Light")) themes.push_back(g_iconTheme.substr(0, g_iconTheme.rfind('-')));
    themes.push_back("Adwaita");
    themes.push_back("hicolor");
    static const char *sizes[] = {"scalable", "64x64", "48x48", "128x128", "256x256", "32x32", "96x96", "512x512", "24x24", "22x22", "16x16"};
    static const char *cats[] = {"apps", "applications", "devices", "places", "mimetypes", "status", "actions", "categories", "panel"};
    for (auto &base : iconBaseDirs()) {
        for (auto &th : themes) {
            std::string tdir = base + "/" + th;
            if (!fs::is_directory(tdir)) continue;
            for (const char *sz : sizes)
                for (const char *cat : cats) {
                    // both layouts exist: <size>/<cat> (hicolor) and <cat>/<size> (Papirus)
                    for (std::string dir : {tdir + "/" + sz + "/" + cat, tdir + "/" + cat + "/" + sz}) {
                        for (const char *ext : {".svg", ".png"}) {
                            std::string p = dir + "/" + name + ext;
                            if (fs::exists(p)) { found = p; goto done; }
                        }
                    }
                }
        }
    }
    for (std::string p : {"/usr/share/pixmaps/" + name + ".png", "/usr/share/pixmaps/" + name + ".svg"})
        if (fs::exists(p)) { found = p; break; }
done:
    memo[key] = found;
    return found;
}

void Painter::appIcon(const std::string &nameOrPath, const Rect &r) {
    double ds = deviceScale(cr_);
    int pw = std::max(1, (int)std::lround(r.w * ds)), ph = std::max(1, (int)std::lround(r.h * ds));
    std::string path = findAppIcon(nameOrPath, pw);
    if (path.empty()) path = findAppIcon("application-x-executable", pw);
    if (path.empty()) {   // last resort: a soft square
        fill(r.inset(r.w * 0.1), theme().surface3, r.w * 0.22);
        return;
    }
    std::string key = "app:" + path + "@" + std::to_string(pw) + "x" + std::to_string(ph);
    cairo_surface_t *s = iconCache().get(key);
    if (!s) {
        if (endsWith(path, ".svg")) s = renderSvg(path, pw, ph);
        else {
            Image img(path, pw, ph);
            if (img.valid()) { s = img.surface(); cairo_surface_reference(s); }
        }
        iconCache().put(key, s);
    }
    if (!s) return;
    cairo_save(cr_);
    int iw = cairo_image_surface_get_width(s), ih = cairo_image_surface_get_height(s);
    cairo_translate(cr_, r.x, r.y);
    cairo_scale(cr_, r.w / iw, r.h / ih);
    cairo_set_source_surface(cr_, s, 0, 0);
    cairo_pattern_set_filter(cairo_get_source(cr_), CAIRO_FILTER_GOOD);
    cairo_paint(cr_);
    cairo_restore(cr_);
}

// ------------------------------------------------------------------- images --
Image Image::fromRawArgb(const std::string &path) {
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return Image();
    int32_t hdr[2] = {0, 0};
    if (fread(hdr, sizeof hdr, 1, f) != 1 || hdr[0] <= 0 || hdr[1] <= 0 || hdr[0] > 8192 || hdr[1] > 8192) { fclose(f); return Image(); }
    cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, hdr[0], hdr[1]);
    unsigned char *d = cairo_image_surface_get_data(s);
    int stride = cairo_image_surface_get_stride(s);
    bool ok = true;
    for (int y = 0; y < hdr[1] && ok; y++) ok = fread(d + y * stride, 4, hdr[0], f) == (size_t)hdr[0];
    fclose(f);
    if (!ok) { cairo_surface_destroy(s); return Image(); }
    cairo_surface_mark_dirty(s);
    return fromSurface(s);
}
Image::Image(const std::string &path, int maxW, int maxH) {
    int w, h, n;
    unsigned char *px = stbi_load(path.c_str(), &w, &h, &n, 4);
    if (!px) return;
    cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, w, h);
    unsigned char *d = cairo_image_surface_get_data(s);
    int stride = cairo_image_surface_get_stride(s);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            unsigned char *p = px + (y * w + x) * 4;
            uint32_t a = p[3];
            uint32_t r = p[0] * a / 255, g = p[1] * a / 255, b = p[2] * a / 255;
            *(uint32_t *)(d + y * stride + x * 4) = (a << 24) | (r << 16) | (g << 8) | b;
        }
    stbi_image_free(px);
    cairo_surface_mark_dirty(s);
    // scale down large images once (wallpapers are decoded at screen size)
    if ((maxW > 0 && w > maxW) || (maxH > 0 && h > maxH)) {
        double f = std::max(maxW > 0 ? (double)maxW / w : 0.0, maxH > 0 ? (double)maxH / h : 0.0);
        if (f <= 0) f = std::min(maxW > 0 ? (double)maxW / w : 1.0, maxH > 0 ? (double)maxH / h : 1.0);
        int nw = std::max(1, (int)std::lround(w * f)), nh = std::max(1, (int)std::lround(h * f));
        cairo_surface_t *t = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, nw, nh);
        cairo_t *c = cairo_create(t);
        cairo_scale(c, (double)nw / w, (double)nh / h);
        cairo_set_source_surface(c, s, 0, 0);
        cairo_pattern_set_filter(cairo_get_source(c), CAIRO_FILTER_GOOD);
        cairo_paint(c);
        cairo_destroy(c);
        cairo_surface_destroy(s);
        s = t; w = nw; h = nh;
    }
    s_ = s; w_ = w; h_ = h;
}
Image::~Image() {
    if (s_) cairo_surface_destroy(s_);
}
Image &Image::operator=(Image &&o) noexcept {
    if (this != &o) {
        if (s_) cairo_surface_destroy(s_);
        s_ = o.s_; w_ = o.w_; h_ = o.h_;
        o.s_ = nullptr;
    }
    return *this;
}
Image Image::fromSurface(cairo_surface_t *s) {
    Image i;
    if (!s) return i;
    i.s_ = s;
    i.w_ = cairo_image_surface_get_width(s);
    i.h_ = cairo_image_surface_get_height(s);
    return i;
}
Image Image::blurred(int radius, double saturation) const {
    if (!s_) return {};
    // work at a quarter of the size: much faster and blur hides the difference
    int f = radius >= 8 ? 4 : 2;
    int w = std::max(1, w_ / f), h = std::max(1, h_ / f);
    cairo_surface_t *t = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, w, h);
    cairo_t *c = cairo_create(t);
    cairo_scale(c, (double)w / w_, (double)h / h_);
    cairo_set_source_surface(c, s_, 0, 0);
    cairo_pattern_set_filter(cairo_get_source(c), CAIRO_FILTER_GOOD);
    cairo_paint(c);
    cairo_destroy(c);
    cairo_surface_flush(t);
    unsigned char *d = cairo_image_surface_get_data(t);
    int stride = cairo_image_surface_get_stride(t);
    for (int ch = 0; ch < 4; ch++) boxBlurChannel(d, w, h, stride, 4, ch, std::max(1, radius / f));
    if (saturation != 1.0) {
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                uint8_t *p = d + y * stride + x * 4;
                double l = 0.0722 * p[0] + 0.7152 * p[1] + 0.2126 * p[2];
                for (int k = 0; k < 3; k++) p[k] = (uint8_t)std::clamp(l + (p[k] - l) * saturation, 0.0, (double)p[3]);
            }
    }
    cairo_surface_mark_dirty(t);
    return fromSurface(t);
}
Color Image::average() const {
    if (!s_) return {};
    cairo_surface_flush(s_);
    const unsigned char *d = cairo_image_surface_get_data(s_);
    int stride = cairo_image_surface_get_stride(s_);
    double r = 0, g = 0, b = 0;
    long n = 0;
    int step = std::max(1, std::min(w_, h_) / 64);
    for (int y = 0; y < h_; y += step)
        for (int x = 0; x < w_; x += step) {
            const unsigned char *p = d + y * stride + x * 4;
            b += p[0]; g += p[1]; r += p[2]; n++;
        }
    if (!n) return {};
    return {r / n / 255, g / n / 255, b / n / 255, 1};
}
void Painter::image(const Image &img, const Rect &r, double radius, bool cover, double opacity) {
    if (!img.valid() || r.empty()) return;
    cairo_save(cr_);
    if (radius > 0) { roundRectPath(r, radius); cairo_clip(cr_); }
    else { cairo_rectangle(cr_, r.x, r.y, r.w, r.h); cairo_clip(cr_); }
    double sx = r.w / img.width(), sy = r.h / img.height();
    double s = cover ? std::max(sx, sy) : std::min(sx, sy);
    double w = img.width() * s, h = img.height() * s;
    cairo_translate(cr_, r.x + (r.w - w) / 2, r.y + (r.h - h) / 2);
    cairo_scale(cr_, s, s);
    cairo_set_source_surface(cr_, img.surface(), 0, 0);
    cairo_pattern_set_filter(cairo_get_source(cr_), CAIRO_FILTER_GOOD);
    if (opacity < 1) cairo_paint_with_alpha(cr_, opacity);
    else cairo_paint(cr_);
    cairo_restore(cr_);
}

}  // namespace ui
