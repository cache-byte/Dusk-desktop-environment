// Window previews for the overview: each window's surfaces (with subsurfaces) are read back
// from their textures, composed at the window's size, scaled down and written as raw ARGB
// files in $XDG_RUNTIME_DIR/nova-thumbs/<id>.raw  (header: int32 width, int32 height).
#include "ipc.hpp"
#include "server.hpp"

#include <cstdio>
#include <cstring>
#include <sys/stat.h>
#include <vector>
extern "C" {
#include <drm_fourcc.h>
#include <wlr/render/wlr_texture.h>
}

namespace {
struct Canvas {
    int w = 0, h = 0;
    double scale = 1;     // canvas pixels per surface-local unit
    std::vector<uint32_t> px;
};
struct Ctx {
    Canvas *c;
    int ox, oy;           // geometry offset (client-side shadows are cut off)
};

void draw_surface(wlr_surface *s, int sx, int sy, void *data) {
    auto *ctx = static_cast<Ctx *>(data);
    Canvas &c = *ctx->c;
    wlr_texture *tex = wlr_surface_get_texture(s);
    if (!tex || tex->width == 0 || tex->height == 0) return;
    int tw = (int)tex->width, th = (int)tex->height;
    std::vector<uint32_t> buf((size_t)tw * th);
    wlr_texture_read_pixels_options opt{
        .data = buf.data(),
        .format = DRM_FORMAT_ARGB8888,
        .stride = (uint32_t)tw * 4,
        .dst_x = 0,
        .dst_y = 0,
        .src_box = {0, 0, tw, th},
    };
    if (!wlr_texture_read_pixels(tex, &opt)) return;
    bool opaque = wlr_texture_preferred_read_format(tex) == DRM_FORMAT_XRGB8888;
    // where this surface lands on the canvas, and how big (buffer scale may differ)
    int lw = s->current.width > 0 ? s->current.width : tw, lh = s->current.height > 0 ? s->current.height : th;
    double x0 = (sx - ctx->ox) * c.scale, y0 = (sy - ctx->oy) * c.scale;
    double dw = lw * c.scale, dh = lh * c.scale;
    int ix0 = std::max(0, (int)x0), iy0 = std::max(0, (int)y0);
    int ix1 = std::min(c.w, (int)(x0 + dw)), iy1 = std::min(c.h, (int)(y0 + dh));
    for (int y = iy0; y < iy1; y++) {
        int ty = std::clamp((int)((y - y0) / dh * th), 0, th - 1);
        for (int x = ix0; x < ix1; x++) {
            int tx = std::clamp((int)((x - x0) / dw * tw), 0, tw - 1);
            uint32_t p = buf[(size_t)ty * tw + tx];
            if (opaque) p |= 0xff000000u;
            uint32_t a = p >> 24;
            if (a == 255) { c.px[(size_t)y * c.w + x] = p; continue; }
            if (a == 0) continue;
            // premultiplied "over"
            uint32_t d = c.px[(size_t)y * c.w + x], out = 0;
            for (int sh = 0; sh < 32; sh += 8) {
                uint32_t sc = (p >> sh) & 255, dc = (d >> sh) & 255;
                uint32_t v = sc + dc * (255 - a) / 255;
                out |= std::min<uint32_t>(v, 255) << sh;
            }
            c.px[(size_t)y * c.w + x] = out;
        }
    }
}

wlr_surface *main_surface(View *v, int &gx, int &gy, int &gw, int &gh) {
    gx = gy = 0;
    if (v->kind == View::Kind::Xdg) {
        wlr_box g = v->xdg->base->geometry;
        gx = g.x;
        gy = g.y;
        gw = g.width;
        gh = g.height;
        return v->xdg->base->surface;
    }
#ifdef NOVA_XWAYLAND
    if (v->xw && v->xw->surface) {
        gw = v->xw->width;
        gh = v->xw->height;
        return v->xw->surface;
    }
#endif
    return nullptr;
}
}  // namespace

std::string Server::write_thumbnails(int maxw) {
    maxw = std::clamp(maxw, 64, 800);
    const char *rt = getenv("XDG_RUNTIME_DIR");
    std::string dir = std::string(rt && *rt ? rt : "/tmp") + "/nova-thumbs";
    mkdir(dir.c_str(), 0700);
    std::string j = "{\"thumbs\":[";
    bool first = true;
    for (View *v : views) {
        if (!v->mapped || v->override_redirect()) continue;
        int gx, gy, gw, gh;
        wlr_surface *s = main_surface(v, gx, gy, gw, gh);
        if (!s || gw <= 0 || gh <= 0) continue;
        Canvas c;
        c.scale = std::min(1.0, (double)maxw / gw);
        c.w = std::max(1, (int)(gw * c.scale));
        c.h = std::max(1, (int)(gh * c.scale));
        c.px.assign((size_t)c.w * c.h, 0);
        Ctx ctx{&c, gx, gy};
        wlr_surface_for_each_surface(s, draw_surface, &ctx);
        char id[32];
        snprintf(id, sizeof id, "%p", (void *)v);
        std::string path = dir + "/" + id + ".raw";
        FILE *f = fopen((path + ".tmp").c_str(), "wb");
        if (!f) continue;
        int32_t hdr[2] = {c.w, c.h};
        bool ok = fwrite(hdr, sizeof hdr, 1, f) == 1 && fwrite(c.px.data(), 4, c.px.size(), f) == c.px.size();
        fclose(f);
        if (!ok || rename((path + ".tmp").c_str(), path.c_str()) != 0) continue;
        j += std::string(first ? "" : ",") + "{\"id\":\"" + id + "\",\"path\":\"" + json_escape(path) + "\",\"w\":" +
             std::to_string(c.w) + ",\"h\":" + std::to_string(c.h) + "}";
        first = false;
    }
    return j + "]}";
}
