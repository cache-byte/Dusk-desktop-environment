// Tiny line-based IPC over a unix socket.
//
// Socket: $XDG_RUNTIME_DIR/nova-$WAYLAND_DISPLAY.sock (exported as NOVA_SOCK)
//
// Requests (one per line)          Reply
//   subscribe                      stream of JSON events, starting with current state
//   get workspaces | leds | windows   one JSON line
//   dispatch <action>              {"ok":true}
//   lock                           shorthand for "dispatch lock"
//
// Events: {"event":"workspaces",...} {"event":"leds","caps":true,"num":false}
//         {"event":"shell","action":"launcher"} {"event":"lock"} {"event":"reload"}
#pragma once
#include <list>
#include <memory>
#include <string>

struct Server;
struct wl_event_source;

std::string json_escape(const std::string &s);

class Ipc {
public:
    explicit Ipc(Server *s) : server_(s) {}
    ~Ipc();
    bool start();
    void broadcast(const std::string &json_line);
    const std::string &path() const { return path_; }

private:
    struct Client {
        Ipc *owner;
        int fd;
        wl_event_source *src;
        std::string buf;
        bool subscribed = false;
    };
    static int on_accept(int fd, uint32_t mask, void *data);
    static int on_readable(int fd, uint32_t mask, void *data);
    void handle(Client *c, const std::string &line);
    void send(Client *c, const std::string &line);
    void drop(Client *c);

    Server *server_;
    int fd_ = -1;
    wl_event_source *src_ = nullptr;
    std::string path_;
    std::list<std::unique_ptr<Client>> clients_;
};
