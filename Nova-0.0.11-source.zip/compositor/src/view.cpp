// Window management: xdg-shell + XWayland toplevels, popups, focus, move /
// resize / snap, maximize, fullscreen, minimize and workspaces.
#include "ipc.hpp"
#include "server.hpp"

#include <algorithm>
#include <cmath>

// ---------------------------------------------------------------- helpers --

wlr_surface *View::surface() const {
    if (kind == Kind::Xdg) return xdg->base->surface;
#ifdef NOVA_XWAYLAND
    return xw ? xw->surface : nullptr;
#else
    return nullptr;
#endif
}

wlr_box View::geometry() const {
    if (kind == Kind::Xdg) return nova_xdg_geometry(xdg->base);
#ifdef NOVA_XWAYLAND
    return {0, 0, xw->width, xw->height};
#else
    return {};
#endif
}

std::string View::title() const {
    const char *t = nullptr;
    if (kind == Kind::Xdg) t = xdg->title;
#ifdef NOVA_XWAYLAND
    else t = xw->title;
#endif
    return t ? t : "";
}

std::string View::app_id() const {
    const char *t = nullptr;
    if (kind == Kind::Xdg) t = xdg->app_id;
#ifdef NOVA_XWAYLAND
    else t = xw->class_;
#endif
    return t ? t : "";
}

bool View::override_redirect() const {
#ifdef NOVA_XWAYLAND
    return kind == Kind::XWayland && xw->override_redirect;
#else
    return false;
#endif
}

static Output *output_for_view(View *v) {
    wlr_box g = v->geometry();
    Output *o = v->server->output_at(v->x + g.width / 2.0, v->y + g.height / 2.0);
    return o ? o : v->server->focused_output();
}

void View::set_activated(bool on) {
    if (kind == Kind::Xdg) wlr_xdg_toplevel_set_activated(xdg, on);
#ifdef NOVA_XWAYLAND
    else wlr_xwayland_surface_activate(xw, on);
#endif
    if (ftl) wlr_foreign_toplevel_handle_v1_set_activated(ftl, on);
}

void View::move_to(int nx, int ny) {
    x = nx;
    y = ny;
    if (!tree) return;
    wlr_box g = geometry();
    if (kind == Kind::Xdg) {
        wlr_scene_node_set_position(&tree->node, x - g.x, y - g.y);
    }
#ifdef NOVA_XWAYLAND
    else {
        wlr_scene_node_set_position(&tree->node, x, y);
        wlr_xwayland_surface_configure(xw, x, y, xw->width, xw->height);
    }
#endif
    update_ftl_output();
}

void View::configure(int nx, int ny, int w, int h) {
    w = std::max(w, 1);
    h = std::max(h, 1);
    if (kind == Kind::Xdg) {
        wlr_xdg_toplevel_set_size(xdg, w, h);
        move_to(nx, ny);
    }
#ifdef NOVA_XWAYLAND
    else {
        x = nx;
        y = ny;
        wlr_xwayland_surface_configure(xw, nx, ny, w, h);
        if (tree) wlr_scene_node_set_position(&tree->node, nx, ny);
        update_ftl_output();
    }
#endif
}

void View::close() {
    if (kind == Kind::Xdg) wlr_xdg_toplevel_send_close(xdg);
#ifdef NOVA_XWAYLAND
    else wlr_xwayland_surface_close(xw);
#endif
}

static void save_restore(View *v) {
    if (v->maximized || v->fullscreen || v->tile != View::Tile::None) return;
    wlr_box g = v->geometry();
    v->restore = {v->x, v->y, g.width, g.height};
}

void View::set_maximized(bool on) {
    if (on) {
        save_restore(this);
        Output *o = output_for_view(this);
        if (!o) return;
        maximized = true;
        tile = Tile::None;
        int gp = server->config.gaps;
        configure(o->usable.x + gp, o->usable.y + gp, o->usable.width - 2 * gp, o->usable.height - 2 * gp);
    } else {
        maximized = false;
        if (restore.width > 0) configure(restore.x, restore.y, restore.width, restore.height);
    }
    if (kind == Kind::Xdg) {
        wlr_xdg_toplevel_set_maximized(xdg, on);
        wlr_xdg_toplevel_set_tiled(xdg, on ? WLR_EDGE_TOP | WLR_EDGE_BOTTOM | WLR_EDGE_LEFT | WLR_EDGE_RIGHT
                                           : WLR_EDGE_NONE);
    }
    if (ftl) wlr_foreign_toplevel_handle_v1_set_maximized(ftl, on);
}

void View::set_fullscreen(bool on) {
    Output *o = output_for_view(this);
    if (on) {
        save_restore(this);
        fullscreen = true;
        if (o) configure(o->full.x, o->full.y, o->full.width, o->full.height);
        if (tree) wlr_scene_node_raise_to_top(&tree->node);
    } else {
        fullscreen = false;
        if (maximized && o) {
            int gp = server->config.gaps;
            configure(o->usable.x + gp, o->usable.y + gp, o->usable.width - 2 * gp, o->usable.height - 2 * gp);
        } else if (restore.width > 0) {
            configure(restore.x, restore.y, restore.width, restore.height);
        }
    }
    if (kind == Kind::Xdg) wlr_xdg_toplevel_set_fullscreen(xdg, on);
#ifdef NOVA_XWAYLAND
    else wlr_xwayland_surface_set_fullscreen(xw, on);
#endif
    if (ftl) wlr_foreign_toplevel_handle_v1_set_fullscreen(ftl, on);
    server->update_fullscreen_layering();
}

void View::set_minimized(bool on) {
    minimized = on;
    if (tree) wlr_scene_node_set_enabled(&tree->node, !on);
    if (ftl) wlr_foreign_toplevel_handle_v1_set_minimized(ftl, on);
#ifdef NOVA_XWAYLAND
    if (kind == Kind::XWayland) wlr_xwayland_surface_set_minimized(xw, on);
#endif
    if (on) {
        if (server->focused_view() == this) {
            set_activated(false);
            server->focus_top_view();
        }
    } else {
        server->focus_view(this);
    }
    server->update_fullscreen_layering();
}

void View::set_tile(Tile t) {
    if (t == Tile::None) {
        tile = Tile::None;
        if (restore.width > 0) configure(restore.x, restore.y, restore.width, restore.height);
        if (kind == Kind::Xdg) wlr_xdg_toplevel_set_tiled(xdg, WLR_EDGE_NONE);
        return;
    }
    save_restore(this);
    Output *o = output_for_view(this);
    if (!o) return;
    if (maximized) {
        maximized = false;
        if (kind == Kind::Xdg) wlr_xdg_toplevel_set_maximized(xdg, false);
        if (ftl) wlr_foreign_toplevel_handle_v1_set_maximized(ftl, false);
    }
    tile = t;
    const wlr_box &u = o->usable;
    int gp = server->config.gaps;
    int half = u.width / 2;
    if (t == Tile::Left) {
        configure(u.x + gp, u.y + gp, half - gp - gp / 2, u.height - 2 * gp);
        if (kind == Kind::Xdg) wlr_xdg_toplevel_set_tiled(xdg, WLR_EDGE_TOP | WLR_EDGE_BOTTOM | WLR_EDGE_LEFT);
    } else {
        configure(u.x + half + gp / 2, u.y + gp, u.width - half - gp - gp / 2, u.height - 2 * gp);
        if (kind == Kind::Xdg) wlr_xdg_toplevel_set_tiled(xdg, WLR_EDGE_TOP | WLR_EDGE_BOTTOM | WLR_EDGE_RIGHT);
    }
}

void View::update_ftl_output() {
    if (!ftl) return;
    Output *o = output_for_view(this);
    wlr_output *wo = o ? o->output : nullptr;
    if (wo == ftl_out) return;
    if (ftl_out) wlr_foreign_toplevel_handle_v1_output_leave(ftl, ftl_out);
    if (wo) wlr_foreign_toplevel_handle_v1_output_enter(ftl, wo);
    ftl_out = wo;
}

void View::place_initially() {
    wlr_box g = geometry();
    // Child dialogs: centre over their parent.
    if (kind == Kind::Xdg && xdg->parent) {
        for (View *p : server->views) {
            if (p->kind == Kind::Xdg && p->xdg == xdg->parent) {
                wlr_box pg = p->geometry();
                move_to(p->x + (pg.width - g.width) / 2, p->y + (pg.height - g.height) / 2);
                return;
            }
        }
    }
#ifdef NOVA_XWAYLAND
    // X11 clients that asked for a specific position (games, splash screens) keep it.
    if (kind == Kind::XWayland && (xw->x != 0 || xw->y != 0)) {
        move_to(xw->x, xw->y);
        return;
    }
#endif
    Output *o = server->focused_output();
    if (!o) {
        move_to(0, 0);
        return;
    }
    const wlr_box &u = o->usable;
    int w = std::min(g.width, u.width), h = std::min(g.height, u.height);
    int n = 0;
    for (View *v : server->views)
        if (v != this && v->mapped && v->workspace == workspace) n++;
    int cascade = (n % 6) * 28;
    move_to(u.x + (u.width - w) / 2 + cascade - 70, u.y + (u.height - h) / 2 + cascade - 70);
    if (n == 0) move_to(u.x + (u.width - w) / 2, u.y + (u.height - h) / 2);
}

// ---- foreign toplevel handle (feeds the shell's taskbar) -------------------
static void create_ftl(View *v) {
    Server *s = v->server;
    v->ftl = wlr_foreign_toplevel_handle_v1_create(s->ftl_manager);
    wlr_foreign_toplevel_handle_v1_set_title(v->ftl, v->title().c_str());
    wlr_foreign_toplevel_handle_v1_set_app_id(v->ftl, v->app_id().c_str());
    v->ftl_out = nullptr;
    v->update_ftl_output();

    v->ftl_activate.connect(&v->ftl->events.request_activate, [v](void *) {
        Server *s = v->server;
        if (!s->ws_shown(v->workspace)) s->switch_workspace(v->workspace);
        if (v->minimized) v->set_minimized(false);
        else s->focus_view(v);
    });
    v->ftl_close.connect(&v->ftl->events.request_close, [v](void *) { v->close(); });
    v->ftl_minimize.connect(&v->ftl->events.request_minimize, [v](void *data) {
        auto *e = static_cast<wlr_foreign_toplevel_handle_v1_minimized_event *>(data);
        v->set_minimized(e->minimized);
    });
    v->ftl_maximize.connect(&v->ftl->events.request_maximize, [v](void *data) {
        auto *e = static_cast<wlr_foreign_toplevel_handle_v1_maximized_event *>(data);
        v->set_maximized(e->maximized);
    });
    v->ftl_fullscreen.connect(&v->ftl->events.request_fullscreen, [v](void *data) {
        auto *e = static_cast<wlr_foreign_toplevel_handle_v1_fullscreen_event *>(data);
        v->set_fullscreen(e->fullscreen);
    });
}

static void destroy_ftl(View *v) {
    v->ftl_activate.disconnect();
    v->ftl_close.disconnect();
    v->ftl_minimize.disconnect();
    v->ftl_maximize.disconnect();
    v->ftl_fullscreen.disconnect();
    if (v->ftl) wlr_foreign_toplevel_handle_v1_destroy(v->ftl);
    v->ftl = nullptr;
    v->ftl_out = nullptr;
}

void View::on_map() {
    mapped = true;
    workspace = server->current_ws();
    if (tree) {
        wlr_scene_node_reparent(&tree->node, server->ws_trees[workspace]);
        wlr_scene_node_set_enabled(&tree->node, true);
    }
    place_initially();
    server->views.push_front(this);
    create_ftl(this);

    bool want_fs = false, want_max = false;
    if (kind == Kind::Xdg) {
        want_fs = xdg->requested.fullscreen;
        want_max = xdg->requested.maximized;
    }
#ifdef NOVA_XWAYLAND
    else {
        want_fs = xw->fullscreen;
        want_max = xw->maximized_horz && xw->maximized_vert;
    }
#endif
    if (want_fs) set_fullscreen(true);
    else if (want_max) set_maximized(true);

    server->focus_view(this);
    server->broadcast_workspaces();
}

void View::on_unmap() {
    if (server->grab_view == this) {
        server->grab = Server::Grab::None;
        server->grab_view = nullptr;
    }
    bool was_focused = server->focused_view() == this;
    mapped = false;
    server->views.remove(this);
    destroy_ftl(this);
    if (tree) wlr_scene_node_set_enabled(&tree->node, false);
    if (was_focused) server->focus_top_view();
    server->update_fullscreen_layering();
    server->broadcast_workspaces();
}

// ----------------------------------------------------------- xdg toplevel --
void create_xdg_view(Server *s, wlr_xdg_toplevel *t) {
    auto *v = new View(s, View::Kind::Xdg);
    v->xdg = t;
    v->tree = wlr_scene_tree_create(s->ws_trees[s->current_ws()]);
    v->tree->node.data = &v->tag;
    v->content = wlr_scene_xdg_surface_create(v->tree, t->base);
    t->base->data = v->content;
    wlr_scene_node_set_enabled(&v->tree->node, false);

    v->map.connect(&t->base->surface->events.map, [v](void *) { v->on_map(); });
    v->unmap.connect(&t->base->surface->events.unmap, [v](void *) { v->on_unmap(); });
    v->commit.connect(&t->base->surface->events.commit, [v](void *) {
        wlr_xdg_toplevel *t = v->xdg;
        if (t->base->initial_commit) {
            wlr_xdg_toplevel_set_wm_capabilities(t, WLR_XDG_TOPLEVEL_WM_CAPABILITIES_MAXIMIZE |
                                                        WLR_XDG_TOPLEVEL_WM_CAPABILITIES_FULLSCREEN |
                                                        WLR_XDG_TOPLEVEL_WM_CAPABILITIES_MINIMIZE);
            wlr_xdg_toplevel_set_size(t, 0, 0);   // let the client pick its size
            return;
        }
        if (!v->mapped) return;
        Server *s = v->server;
        // Keep the opposite edge pinned while resizing from the left / top.
        if (s->grab == Server::Grab::Resize && s->grab_view == v) {
            wlr_box g = v->geometry();
            int nx = v->x, ny = v->y;
            if (s->grab_edges & WLR_EDGE_LEFT) nx = s->grab_box.x + s->grab_box.width - g.width;
            if (s->grab_edges & WLR_EDGE_TOP) ny = s->grab_box.y + s->grab_box.height - g.height;
            v->move_to(nx, ny);
        } else {
            v->move_to(v->x, v->y);   // geometry offset may have changed (CSD shadows)
        }
    });
    v->destroy.connect(&t->events.destroy, [v](void *) {
        if (v->mapped) v->on_unmap();
        delete v;
    });
    v->req_move.connect(&t->events.request_move, [v](void *) {
        v->server->begin_grab(v, Server::Grab::Move, 0);
    });
    v->req_resize.connect(&t->events.request_resize, [v](void *data) {
        auto *e = static_cast<wlr_xdg_toplevel_resize_event *>(data);
        v->server->begin_grab(v, Server::Grab::Resize, e->edges);
    });
    v->req_maximize.connect(&t->events.request_maximize, [v](void *) {
        if (!v->xdg->base->initialized) return;
        if (v->mapped) v->set_maximized(v->xdg->requested.maximized);
        else wlr_xdg_surface_schedule_configure(v->xdg->base);
    });
    v->req_fullscreen.connect(&t->events.request_fullscreen, [v](void *) {
        if (!v->xdg->base->initialized) return;
        if (v->mapped) v->set_fullscreen(v->xdg->requested.fullscreen);
        else wlr_xdg_surface_schedule_configure(v->xdg->base);
    });
    v->req_minimize.connect(&t->events.request_minimize, [v](void *) {
        if (v->mapped) v->set_minimized(true);
    });
    v->set_title.connect(&t->events.set_title, [v](void *) {
        if (v->ftl) wlr_foreign_toplevel_handle_v1_set_title(v->ftl, v->title().c_str());
    });
    v->set_app_id.connect(&t->events.set_app_id, [v](void *) {
        if (v->ftl) wlr_foreign_toplevel_handle_v1_set_app_id(v->ftl, v->app_id().c_str());
    });
}

// ------------------------------------------------------------------ popups --
static void unconstrain_popup(Server *s, wlr_xdg_popup *popup) {
    // Find the root (toplevel or layer surface) of this popup chain.
    wlr_surface *parent = popup->parent;
    while (parent) {
        wlr_xdg_surface *xs = wlr_xdg_surface_try_from_wlr_surface(parent);
        if (xs && xs->role == WLR_XDG_SURFACE_ROLE_POPUP && xs->popup) {
            parent = xs->popup->parent;
            continue;
        }
        break;
    }
    if (!parent) return;

    int rx = 0, ry = 0;
    Output *o = nullptr;
    if (View *v = s->view_for_surface(parent)) {
        wlr_box g = v->geometry();
        rx = v->x - g.x;
        ry = v->y - g.y;
        o = s->output_at(v->x + g.width / 2.0, v->y + g.height / 2.0);
    } else if (wlr_layer_surface_v1 *l = wlr_layer_surface_v1_try_from_wlr_surface(parent)) {
        auto *ls = static_cast<LayerSurface *>(l->data);
        if (ls) {
            wlr_scene_node_coords(&ls->scene->tree->node, &rx, &ry);
            o = ls->output;
        }
    }
    if (!o) o = s->focused_output();
    if (!o) return;
    wlr_box box{o->full.x - rx, o->full.y - ry, o->full.width, o->full.height};
    wlr_xdg_popup_unconstrain_from_box(popup, &box);
}

void create_popup(Server *s, wlr_xdg_popup *popup) {
    wlr_scene_tree *parent_tree = nullptr;
    if (wlr_xdg_surface *px = wlr_xdg_surface_try_from_wlr_surface(popup->parent)) {
        parent_tree = static_cast<wlr_scene_tree *>(px->data);
    } else if (wlr_layer_surface_v1 *l = wlr_layer_surface_v1_try_from_wlr_surface(popup->parent)) {
        auto *ls = static_cast<LayerSurface *>(l->data);
        if (ls) parent_tree = ls->popups;
    }
    if (!parent_tree) return;   // parent not ready; client will be sent popup_done when parent dies

    auto *p = new Popup{popup, {}, {}, {}};
    wlr_scene_tree *tree = wlr_scene_xdg_surface_create(parent_tree, popup->base);
    popup->base->data = tree;

    p->commit.connect(&popup->base->surface->events.commit, [s, p](void *) {
        if (p->popup->base->initial_commit) {
            unconstrain_popup(s, p->popup);
            wlr_xdg_surface_schedule_configure(p->popup->base);
        }
    });
    p->reposition.connect(&popup->events.reposition, [s, p](void *) { unconstrain_popup(s, p->popup); });
    p->destroy.connect(&popup->events.destroy, [p](void *) { delete p; });
}

// ---------------------------------------------------------------- XWayland --
#ifdef NOVA_XWAYLAND
void create_xwayland_view(Server *s, wlr_xwayland_surface *xs) {
    auto *v = new View(s, View::Kind::XWayland);
    v->xw = xs;

    auto do_map = [v](void *) {
        Server *s = v->server;
        wlr_xwayland_surface *xs = v->xw;
        if (xs->override_redirect) {
            // Menus / tooltips: unmanaged, drawn above everything, positioned by the client.
            v->tree = wlr_scene_tree_create(s->popup_tree);
            v->tree->node.data = &v->tag;
            wlr_scene_subsurface_tree_create(v->tree, xs->surface);
            v->x = xs->x;
            v->y = xs->y;
            wlr_scene_node_set_position(&v->tree->node, xs->x, xs->y);
            v->mapped = true;
            if (wlr_xwayland_or_surface_wants_focus(xs)) s->focus_surface(xs->surface);
            return;
        }
        v->tree = wlr_scene_tree_create(s->ws_trees[s->current_ws()]);
        v->tree->node.data = &v->tag;
        v->content = wlr_scene_subsurface_tree_create(v->tree, xs->surface);
        v->on_map();
    };
    auto do_unmap = [v](void *) {
        if (v->override_redirect()) {
            v->mapped = false;
        } else if (v->mapped) {
            v->on_unmap();
        }
        if (v->tree) wlr_scene_node_destroy(&v->tree->node);
        v->tree = nullptr;
        v->content = nullptr;
    };

    v->xw_associate.connect(&xs->events.associate, [v, do_map, do_unmap](void *) {
        v->map.connect(&v->xw->surface->events.map, do_map);
        v->unmap.connect(&v->xw->surface->events.unmap, do_unmap);
    });
    v->xw_dissociate.connect(&xs->events.dissociate, [v](void *) {
        v->map.disconnect();
        v->unmap.disconnect();
    });
    v->destroy.connect(&xs->events.destroy, [v](void *) {
        if (v->mapped && !v->override_redirect()) v->on_unmap();
        if (v->tree) wlr_scene_node_destroy(&v->tree->node);
        delete v;
    });
    v->xw_configure.connect(&xs->events.request_configure, [v](void *data) {
        auto *e = static_cast<wlr_xwayland_surface_configure_event *>(data);
        if (!v->mapped || v->override_redirect()) {
            wlr_xwayland_surface_configure(v->xw, e->x, e->y, e->width, e->height);
            return;
        }
        if (v->fullscreen || v->maximized) {
            wlr_box g = v->geometry();
            wlr_xwayland_surface_configure(v->xw, v->x, v->y, g.width, g.height);
            return;
        }
        v->configure(v->x, v->y, e->width, e->height);
    });
    v->xw_set_geometry.connect(&xs->events.set_geometry, [v](void *) {
        if (v->override_redirect() && v->tree) {
            v->x = v->xw->x;
            v->y = v->xw->y;
            wlr_scene_node_set_position(&v->tree->node, v->x, v->y);
        }
    });
    v->xw_activate.connect(&xs->events.request_activate, [v](void *) {
        if (v->mapped && !v->override_redirect()) v->server->focus_view(v);
    });
    v->req_move.connect(&xs->events.request_move, [v](void *) {
        if (v->mapped) v->server->begin_grab(v, Server::Grab::Move, 0);
    });
    v->req_resize.connect(&xs->events.request_resize, [v](void *data) {
        auto *e = static_cast<wlr_xwayland_resize_event *>(data);
        if (v->mapped) v->server->begin_grab(v, Server::Grab::Resize, e->edges);
    });
    v->req_maximize.connect(&xs->events.request_maximize, [v](void *) {
        if (v->mapped) v->set_maximized(v->xw->maximized_horz && v->xw->maximized_vert);
    });
    v->req_fullscreen.connect(&xs->events.request_fullscreen, [v](void *) {
        if (v->mapped) v->set_fullscreen(v->xw->fullscreen);
    });
    v->req_minimize.connect(&xs->events.request_minimize, [v](void *data) {
        auto *e = static_cast<wlr_xwayland_minimize_event *>(data);
        if (v->mapped) v->set_minimized(e->minimize);
    });
    v->set_title.connect(&xs->events.set_title, [v](void *) {
        if (v->ftl) wlr_foreign_toplevel_handle_v1_set_title(v->ftl, v->title().c_str());
    });
    v->set_app_id.connect(&xs->events.set_class, [v](void *) {
        if (v->ftl) wlr_foreign_toplevel_handle_v1_set_app_id(v->ftl, v->app_id().c_str());
    });
}
#endif

// ------------------------------------------------------------ server side --
NodeTag *Server::tag_at(double lx, double ly, wlr_surface **surf, double *sx, double *sy) {
    *surf = nullptr;
    wlr_scene_node *node = wlr_scene_node_at(&scene->tree.node, lx, ly, sx, sy);
    if (!node || node->type != WLR_SCENE_NODE_BUFFER) return nullptr;
    wlr_scene_buffer *buf = wlr_scene_buffer_from_node(node);
    wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(buf);
    if (!ss) return nullptr;
    *surf = ss->surface;
    for (wlr_scene_tree *t = node->parent; t; t = t->node.parent) {
        if (t->node.data) return static_cast<NodeTag *>(t->node.data);
    }
    return nullptr;
}

View *Server::view_at(double lx, double ly, wlr_surface **surf, double *sx, double *sy) {
    NodeTag *tag = tag_at(lx, ly, surf, sx, sy);
    return tag && tag->kind == NodeKind::View ? static_cast<View *>(tag->ptr) : nullptr;
}

LayerSurface *Server::layer_at(double lx, double ly, wlr_surface **surf, double *sx, double *sy) {
    NodeTag *tag = tag_at(lx, ly, surf, sx, sy);
    return tag && tag->kind == NodeKind::Layer ? static_cast<LayerSurface *>(tag->ptr) : nullptr;
}

View *Server::view_for_surface(wlr_surface *s) {
    if (!s) return nullptr;
    wlr_surface *root = wlr_surface_get_root_surface(s);
    // Popups are separate surfaces: climb to their toplevel.
    for (int guard = 0; guard < 32; guard++) {
        wlr_xdg_surface *xs = wlr_xdg_surface_try_from_wlr_surface(root);
        if (!xs || xs->role != WLR_XDG_SURFACE_ROLE_POPUP || !xs->popup || !xs->popup->parent) break;
        root = wlr_surface_get_root_surface(xs->popup->parent);
    }
    for (View *v : views)
        if (v->surface() == root) return v;
    return nullptr;
}

View *Server::focused_view() { return view_for_surface(seat->keyboard_state.focused_surface); }

void Server::focus_surface(wlr_surface *s) {
    wlr_keyboard *kb = wlr_seat_get_keyboard(seat);
    if (kb) wlr_seat_keyboard_notify_enter(seat, s, kb->keycodes, kb->num_keycodes, &kb->modifiers);
    else wlr_seat_keyboard_notify_enter(seat, s, nullptr, 0, nullptr);
    check_constraint();
}

void Server::focus_view(View *v) {
    if (locked || !v || !v->mapped || v->override_redirect()) return;
    if (v->minimized) {
        v->minimized = false;
        if (v->tree) wlr_scene_node_set_enabled(&v->tree->node, true);
        if (v->ftl) wlr_foreign_toplevel_handle_v1_set_minimized(v->ftl, false);
    }
    views.remove(v);
    views.push_front(v);
    if (v->tree) wlr_scene_node_raise_to_top(&v->tree->node);

    // An exclusive layer surface (launcher, lock prompt) keeps the keyboard.
    if (exclusive_layer) return;

    wlr_surface *prev = seat->keyboard_state.focused_surface;
    wlr_surface *s = v->surface();
    if (prev == s) return;
    if (View *pv = view_for_surface(prev); pv && pv != v) pv->set_activated(false);
    v->set_activated(true);
    focused_layer = nullptr;
    focus_surface(s);
    update_fullscreen_layering();
}

void Server::focus_top_view() {
    if (locked || exclusive_layer) return;
    for (View *v : views) {
        if (v->mapped && !v->minimized && v->workspace == current_ws()) {
            focus_view(v);
            // focus_view early-outs if already focused; make sure activation is right.
            v->set_activated(true);
            return;
        }
    }
    wlr_seat_keyboard_notify_clear_focus(seat);
    check_constraint();
}

void Server::begin_grab(View *v, Grab g, uint32_t edges) {
    if (locked || !v || !v->mapped || v->fullscreen) return;
    wlr_box geo = v->geometry();

    if (g == Grab::Move && (v->maximized || v->tile != View::Tile::None)) {
        // Dragging a maximized / snapped window un-maximizes it under the cursor.
        double fx = (cursor->x - v->x) / std::max(1, geo.width);
        wlr_box r = v->restore;
        if (r.width <= 0) r = {v->x, v->y, geo.width * 2 / 3, geo.height * 2 / 3};
        v->maximized = false;
        v->tile = View::Tile::None;
        if (v->kind == View::Kind::Xdg) {
            wlr_xdg_toplevel_set_maximized(v->xdg, false);
            wlr_xdg_toplevel_set_tiled(v->xdg, WLR_EDGE_NONE);
        }
        if (v->ftl) wlr_foreign_toplevel_handle_v1_set_maximized(v->ftl, false);
        r.x = (int)(cursor->x - fx * r.width);
        r.y = (int)cursor->y - 16;
        v->configure(r.x, r.y, r.width, r.height);
        geo = {0, 0, r.width, r.height};
    }

    grab = g;
    grab_view = v;
    if (g == Grab::Move) {
        grab_x = cursor->x - v->x;
        grab_y = cursor->y - v->y;
        wlr_cursor_set_xcursor(cursor, xcursor, "grabbing");
    } else {
        grab_x = cursor->x;
        grab_y = cursor->y;
        grab_box = {v->x, v->y, geo.width, geo.height};
        grab_edges = edges;
        wlr_cursor_set_xcursor(cursor, xcursor, wlr_xcursor_get_resize_name((wlr_edges)edges));
    }
    wlr_seat_pointer_notify_clear_focus(seat);
}

bool Server::ws_shown(int ws) const {
    for (auto &o : outputs) if (o->active == ws) return true;
    return false;
}

Output *Server::output_for_ws(int ws) const {
    for (auto &o : outputs) if (o->slot == ws / kWsPerOutput) return o.get();
    return nullptr;
}

int Server::current_ws() {
    Output *o = focused_output();
    return o ? o->active : 0;
}

void Server::switch_workspace(int ws) {
    if (ws < 0 || ws >= kWorkspaces) return;
    Output *o = output_for_ws(ws);
    if (!o || o->active == ws) return;
    if (View *f = focused_view()) f->set_activated(false);
    wlr_scene_node_set_enabled(&ws_trees[o->active]->node, false);
    o->active = ws;
    wlr_scene_node_set_enabled(&ws_trees[ws]->node, true);
    wlr_seat_keyboard_notify_clear_focus(seat);
    // focus the top window of the workspace we just showed
    for (View *v : views)
        if (v->mapped && !v->minimized && v->workspace == ws) { focus_view(v); v->set_activated(true); break; }
    update_fullscreen_layering();
    broadcast_workspaces();
}

void Server::move_to_workspace(View *v, int ws) {
    if (!v || ws < 0 || ws >= kWorkspaces || v->workspace == ws || !v->tree) return;
    // moving to another monitor: keep the window's position relative to the screen
    Output *from = output_for_ws(v->workspace), *to = output_for_ws(ws);
    if (to && from != to) {
        int ox = from ? from->full.x : 0, oy = from ? from->full.y : 0;
        v->move_to(v->x - ox + to->full.x, v->y - oy + to->full.y);
    }
    wlr_scene_node_reparent(&v->tree->node, ws_trees[ws]);
    v->workspace = ws;
    v->update_ftl_output();
    if (!ws_shown(ws)) {
        v->set_activated(false);
        wlr_seat_keyboard_notify_clear_focus(seat);
        focus_top_view();
    }
    update_fullscreen_layering();
    broadcast_workspaces();
}

void Server::cycle_focus(bool reverse) {
    std::vector<View *> cands;
    for (View *v : views)
        if (v->mapped && !v->minimized && v->workspace == current_ws()) cands.push_back(v);
    if (cands.size() < 2) return;
    if (!reverse) {
        focus_view(cands.back());   // bring the bottom-most up: repeated presses visit every window
    } else {
        View *top = cands.front();
        views.remove(top);
        views.push_back(top);
        if (top->tree) wlr_scene_node_lower_to_bottom(&top->tree->node);
        top->set_activated(false);
        focus_view(cands[1]);
    }
}

void Server::update_fullscreen_layering() {
    // Hide the panel only on the monitor that shows something fullscreen.
    bool fs = false;
    for (LayerSurface *ls : layers) {
        if (!ls->output || ls->layer->current.layer != ZWLR_LAYER_SHELL_V1_LAYER_TOP) continue;
        wlr_scene_node_set_enabled(&ls->scene->tree->node, fullscreen_view_on(ls->output) == nullptr);
    }
    for (auto &o : outputs) fs |= fullscreen_view_on(o.get()) != nullptr;
    // Never dim, lock or sleep while something is fullscreen (games, videos, presentations).
    fullscreen_active = fs;
    update_idle_inhibit();
    if (ipc && fs != fullscreen_reported) {
        fullscreen_reported = fs;
        ipc->broadcast(std::string("{\"event\":\"fullscreen\",\"active\":") + (fs ? "true" : "false") + "}");
    }
}

View *Server::fullscreen_view_on(Output *o) const {
    for (View *v : views) {
        if (v->mapped && v->fullscreen && !v->minimized && v->workspace == o->active) return v;
    }
    return nullptr;
}

void Server::update_idle_inhibit() {
    wlr_idle_notifier_v1_set_inhibited(idle_notifier, inhibitors_active > 0 || fullscreen_active);
}

// {"event":"workspaces","active":2,"occupied":[1,2],          <- monitor under the pointer
//  "outputs":[{"name":"eDP-1","active":2,"occupied":[1,2],"base":0}, ...]}
// Numbers are per monitor (1-based). "base" + number - 1 = the global id used by
// window-to-workspace / close-workspace.
static std::string ws_json(Server *s, Output *o) {
    bool occ[kWsPerOutput]{};
    for (View *v : s->views)
        if (v->mapped && v->workspace / kWsPerOutput == o->slot) occ[v->workspace % kWsPerOutput] = true;
    std::string j = "\"active\":" + std::to_string(o->active % kWsPerOutput + 1) + ",\"occupied\":[";
    bool first = true;
    for (int i = 0; i < kWsPerOutput; i++) {
        if (!occ[i]) continue;
        j += (first ? "" : ",") + std::to_string(i + 1);
        first = false;
    }
    return j + "],\"base\":" + std::to_string(o->slot * kWsPerOutput + 1);
}

std::string Server::workspaces_json() {
    Output *f = focused_output();
    std::string j = "{";
    if (f) j += ws_json(this, f) + ",";
    j += "\"count\":" + std::to_string(kWsPerOutput) + ",\"outputs\":[";
    bool first = true;
    for (auto &o : outputs) {
        j += std::string(first ? "" : ",") + "{\"name\":\"" + o->output->name + "\"," + ws_json(this, o.get()) + "}";
        first = false;
    }
    return j + "]}";
}

void Server::broadcast_workspaces() {
    if (!ipc) return;
    std::string j = workspaces_json();
    ipc->broadcast("{\"event\":\"workspaces\"," + j.substr(1));
}
