// Server-side title bars and rounded window corners.
//
// Apps that ask for server-side decorations (xdg-decoration "server side": Electron apps like
// Heroic, Qt apps) and X11 apps that don't draw their own frame get a title bar with the
// window title and minimise / maximise / close buttons. It's drawn with Cairo + Pango into a
// buffer and sits right above the window. Drag it to move, double-click to maximise.
//
// With SceneFX, windows also get rounded corners (not when maximised, snapped or fullscreen).
#include "server.hpp"

#include <cairo.h>
#include <cmath>
#include <cstdlib>
#include <drm_fourcc.h>
#include <pango/pangocairo.h>
extern "C" {
#include <wlr/interfaces/wlr_buffer.h>
}

namespace {

// ---- a wlr_buffer in plain memory, drawn into with Cairo -------------------------------------
struct MemBuffer {
    wlr_buffer base;
    unsigned char *data = nullptr;
    int stride = 0;
};
void mem_destroy(wlr_buffer *b) {
    auto *m = wl_container_of(b, (MemBuffer *)nullptr, base);
    wlr_buffer_finish(b);
    free(m->data);
    delete m;
}
bool mem_begin(wlr_buffer *b, uint32_t, void **data, uint32_t *format, size_t *stride) {
    auto *m = wl_container_of(b, (MemBuffer *)nullptr, base);
    *data = m->data;
    *format = DRM_FORMAT_ARGB8888;
    *stride = m->stride;
    return true;
}
void mem_end(wlr_buffer *) {}
const wlr_buffer_impl mem_impl = {
    .destroy = mem_destroy,
    .get_dmabuf = nullptr,
    .get_shm = nullptr,
    .begin_data_ptr_access = mem_begin,
    .end_data_ptr_access = mem_end,
};
MemBuffer *mem_create(int w, int h) {
    auto *m = new MemBuffer;
    m->stride = cairo_format_stride_for_width(CAIRO_FORMAT_ARGB32, w);
    m->data = (unsigned char *)calloc(1, (size_t)m->stride * h);
    wlr_buffer_init(&m->base, &mem_impl, w, h);
    return m;
}

}  // namespace

struct Deco {
    View *view;
    wlr_scene_tree *tree = nullptr;
    wlr_scene_buffer *buf = nullptr;
    NodeTag tag{NodeKind::Deco, nullptr};
    // what the buffer shows (redraw only when one of these changes)
    int width = 0;
    double scale = 0;
    std::string title;
    bool active = false, rounded = true;
    int hover = -1;            // button under the pointer: 0 minimise, 1 maximise, 2 close
    uint32_t last_click = 0;
};

int View::top() const { return ssd && !fullscreen ? kTitleHeight : 0; }

static constexpr int kButton = 28, kButtonGap = 6, kButtonPad = 8;

// x of button i (0 min, 1 max, 2 close) inside a title bar of width w
static int button_x(int w, int i) { return w - kButtonPad - (3 - i) * kButton - (2 - i) * kButtonGap; }

static void rounded_top(cairo_t *cr, double w, double h, double r) {
    cairo_new_path(cr);
    cairo_move_to(cr, 0, h);
    cairo_line_to(cr, 0, r);
    cairo_arc(cr, r, r, r, M_PI, 1.5 * M_PI);
    cairo_line_to(cr, w - r, 0);
    cairo_arc(cr, w - r, r, r, 1.5 * M_PI, 2 * M_PI);
    cairo_line_to(cr, w, h);
    cairo_close_path(cr);
}

static double output_scale(View *v) {
    double s = 1;
    for (auto &o : v->server->outputs) s = std::max(s, (double)o->output->scale);
    return std::ceil(s);
}

static void draw(Deco *d) {
    View *v = d->view;
    int w = d->width, h = kTitleHeight;
    double s = d->scale;
    int pw = (int)std::ceil(w * s), ph = (int)std::ceil(h * s);
    MemBuffer *m = mem_create(pw, ph);
    cairo_surface_t *cs = cairo_image_surface_create_for_data(m->data, CAIRO_FORMAT_ARGB32, pw, ph, m->stride);
    cairo_t *cr = cairo_create(cs);
    cairo_scale(cr, s, s);

    // background: dark glass, a little lighter when focused
    rounded_top(cr, w, h, d->rounded ? kCornerRadius : 0);
    cairo_set_source_rgba(cr, d->active ? 0.125 : 0.10, d->active ? 0.12 : 0.095, d->active ? 0.16 : 0.13, 0.97);
    cairo_fill(cr);
    cairo_rectangle(cr, 0, h - 1, w, 1);
    cairo_set_source_rgba(cr, 1, 1, 1, 0.06);
    cairo_fill(cr);

    // title, centred in the space left of the buttons
    int textRight = button_x(w, 0) - 12, textLeft = 16;
    if (textRight > textLeft + 20) {
        PangoLayout *pl = pango_cairo_create_layout(cr);
        PangoFontDescription *fd = pango_font_description_from_string("Inter, sans-serif 10");
        pango_font_description_set_weight(fd, PANGO_WEIGHT_SEMIBOLD);
        pango_font_description_set_absolute_size(fd, 13 * PANGO_SCALE);
        pango_layout_set_font_description(pl, fd);
        pango_font_description_free(fd);
        pango_layout_set_text(pl, d->title.c_str(), -1);
        pango_layout_set_width(pl, (textRight - textLeft) * PANGO_SCALE);
        pango_layout_set_ellipsize(pl, PANGO_ELLIPSIZE_END);
        pango_layout_set_single_paragraph_mode(pl, true);
        int tw, th;
        pango_layout_get_pixel_size(pl, &tw, &th);
        double tx = std::max<double>(textLeft, (w - tw) / 2.0);
        if (tx + tw > textRight) tx = textLeft;
        double a = d->active ? 0.92 : 0.55;
        cairo_set_source_rgba(cr, 0.93, 0.92, 0.96, a);
        cairo_move_to(cr, tx, (h - th) / 2.0);
        pango_cairo_show_layout(cr, pl);
        g_object_unref(pl);
    }

    // buttons
    for (int i = 0; i < 3; i++) {
        double bx = button_x(w, i), by = (h - kButton) / 2.0, cx = bx + kButton / 2.0, cy = by + kButton / 2.0;
        bool hot = d->hover == i;
        if (hot) {
            cairo_arc(cr, cx, cy, kButton / 2.0, 0, 2 * M_PI);
            if (i == 2) cairo_set_source_rgba(cr, 0.90, 0.28, 0.30, 1);
            else cairo_set_source_rgba(cr, 1, 1, 1, 0.12);
            cairo_fill(cr);
        }
        cairo_set_line_width(cr, 1.6);
        cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
        cairo_set_line_join(cr, CAIRO_LINE_JOIN_ROUND);
        double a = d->active || hot ? 0.9 : 0.5;
        cairo_set_source_rgba(cr, 1, 1, 1, a);
        double r = 5;
        if (i == 0) {
            cairo_move_to(cr, cx - r, cy + 0.5);
            cairo_line_to(cr, cx + r, cy + 0.5);
        } else if (i == 1) {
            if (v->maximized) {
                cairo_rectangle(cr, cx - r + 2, cy - r, 2 * r - 2, 2 * r - 2);
                cairo_rectangle(cr, cx - r, cy - r + 2, 2 * r - 2, 2 * r - 2);
            } else {
                cairo_rectangle(cr, cx - r, cy - r, 2 * r, 2 * r);
            }
        } else {
            cairo_move_to(cr, cx - r, cy - r);
            cairo_line_to(cr, cx + r, cy + r);
            cairo_move_to(cr, cx + r, cy - r);
            cairo_line_to(cr, cx - r, cy + r);
        }
        cairo_stroke(cr);
    }
    cairo_destroy(cr);
    cairo_surface_flush(cs);
    cairo_surface_destroy(cs);
    wlr_scene_buffer_set_buffer(d->buf, &m->base);
    wlr_scene_buffer_set_dest_size(d->buf, w, h);
    wlr_buffer_drop(&m->base);   // the scene holds its own reference
}

void deco_destroy(View *v) {
    if (!v->deco) return;
    if (v->server->hover_deco == v) v->server->hover_deco = nullptr;
    if (v->deco->tree) wlr_scene_node_destroy(&v->deco->tree->node);
    delete v->deco;
    v->deco = nullptr;
}

void deco_update(View *v) {
    if (!v->ssd || !v->tree || !v->mapped || v->fullscreen || v->override_redirect()) {
        if (v->deco && v->tree && v->mapped && v->ssd && v->fullscreen) {
            wlr_scene_node_set_enabled(&v->deco->tree->node, false);
            return;
        }
        deco_destroy(v);
        return;
    }
    Deco *d = v->deco;
    if (!d) {
        d = v->deco = new Deco;
        d->view = v;
        d->tag.ptr = v;
        d->tree = wlr_scene_tree_create(v->tree);
        d->tree->node.data = &d->tag;
        d->buf = wlr_scene_buffer_create(d->tree, nullptr);
    }
    wlr_scene_node_set_enabled(&d->tree->node, true);
    wlr_box g = v->geometry();
    // the view tree's origin is the surface origin; the content starts at the geometry offset
    if (v->kind == View::Kind::Xdg) wlr_scene_node_set_position(&d->tree->node, g.x, g.y - kTitleHeight);
    else wlr_scene_node_set_position(&d->tree->node, 0, -kTitleHeight);
    bool active = v->active;
    bool rounded = !v->maximized && v->tile == View::Tile::None;
    double scale = output_scale(v);
    std::string title = v->title();
    if (title.empty()) title = v->app_id();
    if (g.width != d->width || scale != d->scale || title != d->title || active != d->active || rounded != d->rounded || !d->buf->buffer) {
        d->width = std::max(g.width, 1);
        d->scale = scale;
        d->title = title;
        d->active = active;
        d->rounded = rounded;
        draw(d);
    }
}

static int button_at(View *v, double lx, double ly) {
    if (!v->deco) return -1;
    wlr_box g = v->geometry();
    double x = lx - v->x, y = ly - (v->y - kTitleHeight);
    if (y < (kTitleHeight - kButton) / 2.0 || y > (kTitleHeight + kButton) / 2.0) return -1;
    for (int i = 0; i < 3; i++) {
        int bx = button_x(g.width, i);
        if (x >= bx && x < bx + kButton) return i;
    }
    return -1;
}

void deco_hover(View *v, double lx, double ly) {
    Server *s = v->server;
    if (s->hover_deco && s->hover_deco != v) deco_leave(s);
    s->hover_deco = v;
    int h = button_at(v, lx, ly);
    if (v->deco && h != v->deco->hover) {
        v->deco->hover = h;
        draw(v->deco);
    }
}

void deco_leave(Server *s) {
    if (s->hover_deco && s->hover_deco->deco && s->hover_deco->deco->hover != -1) {
        s->hover_deco->deco->hover = -1;
        draw(s->hover_deco->deco);
    }
    s->hover_deco = nullptr;
}

bool deco_press(View *v, double lx, double ly, uint32_t button, uint32_t time_msec) {
    if (!v->deco) return false;
    Server *s = v->server;
    s->focus_view(v);
    if (button != 0x110 /* BTN_LEFT */) return true;
    int b = button_at(v, lx, ly);
    if (b == 0) { v->set_minimized(true); return true; }
    if (b == 1) { v->set_maximized(!v->maximized); deco_update(v); return true; }
    if (b == 2) { v->close(); return true; }
    if (time_msec - v->deco->last_click < 400) {
        v->deco->last_click = 0;
        v->set_maximized(!v->maximized);
        deco_update(v);
        return true;
    }
    v->deco->last_click = time_msec;
    s->begin_grab(v, Server::Grab::Move, 0);
    return true;
}

// ---- rounded corners ---------------------------------------------------------------------
#ifdef NOVA_SCENEFX
struct CornerCtx { View *v; wlr_surface *main; int radius; enum corner_location where; wlr_box g; };
static void corner_buffer(wlr_scene_buffer *buf, int, int, void *data) {
    auto *c = static_cast<CornerCtx *>(data);
    wlr_scene_surface *ss = wlr_scene_surface_try_from_buffer(buf);
    if (!ss || ss->surface != c->main) { wlr_scene_buffer_set_corner_radius(buf, 0, CORNER_LOCATION_NONE); return; }
    // only when the buffer is the window itself (no client-side shadow around it)
    bool exact = c->g.x == 0 && c->g.y == 0 && c->g.width == ss->surface->current.width && c->g.height == ss->surface->current.height;
    if (exact && c->radius > 0) wlr_scene_buffer_set_corner_radius(buf, c->radius, c->where);
    else wlr_scene_buffer_set_corner_radius(buf, 0, CORNER_LOCATION_NONE);
}
#endif

void apply_corners(View *v) {
#ifdef NOVA_SCENEFX
    if (!v->content || !v->mapped) return;
    CornerCtx c{v, v->surface(), kCornerRadius, CORNER_LOCATION_ALL, v->geometry()};
    if (v->maximized || v->fullscreen || v->tile != View::Tile::None) c.radius = 0;
    if (v->deco && v->top() > 0) c.where = CORNER_LOCATION_BOTTOM;
    wlr_scene_node_for_each_buffer(&v->content->node, corner_buffer, &c);
#else
    (void)v;
#endif
}
