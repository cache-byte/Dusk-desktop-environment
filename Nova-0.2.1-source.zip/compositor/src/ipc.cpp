#include "ipc.hpp"
#include "server.hpp"

#include <cerrno>
#include <sys/socket.h>
#include <sys/un.h>

std::string json_escape(const std::string &s) {
    std::string o;
    o.reserve(s.size() + 2);
    for (unsigned char c : s) {
        switch (c) {
        case '"': o += "\\\""; break;
        case '\\': o += "\\\\"; break;
        case '\n': o += "\\n"; break;
        case '\t': o += "\\t"; break;
        default:
            if (c < 0x20) {
                char b[8];
                snprintf(b, sizeof b, "\\u%04x", c);
                o += b;
            } else {
                o += (char)c;
            }
        }
    }
    return o;
}

Ipc::~Ipc() {
    for (auto &c : clients_) {
        wl_event_source_remove(c->src);
        close(c->fd);
    }
    if (src_) wl_event_source_remove(src_);
    if (fd_ >= 0) close(fd_);
    if (!path_.empty()) unlink(path_.c_str());
}

bool Ipc::start() {
    const char *rt = getenv("XDG_RUNTIME_DIR");
    if (!rt) return false;
    path_ = std::string(rt) + "/nova-" + server_->socket_name + ".sock";

    fd_ = socket(AF_UNIX, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);
    if (fd_ < 0) return false;
    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    if (path_.size() >= sizeof(addr.sun_path)) return false;
    strcpy(addr.sun_path, path_.c_str());
    unlink(path_.c_str());
    if (bind(fd_, (sockaddr *)&addr, sizeof addr) < 0 || listen(fd_, 16) < 0) {
        wlr_log(WLR_ERROR, "ipc: cannot listen on %s: %s", path_.c_str(), strerror(errno));
        return false;
    }
    src_ = wl_event_loop_add_fd(server_->loop, fd_, WL_EVENT_READABLE, on_accept, this);
    setenv("NOVA_SOCK", path_.c_str(), 1);
    wlr_log(WLR_INFO, "ipc: listening on %s", path_.c_str());
    return true;
}

int Ipc::on_accept(int fd, uint32_t, void *data) {
    auto *self = static_cast<Ipc *>(data);
    int cfd = accept4(fd, nullptr, nullptr, SOCK_NONBLOCK | SOCK_CLOEXEC);
    if (cfd < 0) return 0;
    auto c = std::make_unique<Client>();
    c->owner = self;
    c->fd = cfd;
    c->src = wl_event_loop_add_fd(self->server_->loop, cfd, WL_EVENT_READABLE, on_readable, c.get());
    self->clients_.push_back(std::move(c));
    return 0;
}

int Ipc::on_readable(int fd, uint32_t mask, void *data) {
    auto *c = static_cast<Client *>(data);
    Ipc *self = c->owner;

    if (mask & (WL_EVENT_HANGUP | WL_EVENT_ERROR)) {
        self->drop(c);
        return 0;
    }
    char buf[4096];
    ssize_t n = recv(fd, buf, sizeof buf, 0);
    if (n <= 0) {
        if (n < 0 && (errno == EAGAIN || errno == EINTR)) return 0;
        self->drop(c);
        return 0;
    }
    c->buf.append(buf, n);
    if (c->buf.size() > 65536) {
        self->drop(c);
        return 0;
    }
    size_t pos;
    while ((pos = c->buf.find('\n')) != std::string::npos) {
        std::string line = c->buf.substr(0, pos);
        c->buf.erase(0, pos + 1);
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (!line.empty()) self->handle(c, line);
    }
    return 0;
}

void Ipc::send(Client *c, const std::string &line) {
    std::string out = line + "\n";
    ::send(c->fd, out.data(), out.size(), MSG_NOSIGNAL | MSG_DONTWAIT);
}

void Ipc::drop(Client *c) {
    for (auto it = clients_.begin(); it != clients_.end(); ++it) {
        if (it->get() == c) {
            wl_event_source_remove(c->src);
            close(c->fd);
            clients_.erase(it);
            return;
        }
    }
}

void Ipc::broadcast(const std::string &json_line) {
    for (auto &c : clients_)
        if (c->subscribed) send(c.get(), json_line);
}

static std::string leds_json(Server *s) {
    return std::string("{\"event\":\"leds\",\"caps\":") + (s->caps_on ? "true" : "false") +
           ",\"num\":" + (s->num_on ? "true" : "false") + "}";
}

static std::string windows_json(Server *s) {
    std::string j = "{\"windows\":[";
    View *f = s->focused_view();
    bool first = true;
    for (View *v : s->views) {
        if (!v->mapped) continue;
        if (!first) j += ",";
        first = false;
        char id[32];
        snprintf(id, sizeof id, "%p", (void *)v);
        j += std::string("{\"id\":\"") + id + "\",\"title\":\"" + json_escape(v->title()) + "\",\"app_id\":\"" +
             json_escape(v->app_id()) + "\",\"workspace\":" + std::to_string(v->workspace + 1) +
             ",\"index\":" + std::to_string(v->workspace % kWsPerOutput + 1) +
             ",\"output\":\"" + json_escape(s->output_for_ws(v->workspace) ? s->output_for_ws(v->workspace)->output->name : "") + "\"" +
             ",\"focused\":" + (v == f ? "true" : "false") + ",\"minimized\":" + (v->minimized ? "true" : "false") +
             ",\"fullscreen\":" + (v->fullscreen ? "true" : "false") +
             ",\"x\":" + std::to_string(v->x) + ",\"y\":" + std::to_string(v->y) +
             ",\"w\":" + std::to_string(v->geometry().width) + ",\"h\":" + std::to_string(v->geometry().height) + "}";
    }
    return j + "]}";
}

void Ipc::handle(Client *c, const std::string &line) {
    if (line == "subscribe") {
        c->subscribed = true;
        server_->broadcast_workspaces();   // everyone gets a fresh snapshot; harmless
        send(c, leds_json(server_));
        return;
    }
    if (line == "get workspaces") return send(c, server_->workspaces_json());
    if (line == "get leds") return send(c, leds_json(server_));
    if (line == "get windows") return send(c, windows_json(server_));
    if (line.rfind("get thumbnails", 0) == 0) return send(c, server_->write_thumbnails(atoi(line.c_str() + 14)));
    if (line == "lock") {
        server_->run_action("lock");
        return send(c, "{\"ok\":true}");
    }
    if (line.rfind("dispatch ", 0) == 0) {
        server_->run_action(line.substr(9));
        return send(c, "{\"ok\":true}");
    }
    send(c, "{\"ok\":false,\"error\":\"unknown command\"}");
}
