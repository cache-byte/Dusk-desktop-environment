# Nova

A desktop environment for Fedora, all in C++: a **wlroots compositor** (`nova`), a **shell** (`nova-shell`: panel, pop-ups, lock screen…) and a **Settings app** (`nova-settings`). The shell and Settings are drawn with a small Cairo/Pango toolkit (`ui/`), no Qt or QML. It uses the login screen you already have (GDM, SDDM...).

```
nova/
├── compositor/   C++20 + wlroots: windows, workspaces, snapping, lock, IPC   → `nova`, `novactl`
├── ui/           novaui: Cairo + Pango widgets, Wayland (layer-shell, session lock, blur)
├── shell/        C++: panel, launcher, control centre, now playing, notifications,
│                 OSD, clipboard, overview, lock screen, wallpaper            → `nova-shell`
├── settings/     C++ on novaui: every Settings page, the recording trimmer    → `nova-settings`
├── session/      nova-session, nova-doctor, wayland-session file, portal config
├── install.sh    dnf deps → build → install to /usr (+ update.sh, tools/, extras/)
└── nova.spec     RPM spec
```

## Install

Paste this in a terminal on Fedora 43 or newer. It finds the newest `Nova-*-source.zip` in the GitHub repo, downloads it, and runs the installer:

```sh
command -v unzip >/dev/null || sudo dnf install -y unzip; z=$(curl -fsSL https://api.github.com/repos/cache-byte/Nova-desktop-environment/contents | grep -oE 'Nova-[0-9.]+-source\.zip' | sort -uV | tail -1); d=$(mktemp -d); curl -fL -o "$d/nova.zip" "https://raw.githubusercontent.com/cache-byte/Nova-desktop-environment/main/$z" && unzip -q "$d/nova.zip" -d "$d/src" && bash "$d/src/install.sh"
```

Or from an unzipped copy: `./install.sh` (`--deps` only installs packages).

The installer:

* installs packages with dnf (gpu-screen-recorder from COPR if Fedora doesn't have it, SongRec from Flathub),
* builds and installs Nova to `/usr`,
* adds "Nova" to your existing login screen's session list (your keyring unlocks at login as usual),
* sets GTK, libadwaita/Flatpak and Qt apps up to follow Nova's light/dark mode (adw-gtk3, qt6ct),
* writes every change to `/var/lib/nova/manifest`.

Then reboot (if the login screen changed) and choose **Nova**. You can also try it inside your current desktop first: `nova -s nova-shell`.

**Update:** Settings → Updates (shows each step with a progress bar and asks for your password once), `nova-update` in a terminal, or `./update.sh`. It installs the zip with the highest version number in the repo (or, on the "Latest" channel, the zip from the newest commit).

**Remove:** `nova-uninstall`, or Settings → Updates → Uninstall. It undoes everything in the manifest, including the old login screen. `--remove-deps` also removes packages Nova added and `--purge` deletes your Nova settings.

**Making a release zip:** `tools/set-version.sh 0.0.2` then `tools/package.sh`. Upload `Nova-0.0.2-source.zip` to the repo root.

**Automatic builds on GitHub (optional, one time):** copy `extras/.github/workflows/build.yml` into the repo at `.github/workflows/build.yml`. Every push then unzips the newest zip and builds it on Fedora 43; results are in the Actions tab.

**Defaults:** Papirus-Dark icons, Bibata Modern Classic cursor, Inter font, accent `#C8B64A`, dark mode. Decisions behind everything are in `docs/DECISIONS.md`.

## How the pieces talk

| From → To | How |
|---|---|
| shell ↔ compositor | `$NOVA_SOCK` unix socket. The shell subscribes to workspace, Caps/Num Lock and keybind events. `novactl dispatch <action>` drives the compositor |
| taskbar | `wlr-foreign-toplevel-management` |
| lock screen | `ext-session-lock` + PAM (`/etc/pam.d/nova-lock`) |
| settings ↔ shell | `~/.config/nova/settings.json` (both sides watch it) |
| settings → compositor | `~/.config/nova/nova.conf` + `novactl dispatch reload` |
| GTK/libadwaita apps | `gsettings` (icons, cursor, fonts, colour scheme) |

## Control centre & indicators

* The control centre, launcher and calendar share a **6 × 10 grid** of 52 px cells. Sliders default to 1 × 3 cells and turn horizontal when resized wider than tall. Toggles take 1 cell, Wi-Fi and Bluetooth 3, power mode 6.
* **Settings → Popups & indicators** places each popup on one of nine anchor points. The popups are volume/brightness/mic, lock keys, power mode, notifications, small messages and Now Playing. Each one runs **Up** (vertical) or **Across** (horizontal). Drag it on the preview to nudge it up to 200 px. You can also set hide-after (1/2/4 s), size (S/M/L), and whether it shows on the screen under the pointer or on all screens.
* Small messages from scripts: `nova-shell toast "Copied" clip`. Also `nova-shell toggle launcher|controlcentre|notifications|clipboard|capture|overview`, `nova-shell lock`.
* The Super tap is set with a bare `Super = …` line under `[bindings]` (empty value turns it off); `super_tap_ms` under `[input]` sets how quick the tap must be (default 400).
* Caps/Num Lock state is restored after restart (`remember_locks` in nova.conf, state kept in `~/.local/state/nova/locks`).

## Keys (edit in `~/.config/nova/nova.conf`)

| Key | Action |
|---|---|
| Super (tap) | app launcher — press and release Super on its own; Super+Space also works |
| Super+A / Super+N / Super+V | control centre / notifications / clipboard |
| Super+Tab | overview |
| Super+Return / Super+E | terminal / files |
| Super+Q, Alt+F4 | close |
| Super+↑ ↓ ← → | maximise / restore-or-minimise / snap left / snap right |
| Super+F | fullscreen (hides the panel) |
| Super+1…9, Super+Shift+1…9 | switch workspace / move window there (on the monitor under the mouse) |
| Super+Ctrl+← →, 3-finger swipe | previous / next workspace |
| 3-finger swipe up | overview |
| Super+Shift+O | move window to the other monitor |
| Super+drag, Super+right-drag | move / resize any window |
| Drag a window to a screen edge | snap left/right half, top edge maximises |
| Super+L | lock |
| Print | capture bar: screenshot or record, region / window / screen |
| Alt+Print, Shift+Print | quick region / full-screen screenshot (clipboard + ~/Pictures/Screenshots) |
| Ctrl+Print, Super+Shift+S | region screenshot, draw on it before saving (Satty) |
| Super+Shift+R | start / stop screen recording (~/Videos/Recordings) |
| Super+Alt+R | save instant replay (when on in Settings → Gaming) |
| Super+G | game overlay |

## Status

* **The shell and Settings were rewritten in C++** (0.1.0) because Quickshell used too much memory and CPU. They were compiled and linked against the real headers and their cards were rendered offscreen to check the layouts, but this build hasn't run on a real session yet: report anything that looks or behaves wrong.
* **Troubleshooting:** the compositor (`nova`) and the shell (`nova-shell`) are separate programs. If the panel is gone, run `nova-shell` in a terminal inside Nova to see its messages; `nova-doctor` shows what's running and how much memory the shell uses.
* **Real blur** behind the panel and pop-ups needs SceneFX (built with the compositor on wlroots 0.19). Without it the shell blurs the wallpaper instead.
* **Video wallpapers** play with `mpvpaper`. The overview shows app icons instead of live window previews.
* **Power profiles** use `tuned-ppd`. **Night light** uses `gammastep`. **Recording and instant replay** use `gpu-screen-recorder` (falls back to `wf-recorder` without replay).
* **Capture:** Print opens the capture bar (screenshot or record · region, window or screen · delay · sound and mic · draw before saving with Satty). Print while a pop-up is open captures the screen with the pop-up in it. A finished recording's notification has a **Trim** button (`nova-settings --trim FILE`, ffmpeg, no re-encode; preview plays in mpv).
* **Hybrid NVIDIA laptops:** the desktop runs on the integrated GPU (`nova-gpu order` sets `WLR_DRM_DEVICES`); games from the launcher start on NVIDIA with GameMode (`nova-gpu run`). Change it in Settings → Power → Graphics.

## Lyrics lookup

1. A `.lrc` file next to the song.
2. LRCLIB search by title, artist and length.
3. If that finds nothing, SongRec listens to a few seconds of the audio to identify the song.
4. LRCLIB is searched again with SongRec's title and artist.

The current line is coloured with the accent as it is sung, in every lyric style. Lyrics are cached in `~/.cache/nova/lyrics`; misses are retried after a day.

Monitor scale is limited to 100–200 %.
