#!/usr/bin/env bash
# Set the Nova version everywhere: tools/set-version.sh 0.0.2
set -euo pipefail
cd "$(dirname "$0")/.."
v="${1:?usage: tools/set-version.sh X.Y.Z}"
echo "$v" > VERSION
sed -i "s/^\(  version: '\)[^']*'/\1$v'/" compositor/meson.build
sed -i "s/^Version:\( *\).*/Version:\1$v/" nova.spec
echo "Nova is now $v. Package with: tools/package.sh"
