#include "sys.hpp"

#include <cerrno>
#include <csignal>
#include <fcntl.h>
#include <poll.h>
#include <sys/inotify.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#include <filesystem>
#include <map>

namespace ui {

// =================================================================== Process ==
Process::~Process() {
    if (watch_) Loop::get().removeFd(watch_);
    if (outFd_ >= 0) close(outFd_);
}
bool Process::start(const std::vector<std::string> &argv, const std::string &stdinData) {
    if (argv.empty()) return false;
    int out[2], in[2] = {-1, -1};
    if (pipe2(out, O_CLOEXEC) < 0) return false;
    if (!stdinData.empty() && pipe2(in, O_CLOEXEC) < 0) { close(out[0]); close(out[1]); return false; }
    pid_t pid = fork();
    if (pid < 0) return false;
    if (pid == 0) {
        sigset_t set;
        sigemptyset(&set);
        sigprocmask(SIG_SETMASK, &set, nullptr);
        signal(SIGPIPE, SIG_DFL);
        dup2(out[1], 1);
        int nul = open("/dev/null", O_RDWR);
        if (in[0] >= 0) dup2(in[0], 0);
        else if (nul >= 0) dup2(nul, 0);
        if (nul >= 0) dup2(nul, 2);
        setpgid(0, 0);
        std::vector<char *> a;
        for (auto &s : argv) a.push_back(const_cast<char *>(s.c_str()));
        a.push_back(nullptr);
        execvp(a[0], a.data());
        _exit(127);
    }
    close(out[1]);
    if (in[0] >= 0) {
        close(in[0]);
        // small inputs only (passwords for helpers, text for wl-copy): write and close
        size_t off = 0;
        while (off < stdinData.size()) {
            ssize_t n = write(in[1], stdinData.data() + off, stdinData.size() - off);
            if (n <= 0) break;
            off += n;
        }
        close(in[1]);
    }
    pid_ = pid;
    outFd_ = out[0];
    fcntl(outFd_, F_SETFL, fcntl(outFd_, F_GETFL) | O_NONBLOCK);
    watch_ = Loop::get().addFd(outFd_, POLLIN, [this](int, short) { readable(); });
    return true;
}
void Process::readable() {
    char tmp[8192];
    for (;;) {
        ssize_t n = read(outFd_, tmp, sizeof tmp);
        if (n > 0) {
            buf_.append(tmp, n);
            if (line_) {
                size_t pos;
                while ((pos = buf_.find('\n')) != std::string::npos) {
                    std::string l = buf_.substr(0, pos);
                    buf_.erase(0, pos + 1);
                    line_(l);
                }
            }
            continue;
        }
        if (n < 0 && (errno == EAGAIN || errno == EINTR)) return;
        finish();   // EOF
        return;
    }
}
void Process::finish() {
    Loop::get().removeFd(watch_);
    watch_ = 0;
    close(outFd_);
    outFd_ = -1;
    if (line_ && !buf_.empty()) { line_(buf_); buf_.clear(); }
    // stdout closed; the exit code comes when the child is reaped. It can take a while
    // (pkexec, an installer finishing up), so wait for it instead of guessing a failure.
    auto keep = self_;
    auto tryReap = [this, keep]() -> bool {
        int status = 0;
        pid_t r = pid_ > 0 ? waitpid(pid_, &status, WNOHANG) : -1;
        if (r == 0) return false;          // still running
        int code = r == pid_ ? (WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status)) : 0;
        pid_ = -1;
        auto done = std::move(done_);
        done_ = nullptr;
        self_.reset();
        if (done) done(code, buf_);
        return true;
    };
    if (tryReap()) return;
    auto id = std::make_shared<int>(0);
    *id = Loop::get().addTimer(50, [tryReap, id] { if (tryReap()) Loop::get().removeTimer(*id); }, true);
}
void Process::kill(int sig) {
    if (pid_ > 0) ::kill(-pid_, sig);   // the whole process group
}
std::shared_ptr<Process> Process::run(const std::vector<std::string> &argv, Done done, const std::string &stdinData) {
    auto p = std::shared_ptr<Process>(new Process);
    p->done_ = std::move(done);
    if (!p->start(argv, stdinData)) {
        if (p->done_) Loop::get().defer([d = p->done_] { d(127, ""); });
        return p;
    }
    p->self_ = p;
    return p;
}
std::shared_ptr<Process> Process::lines(const std::vector<std::string> &argv, Line line, Done onExit) {
    auto p = std::shared_ptr<Process>(new Process);
    p->line_ = std::move(line);
    p->done_ = std::move(onExit);
    if (!p->start(argv, "")) {
        if (p->done_) Loop::get().defer([d = p->done_] { d(127, ""); });
        return p;
    }
    p->self_ = p;
    return p;
}

bool haveProgram(const std::string &name) {
    if (name.find('/') != std::string::npos) return access(name.c_str(), X_OK) == 0;
    const char *path = getenv("PATH");
    for (auto &d : split(path ? path : "/usr/bin:/bin", ':'))
        if (!d.empty() && access((d + "/" + name).c_str(), X_OK) == 0) return true;
    return false;
}

// ================================================================= FileWatch ==
namespace {
struct Watcher {
    int fd = -1;
    struct W { int id; int wd; std::string dir, file; std::function<void()> fn; };
    std::vector<W> list;
    int next = 0;
};
Watcher &watcher() {
    static Watcher w;
    if (w.fd < 0) {
        w.fd = inotify_init1(IN_NONBLOCK | IN_CLOEXEC);
        if (w.fd >= 0)
            Loop::get().addFd(w.fd, POLLIN, [](int fd, short) {
                alignas(inotify_event) char buf[8192];
                std::vector<std::function<void()>> fire;
                for (;;) {
                    ssize_t n = read(fd, buf, sizeof buf);
                    if (n <= 0) break;
                    for (char *p = buf; p < buf + n;) {
                        auto *e = (inotify_event *)p;
                        std::string name = e->len ? e->name : "";
                        for (auto &x : watcher().list)
                            if (x.wd == e->wd && (x.file.empty() || x.file == name)) fire.push_back(x.fn);
                        p += sizeof(inotify_event) + e->len;
                    }
                }
                for (auto &f : fire) f();
            });
    }
    return w;
}
}  // namespace

int FileWatch::watch(const std::string &path, std::function<void()> changed) {
    Watcher &w = watcher();
    if (w.fd < 0) return 0;
    std::filesystem::path p(path);
    std::string dir = std::filesystem::is_directory(p) ? path : p.parent_path().string();
    std::string file = std::filesystem::is_directory(p) ? "" : p.filename().string();
    std::filesystem::create_directories(dir);
    int wd = inotify_add_watch(w.fd, dir.c_str(), IN_CLOSE_WRITE | IN_MOVED_TO | IN_CREATE | IN_DELETE);
    if (wd < 0) return 0;
    // debounce: several events in a row become one call
    auto pending = std::make_shared<int>(0);
    auto fn = [changed, pending] {
        if (*pending && Loop::get().timerActive(*pending)) return;
        *pending = Loop::get().addTimer(60, changed);
    };
    w.list.push_back({++w.next, wd, dir, file, fn});
    return w.next;
}
void FileWatch::unwatch(int id) {
    Watcher &w = watcher();
    std::erase_if(w.list, [id](const Watcher::W &x) { return x.id == id; });
}

}  // namespace ui
