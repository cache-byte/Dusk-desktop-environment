// System plumbing on the novaui event loop: child processes, file watching, JSON helpers.
#pragma once
#include "core.hpp"

namespace ui {

// A child process whose output is read without blocking the UI.
//   auto p = Process::run({"nmcli", "-t", "..."}, [](int code, const std::string &out) { ... });
//   Process::lines({"pactl", "subscribe"}, [](const std::string &line) { ... });
class Process {
public:
    using Done = std::function<void(int exitCode, const std::string &out)>;
    using Line = std::function<void(const std::string &line)>;
    ~Process();
    // run to completion, collect stdout
    static std::shared_ptr<Process> run(const std::vector<std::string> &argv, Done done = {}, const std::string &stdinData = "");
    // long-running: one callback per stdout line; onExit when it ends
    static std::shared_ptr<Process> lines(const std::vector<std::string> &argv, Line line, Done onExit = {});
    void kill(int sig = 15);
    bool running() const { return pid_ > 0; }
    int pid() const { return pid_; }
private:
    int pid_ = -1, outFd_ = -1, watch_ = 0;
    std::string buf_;
    Done done_;
    Line line_;
    std::shared_ptr<Process> self_;     // alive until the child is reaped
    bool start(const std::vector<std::string> &argv, const std::string &stdinData);
    void readable();
    void finish();
};

// Is a program on $PATH?
bool haveProgram(const std::string &name);

// inotify: callback when a file is written / replaced (watches the directory, so atomic
// renames like "write tmp + rename" are seen)
class FileWatch {
public:
    static int watch(const std::string &path, std::function<void()> changed);   // returns id
    static void unwatch(int id);
};

}  // namespace ui
