// novaui core: geometry, colours, the theme, signals, the event loop and animations.
// Shared by nova-shell and nova-settings. No toolkit underneath: Cairo + Pango + Wayland.
#pragma once
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace ui {

// ------------------------------------------------------------------ geometry --
struct Point { double x = 0, y = 0; };
struct Size { double w = 0, h = 0; };
struct Rect {
    double x = 0, y = 0, w = 0, h = 0;
    bool contains(Point p) const { return p.x >= x && p.y >= y && p.x < x + w && p.y < y + h; }
    Rect translated(double dx, double dy) const { return {x + dx, y + dy, w, h}; }
    Rect inset(double d) const { return {x + d, y + d, std::max(0.0, w - 2 * d), std::max(0.0, h - 2 * d)}; }
    Rect inset(double l, double t, double r, double b) const {
        return {x + l, y + t, std::max(0.0, w - l - r), std::max(0.0, h - t - b)};
    }
    Rect united(const Rect &o) const;
    Rect intersected(const Rect &o) const;
    bool empty() const { return w <= 0 || h <= 0; }
    double right() const { return x + w; }
    double bottom() const { return y + h; }
    Point center() const { return {x + w / 2, y + h / 2}; }
};

// ------------------------------------------------------------------ colours --
struct Color {
    double r = 0, g = 0, b = 0, a = 1;
    static Color rgb(int r, int g, int b, double a = 1) { return {r / 255.0, g / 255.0, b / 255.0, a}; }
    static Color hex(const std::string &s, Color fallback);   // "#rrggbb" / "#aarrggbb" / "#rgb"
    static Color hex(const std::string &s) { return hex(s, Color{0, 0, 0, 1}); }
    Color alpha(double na) const { return {r, g, b, na}; }
    Color withAlpha(double factor) const { return {r, g, b, a * factor}; }
    Color mix(const Color &o, double t) const { return {r + (o.r - r) * t, g + (o.g - g) * t, b + (o.b - b) * t, a + (o.a - a) * t}; }
    Color lighter(double f) const;   // HSL lightness * f
    Color darker(double f) const;
    double luminance() const { return 0.2126 * r + 0.7152 * g + 0.0722 * b; }
    std::string toHex() const;
    bool operator==(const Color &o) const { return r == o.r && g == o.g && b == o.b && a == o.a; }
};

// ---------------------------------------------------------------- signals --
// Tiny observer: services emit, widgets connect. Connections live as long as the signal
// (widgets disconnect by token when they are destroyed).
template <typename... Args> class Signal {
public:
    using Fn = std::function<void(Args...)>;
    int connect(Fn f) { slots_.emplace_back(++next_, std::move(f)); return next_; }
    void disconnect(int id) {
        for (auto &s : slots_) if (s.first == id) s.second = nullptr;
    }
    void emit(Args... a) {
        // copy: a slot may connect/disconnect while we iterate
        auto copy = slots_;
        for (auto &s : copy) if (s.second) s.second(a...);
        std::erase_if(slots_, [](auto &s) { return !s.second; });
    }
    void operator()(Args... a) { emit(a...); }
private:
    std::vector<std::pair<int, Fn>> slots_;
    int next_ = 0;
};

// ------------------------------------------------------------------- time --
using Clock = std::chrono::steady_clock;
// bumped at the start of every layout pass: size hints are cached within one pass
uint64_t layoutGeneration();
void bumpLayoutGeneration();

inline int64_t nowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now().time_since_epoch()).count();
}

// --------------------------------------------------------------- event loop --
// poll()-based: file descriptors, timers and "do this soon" callbacks.
class Loop {
public:
    static Loop &get();
    using FdFn = std::function<void(int fd, short revents)>;
    int addFd(int fd, short events, FdFn fn);          // returns a watch id
    void setFdEvents(int id, short events);
    void removeFd(int id);
    int addTimer(int ms, std::function<void()> fn, bool repeat = false);
    void removeTimer(int id);
    void restartTimer(int id);                           // from now, with its interval
    bool timerActive(int id) const;
    void defer(std::function<void()> fn);                // runs on the next loop pass
    // Called right before poll() blocks (Wayland: flush + prepare_read)
    void addPrePoll(std::function<void()> fn) { prePoll_.push_back(std::move(fn)); }
    void run();
    void quit() { running_ = false; }
    void iterate(int maxWaitMs);                         // one pass (tests, nested waits)
private:
    struct Watch { int id; int fd; short events; FdFn fn; bool dead = false; };
    struct Timer { int id; int64_t due; int interval; bool repeat; std::function<void()> fn; bool dead = false; };
    std::vector<Watch> watches_;
    std::vector<Timer> timers_;
    std::vector<std::function<void()>> deferred_, prePoll_;
    int nextId_ = 0;
    bool running_ = false;
};

// A timer object that can be started / restarted / stopped any number of times
// (Loop timers are one-shot ids; this keeps the bookkeeping in one place).
class Timer {
public:
    Timer() = default;
    Timer(int ms, std::function<void()> fn, bool repeat = false) : ms_(ms), repeat_(repeat), fn_(std::move(fn)) {}
    ~Timer() { stop(); }
    Timer(const Timer &) = delete;
    Timer &operator=(const Timer &) = delete;
    void setup(int ms, std::function<void()> fn, bool repeat = false) { stop(); ms_ = ms; fn_ = std::move(fn); repeat_ = repeat; }
    void setInterval(int ms) { ms_ = ms; }
    int interval() const { return ms_; }
    void start() {           // (re)start from now
        stop();
        id_ = Loop::get().addTimer(ms_, [this] {
            if (!repeat_) id_ = 0;
            auto f = fn_;
            if (f) f();
        }, repeat_);
    }
    void stop() { if (id_) { Loop::get().removeTimer(id_); id_ = 0; } }
    bool active() const { return id_ != 0; }
private:
    int ms_ = 0, id_ = 0;
    bool repeat_ = false;
    std::function<void()> fn_;
};

// ---------------------------------------------------------------- animation --
enum class Ease { Linear, OutCubic, InOutCubic, OutBack, OutQuint };
double ease(Ease e, double t);

// A value that glides to its target. Widgets hold these and ask their window for frames
// while any of them is moving.
class Anim {
public:
    Anim(double v = 0) : value_(v), from_(v), to_(v) {}
    void set(double v) { value_ = from_ = to_ = v; running_ = false; }       // jump
    void animate(double to, int ms, Ease e = Ease::OutCubic);               // glide
    bool tick(int64_t now);      // advance; returns true while still moving
    double value() const { return value_; }
    double target() const { return to_; }
    bool running() const { return running_; }
    operator double() const { return value_; }
private:
    double value_, from_, to_;
    int64_t start_ = 0;
    int dur_ = 0;
    Ease ease_ = Ease::OutCubic;
    bool running_ = false;
};

// ------------------------------------------------------------------- theme --
// Colours and metrics, rebuilt whenever settings change (light/dark, accent, transparency).
struct Theme {
    bool dark = true;
    Color accent = Color::hex("#c8b64a");
    Color accentBright, accentSoft, accentLine, onAccent;
    Color text, text2, text3;
    Color surface, surface2, surface3, panel, window, border;
    Color danger = Color::hex("#e5484d"), warn = Color::hex("#f0a43a"), ok = Color::hex("#46a758");
    std::string font = "Inter", mono = "JetBrains Mono";
    double fontSize = 14;
    double radius = 20, radiusS = 14;
    double transparencyUi = 0.8, transparencyPanel = 0.8, transparencyApps = 0.8;
    double blurUi = 0.8, blurPanel = 0.8, blurApps = 0.8;
    double animationSpeed = 1.0;
    bool realBlur = false;      // the compositor blurs behind cards (SceneFX); else fake it from the wallpaper
    // popout grid: 8 columns × up to 10 rows of square cells
    int gridCols = 6, gridRows = 10;
    double gridCell = 52, gridGap = 10, gridPad = 18;
    double panelHeight = 48, gap = 12;

    double gridWidth() const { return gridCols * gridCell + (gridCols - 1) * gridGap + 2 * gridPad; }
    double gridHeight(int rows) const { return rows * gridCell + (rows - 1) * gridGap + 2 * gridPad; }
    int gridRowsFor(double h) const {
        int r = (int)std::ceil((h - 2 * gridPad + gridGap) / (gridCell + gridGap));
        return std::clamp(r, 1, gridRows);
    }
    int ms(int t) const { return (int)std::lround(t / std::max(0.1, animationSpeed)); }
    void rebuild();     // derive the dependent colours from dark / accent / transparency

    static Theme &get();
    Signal<> changed;
};
inline Theme &theme() { return Theme::get(); }

// ---------------------------------------------------------------- strings --
std::string trim(const std::string &s);
std::vector<std::string> split(const std::string &s, char sep);
std::string lower(std::string s);
bool startsWith(const std::string &s, const std::string &p);
bool endsWith(const std::string &s, const std::string &p);
std::string replaceAll(std::string s, const std::string &from, const std::string &to);
std::string homeDir();
std::string configDir();       // ~/.config
std::string runtimeDir();      // $XDG_RUNTIME_DIR
std::string readFile(const std::string &path, bool *ok = nullptr);
bool writeFile(const std::string &path, const std::string &data);   // atomic (tmp + rename)
std::string shellQuote(const std::string &s);

// Run a program detached (double fork), like Quickshell.execDetached.
void spawn(const std::vector<std::string> &argv);
void spawnShell(const std::string &cmd);      // sh -c

}  // namespace ui
