// Painting: rounded shapes, soft shadows, text (Pango), icons (librsvg) and images.
#pragma once
#include "core.hpp"

typedef struct _cairo cairo_t;
typedef struct _cairo_surface cairo_surface_t;
typedef struct _PangoLayout PangoLayout;

namespace ui {

enum class Weight { Normal = 400, Medium = 500, DemiBold = 600, Bold = 700 };
enum class Align { Start, Center, End };
enum class Elide { None, End, Middle, Start };

struct Font {
    std::string family;      // empty = theme font
    double size = 14;        // px
    Weight weight = Weight::Normal;
    bool mono = false;
    bool italic = false;
    double letterSpacing = 0;
};

// A laid-out piece of text. Cheap to keep around; re-created when its inputs change.
class Text {
public:
    Text() = default;
    Text(const std::string &s, Font f, double maxWidth = -1, Elide e = Elide::End, int maxLines = 1, bool markup = false);
    ~Text();
    Text(const Text &) = delete;
    Text &operator=(const Text &) = delete;
    Text(Text &&o) noexcept;
    Text &operator=(Text &&o) noexcept;
    void set(const std::string &s, Font f, double maxWidth = -1, Elide e = Elide::End, int maxLines = 1, bool markup = false);
    Size size() const { return size_; }
    double baseline() const { return baseline_; }
    PangoLayout *layout() const { return layout_; }
    const std::string &str() const { return str_; }
    // cursor helpers for text input (byte index <-> x)
    double xForIndex(int index) const;
    int indexForX(double x) const;
private:
    PangoLayout *layout_ = nullptr;
    Size size_;
    double baseline_ = 0;
    std::string str_;
    Font font_;
    double maxWidth_ = -1;
    Elide elide_ = Elide::End;
    int maxLines_ = 1;
    bool markup_ = false;
    void build();
};

// Text measured without creating a long-lived layout
Size measureText(const std::string &s, const Font &f, double maxWidth = -1, int maxLines = 1);

class Image;   // decoded raster (wallpapers, art, avatars)

class Painter {
public:
    explicit Painter(cairo_t *cr) : cr_(cr) {}
    cairo_t *cr() const { return cr_; }

    void save();
    void restore();
    void translate(double x, double y);
    void scale(double s);
    void clip(const Rect &r, double radius = 0);
    void setOpacityGroup();          // start drawing into a group…
    void endOpacityGroup(double a);  // …and composite it with this opacity

    void fill(const Rect &r, Color c, double radius = 0);
    void stroke(const Rect &r, Color c, double width = 1, double radius = 0);
    void fillCircle(Point c, double r, Color col);
    void strokeCircle(Point c, double r, Color col, double width);
    void line(Point a, Point b, Color c, double width = 1, bool round = true);
    void arc(Point c, double r, double a0, double a1, Color col, double width);
    // soft drop shadow under a rounded rectangle (cached blur)
    void shadow(const Rect &r, double radius, double blur, double offsetY, Color c, double spread = 0);
    void gradient(const Rect &r, Color top, Color bottom, double radius = 0, bool horizontal = false);

    void text(const Text &t, Point at, Color c);
    void textIn(const Text &t, const Rect &box, Color c, Align h = Align::Start, Align v = Align::Center);
    void textAt(const std::string &s, const Font &f, Point at, Color c);   // one-off

    void icon(const std::string &name, const Rect &r, Color c);            // Nova line icon (tinted)
    void icon(const std::string &name, Point center, double size, Color c);
    void appIcon(const std::string &nameOrPath, const Rect &r);            // themed app icon, untinted
    void image(const Image &img, const Rect &r, double radius = 0, bool cover = true, double opacity = 1);

    // rounded-rectangle path (for custom fills / clips)
    void roundRectPath(const Rect &r, double radius);
    void roundRectPath(const Rect &r, double tl, double tr, double br, double bl);
private:
    cairo_t *cr_;
};

// ------------------------------------------------------------------ images --
class Image {
public:
    Image() = default;
    explicit Image(const std::string &path, int maxW = 0, int maxH = 0);   // decodes (scaled down if larger)
    ~Image();
    Image(const Image &) = delete;
    Image &operator=(const Image &) = delete;
    Image(Image &&o) noexcept : s_(o.s_), w_(o.w_), h_(o.h_) { o.s_ = nullptr; }
    Image &operator=(Image &&o) noexcept;
    bool valid() const { return s_ != nullptr; }
    int width() const { return w_; }
    int height() const { return h_; }
    cairo_surface_t *surface() const { return s_; }
    // a blurred copy (box blur, a few passes), for glass backgrounds and the lock screen
    Image blurred(int radius, double saturation = 1.0) const;
    static Image fromSurface(cairo_surface_t *s);
    // raw premultiplied ARGB with an int32 width / height header (window previews from Nova)
    static Image fromRawArgb(const std::string &path);
    Color average() const;        // mean colour (accent from wallpaper)
private:
    cairo_surface_t *s_ = nullptr;
    int w_ = 0, h_ = 0;
};

// Icon lookup
void setIconSearchPath(const std::string &dir);   // Nova's own line icons (*.svg)
void setIconTheme(const std::string &theme);       // app icon theme (Papirus-Dark…)
std::string findAppIcon(const std::string &name, int size);   // full path or ""

}  // namespace ui
