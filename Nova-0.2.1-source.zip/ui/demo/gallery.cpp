// Renders every novaui widget to a PNG (dark and light), for checking the toolkit's look.
//   gallery out-dir [wallpaper.jpg]
#include "ui/window.hpp"

#include <cstdio>

using namespace ui;

static void build(Window &w, bool dark) {
    auto *root = w.setRoot<Box>(Dir::Row, 24);
    root->padding(40);

    // ---- column 1: buttons, toggles, segmented, stepper, inputs ----
    auto *c1 = root->add<Card>(Dir::Column, 14);
    c1->fixedW = 420;
    c1->alignSelf = Align::Start;
    c1->fill = false;
    auto *title = c1->add<Label>("Controls", 18, Weight::DemiBold);
    (void)title;
    auto *r1 = row(c1, 8);
    r1->add<TextButton>("Reset", "restart");
    r1->add<TextButton>("Log out now", "", true);
    r1->add<IconButton>("settings");
    r1->add<IconButton>("power")->icon->role = Role::Danger;
    auto *r2 = row(c1, 12);
    r2->add<Label>("Do not disturb", 14)->grow = 1;
    r2->add<Toggle>(true);
    r2->add<Toggle>(false);
    auto *seg = c1->add<Segmented>();
    seg->fill = false;
    seg->options = {{"release", "Release", ""}, {"latest", "Latest", ""}};
    seg->value = "release";
    auto *seg2 = c1->add<Segmented>();
    seg2->fill = false;
    seg2->small = true;
    seg2->options = {{"1", "1 s", ""}, {"2", "2 s", ""}, {"4", "4 s", ""}};
    seg2->value = "2";
    auto *r3 = row(c1, 12);
    auto *st = r3->add<Stepper>();
    st->value = 24; st->suffix = " px";
    auto *cb = r3->add<Checkbox>();
    cb->checked = true;
    r3->add<Label>("Appearance", 14);
    auto *ti = c1->add<TextInput>();
    ti->leadingIcon = "search";
    ti->placeholder = "Search apps, files, settings…";
    auto *ti2 = c1->add<TextInput>();
    ti2->setText("hunter2");
    ti2->password = true;
    auto *sl = c1->add<Slider>();
    sl->thick = false;
    sl->setValue(0.62);
    auto *dd = c1->add<Dropdown>();
    dd->items = {{"Papirus-Dark", "Papirus-Dark"}, {"Adwaita", "Adwaita"}};
    dd->value = "Papirus-Dark";

    // ---- column 2: control-centre-like tiles ----
    auto *c2 = root->add<Card>(Dir::Column, 10);
    c2->fixedW = theme().gridWidth();
    c2->padding(theme().gridPad);
    c2->alignSelf = Align::Start;
    c2->fill = false;
    auto *top = row(c2, 10);
    auto *tiles = col(top, 10);
    tiles->grow = 1;
    for (auto [ic, lab, sub, on] : std::vector<std::tuple<std::string, std::string, std::string, bool>>{
             {"wifi", "Wi-Fi", "HomeNet", true}, {"bt", "Bluetooth", "Off", false}}) {
        auto *b = tiles->add<Button>(Dir::Row, 12);
        b->fixedH = theme().gridCell;
        b->radius = 16;
        b->padding(14, 0);
        b->bg = theme().surface2;
        b->active = on;
        auto *ib = b->add<Box>(Dir::Row);
        ib->fixedW = ib->fixedH = 32;
        ib->radius = 16;
        ib->bg = on ? theme().accent : theme().surface3;
        ib->justify = Justify::Center;
        ib->add<IconW>(ic, 17, on ? Role::OnAccent : Role::Text2);
        auto *tx = col(b, 1);
        tx->grow = 1;
        tx->add<Label>(lab, 13.5, Weight::DemiBold);
        tx->add<Label>(sub, 12, Weight::Normal, Role::Text3);
        b->add<IconW>("chevr", 16, Role::Text3);
    }
    for (auto ic : {"sun", "volume", "mic"}) {
        auto *s = top->add<Slider>(true);
        s->iconName = ic;
        s->fixedW = theme().gridCell;
        s->fixedH = theme().gridCell * 2 + theme().gridGap;
        s->setValue(ic == std::string("volume") ? 0.7 : 0.45);
    }
    auto *g = row(c2, 10);
    for (auto ic : {"moon", "sunset", "plane", "contrast", "shot"}) {
        auto *b = g->add<IconButton>(ic, theme().gridCell, 20);
        b->radius = 16;
        b->bg = theme().surface2;
        b->active = ic == std::string("moon");
    }
    auto *pw = c2->add<Segmented>();
    pw->options = {{"power-saver", "Saver", "leaf"}, {"balanced", "Balanced", "gauge"}, {"performance", "Performance", "bolt"}};
    pw->value = "balanced";
    auto *ns = c2->add<Label>("Now playing · Spotify", 12, Weight::Normal, Role::Text2);
    (void)ns;
    auto *np = row(c2, 14);
    auto *art = np->add<ImageW>();
    art->fixedW = art->fixedH = 64;
    art->radius = 14;
    art->placeholder = theme().surface3;
    art->placeholderIcon = "music";
    auto *meta = col(np, 3);
    meta->grow = 1;
    meta->add<Label>("A very long song title that should end with an ellipsis", 16, Weight::DemiBold);
    meta->add<Label>("Artist · Album", 13, Weight::Normal, Role::Text2);
    (void)dark;
}

int main(int argc, char **argv) {
    std::string out = argc > 1 ? argv[1] : ".";
    setIconSearchPath("/home/claude/nova/shell/icons");
    for (bool dark : {true, false}) {
        Theme &t = theme();
        t.dark = dark;
        t.transparencyUi = 0.2;    // readable on a plain background
        t.rebuild();
        OffscreenWindow w({1020, 720});
        w.clearColor = dark ? Color::hex("#0e1420") : Color::hex("#d9d2ee");
        if (argc > 2) {
            w.backdrop = std::make_shared<Image>(Image(argv[2], 1020, 720).blurred(40, 1.15));
            w.screenRect = {0, 0, 1020, 720};
            w.screenSize = {1020, 720};
            t.transparencyUi = 0.8;
            t.rebuild();
        }
        build(w, dark);
        std::string p = out + (dark ? "/gallery-dark.png" : "/gallery-light.png");
        if (!w.savePng(p)) { fprintf(stderr, "failed %s\n", p.c_str()); return 1; }
        printf("%s\n", p.c_str());
    }
}
