# Nova C++ rewrite

Decided 11 Nov 2026: the Quickshell (QML) shell and the Qt Settings app are replaced by C++
programs on a small toolkit of Nova's own. Released all at once when everything is ported.

## Programs

| Program        | What it is                                                         |
|----------------|--------------------------------------------------------------------|
| `nova`         | Compositor (wlroots + SceneFX). Unchanged by the rewrite.           |
| `nova-shell`   | Panel, pop-ups, notifications, lock screen, wallpaper, OSDs. C++.   |
| `nova-settings`| Settings app. C++, same toolkit as the shell.                       |
| `novactl`      | Talks to the compositor (unchanged).                                |

Compositor and shell stay separate processes: a crash in one is visible in its own log
(`journalctl -t nova` / `-t nova-shell`) and the compositor restarts the shell.

## Toolkit: `ui/` (libnovaui, static)

* Drawing: Cairo into wl_shm buffers (CPU). Windows repaint only when something changed; pop-ups are sized to their card, click-catchers are one-pixel buffers.
* Text: Pango (wrapping, ellipsis, bidi, font fallback). Inter by default.
* Icons: Nova's line icons through a small built-in SVG reader (paths, circles, rects,
  lines); app icons from the icon theme through librsvg (SVG) and stb_image (PNG).
* Images: stb_image (JPG/PNG) for wallpapers, album art, avatars.
* Widgets: Label, Icon, Image, Button, IconButton, Toggle, Slider, Segmented, Checkbox,
  Stepper, TextInput, Dropdown, ScrollView, ListView, Card (glass), Row/Column/Grid layouts.
* Animation: tweens on the frame clock; speed from Settings (`animationSpeed`).
* Wayland: layer-shell surfaces (shell), xdg-toplevel (Settings), ext-session-lock (lock),
  pointer + keyboard (xkbcommon), cursor-shape, clipboard (wl_data_device), fractional
  scale, ext-background-effect (real blur from the compositor).
* Event loop: poll() over Wayland, timers (timerfd), D-Bus, child processes, inotify.
* Offscreen backend: renders any widget tree to PNG — used to check every screen.

## Shell services (C++)

Config (settings.json, inotify) · compositor IPC ($NOVA_SOCK) · D-Bus via sd-bus:
notifications server, MPRIS, UPower, NetworkManager, StatusNotifierItem tray, BlueZ,
power profiles, logind · audio (wpctl / pactl subscribe) · brightness (brightnessctl) ·
toplevels (wlr-foreign-toplevel) · desktop entries + icon theme lookup · idle
(ext-idle-notify) · cava (raw output) · lyrics (nova-lyrics) · clipboard (cliphist) ·
recorder (nova-record) · replay · game mode.

## Status (0.1.0)

Everything below is ported. Compiled and linked in the sandbox against the real headers;
the cards were rendered offscreen and checked. First run on real hardware is pending.

## Feature parity checklist (from the QML shell and Settings)

Shell
- [x] Panel: launcher button, pinned + running apps (focus / minimise / launch), clipboard,
      capture countdown, lock-key pill, tray (menus), status pill (net, volume, battery),
      clock pill (music bars / visualizer, recording stop, notification badge), blur
- [x] Launcher (8×10 grid): search apps (name-first ranking), files (fd), run, settings
      pages, calculator (qalc), web / Software fallback, favourites, list/grid view,
      user + uptime, settings / lock / power menu, games on dGPU + GameMode + MangoHud
- [x] Control centre (8×10): tiles (Wi-Fi, Bluetooth, brightness, volume, mic, DND, night
      light, airplane, dark mode, mic mute, screenshot, caffeine, record, hotspot, keyboard
      light, power mode), edit mode (drag, resize, remove, add)
- [x] Calendar + notification centre (grid sized), DND toggle, grouped history
- [x] Notification pop-ups (placement, stacking, timeout, actions, auto-DND when fullscreen,
      missed count)
- [x] Now playing (clock hover 1.5 s, player switch, art, seek, controls, lyrics tab,
      visualizer)
- [x] OSDs: volume / brightness / mic / keyboard light, caps / num lock, power mode, small
      messages — placement, direction, size, timeout, screen
- [x] Lock screen (glance + auth stages, PAM, caps-lock hint, media, battery, network,
      notification count)
- [x] Clipboard history (cliphist, search, delete, keep across reboots)
- [x] Capture bar (screenshot / record, region / window / screen, delay + countdown, draw,
      sound, mic)
- [x] Overview (workspaces per monitor, window cards, search, close, minimised list)
- [x] Wallpaper + desktop icons (~/Desktop); video wallpapers (later)
- [x] Game overlay (Super+G)
- [x] Desktop lyrics, desktop visualizer
- [x] Idle: dim / lock / sleep per power source, caffeine, inhibit while fullscreen
- [x] IPC: `novactl dispatch shell <action>` (launcher, controlcentre, notifications,
      clipboard, capture, overview, close, save-replay)

Settings (17 pages, every setting with its own reset)
- [x] For you, Appearance, Connections, Display, Sound, Power, Notifications,
      Popups & indicators, Music & lyrics, Gaming, Windows & tiling, Keyboard,
      Mouse & touchpad, Panel & launcher, Users, Updates (what's new, progress), About
      (selective reset), video trim window

Removed with the rewrite
- Quickshell, qt6-qtdeclarative, qt6-qtmultimedia (unless something else needs them)
