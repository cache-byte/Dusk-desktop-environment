# What's new in Nova

Each version lists what changed. The updater shows the entries newer than what you have.

## 0.2.1
- Fixed: 0.2.0 didn't build on Fedora 45 (the compositor was missing a header newer compilers need)

## 0.2.0
Fixes
- The mouse button no longer gets "stuck": a drag keeps going to the app you pressed in until you let go
- Lock screen: the first letter you type (a Shift-ed capital) is no longer lost, and Caps / Num Lock don't reset the screen or clear your password
- Games that make a borderless window the size of the screen (Wine / Proton, Heroic) now go properly fullscreen, above the panel
- Steam starts again (error 0x3008): game launchers no longer run on the NVIDIA GPU themselves; their games still do
- Settings no longer freezes when changing pages (fonts are listed once, in the background), and a new font shows at once
- The capture tool works like GNOME's: the screen freezes, pick a selection, a screen or a window, photo or video. Works over the overview and pop-ups too
- Clipboard history shows pictures
- Launcher grid columns line up; nothing is pinned to the launcher or panel by default
- Now Playing: no more giant circles; the visualizer ignores broken frames, and lyrics without timing are shown
- Scroll bars always sit on top, and you can drag them or click the track
- Volume and brightness keys move in exact 5 % steps
Overview & windows
- Windows show their real content in the overview and in the workspace previews
- Workspaces are no longer dynamic: you choose how many (+ in the overview, x to remove; Settings > Windows & tiling)
- Tiling per workspace (Super+T or the grid button on a workspace in the overview): a main window and a stack. Super+Shift+Space floats a window, Super+Shift+Enter makes it the main one
Panel & desktop
- Customise the panel: what it shows and in which order, top or bottom, which monitors, its height; add more panels (Settings > Panel & launcher)
- Right-click menus on the panel, app buttons (pin, new window, close), the clock, the status icons, the desktop (new folder, terminal, wallpaper…) and desktop icons (open, open with, rename, trash…)
- Hover anything for 1.5 s for a tooltip
- The media button only shows while something plays
- Steam games and Wine apps get their own icons on the panel; X11 tray icons show when xembedsniproxy is installed
- Startup apps (Settings > Panel & launcher)
Control centre
- Right-click a tile, or click its arrow, for its options right there: Wi-Fi networks (with password), Bluetooth devices, sound output and microphone, power mode, night light warmth
- The power mode selector has three equal parts and fits in three cells
Settings
- "For you" is gone; the health check is at the bottom of Updates, runs when you ask, and its output can be copied
- Font lists are searchable and show each font in its own face
- Keyboard shortcuts can open apps, and vendor keys with no name on Linux (like OMEN) can be mapped
- A fuller Users page: your name, account details, storage
Look
- GTK 3, GTK 4 / libadwaita, Flatpak and Qt apps use your accent colour, and switch light / dark together
- Volume, brightness and mic indicators sit at the bottom centre; small messages bottom left (if you never moved them)
- Notification history, kept between restarts (Notifications > History)

## 0.1.6
- Fixed: the desktop resetting (wallpaper and panel vanishing for a moment) while using the launcher or doing things quickly. A text field's blinking cursor kept running after the launcher or overview closed and wrote into freed memory, which crashed the shell a moment later
- Fixed: closing a pop-up while it was still drawing could crash the shell
- Overview fixed: window cards show again (they failed to load whenever a window was open), and the close buttons no longer cover whole cards and workspaces
- Overview: drag a window onto a workspace, or onto +, to move it there
- Overview: workspace previews show where each window is, with its app icon
- The overview fits smaller and scaled screens

## 0.1.5
- Pop-ups (launcher, control centre, notifications…) close as soon as you click anywhere else, and that click still reaches what you clicked
- Fixed: typing in the launcher search could crash the shell
- The control centre and the clock's notification centre use a 6-column grid; your control centre layout is moved to the new grid once
- Now Playing is separate from the clock: a small visualizer button on the panel while music plays — click it to open Now Playing (Settings → Panel & launcher → Media button)
- Hot corner: touching the top-left corner opens the overview (Settings → Panel & launcher → Top-left hot corner: overview, launcher, control centre, notifications or nothing)
- Settings can be resized from any edge or corner
- Opening Settings again brings the open window forward (on the requested page) instead of starting a second one
- Pop-ups never grow past the screen; the launcher and capture bar fit small or scaled screens (the capture bar shows icons only when space is short)
- Qt apps (including the password prompt for admin actions) get Nova's dark title bar instead of a light one
- Fixed: the installer said "Nova 45 is installed" (the Fedora version) instead of Nova's version

## 0.1.4
- Fixed: 0.1.3 didn't build (the compositor couldn't link its title bars)
- Drawing on screenshots uses Swappy when Fedora has no Satty (Satty isn't on Flathub, so that step always failed)

## 0.1.3
- Title bars with minimise, maximise and close for apps that don't draw their own (Heroic and other Electron apps, Qt apps, X11 apps); drag to move, double-click to maximise
- Rounded window corners (with SceneFX) and rounded screen corners (Settings → Appearance → Screen corners)
- A window's title bar can't be dragged under the panel or above the top of the screen
- The shell keeps running when it meets something unexpected, and writes crash reports to ~/.cache/nova/nova-shell.log (nova-doctor shows them)
- Fixed: the control centre layout could be reset every time the shell started

## 0.1.2
- Fixed: updates from Settings said "The update didn't finish" even when Nova was installed
- Settings: what's behind the window is blurred now instead of showing through sharp
- Lighter blur in the compositor (two passes at most) for less lag when windows move over the panel and pop-ups

## 0.1.1
- Fixed: clicking outside a pop-up, picking something in the launcher or opening an app crashed the shell (the desktop flashed and came back)
- Much less lag: each widget is measured once per layout instead of many times, and text sizes are remembered
- The panel no longer rebuilds when a window's title changes (browsers and players change it constantly)
- Music bars and the visualizer redraw less often
- Settings → Popups & indicators: the preview is gone

## 0.1.0
- The shell and Settings are rewritten in C++ and no longer use Quickshell or Qt: much less memory and CPU
- The compositor and the shell are separate programs; if the shell crashes, Nova restarts it
- `nova-shell` commands for scripts: `nova-shell toggle launcher`, `nova-shell toast "Copied" clip`, `nova-shell lock`
- Pop-ups size themselves to their card and close when you click anywhere else
- Control centre edit mode: drag tiles, resize from the corner, remove, add from the drawer
- Video wallpapers play with mpvpaper; the recording trimmer previews in mpv
- Settings: every page rebuilt with the same look; picking a file or colour uses the system dialog (zenity)
- nova-doctor shows how much memory the shell uses

## 0.0.20
- Workspaces slide when you switch; swiping never goes to a workspace that doesn't exist
- Maximized windows fill the screen edge to edge; new windows always open above the panel
- Less flicker in Chromium / Electron apps (Vivaldi, VS Code) on NVIDIA: explicit sync
- Shorter panel, now with blur behind it
- Blur and transparency default to 80 % everywhere, including Settings
- Now playing opens after resting on the clock for 1.5 s, sits right above it, and stays while you move onto it
- Launcher, calendar and control centre share one 6 × 10 grid; app search ranks names first
- Capture bar: 3 / 5 / 10 s delay so menus and pop-ups can be captured, countdown on the panel
- Drawing on screenshots: Satty from Flathub when Fedora doesn't have it; the calculator (qalc) is installed

## 0.0.19
- Fixed: opening any app window crashed Nova (an xdg-shell version check inside wlroots)
- Fixed: a binding loop in the pop-up layer and a layout warning in the launcher
- nova-doctor recognises the running shell more reliably

## 0.0.18
- Password prompts: Nova finds whichever polkit agent is installed
- Power profiles work with Fedora's tuned-ppd (no powerprofilesctl needed)
- nova-doctor shows the shell's last errors when the shell isn't running

## 0.0.17
- Fixed: clicking the panel or using a shortcut crashed Nova and logged you out (shell menus and pop-ups)
- Nova now uses the login screen you already have; the SDDM theme is gone and an earlier switch to SDDM is undone
- Screens start at 100 % scale unless they are very high resolution (1080p laptops were at 150 %)
- Closed windows no longer leave an empty scene node behind

## 0.0.16
- Fixed: the shell still didn't start (a property used a reserved word)
- The installer always sets up the Nova login screen (no more question)

## 0.0.15
- Fixed: the shell didn't start (black screen) — the battery indicator used a Qt feature that doesn't exist
- Fixed: the lock screen's wrong-password shake
- Idle dimming, locking and sleep work with older Quickshell versions too
- Password prompts for admin apps and the updater now work (Nova starts a polkit agent)
- Every QML file is now checked against the real Qt and Quickshell sources before release

## 0.0.14
- Fixed: the login screen theme and parts of the shell didn't load (text sizes must be whole numbers)

## 0.0.13
- Fixed: a black screen when an older, different "Nova" left its settings behind; the installer moves them aside
- The compositor always starts the shell, even if your config doesn't list it

## 0.0.12
- Fixed: the compositor didn't build with wlroots 0.19 (Fedora 43-45); it now builds against 0.19 and 0.20
- Fixed: one conflicting package (like RPM Fusion's ffmpeg) no longer stops all the optional extras installing
- The installer no longer shows errors for packages it simply looks for elsewhere (SongRec, Quickshell, the recorder)

## 0.0.11
- Nova now ships two wallpapers: a teal dark one and a lilac light one, picked by the theme
- The older wave and gaming wallpapers are gone; if you used one, Nova switches back to the default

## 0.0.10
- Settings → Updates shows what's new before you update, and after
- The terminal updater shows what's new too
- Three gaming wallpapers: Neon Waves, Arcade Waves and Game Dawn Waves

## 0.0.9
- New look for the installer, updater and uninstaller in the terminal: steps, spinners, a summary box
- Update from inside Settings with a progress bar and one password prompt
- Logs of every install, shown when something fails

## 0.0.8
- The lock and login screens no longer show lock-key chips in the password box
- Control centre is a 6 × 10 grid; empty rows are hidden

## 0.0.7
- The Settings sidebar scrolls instead of running off small windows

## 0.0.6
- Only the three wave wallpapers are bundled

## 0.0.5
- New default wallpapers: Dusk Waves (dark) and Dawn Blue Waves (light), plus Dawn Waves

## 0.0.4
- Fixes for reinstalling, updating and uninstalling
- Display settings are remembered between logins; HiDPI screens get a sensible scale
- Qt apps get title bars; touchpad settings apply right away; Settings no longer freezes while checking

## 0.0.3
- The light-mode wallpaper and a set of Nova wallpapers that follow light and dark mode

## 0.0.2
- Capture bar (Print), trim recordings, game overlay (Super+G), shortcut editor, blurred glass panels

## 0.0.1
- First version: compositor, shell, Settings, installer, updater and uninstaller
