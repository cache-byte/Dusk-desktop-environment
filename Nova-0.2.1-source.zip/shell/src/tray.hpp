// System tray: StatusNotifierItem (KDE/freedesktop) with dbusmenu menus.
// Nova runs the watcher itself when nothing else does, and is the host.
#pragma once
#include "config.hpp"
#include "ui/paint.hpp"

namespace nova {

struct TrayMenuItem {
    int id = 0;
    std::string label, icon, type, toggleType;
    bool enabled = true, visible = true, checked = false;
    std::vector<TrayMenuItem> children;
};

struct TrayItem {
    std::string service, path;          // where the item lives on the bus
    std::string id, title, status, iconName, iconThemePath, menuPath;
    bool itemIsMenu = false;
    std::shared_ptr<ui::Image> pixmap;  // IconPixmap when there is no icon name
    void activate(int x, int y);
    void secondaryActivate(int x, int y);
    void scroll(int delta, bool vertical);
    void menu(std::function<void(const TrayMenuItem &root)> cb);
    void menuClicked(int id);
};

class Tray {
public:
    static Tray &get();
    void start();
    std::vector<TrayItem> items;
    ui::Signal<> changed;
    // watcher side (D-Bus vtable callbacks)
    void registerItem(const std::string &sender, const std::string &serviceOrPath);
    std::vector<std::string> registered() const;
private:
    bool ownWatcher_ = false;
    void addItem(const std::string &service, const std::string &path);
    void removeService(const std::string &service);
    void load(TrayItem &it);
};

}  // namespace nova
