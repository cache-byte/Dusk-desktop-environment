// The shell's view of the system: audio, brightness, network, battery, Bluetooth, power
// profiles, media players, lyrics, the visualizer, game mode, instant replay, recording.
// Each one is a singleton that keeps its state up to date and emits `changed`.
#pragma once
#include "config.hpp"
#include "ui/paint.hpp"
#include "ui/sys.hpp"
#include "dbus.hpp"

namespace nova {

// ---------------------------------------------------------------- audio --
class Audio {
public:
    static Audio &get();
    void start();
    double volume = 0, micVolume = 0;
    bool muted = false, micMuted = false, ready = false;
    double maxVolume() const { return cfg().b("allowOverAmplify", false) ? 1.5 : 1.0; }
    void setVolume(double v);
    void setMicVolume(double v);
    void toggleMute();
    void toggleMic();
    ui::Signal<std::string> changed;   // "volume" / "mic": drives the OSD
private:
    std::shared_ptr<ui::Process> sub_;
    int debounce_ = 0;
    void refresh(bool notify);
};

// ------------------------------------------------------------- brightness --
class Brightness {
public:
    static Brightness &get();
    void start();
    bool available() const { return !device_.empty(); }
    double value = 0;
    void set(double v);
    // keyboard backlight (0..max steps); available when kbdMax > 0
    int kbdLevel = 0, kbdMax = 0;
    void setKbd(int level);
    ui::Signal<> changed;
    ui::Signal<> kbdChanged;
private:
    std::string device_, kbdDevice_;
    int max_ = 1, cur_ = -1;
    void poll();
};

// ---------------------------------------------------------------- network --
class Net {
public:
    static Net &get();
    void start();
    bool wifiEnabled = true, wired = false, airplane = false;
    std::string ssid;
    int signal = 0;
    void setWifi(bool on);
    void setAirplane(bool on);
    void refresh();
    ui::Signal<> changed;
private:
    std::shared_ptr<ui::Process> monitor_;
    int debounce_ = 0;
};

// --------------------------------------------------------------- battery --
class Battery {
public:
    static Battery &get();
    void start();
    bool present = false, onBattery = false, charging = false, full = false;
    double percentage = 0;           // 0..100
    int64_t timeToEmpty = 0, timeToFull = 0;   // seconds
    ui::Signal<> changed;
private:
    void load();
};

// ------------------------------------------------------------- bluetooth --
class Bluetooth {
public:
    static Bluetooth &get();
    void start();
    bool available = false, powered = false;
    std::string connectedName;        // first connected device
    void setPowered(bool on);
    ui::Signal<> changed;
private:
    std::string adapter_;
    void load();
};

// --------------------------------------------------------- power profiles --
class Power {
public:
    static Power &get();
    void start();
    std::string profile = "balanced";   // power-saver | balanced | performance
    bool available = false;
    void set(const std::string &p);
    void refresh();
    ui::Signal<> changed;
};

// ------------------------------------------------------------------ media --
struct Player {
    std::string bus;                   // org.mpris.MediaPlayer2.spotify
    std::string identity;
    bool playing = false, canSeek = false, canNext = true, canPrev = true;
    std::string title, artist, album, artUrl, url, trackId;
    double length = 0;                 // seconds
    double position = 0;               // seconds, at positionAt
    int64_t positionAt = 0;
    double positionNow() const;
};

class Media {
public:
    static Media &get();
    void start();
    std::vector<Player> players;
    Player *player();                  // the one the controls drive
    bool playing() { Player *p = player(); return p && p->playing; }
    void choose(const std::string &bus) { chosen_ = bus; changed.emit(); }
    void playPause();
    void next();
    void previous();
    void seek(double seconds);
    std::shared_ptr<ui::Image> art;    // album art of the current player (loaded async)
    static std::string fmt(double sec);
    ui::Signal<> changed;
private:
    std::string last_, chosen_, artFor_;
    void addPlayer(const std::string &bus);
    void removePlayer(const std::string &bus);
    void loadProps(const std::string &bus);
    void parseProps(Player &p, sd_bus_message *m);
    void loadArt();
    void positionTick();
};

// ----------------------------------------------------------------- lyrics --
class Lyrics {
public:
    static Lyrics &get();
    void start();
    std::vector<std::pair<double, std::string>> lines;   // [seconds, text]
    std::string plain, source;
    bool loading = false;
    bool synced() const { return !lines.empty(); }
    int current() const;               // index being sung (-1 before the first line)
    double progress() const;           // 0..1 through the current line
    std::string line(int i) const { return i >= 0 && i < (int)lines.size() ? lines[i].second : ""; }
    bool wanted() const { return cfg().b("lyricsNowPlaying", true) || cfg().b("lyricsDesktop", false); }
    ui::Signal<> changed;
private:
    std::string key_;
    int timer_ = 0;
    void check();
    void load();
};

// -------------------------------------------------------------- visualizer --
class Cava {
public:
    static Cava &get();
    void use(int delta);               // visualizers on screen register themselves
    std::vector<double> values;        // 0..1 per bar
    ui::Signal<> frame;
private:
    int users_ = 0;
    std::shared_ptr<ui::Process> proc_;
    void restart();
};

// ---------------------------------------------------- recording / replay --
class Recorder {
public:
    static Recorder &get();
    void start();
    bool recording = false;
    void stop() { ui::spawn({"nova-record", "stop"}); }
    ui::Signal<> changed;
};

class Replay {
public:
    static Replay &get();
    void start();
    void save();
    ui::Signal<std::string> saved;
private:
    std::shared_ptr<ui::Process> proc_;
    void apply();
};

class Gaming {
public:
    static Gaming &get();
    void start();
    bool active = false;
    ui::Signal<> changed;
private:
    std::string saved_;
    int timer_ = 0;
    void check();
    void setActive(bool on);
};

}  // namespace nova
