// nova-shell: shared state (which pop-up is open, where) and one Screen per monitor
// holding that monitor's panel, wallpaper and pop-up windows.
#pragma once
#include "config.hpp"
#include "ui/wayland.hpp"

namespace nova {

class Screen;

class Shell {
public:
    static Shell &get();
    std::string popout;                 // launcher | controlcentre | notifications | clipboard | capture | gameoverlay
    std::string popoutOutput;           // monitor it belongs to (empty = first)
    bool overview = false;
    bool ccEditing = false;
    int countdown = 0;                  // capture delay, shown on the panel
    // Now playing opens above the music pill on the panel (distance from the screen's right edge)
    double mediaRightGap = 200;

    bool isPopoutScreen(const std::string &output) const;
    void toggle(const std::string &name, const std::string &output = "");
    void close();
    void action(const std::string &a);  // compositor shell actions (Super, Print, Super+Tab…)
    void captureCountdown(int s);
    std::vector<std::unique_ptr<Screen>> screens;
    Screen *screenFor(const std::string &output);
    ui::Signal<> changed;
private:
    ui::Timer countTimer_;
    Shell();
};

inline Shell &shell() { return Shell::get(); }

// Placement from Settings > Popups & indicators: pos 0..8 on a 3×3 grid, nudge dx / dy
struct Placement {
    uint32_t anchors = 0;
    int mt = 0, mr = 0, mb = 0, ml = 0;
    bool vertical = false;
};
// "Show on" for indicators: the monitor under the pointer, or every monitor
bool indicatorOnScreen(const std::string &output);
Placement placementFor(const json &osd, double panelHeight, int edge = 20);

// window types used by several modules
class Panel;
class Wallpaper;
class PopoutWindow;
class NotificationsWindow;
class Osd;
class OverviewWindow;
class DesktopLyricsWindow;
class DesktopVisualizerWindow;

class Screen {
public:
    explicit Screen(ui::Output *o);
    ~Screen();
    ui::Output *output;
    std::string name() const { return output ? output->name : ""; }
    std::unique_ptr<Wallpaper> wallpaper;
    std::vector<std::unique_ptr<Panel>> panels;   // one or more, as set in Settings
    std::string panelsSig_;
    void syncPanels();
    std::unique_ptr<PopoutWindow> popout;
    std::unique_ptr<NotificationsWindow> notifications;
    std::unique_ptr<Osd> osd;
    std::unique_ptr<OverviewWindow> overview;
    std::unique_ptr<DesktopLyricsWindow> lyrics;
    std::unique_ptr<DesktopVisualizerWindow> visualizer;
    std::vector<std::unique_ptr<ui::LayerWindow>> corners;   // rounded screen corners
    void syncCorners();
    std::unique_ptr<ui::LayerWindow> hotCorner;               // top-left hot corner
    void syncHotCorner();
    void sync();          // show / hide windows to match Shell state
};

}  // namespace nova
