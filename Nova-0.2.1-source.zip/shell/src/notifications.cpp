#include <filesystem>
#include "notifications.hpp"
#include "dbus.hpp"
#include "novaipc.hpp"

#include <cairo.h>
#include <chrono>

namespace nova {

Notifications &Notifications::get() {
    static Notifications n;
    return n;
}

bool Notifications::quiet() const {
    return cfg().b("dnd", false) || (cfg().b("autoDnd", true) && ipc().fullscreen);
}

// ---- image-data hint: (iiibiiay) width, height, rowstride, has_alpha, bits, channels, data ----
static std::shared_ptr<ui::Image> readImageData(sd_bus_message *m) {
    if (sd_bus_message_enter_container(m, 'v', "(iiibiiay)") < 0) { skipVariant(m); return nullptr; }
    int32_t w, h, stride, bits, ch;
    int alpha;
    const void *data = nullptr;
    size_t size = 0;
    std::shared_ptr<ui::Image> out;
    if (sd_bus_message_enter_container(m, 'r', "iiibiiay") >= 0 &&
        sd_bus_message_read(m, "iiibii", &w, &h, &stride, &alpha, &bits, &ch) >= 0 &&
        sd_bus_message_read_array(m, 'y', &data, &size) >= 0 && w > 0 && h > 0 && (size_t)stride * h <= size) {
        cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, w, h);
        unsigned char *d = cairo_image_surface_get_data(s);
        int ds = cairo_image_surface_get_stride(s);
        const unsigned char *src = (const unsigned char *)data;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                const unsigned char *p = src + y * stride + x * ch;
                uint32_t a = alpha && ch >= 4 ? p[3] : 255;
                uint32_t r = p[0] * a / 255, g = p[1] * a / 255, b = p[2] * a / 255;
                *(uint32_t *)(d + y * ds + x * 4) = (a << 24) | (r << 16) | (g << 8) | b;
            }
        cairo_surface_mark_dirty(s);
        out = std::make_shared<ui::Image>(ui::Image::fromSurface(s));
        sd_bus_message_exit_container(m);
    }
    sd_bus_message_exit_container(m);
    return out;
}

// ---- D-Bus vtable ----
static int m_getCaps(sd_bus_message *m, void *, sd_bus_error *) {
    sd_bus_message *r = nullptr;
    sd_bus_message_new_method_return(m, &r);
    sd_bus_message_open_container(r, 'a', "s");
    for (const char *c : {"actions", "body", "body-markup", "body-hyperlinks", "icon-static", "persistence", "action-icons"})
        sd_bus_message_append(r, "s", c);
    sd_bus_message_close_container(r);
    int ret = sd_bus_send(nullptr, r, nullptr);
    sd_bus_message_unref(r);
    return ret;
}
static int m_serverInfo(sd_bus_message *m, void *, sd_bus_error *) {
    return sd_bus_reply_method_return(m, "ssss", "Nova", "Nova", "1.0", "1.2");
}
static int m_close(sd_bus_message *m, void *, sd_bus_error *) {
    uint32_t id = 0;
    sd_bus_message_read(m, "u", &id);
    Notifications::get().closeFromClient(id);
    return sd_bus_reply_method_return(m, "");
}
static int m_notify(sd_bus_message *m, void *, sd_bus_error *) {
    const char *app = "", *icon = "", *summary = "", *body = "";
    uint32_t replaces = 0;
    int32_t timeout = -1;
    Notification n;
    sd_bus_message_read(m, "susss", &app, &replaces, &icon, &summary, &body);
    n.app = app ? app : "";
    n.appIcon = icon ? icon : "";
    n.summary = summary ? summary : "";
    n.body = body ? body : "";
    // actions: [key, label, key, label…]
    if (sd_bus_message_enter_container(m, 'a', "s") >= 0) {
        const char *s;
        std::vector<std::string> a;
        while (sd_bus_message_read(m, "s", &s) > 0) a.push_back(s);
        sd_bus_message_exit_container(m);
        for (size_t i = 0; i + 1 < a.size(); i += 2) n.actions.push_back({a[i], a[i + 1]});
    }
    forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
        if (k == "urgency") n.urgency = (int)readVariantNumber(v);
        else if (k == "category") n.category = readVariantString(v);
        else if (k == "desktop-entry") n.desktopEntry = readVariantString(v);
        else if (k == "resident") n.resident = readVariantBool(v);
        else if (k == "transient") n.transient = readVariantBool(v);
        else if (k == "image-data" || k == "image_data" || k == "icon_data") { auto img = readImageData(v); if (img) n.image = img; }
        else if (k == "image-path" || k == "image_path") {
            std::string p = readVariantString(v);
            if (ui::startsWith(p, "file://")) p = p.substr(7);
            if (!p.empty() && p[0] == '/') n.image = std::make_shared<ui::Image>(p, 256, 256);
            else if (!p.empty() && n.appIcon.empty()) n.appIcon = p;
        } else skipVariant(v);
    });
    sd_bus_message_read(m, "i", &timeout);
    n.timeoutMs = timeout;
    uint32_t id = Notifications::get().notify(std::move(n), replaces);
    return sd_bus_reply_method_return(m, "u", id);
}
static const sd_bus_vtable vtable[] = {
    SD_BUS_VTABLE_START(0),
    SD_BUS_METHOD("GetCapabilities", "", "as", m_getCaps, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("Notify", "susssasa{sv}i", "u", m_notify, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("CloseNotification", "u", "", m_close, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("GetServerInformation", "", "ssss", m_serverInfo, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_SIGNAL("NotificationClosed", "uu", 0),
    SD_BUS_SIGNAL("ActionInvoked", "us", 0),
    SD_BUS_SIGNAL("ActivationToken", "us", 0),
    SD_BUS_VTABLE_END,
};

static std::string historyPath() { return ui::homeDir() + "/.local/state/nova/notification-history.json"; }
void Notifications::start() {
    // history from earlier sessions
    try {
        json a = json::parse(ui::readFile(historyPath()));
        if (a.is_array())
            for (auto &x : a)
                if (x.is_object())
                    history.push_back({x.value("app", ""), x.value("icon", ""), x.value("summary", ""), x.value("body", ""), x.value("time", (int64_t)0)});
    } catch (...) {}
    Bus &b = Bus::session();
    if (!b) return;
    sd_bus_add_object_vtable(b.bus(), nullptr, "/org/freedesktop/Notifications", "org.freedesktop.Notifications", vtable, this);
    if (!b.requestName("org.freedesktop.Notifications"))
        fprintf(stderr, "nova-shell: another notification server is running (GNOME?); Nova's pop-ups stay quiet\n");
    // tell the user what they missed once the game / video ends
    ipc().fullscreenChanged.connect([this](bool fs) {
        if (!fs && missed > 0) {
            int m = missed;
            missed = 0;
            missedSummary.emit(m);
            changed.emit();
        }
    });
}

uint32_t Notifications::notify(Notification n, uint32_t replaces) {
    n.time = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    if (replaces) {
        for (auto &x : all_)
            if (x.id == replaces) {
                n.id = replaces;
                x = std::move(n);
                changed.emit();
                return replaces;
            }
    }
    n.id = next_++;
    uint32_t id = n.id;
    bool critical = n.urgency == 2;
    bool transient = n.transient;
    all_.push_back(std::move(n));
    if (all_.size() > 200) all_.erase(all_.begin());   // history limit
    if (!quiet() || critical) {
        popups.insert(popups.begin(), id);
        if (popups.size() > 4) popups.resize(4);
        const Notification &nn = all_.back();
        if (nn.urgency != 2) {
            int ms = nn.timeoutMs > 0 ? nn.timeoutMs : cfg().i("notificationTimeout", 5000);
            due_[id] = ui::nowMs() + ms;
            if (!expiryTimer_) expiryTimer_ = ui::Loop::get().addTimer(250, [this] { checkExpiry(); }, true);
        }
    } else if (!cfg().b("dnd", false)) missed++;
    if (transient && quiet() && !critical) dismiss(id, 1);
    changed.emit();
    return id;
}

const Notification *Notifications::find(uint32_t id) const {
    for (auto &n : all_) if (n.id == id) return &n;
    return nullptr;
}
void Notifications::emitClosed(uint32_t id, uint32_t reason) {
    Bus &b = Bus::session();
    if (b) sd_bus_emit_signal(b.bus(), "/org/freedesktop/Notifications", "org.freedesktop.Notifications", "NotificationClosed", "uu", id, reason);
}
static void saveHistory(const std::vector<PastNotification> &h) {
    json a = json::array();
    for (auto &n : h) a.push_back({{"app", n.app}, {"icon", n.appIcon}, {"summary", n.summary}, {"body", n.body}, {"time", n.time}});
    std::error_code ec;
    std::filesystem::create_directories(ui::homeDir() + "/.local/state/nova", ec);
    ui::writeFile(historyPath(), a.dump());
}
static void remember(std::vector<PastNotification> &h, const Notification &n) {
    if (n.transient || (n.summary.empty() && n.body.empty())) return;
    h.insert(h.begin(), {n.app, n.appIcon, n.summary, n.body, n.time});
    if (h.size() > 150) h.resize(150);
}
void Notifications::clearHistory() {
    history.clear();
    saveHistory(history);
    changed.emit();
}
void Notifications::dismiss(uint32_t id, uint32_t reason) {
    if (const Notification *n = find(id)) { remember(history, *n); saveHistory(history); }
    bool had = std::erase_if(all_, [id](const Notification &n) { return n.id == id; }) > 0;
    std::erase(popups, id);
    if (had) emitClosed(id, reason);
    changed.emit();
}
void Notifications::holdPopups(bool hold) {
    if (hold == held_) return;
    held_ = hold;
    // after the pointer leaves, the toasts get a little more time
    if (!hold) for (auto &[id, due] : due_) due = std::max(due, ui::nowMs() + 2000);
}
void Notifications::checkExpiry() {
    std::erase_if(due_, [this](auto &kv) { return std::find(popups.begin(), popups.end(), kv.first) == popups.end(); });
    if (due_.empty()) { ui::Loop::get().removeTimer(expiryTimer_); expiryTimer_ = 0; return; }
    if (held_) return;
    int64_t now = ui::nowMs();
    std::vector<uint32_t> gone;
    for (auto &[id, due] : due_) if (due <= now) gone.push_back(id);
    for (auto id : gone) { due_.erase(id); std::erase(popups, id); }
    if (!gone.empty()) changed.emit();
}
void Notifications::dismissPopup(uint32_t id) {
    // the toast goes; the notification stays in the history (expired = 1 for the app)
    std::erase(popups, id);
    changed.emit();
}
void Notifications::invoke(uint32_t id, const std::string &action) {
    Bus &b = Bus::session();
    if (b) sd_bus_emit_signal(b.bus(), "/org/freedesktop/Notifications", "org.freedesktop.Notifications", "ActionInvoked", "us", id, action.c_str());
    const Notification *n = find(id);
    if (!n || !n->resident) dismiss(id, 2);
}
void Notifications::clearAll() {
    auto ids = std::vector<uint32_t>();
    for (auto &n : all_) { ids.push_back(n.id); remember(history, n); }
    saveHistory(history);
    all_.clear();
    popups.clear();
    for (auto id : ids) emitClosed(id, 2);
    changed.emit();
}

std::vector<NotifGroup> Notifications::groups() const {
    std::vector<NotifGroup> out;
    bool group = cfg().b("groupNotifications", true);
    for (auto it = all_.rbegin(); it != all_.rend(); ++it) {
        const Notification &n = *it;
        if (!group) { out.push_back({std::to_string(n.id), n.app.empty() ? "System" : n.app, n.appIcon, {&n}}); continue; }
        std::string k = (n.app.empty() ? "System" : n.app) + "|" + n.category.substr(0, n.category.find('.'));
        auto g = std::find_if(out.begin(), out.end(), [&](const NotifGroup &x) { return x.key == k; });
        if (g == out.end()) out.push_back({k, n.app.empty() ? "System" : n.app, n.appIcon, {&n}});
        else g->items.push_back(&n);
    }
    return out;
}

}  // namespace nova
