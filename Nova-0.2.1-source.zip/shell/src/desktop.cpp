// Lyrics and the beat visualizer on the desktop (Bottom layer: under windows, clicks go through).
#include "novaipc.hpp"
#include "services.hpp"
#include "windows.hpp"

namespace nova {

using namespace ui;

// ================================================================ lyrics ==
DesktopLyricsWindow::DesktopLyricsWindow(Screen *s) : FitWindow("nova-lyrics", Layer::Bottom, s->output, 0), screen(s) {
    clickThrough = true;
    wantBlur = false;
    Size scr = s->output ? s->output->logical() : Size{1920, 1080};
    json o = cfg().osd("lyrics");
    auto *lv = root()->add<LyricsView>();
    lv->fixedW = std::min(scr.w * 0.6, 1100.0);
    lv->fixedH = 230;
    lv->center = o.value("dir", std::string("centre")) != "left";
    lv->textColor = Color{1, 1, 1, 1};
    lv->shadowText = true;
    Placement pl = placementFor(o, theme().panelHeight);
    place(pl.anchors, pl.mt, pl.mr, pl.mb, pl.ml);
    fit();
    conns_.on(Media::get().changed, [this] { refresh(); });
    conns_.on(Lyrics::get().changed, [this] { refresh(); });
    conns_.on(ipc().fullscreenChanged, [this](bool) { refresh(); });
    conns_.on(ipc().activeOutputChanged, [this](const std::string &) { refresh(); });
    refresh();
}
DesktopLyricsWindow::~DesktopLyricsWindow() = default;

void DesktopLyricsWindow::refresh() {
    // only on the monitor in use
    Screen *primary = shell().screenFor(ipc().activeOutput);
    bool want = Media::get().playing() && Lyrics::get().synced() && primary == screen &&
                !(cfg().b("lyricsHideFullscreen", true) && ipc().fullscreen);
    if (want && !shown()) show();
    else if (!want && shown()) hide();
}

// ============================================================ visualizer ==
class DesktopViz : public Box {
public:
    Connections conns;
    DesktopViz() : Box(Dir::Column, 12) {
        auto *v = add<Visualizer>();
        v->grow = 1;
        v->opacityK = cfg().d("vizDesktopOpacity", 0.85);
        if (cfg().b("vizDesktopTitle", false)) {
            auto *title = add<Label>("", 30, Weight::Bold);
            title->role = Role::Custom;
            title->color = Color{1, 1, 1, 1};
            title->hAlign = Align::Center;
            auto *artist = add<Label>("", 16, Weight::Normal, Role::AccentBright);
            artist->hAlign = Align::Center;
            auto upd = [title, artist] {
                Player *p = Media::get().player();
                title->setText(p ? p->title : "");
                artist->setText(p ? p->artist : "");
            };
            upd();
            conns.on(Media::get().changed, upd);
        }
    }
};

DesktopVisualizerWindow::DesktopVisualizerWindow(Screen *s) : LayerWindow("nova-visualizer", Layer::Bottom, s->output), screen(s) {
    wantBlur = false;
    setExclusiveZone(-1);
    setInputRegion({});
    std::string pos = cfg().s("vizDesktopPos", "bottom");
    json o = cfg().osd("visualizer");
    int ph = (int)theme().panelHeight;
    if (pos == "custom") {
        Placement pl = placementFor(o, ph);
        setAnchors(pl.anchors);
        setMargins(pl.mt, pl.mr, pl.mb, pl.ml);
        setRequestedSize(900, 280);
    } else if (pos == "centre") {
        setRequestedSize(900, 280);
    } else if (pos == "top") {
        setAnchors(AnchorTop | AnchorLeft | AnchorRight);
        setMargins(8, 0, 0, 0);
        setRequestedSize(0, 170);
    } else {
        setAnchors(AnchorBottom | AnchorLeft | AnchorRight);
        setMargins(0, 0, ph + 8, 0);
        setRequestedSize(0, 170);
    }
    setRoot<DesktopViz>();
    auto refresh = [this] {
        bool want = Media::get().playing() && !ipc().fullscreen;
        if (want && !shown()) show();
        else if (!want && shown()) hide();
    };
    conns_.on(Media::get().changed, refresh);
    conns_.on(ipc().fullscreenChanged, [refresh](bool) { refresh(); });
    refresh();
}
DesktopVisualizerWindow::~DesktopVisualizerWindow() = default;

}  // namespace nova
