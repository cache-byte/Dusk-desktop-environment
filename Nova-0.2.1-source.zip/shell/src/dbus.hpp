// sd-bus on the novaui event loop, plus small helpers for the common calls.
#pragma once
#include "ui/core.hpp"

#include <systemd/sd-bus.h>

#include <variant>

namespace nova {

class Bus {
public:
    static Bus &session();
    static Bus &system();
    sd_bus *bus() const { return bus_; }
    explicit operator bool() const { return bus_ != nullptr; }

    // Async method call; reply is null on error (err holds the message)
    using Reply = std::function<void(sd_bus_message *reply, const std::string &err)>;
    void call(const std::string &dest, const std::string &path, const std::string &iface, const std::string &method,
              Reply cb, std::function<void(sd_bus_message *)> args = {});
    // org.freedesktop.DBus.Properties.Get / GetAll / Set
    void getAll(const std::string &dest, const std::string &path, const std::string &iface,
                std::function<void(sd_bus_message *props)> cb);
    void setProperty(const std::string &dest, const std::string &path, const std::string &iface,
                     const std::string &prop, const char *type, ...);
    // signal subscription; the slot lives until unsubscribe(id)
    int match(const std::string &rule, std::function<void(sd_bus_message *)> cb);
    void unsubscribe(int id);
    // watch a bus name appearing / vanishing (NameOwnerChanged)
    int watchName(const std::string &name, std::function<void(bool present)> cb);
    void listNames(std::function<void(const std::vector<std::string> &)> cb);
    bool requestName(const std::string &name);
    void flushSoon();
private:
    Bus(bool system);
    sd_bus *bus_ = nullptr;
    int watch_ = 0, timer_ = 0;
    struct Slot { int id; sd_bus_slot *slot; std::function<void(sd_bus_message *)> fn; };
    std::vector<std::unique_ptr<Slot>> slots_;
    int next_ = 0;
    void process();
    void updateWatch();
};

// Reading a{sv} property dictionaries: calls fn(name, msg) with msg positioned at the variant
void forEachProperty(sd_bus_message *m, const std::function<void(const std::string &, sd_bus_message *)> &fn);
// read a variant of a basic type (s, b, d, i, u, x, t, o) as string / number / bool
std::string readVariantString(sd_bus_message *m);
double readVariantNumber(sd_bus_message *m);
bool readVariantBool(sd_bus_message *m);
std::vector<std::string> readVariantStrings(sd_bus_message *m);   // "as"
void skipVariant(sd_bus_message *m);

}  // namespace nova
