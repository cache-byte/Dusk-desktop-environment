// Screenshot / screencast UI like GNOME's: the screen is frozen first (so pop-ups and the
// overview can be captured), then a full-screen overlay lets you pick a selection, a whole
// screen or a window, photo or video, and capture. Esc cancels, Enter / Space captures.
#include "novaipc.hpp"
#include "ui/sys.hpp"
#include "windows.hpp"

#include <cairo.h>
#include <ctime>
#include <filesystem>

namespace nova {

using namespace ui;

namespace {

enum class Mode { Selection, Screen, Window };

struct Shared {
    std::shared_ptr<Image> frozen;     // the whole layout, as grim saw it
    double px = 1;                     // image pixels per layout unit
    Mode mode = Mode::Selection;
    bool video = false;
    Rect sel{-1, -1, 0, 0};            // layout coordinates
    std::vector<Rect> windows;         // layout coordinates
    std::vector<std::unique_ptr<LayerWindow>> wins;
    bool active = false;
};
Shared &S() { static Shared s; return s; }
Rect lastSelection{-1, -1, 0, 0};

void finish();

std::string stamp() {
    char b[64];
    time_t t = time(nullptr);
    tm lt;
    localtime_r(&t, &lt);
    strftime(b, sizeof b, "%Y-%m-%d_%H-%M-%S", &lt);
    return b;
}

void capture(Rect r) {
    auto &s = S();
    if (r.w < 4 || r.h < 4) return;
    if (s.video) {
        std::string g = std::to_string((int)r.x) + "," + std::to_string((int)r.y) + " " + std::to_string((int)r.w) + "x" + std::to_string((int)r.h);
        finish();
        // give the overlay a moment to disappear before recording starts
        Loop::get().addTimer(250, [g] { spawn({"nova-record", "start", g}); });
        return;
    }
    // cut the frozen frame: nothing of this overlay ends up in the picture
    std::string dir = homeDir() + "/Pictures/Screenshots";
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    std::string f = dir + "/Screenshot_" + stamp() + ".png";
    if (s.frozen && s.frozen->valid()) {
        int w = (int)std::round(r.w * s.px), h = (int)std::round(r.h * s.px);
        cairo_surface_t *out = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, std::max(1, w), std::max(1, h));
        cairo_t *cr = cairo_create(out);
        cairo_set_source_surface(cr, s.frozen->surface(), -r.x * s.px, -r.y * s.px);
        cairo_paint(cr);
        cairo_destroy(cr);
        cairo_surface_write_to_png(out, f.c_str());
        cairo_surface_destroy(out);
    }
    finish();
    spawnShell("wl-copy -t image/png < " + shellQuote(f) + " && notify-send -a Screenshot -i " + shellQuote(f) +
               " 'Screenshot saved' 'Copied to the clipboard · Pictures/Screenshots'");
}

// The overlay on one monitor
class CaptureView : public Stack {
public:
    CaptureView(Rect out) : out_(out) {
        interactive = true;
        cursor = Cursor::Default;
        manual = true;
        buildBar();
    }
    Rect out_;   // this monitor in layout coordinates

    // ---- drawing ----
    void paint(Painter &p) override {
        auto &s = S();
        const Theme &t = theme();
        if (s.frozen && s.frozen->valid()) {
            p.save();
            p.clip(geom);
            p.translate(-out_.x, -out_.y);
            p.scale(1.0 / s.px);
            Rect all{0, 0, (double)s.frozen->width(), (double)s.frozen->height()};
            p.image(*s.frozen, all, 0, false);
            p.restore();
        }
        Rect hl = highlight();
        // dim everything but the selection
        Color dim{0, 0, 0, 0.5};
        if (hl.w > 0) {
            p.fill({geom.x, geom.y, geom.w, std::max(0.0, hl.y - geom.y)}, dim);
            p.fill({geom.x, hl.bottom(), geom.w, std::max(0.0, geom.bottom() - hl.bottom())}, dim);
            p.fill({geom.x, hl.y, std::max(0.0, hl.x - geom.x), hl.h}, dim);
            p.fill({hl.right(), hl.y, std::max(0.0, geom.right() - hl.right()), hl.h}, dim);
            p.stroke(hl, Color{1, 1, 1, 0.95}, 2);
            if (s.mode == Mode::Selection) {
                for (Point c : {Point{hl.x, hl.y}, Point{hl.right(), hl.y}, Point{hl.x, hl.bottom()}, Point{hl.right(), hl.bottom()}}) {
                    p.fill({c.x - 7, c.y - 7, 14, 14}, Color{1, 1, 1, 1}, 7);
                    p.stroke({c.x - 7, c.y - 7, 14, 14}, t.accent, 2, 7);
                }
                // size readout
                Text sz(std::to_string((int)hl.w) + " × " + std::to_string((int)hl.h), Font{.size = 12, .weight = Weight::DemiBold});
                Rect b{hl.x, hl.y - 30, sz.size().w + 16, 24};
                if (b.y < geom.y + 4) b.y = hl.y + 6;
                p.fill(b, Color{0, 0, 0, 0.65}, 8);
                p.text(sz, {b.x + 8, b.y + (24 - sz.size().h) / 2}, Color{1, 1, 1, 1});
            }
        } else {
            p.fill(geom, dim);
        }
    }

    // ---- input ----
    Rect local(Rect r) const { return {r.x - out_.x + geom.x, r.y - out_.y + geom.y, r.w, r.h}; }
    Rect layout(Rect r) const { return {r.x + out_.x - geom.x, r.y + out_.y - geom.y, r.w, r.h}; }
    Rect highlight() const {
        auto &s = S();
        if (s.mode == Mode::Screen) return hoverScreen_ ? geom : Rect{};
        if (s.mode == Mode::Window) return hoverWin_.w > 0 ? local(hoverWin_) : Rect{};
        if (s.sel.w <= 0) return {};
        Rect r = local(s.sel);
        // only the part on this monitor
        double x0 = std::max(r.x, geom.x), y0 = std::max(r.y, geom.y);
        double x1 = std::min(r.right(), geom.right()), y1 = std::min(r.bottom(), geom.bottom());
        if (x1 <= x0 || y1 <= y0) return {};
        return {x0, y0, x1 - x0, y1 - y0};
    }
    void pointerEnter() override { hoverScreen_ = true; Widget::pointerEnter(); }
    void pointerLeave() override { hoverScreen_ = false; Widget::pointerLeave(); refreshAll(); }
    void pointerMove(Point p) override {
        auto &s = S();
        hoverScreen_ = true;
        if (s.mode == Mode::Window) {
            Rect lp{p.x, p.y, 0, 0};
            Rect l = layout(lp);
            hoverWin_ = {};
            for (auto &w : s.windows)   // front-most first
                if (w.contains({l.x, l.y})) { hoverWin_ = w; break; }
            update();
            return;
        }
        if (s.mode != Mode::Selection) { update(); return; }
        if (drag_ == 0) { cursor = edgeAt(p) ? Cursor::ResizeNWSE : inside(p) ? Cursor::Move : Cursor::Default; return; }
        Rect l = layout({p.x, p.y, 0, 0});
        double dx = l.x - start_.x, dy = l.y - start_.y;
        Rect r = orig_;
        if (drag_ == 1) {   // new selection
            r = {std::min(start_.x, l.x), std::min(start_.y, l.y), std::abs(dx), std::abs(dy)};
        } else if (drag_ == 2) {   // move
            r.x += dx;
            r.y += dy;
        } else {   // resize from a corner (3..6 = tl, tr, bl, br)
            double x0 = r.x, y0 = r.y, x1 = r.right(), y1 = r.bottom();
            if (drag_ == 3 || drag_ == 5) x0 += dx; else x1 += dx;
            if (drag_ == 3 || drag_ == 4) y0 += dy; else y1 += dy;
            r = {std::min(x0, x1), std::min(y0, y1), std::abs(x1 - x0), std::abs(y1 - y0)};
        }
        s.sel = r;
        refreshAll();
    }
    bool pointerPress(Point p, int button) override {
        auto &s = S();
        if (button == 3) { finish(); return true; }
        if (button != 1) return false;
        if (s.mode == Mode::Screen) { capture(out_); return true; }
        if (s.mode == Mode::Window) { if (hoverWin_.w > 0) capture(hoverWin_); return true; }
        start_ = {layout({p.x, p.y, 0, 0}).x, layout({p.x, p.y, 0, 0}).y};
        orig_ = s.sel;
        if (int e = edgeAt(p)) drag_ = e;
        else if (inside(p)) drag_ = 2;
        else { drag_ = 1; s.sel = {start_.x, start_.y, 0, 0}; }
        pressed = true;
        return true;
    }
    void pointerRelease(Point, int) override {
        drag_ = 0;
        pressed = false;
        if (S().sel.w > 0) lastSelection = S().sel;
        refreshAll();
    }
    static void refreshAll() {
        for (auto &w : S().wins) if (w->root()) w->root()->update();
    }

private:
    bool hoverScreen_ = false;
    Rect hoverWin_{};
    int drag_ = 0;
    Point start_;
    Rect orig_;
    Card *bar_ = nullptr;

    bool inside(Point p) const { Rect h = highlight(); return h.w > 0 && h.contains(p); }
    int edgeAt(Point p) const {
        Rect h = highlight();
        if (h.w <= 0) return 0;
        Point cs[4] = {{h.x, h.y}, {h.right(), h.y}, {h.x, h.bottom()}, {h.right(), h.bottom()}};
        for (int i = 0; i < 4; i++) if (std::abs(p.x - cs[i].x) < 14 && std::abs(p.y - cs[i].y) < 14) return 3 + i;
        return 0;
    }

    void buildBar() {
        const Theme &t = theme();
        bar_ = add<Card>(Dir::Row, 10);
        bar_->radius = 26;
        bar_->padding(10, 8);
        bar_->blurBehind = false;
        bar_->useTint = true;
        bar_->tint = Color{0.1, 0.095, 0.13, 0.96};
        auto seg = [&](std::vector<std::tuple<std::string, std::string, std::function<bool()>, std::function<void()>>> items) {
            auto *g = bar_->add<Box>(Dir::Row, 2);
            g->bg = Color{1, 1, 1, 0.06};
            g->radius = 18;
            g->padding(3);
            for (auto &[icon, tip, on, act] : items) {
                auto *b = g->add<IconButton>(icon, 38, 18);
                b->radius = 15;
                b->tooltip = tip;
                bool active = on();
                b->bg = active ? t.accent : Color{0, 0, 0, 0};
                b->hoverBg = active ? t.accentBright : Color{1, 1, 1, 0.08};
                b->icon->role = Role::Custom;
                b->icon->color = active ? t.onAccent : Color{1, 1, 1, 0.9};
                auto a = act;
                b->onClick = [a] { a(); rebuildBars(); };
            }
        };
        auto &s = S();
        seg({{"frame", "Selection", [] { return S().mode == Mode::Selection; }, [] { S().mode = Mode::Selection; }},
             {"monitor", "Screen", [] { return S().mode == Mode::Screen; }, [] { S().mode = Mode::Screen; }},
             {"square", "Window", [] { return S().mode == Mode::Window; }, [] { S().mode = Mode::Window; }}});
        auto *shot = bar_->add<IconButton>(s.video ? "record" : "shot", 56, 24);
        shot->radius = 28;
        shot->bg = s.video ? t.danger : Color{1, 1, 1, 0.92};
        shot->hoverBg = s.video ? t.danger.lighter(0.1) : Color{1, 1, 1, 1};
        shot->icon->role = Role::Custom;
        shot->icon->color = s.video ? Color{1, 1, 1, 1} : Color{0.08, 0.08, 0.1, 1};
        shot->tooltip = s.video ? "Start recording" : "Take screenshot";
        shot->onClick = [this] { doCapture(); };
        seg({{"shot", "Screenshot", [] { return !S().video; }, [] { S().video = false; }},
             {"record", "Screen recording", [] { return S().video; }, [] { S().video = true; }}});
        auto *x = bar_->add<IconButton>("x", 38, 16);
        x->radius = 19;
        x->bg = Color{1, 1, 1, 0.08};
        x->icon->role = Role::Custom;
        x->icon->color = Color{1, 1, 1, 0.9};
        x->tooltip = "Close (Esc)";
        x->onClick = [] { finish(); };
    }

public:
    void doCapture() {
        auto &s = S();
        if (s.mode == Mode::Screen) capture(out_);
        else if (s.mode == Mode::Window) { if (hoverWin_.w > 0) capture(hoverWin_); }
        else if (s.sel.w > 3) capture(s.sel);
    }
    void arrange() override {
        Size h = bar_->hint(geom.w, 80);
        bar_->setGeometry({geom.x + (geom.w - h.w) / 2, geom.bottom() - h.h - 40, h.w, h.h});
    }
    Widget *hitTest(Point p) override {
        if (bar_ && bar_->geom.contains(p)) return Widget::hitTest(p);
        return geom.contains(p) ? this : nullptr;
    }
    static void rebuildBars();
};

void CaptureView::rebuildBars() {
    Loop::get().defer([] {
        for (auto &w : S().wins) {
            if (auto *v = dynamic_cast<CaptureView *>(w->root())) {
                v->clear();
                v->buildBar();
                v->relayout();
                v->update();
            }
        }
    });
}

void finish() {
    auto &s = S();
    if (!s.active) return;
    s.active = false;
    // windows go after this event has been delivered
    Loop::get().defer([] {
        S().wins.clear();
        S().frozen.reset();
    });
}

void show() {
    auto &s = S();
    auto &wl = Wayland::get();
    // layout size from the outputs, to map grim's image (taken at the highest scale)
    double lw = 0;
    for (auto &o : wl.outputs) lw = std::max(lw, o->x + o->logical().w);
    s.px = s.frozen && s.frozen->valid() && lw > 0 ? s.frozen->width() / lw : 1;
    if (s.sel.w <= 0 && lastSelection.w > 0) s.sel = lastSelection;
    for (auto &o : wl.outputs) {
        auto w = std::make_unique<LayerWindow>("nova-capture", Layer::Overlay, o.get());
        w->wantBlur = false;
        w->setAnchors(AnchorTop | AnchorBottom | AnchorLeft | AnchorRight);
        w->setExclusiveZone(-1);
        w->setKeyboard(KeyboardMode::Exclusive);
        Size l = o->logical();
        Rect out{(double)o->x, (double)o->y, l.w, l.h};
        w->setRoot<CaptureView>(out);
        if (s.sel.w <= 0) s.sel = {out.x + l.w / 4, out.y + l.h / 4, l.w / 2, l.h / 2};
        LayerWindow *wp = w.get();
        w->onKey = [wp](const KeyEvent &e) {
            if (!e.pressed) return false;
            if (e.sym == key::Escape) { finish(); return true; }
            if (e.sym == key::Return || e.sym == key::KP_Enter || e.sym == key::space) {
                if (auto *v = dynamic_cast<CaptureView *>(wp->root())) v->doCapture();
                return true;
            }
            return false;
        };
        w->show();
        s.wins.push_back(std::move(w));
    }
}

}  // namespace

void startCapture() {
    auto &s = S();
    if (s.active) return;
    s.active = true;
    std::string f = std::string(getenv("XDG_RUNTIME_DIR") ? getenv("XDG_RUNTIME_DIR") : "/tmp") + "/nova-capture.png";
    // windows for window mode (front-most first)
    ipc().request("get windows", [](const json &r) {
        auto &s = S();
        s.windows.clear();
        if (!r.is_object() || !r.contains("windows")) return;
        for (auto &w : r["windows"]) {
            if (!w.is_object() || w.value("minimized", false)) continue;
            double x = w.value("x", 0.0), y = w.value("y", 0.0), ww = w.value("w", 0.0), hh = w.value("h", 0.0);
            if (ww > 0 && hh > 0) s.windows.push_back({x, y, ww, hh});
        }
    });
    Process::run({"grim", f}, [f](int code, const std::string &) {
        auto &s = S();
        if (!s.active) return;
        if (code != 0) {
            s.active = false;
            spawn({"notify-send", "-a", "Screenshot", "Couldn't take a screenshot", "grim isn't working (is it installed?)"});
            return;
        }
        s.frozen = std::make_shared<Image>(f);
        show();
    });
}

}  // namespace nova
