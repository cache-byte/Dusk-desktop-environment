#include <set>
#include <map>
// nova-shell: panel, pop-ups, notifications, indicators, lock screen and wallpaper for the
// Nova compositor (any wlroots compositor with layer-shell works for the basics).
//
//   nova-shell                 run the shell
//   nova-shell toggle NAME     launcher | controlcentre | notifications | clipboard | capture | gameoverlay | overview
//   nova-shell close | lock | quit
//   nova-shell toast TEXT [ICON]
//   nova-shell --version
#include "apps.hpp"
#include "dbus.hpp"
#include "notifications.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "tray.hpp"
#include "windows.hpp"

#include <csignal>
#include <execinfo.h>
#include <exception>
#include <filesystem>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <cstring>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#ifndef NOVA_VERSION
#define NOVA_VERSION "dev"
#endif

using namespace nova;
using namespace ui;

static std::string socketPath() { return runtimeDir() + "/nova-shell.sock"; }

// ---- talking to a running shell ----
static int sendCommand(const std::vector<std::string> &args) {
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, socketPath().c_str(), sizeof a.sun_path - 1);
    if (fd < 0 || connect(fd, (sockaddr *)&a, sizeof a) < 0) {
        fprintf(stderr, "nova-shell: the shell isn't running\n");
        return 1;
    }
    json j = args;
    std::string line = j.dump() + "\n";
    ssize_t n = write(fd, line.data(), line.size());
    close(fd);
    return n == (ssize_t)line.size() ? 0 : 1;
}

static void runCommand(const json &a) {
    if (!a.is_array() || a.empty() || !a[0].is_string()) return;
    std::string cmd = a[0];
    std::string arg = a.size() > 1 && a[1].is_string() ? a[1].get<std::string>() : "";
    if (cmd == "toggle") shell().action(arg);
    else if (cmd == "close") shell().close();
    else if (cmd == "lock") LockScreen::get().lock();
    else if (cmd == "toast") broadcastToast(arg, a.size() > 2 && a[2].is_string() ? a[2].get<std::string>() : "check");
    else if (cmd == "reload") cfg().load();
    else if (cmd == "quit") Loop::get().quit();
}

static void listen() {
    std::string path = socketPath();
    unlink(path.c_str());
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, path.c_str(), sizeof a.sun_path - 1);
    if (fd < 0 || bind(fd, (sockaddr *)&a, sizeof a) < 0 || ::listen(fd, 8) < 0) {
        fprintf(stderr, "nova-shell: can't listen on %s: %s\n", path.c_str(), strerror(errno));
        return;
    }
    Loop::get().addFd(fd, POLLIN, [](int lfd, short) {
        int c = accept4(lfd, nullptr, nullptr, SOCK_CLOEXEC | SOCK_NONBLOCK);
        if (c < 0) return;
        auto buf = std::make_shared<std::string>();
        auto id = std::make_shared<int>(0);
        *id = Loop::get().addFd(c, POLLIN, [buf, id](int cfd, short) {
            char b[4096];
            ssize_t n = read(cfd, b, sizeof b);
            if (n > 0) { buf->append(b, n); return; }
            if (n < 0 && errno == EAGAIN) return;
            Loop::get().removeFd(*id);
            close(cfd);
            for (auto &line : split(*buf, '\n')) {
                if (trim(line).empty()) continue;
                try { runCommand(json::parse(line)); } catch (...) {}
            }
        });
    });
}

// ---- crash reports ----
// The shell's messages go to ~/.cache/nova/nova-shell.log; a crash adds a backtrace there,
// which nova-doctor shows. (Run `nova-shell` in a terminal to see them live instead.)
static std::string g_logPath;
static void crashHandler(int sig) {
    const char *name = sig == SIGSEGV ? "segmentation fault" : sig == SIGABRT ? "abort" : sig == SIGBUS ? "bus error" : sig == SIGFPE ? "arithmetic error" : "signal";
    char head[128];
    int n = snprintf(head, sizeof head, "\n=== nova-shell crashed: %s (signal %d) ===\n", name, sig);
    if (n > 0) { ssize_t w = write(2, head, n); (void)w; }
    void *frames[64];
    int count = backtrace(frames, 64);
    backtrace_symbols_fd(frames, count, 2);
    const char *tail = "=== end of backtrace ===\n";
    ssize_t w = write(2, tail, strlen(tail));
    (void)w;
    signal(sig, SIG_DFL);
    raise(sig);
}
static void setupLogging() {
    std::string dir = (getenv("XDG_CACHE_HOME") && *getenv("XDG_CACHE_HOME") ? std::string(getenv("XDG_CACHE_HOME")) : homeDir() + "/.cache") + "/nova";
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    g_logPath = dir + "/nova-shell.log";
    if (!isatty(2)) {
        // keep the log small: start over past 512 KB
        struct stat st{};
        bool big = stat(g_logPath.c_str(), &st) == 0 && st.st_size > 512 * 1024;
        int fd = open(g_logPath.c_str(), O_WRONLY | O_CREAT | O_CLOEXEC | (big ? O_TRUNC : O_APPEND), 0644);
        if (fd >= 0) { dup2(fd, 2); close(fd); }
    }
    time_t now = time(nullptr);
    fprintf(stderr, "\n--- nova-shell %s started %s", NOVA_VERSION, ctime(&now));
    setvbuf(stderr, nullptr, _IONBF, 0);
    for (int s : {SIGSEGV, SIGABRT, SIGBUS, SIGFPE, SIGILL}) signal(s, crashHandler);
    std::set_terminate([] {
        if (auto e = std::current_exception()) {
            try { std::rethrow_exception(e); }
            catch (const std::exception &x) { fprintf(stderr, "nova-shell: uncaught exception: %s\n", x.what()); }
            catch (...) { fprintf(stderr, "nova-shell: uncaught exception\n"); }
        }
        abort();
    });
}

// ---- screens follow the outputs ----
static void addScreen(Output *o) {
    for (auto &s : shell().screens) if (s->output == o) return;
    shell().screens.push_back(std::make_unique<Screen>(o));
}
static void removeScreen(Output *o) {
    auto &v = shell().screens;
    v.erase(std::remove_if(v.begin(), v.end(), [o](auto &s) { return s->output == o; }), v.end());
}

// XDG autostart, once per login (the shell can restart; the marker lives in XDG_RUNTIME_DIR):
// ~/.config/autostart, plus system entries meant for Nova. Hidden / disabled / OnlyShowIn /
// NotShowIn / TryExec are respected.
static void runAutostart() {
    namespace fs = std::filesystem;
    std::string marker = ui::runtimeDir() + "/nova-autostart-done";
    if (fs::exists(marker)) return;
    ui::writeFile(marker, "1");
    // tray icons of X11 apps (Steam, Wine games…): XEmbed -> StatusNotifier bridge, when installed
    if (ui::haveProgram("xembedsniproxy")) ui::spawn({"xembedsniproxy"});
    std::map<std::string, fs::path> entries;   // file name -> path (the user's copy wins)
    std::error_code ec;
    for (auto &e : fs::directory_iterator("/etc/xdg/autostart", ec)) entries[e.path().filename().string()] = e.path();
    std::set<std::string> userOnes;
    for (auto &e : fs::directory_iterator(ui::homeDir() + "/.config/autostart", ec)) {
        entries[e.path().filename().string()] = e.path();
        userOnes.insert(e.path().filename().string());
    }
    for (auto &[name, path] : entries) {
        if (path.extension() != ".desktop") continue;
        std::string exec, tryExec, only, notShow;
        bool hidden = false;
        bool inEntry = false;
        for (auto &l : ui::split(ui::readFile(path.string()), '\n')) {
            std::string t = ui::trim(l);
            if (t.rfind("[", 0) == 0) { inEntry = t == "[Desktop Entry]"; continue; }
            if (!inEntry) continue;
            if (t.rfind("Exec=", 0) == 0) exec = t.substr(5);
            else if (t.rfind("TryExec=", 0) == 0) tryExec = t.substr(8);
            else if (t.rfind("OnlyShowIn=", 0) == 0) only = t.substr(11);
            else if (t.rfind("NotShowIn=", 0) == 0) notShow = t.substr(10);
            else if (t == "Hidden=true" || t == "X-GNOME-Autostart-enabled=false") hidden = true;
        }
        if (hidden || exec.empty()) continue;
        if (!only.empty() && only.find("Nova") == std::string::npos) continue;
        if (notShow.find("Nova") != std::string::npos) continue;
        // system entries only when they ask for Nova (they're mostly GNOME / KDE helpers)
        if (!userOnes.count(name) && only.find("Nova") == std::string::npos) continue;
        if (!tryExec.empty() && !ui::haveProgram(tryExec)) continue;
        // drop field codes (%u %f …)
        std::string cmd;
        for (size_t i = 0; i < exec.size(); i++) {
            if (exec[i] == '%' && i + 1 < exec.size()) { if (exec[i + 1] == '%') cmd += '%'; i++; continue; }
            cmd += exec[i];
        }
        ui::spawnShell(cmd);
    }
}

int main(int argc, char **argv) {
    if (argc > 1) {
        std::string a = argv[1];
        if (a == "--version" || a == "-v") { printf("nova-shell %s\n", NOVA_VERSION); return 0; }
        if (a == "--help" || a == "-h") {
            printf("usage: nova-shell [toggle NAME | close | lock | toast TEXT [ICON] | reload | quit]\n");
            return 0;
        }
        std::vector<std::string> args(argv + 1, argv + argc);
        return sendCommand(args);
    }

    // one shell per session
    std::string lockPath = runtimeDir() + "/nova-shell.lock";
    int lockFd = open(lockPath.c_str(), O_CREAT | O_RDWR | O_CLOEXEC, 0600);
    if (lockFd < 0 || flock(lockFd, LOCK_EX | LOCK_NB) < 0) {
        fprintf(stderr, "nova-shell: already running\n");
        return 1;
    }

    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_DFL);
    setupLogging();

    auto &wl = Wayland::get();
    if (!wl.connect()) {
        fprintf(stderr, "nova-shell: can't connect to a Wayland compositor (WAYLAND_DISPLAY=%s)\n", getenv("WAYLAND_DISPLAY") ? getenv("WAYLAND_DISPLAY") : "");
        return 1;
    }
    if (!wl.layerShell) {
        fprintf(stderr, "nova-shell: the compositor has no wlr-layer-shell; the shell needs it\n");
        return 1;
    }

    std::string assets = "/usr/share/nova/shell";
    if (const char *d = getenv("NOVA_ASSETS"); d && *d) assets = d;
    setIconSearchPath(assets + "/icons");
    cfg().load();

    // services
    NovaIpc::get().connect();
    Apps::get().start();
    ui::Loop::get().addTimer(1500, [] { runAutostart(); });
    Toplevels::get().start();
    Idle::get().start();
    Notifications::get().start();
    Tray::get().start();
    Audio::get().start();
    Brightness::get().start();
    Net::get().start();
    Battery::get().start();
    Bluetooth::get().start();
    Power::get().start();
    Media::get().start();
    Lyrics::get().start();
    Recorder::get().start();
    Replay::get().start();
    Gaming::get().start();

    // the compositor's blur follows Settings
    auto pushBlur = [] {
        if (theme().realBlur) ipc().dispatch("blur " + std::to_string(cfg().d("blurUi", 0.8)));
    };
    pushBlur();

    for (auto &o : wl.outputs) addScreen(o.get());
    wl.outputAdded.connect([](Output *o) { Loop::get().defer([o] { addScreen(o); }); });
    wl.outputRemoved.connect([](Output *o) { removeScreen(o); });

    // Screens add and remove windows; never while one of those windows is still handling the
    // click or key that caused it (that crashed the shell), so sync on the next loop pass.
    static bool syncPending = false;
    auto syncAll = [] {
        if (syncPending) return;
        syncPending = true;
        Loop::get().defer([] {
            syncPending = false;
            for (auto &s : shell().screens) s->sync();
        });
    };
    shell().changed.connect(syncAll);
    cfg().changed.connect([syncAll, pushBlur] { syncAll(); pushBlur(); });
    Media::get().changed.connect(syncAll);
    ipc().shellAction.connect([](const std::string &a) { shell().action(a); });
    ipc().lockRequested.connect([] { LockScreen::get().lock(); });
    // pop-ups close when you click anything else (the click still goes where you clicked)
    ipc().pressed.connect([](const std::string &layer) {
        if (startsWith(layer, "nova-popout") || layer == "nova-panel" || layer == "nova-overview" || startsWith(layer, "nova-hotcorner")) return;
        shell().close();
    });
    ipc().activeOutputChanged.connect([syncAll](const std::string &) { syncAll(); });

    listen();
    Loop::get().run();

    shell().screens.clear();
    unlink(socketPath().c_str());
    return 0;
}
