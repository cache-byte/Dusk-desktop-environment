// Bottom panel: launcher, pinned + running apps, then capture countdown, clipboard,
// lock keys, tray, status (network, volume, battery) and the clock.
#pragma once
#include "common.hpp"
#include "shell.hpp"

namespace nova {

// What one panel shows. Settings > Panel & launcher edits the list ("panels" in settings.json).
struct PanelSpec {
    std::string position = "bottom";     // bottom | top
    std::string monitors = "all";        // all | primary | <output name>
    int height = 0;                      // 0 = theme default
    std::vector<std::string> elements;   // launcher separator apps spacer countdown clipboard locks tray media status clock
    static std::vector<PanelSpec> fromConfig();
    static std::vector<std::string> defaultElements();
};

class Panel : public ui::LayerWindow {
public:
    Panel(Screen *s, PanelSpec spec);
    ~Panel() override;
    Screen *screen;
    PanelSpec spec;
    bool top() const { return spec.position == "top"; }
    int height() const;
    ui::Rect clockRect() const;          // window coordinates
private:
    ui::Box *apps_ = nullptr, *right_ = nullptr;
    PanelButton *launcherBtn_ = nullptr, *clipBtn_ = nullptr;
    Pill *countdown_ = nullptr, *locks_ = nullptr, *tray_ = nullptr, *status_ = nullptr, *clock_ = nullptr, *media_ = nullptr;
    ui::Label *countdownL_ = nullptr, *time_ = nullptr, *date_ = nullptr, *badgeL_ = nullptr;
    ui::IconW *capsI_ = nullptr, *numI_ = nullptr, *netI_ = nullptr, *volI_ = nullptr;
    BatteryW *battery_ = nullptr;
    ui::Box *badge_ = nullptr, *rec_ = nullptr;
    MusicBars *bars_ = nullptr;
    Visualizer *viz_ = nullptr;
    Connections conns_;
    std::string appsKey_;      // what the app buttons show (skip rebuilding when nothing changed)
    int clockTimer_ = 0;
    void build();
    void addElement(ui::Box *bg, const std::string &id);
    void panelMenu(ui::Point at);
    void rebuildApps();
    void rebuildTray();
    void refresh();
    void refreshClock();
};

}  // namespace nova
