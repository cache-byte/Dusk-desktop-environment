#include "tray.hpp"
#include "dbus.hpp"

#include <cairo.h>
#include <unistd.h>

namespace nova {

Tray &Tray::get() {
    static Tray t;
    return t;
}

// ----------------------------------------------------------- watcher vtable --
static int w_registerItem(sd_bus_message *m, void *, sd_bus_error *) {
    const char *s = "";
    sd_bus_message_read(m, "s", &s);
    Tray::get().registerItem(sd_bus_message_get_sender(m) ? sd_bus_message_get_sender(m) : "", s ? s : "");
    return sd_bus_reply_method_return(m, "");
}
static int w_registerHost(sd_bus_message *m, void *, sd_bus_error *) { return sd_bus_reply_method_return(m, ""); }
static int w_items(sd_bus *, const char *, const char *, const char *, sd_bus_message *reply, void *, sd_bus_error *) {
    sd_bus_message_open_container(reply, 'a', "s");
    for (auto &s : Tray::get().registered()) sd_bus_message_append(reply, "s", s.c_str());
    return sd_bus_message_close_container(reply);
}
static int w_hostRegistered(sd_bus *, const char *, const char *, const char *, sd_bus_message *reply, void *, sd_bus_error *) {
    return sd_bus_message_append(reply, "b", 1);
}
static int w_version(sd_bus *, const char *, const char *, const char *, sd_bus_message *reply, void *, sd_bus_error *) {
    return sd_bus_message_append(reply, "i", 0);
}
static const sd_bus_vtable watcherVtable[] = {
    SD_BUS_VTABLE_START(0),
    SD_BUS_METHOD("RegisterStatusNotifierItem", "s", "", w_registerItem, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_METHOD("RegisterStatusNotifierHost", "s", "", w_registerHost, SD_BUS_VTABLE_UNPRIVILEGED),
    SD_BUS_PROPERTY("RegisteredStatusNotifierItems", "as", w_items, 0, SD_BUS_VTABLE_PROPERTY_EMITS_CHANGE),
    SD_BUS_PROPERTY("IsStatusNotifierHostRegistered", "b", w_hostRegistered, 0, SD_BUS_VTABLE_PROPERTY_CONST),
    SD_BUS_PROPERTY("ProtocolVersion", "i", w_version, 0, SD_BUS_VTABLE_PROPERTY_CONST),
    SD_BUS_SIGNAL("StatusNotifierItemRegistered", "s", 0),
    SD_BUS_SIGNAL("StatusNotifierItemUnregistered", "s", 0),
    SD_BUS_SIGNAL("StatusNotifierHostRegistered", "", 0),
    SD_BUS_SIGNAL("StatusNotifierHostUnregistered", "", 0),
    SD_BUS_VTABLE_END,
};

void Tray::start() {
    Bus &b = Bus::session();
    if (!b) return;
    // become the watcher unless another desktop component already is
    sd_bus_add_object_vtable(b.bus(), nullptr, "/StatusNotifierWatcher", "org.kde.StatusNotifierWatcher", watcherVtable, this);
    ownWatcher_ = sd_bus_request_name(b.bus(), "org.kde.StatusNotifierWatcher", 0) >= 0;
    std::string host = "org.kde.StatusNotifierHost-" + std::to_string(getpid());
    b.requestName(host);
    if (!ownWatcher_) {
        // someone else watches: ask it for the items and follow its signals
        b.call("org.kde.StatusNotifierWatcher", "/StatusNotifierWatcher", "org.kde.StatusNotifierWatcher", "RegisterStatusNotifierHost", nullptr,
               [host](sd_bus_message *m) { sd_bus_message_append(m, "s", host.c_str()); });
        b.call("org.kde.StatusNotifierWatcher", "/StatusNotifierWatcher", "org.freedesktop.DBus.Properties", "Get",
               [this](sd_bus_message *r, const std::string &) {
                   if (!r) return;
                   for (auto &s : readVariantStrings(r)) registerItem("", s);
               },
               [](sd_bus_message *m) { sd_bus_message_append(m, "ss", "org.kde.StatusNotifierWatcher", "RegisteredStatusNotifierItems"); });
        b.match("type='signal',interface='org.kde.StatusNotifierWatcher',member='StatusNotifierItemRegistered'", [this](sd_bus_message *m) {
            const char *s;
            if (sd_bus_message_read(m, "s", &s) >= 0) registerItem("", s);
        });
    }
    // items that leave the bus
    b.match("type='signal',sender='org.freedesktop.DBus',interface='org.freedesktop.DBus',member='NameOwnerChanged'", [this](sd_bus_message *m) {
        const char *n, *o, *nw;
        if (sd_bus_message_read(m, "sss", &n, &o, &nw) < 0) return;
        if (nw && !*nw) { removeService(n); if (o && *o) removeService(o); }
    });
    // icon / title / status updates
    for (const char *sig : {"NewIcon", "NewTitle", "NewStatus", "NewAttentionIcon", "NewToolTip", "NewMenu"})
        b.match(std::string("type='signal',interface='org.kde.StatusNotifierItem',member='") + sig + "'", [this](sd_bus_message *m) {
            std::string sender = sd_bus_message_get_sender(m) ? sd_bus_message_get_sender(m) : "";
            std::string path = sd_bus_message_get_path(m) ? sd_bus_message_get_path(m) : "";
            for (auto &it : items) if (it.service == sender && it.path == path) load(it);
        });
    if (ownWatcher_) sd_bus_emit_signal(b.bus(), "/StatusNotifierWatcher", "org.kde.StatusNotifierWatcher", "StatusNotifierHostRegistered", "");
}

std::vector<std::string> Tray::registered() const {
    std::vector<std::string> out;
    for (auto &i : items) out.push_back(i.service + i.path);
    return out;
}

void Tray::registerItem(const std::string &sender, const std::string &s) {
    // "s" is a bus name (":1.42" / "org.app.Tray") or an object path (then the sender is the service)
    std::string service = s, path = "/StatusNotifierItem";
    if (!s.empty() && s[0] == '/') { service = sender; path = s; }
    else if (auto p = s.find('/'); p != std::string::npos) { service = s.substr(0, p); path = s.substr(p); }
    addItem(service, path);
    if (ownWatcher_) {
        std::string full = service + path;
        sd_bus_emit_signal(Bus::session().bus(), "/StatusNotifierWatcher", "org.kde.StatusNotifierWatcher", "StatusNotifierItemRegistered", "s", full.c_str());
    }
}
void Tray::addItem(const std::string &service, const std::string &path) {
    for (auto &i : items) if (i.service == service && i.path == path) return;
    TrayItem it;
    it.service = service;
    it.path = path;
    items.push_back(it);
    load(items.back());
}
void Tray::removeService(const std::string &service) {
    size_t n = items.size();
    std::erase_if(items, [&](const TrayItem &i) { return i.service == service; });
    if (items.size() != n) changed.emit();
}

// largest ARGB32 (network byte order) pixmap -> image
static std::shared_ptr<ui::Image> readPixmap(sd_bus_message *m) {
    if (sd_bus_message_enter_container(m, 'v', "a(iiay)") < 0) { skipVariant(m); return nullptr; }
    std::shared_ptr<ui::Image> best;
    int bestW = 0;
    if (sd_bus_message_enter_container(m, 'a', "(iiay)") >= 0) {
        while (sd_bus_message_enter_container(m, 'r', "iiay") > 0) {
            int32_t w = 0, h = 0;
            const void *data = nullptr;
            size_t size = 0;
            sd_bus_message_read(m, "ii", &w, &h);
            sd_bus_message_read_array(m, 'y', &data, &size);
            if (w > bestW && w > 0 && h > 0 && size >= (size_t)w * h * 4) {
                cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, w, h);
                unsigned char *d = cairo_image_surface_get_data(s);
                int ds = cairo_image_surface_get_stride(s);
                const unsigned char *src = (const unsigned char *)data;
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++) {
                        const unsigned char *p = src + (y * w + x) * 4;   // A R G B
                        uint32_t a = p[0], r = p[1] * a / 255, g = p[2] * a / 255, b = p[3] * a / 255;
                        *(uint32_t *)(d + y * ds + x * 4) = (a << 24) | (r << 16) | (g << 8) | b;
                    }
                cairo_surface_mark_dirty(s);
                best = std::make_shared<ui::Image>(ui::Image::fromSurface(s));
                bestW = w;
            }
            sd_bus_message_exit_container(m);
        }
        sd_bus_message_exit_container(m);
    }
    sd_bus_message_exit_container(m);
    return best;
}

void Tray::load(TrayItem &ref) {
    std::string service = ref.service, path = ref.path;
    Bus::session().getAll(service, path, "org.kde.StatusNotifierItem", [this, service, path](sd_bus_message *m) {
        if (!m) return;
        for (auto &it : items) {
            if (it.service != service || it.path != path) continue;
            forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
                if (k == "Id") it.id = readVariantString(v);
                else if (k == "Title") it.title = readVariantString(v);
                else if (k == "Status") it.status = readVariantString(v);
                else if (k == "IconName") it.iconName = readVariantString(v);
                else if (k == "IconThemePath") it.iconThemePath = readVariantString(v);
                else if (k == "Menu") it.menuPath = readVariantString(v);
                else if (k == "ItemIsMenu") it.itemIsMenu = readVariantBool(v);
                else if (k == "IconPixmap") it.pixmap = readPixmap(v);
                else skipVariant(v);
            });
            // icons shipped with the app (IconThemePath) take a full path
            if (!it.iconName.empty() && !it.iconThemePath.empty()) {
                for (const char *ext : {".png", ".svg"}) {
                    std::string p = it.iconThemePath + "/" + it.iconName + ext;
                    if (access(p.c_str(), R_OK) == 0) { it.iconName = p; break; }
                }
            }
        }
        changed.emit();
    });
}

void TrayItem::activate(int x, int y) {
    Bus::session().call(service, path, "org.kde.StatusNotifierItem", "Activate", nullptr, [x, y](sd_bus_message *m) { sd_bus_message_append(m, "ii", x, y); });
}
void TrayItem::secondaryActivate(int x, int y) {
    Bus::session().call(service, path, "org.kde.StatusNotifierItem", "SecondaryActivate", nullptr, [x, y](sd_bus_message *m) { sd_bus_message_append(m, "ii", x, y); });
}
void TrayItem::scroll(int delta, bool vertical) {
    Bus::session().call(service, path, "org.kde.StatusNotifierItem", "Scroll", nullptr,
                        [delta, vertical](sd_bus_message *m) { sd_bus_message_append(m, "is", delta, vertical ? "vertical" : "horizontal"); });
}

// dbusmenu layout: (ia{sv}av), children are variants of the same struct
static void readLayout(sd_bus_message *m, TrayMenuItem &out) {
    if (sd_bus_message_enter_container(m, 'r', "ia{sv}av") < 0) return;
    sd_bus_message_read(m, "i", &out.id);
    forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
        if (k == "label") { out.label = readVariantString(v); out.label = ui::replaceAll(out.label, "_", ""); }
        else if (k == "enabled") out.enabled = readVariantBool(v);
        else if (k == "visible") out.visible = readVariantBool(v);
        else if (k == "type") out.type = readVariantString(v);
        else if (k == "toggle-type") out.toggleType = readVariantString(v);
        else if (k == "toggle-state") out.checked = readVariantNumber(v) == 1;
        else if (k == "icon-name") out.icon = readVariantString(v);
        else skipVariant(v);
    });
    if (sd_bus_message_enter_container(m, 'a', "v") >= 0) {
        while (sd_bus_message_enter_container(m, 'v', "(ia{sv}av)") > 0) {
            TrayMenuItem c;
            readLayout(m, c);
            if (c.visible) out.children.push_back(std::move(c));
            sd_bus_message_exit_container(m);
        }
        sd_bus_message_exit_container(m);
    }
    sd_bus_message_exit_container(m);
}
void TrayItem::menu(std::function<void(const TrayMenuItem &)> cb) {
    if (menuPath.empty()) return;
    std::string svc = service, mp = menuPath;
    Bus::session().call(svc, mp, "com.canonical.dbusmenu", "AboutToShow", nullptr, [](sd_bus_message *m) { sd_bus_message_append(m, "i", 0); });
    Bus::session().call(svc, mp, "com.canonical.dbusmenu", "GetLayout",
                        [cb](sd_bus_message *r, const std::string &) {
                            if (!r) return;
                            uint32_t rev = 0;
                            sd_bus_message_read(r, "u", &rev);
                            TrayMenuItem root;
                            readLayout(r, root);
                            cb(root);
                        },
                        [](sd_bus_message *m) {
                            sd_bus_message_append(m, "ii", 0, -1);
                            sd_bus_message_open_container(m, 'a', "s");
                            sd_bus_message_close_container(m);
                        });
}
void TrayItem::menuClicked(int id) {
    Bus::session().call(service, menuPath, "com.canonical.dbusmenu", "Event", nullptr, [id](sd_bus_message *m) {
        sd_bus_message_append(m, "is", id, "clicked");
        sd_bus_message_open_container(m, 'v', "i");
        sd_bus_message_append(m, "i", 0);
        sd_bus_message_close_container(m);
        sd_bus_message_append(m, "u", (uint32_t)time(nullptr));
    });
}

}  // namespace nova
