// org.freedesktop.Notifications server: pop-ups, history, grouping, do not disturb
// (manual, or automatic while something is fullscreen) and the missed count.
#pragma once
#include "config.hpp"
#include "ui/paint.hpp"

namespace nova {

struct Notification {
    uint32_t id = 0;
    std::string app, appIcon, summary, body, category, desktopEntry;
    std::vector<std::pair<std::string, std::string>> actions;   // key, label
    int urgency = 1;                    // 0 low, 1 normal, 2 critical
    int timeoutMs = -1;                 // -1 = server default, 0 = never
    int64_t time = 0;                   // when it arrived (ms since epoch)
    std::shared_ptr<ui::Image> image;   // image-data / image-path hint
    bool resident = false, transient = false;
};

struct NotifGroup {
    std::string key, name, icon;
    std::vector<const Notification *> items;   // newest first
};

// a past notification (dismissed or cleared), kept like clipboard history (persisted)
struct PastNotification {
    std::string app, appIcon, summary, body;
    int64_t time = 0;
};

class Notifications {
public:
    static Notifications &get();
    void start();
    const std::vector<Notification> &all() const { return all_; }
    std::vector<uint32_t> popups;       // shown as toasts, newest first
    int missed = 0;
    bool quiet() const;                 // do not disturb in effect
    std::vector<NotifGroup> groups() const;
    const Notification *find(uint32_t id) const;
    void dismiss(uint32_t id, uint32_t reason = 2);    // 2 = dismissed by the user
    void dismissPopup(uint32_t id);
    void holdPopups(bool hold);         // pointer on a toast: it doesn't expire meanwhile
    void invoke(uint32_t id, const std::string &action);
    void clearAll();
    std::vector<PastNotification> history;   // newest first, at most 150
    void clearHistory();
    ui::Signal<> changed;
    ui::Signal<int> missedSummary;      // after fullscreen ends: "3 notifications while you were playing"
    // used by the D-Bus vtable
    uint32_t notify(Notification n, uint32_t replaces);
    void closeFromClient(uint32_t id) { dismiss(id, 3); }
private:
    std::vector<Notification> all_;
    uint32_t next_ = 1;
    std::map<uint32_t, int64_t> due_;   // toast expiry
    bool held_ = false;
    int expiryTimer_ = 0;
    void checkExpiry();
    void emitClosed(uint32_t id, uint32_t reason);
};

}  // namespace nova
