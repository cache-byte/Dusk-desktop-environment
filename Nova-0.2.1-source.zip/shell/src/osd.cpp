// On-screen indicators, each placed and oriented from Settings → Popups & indicators:
//   slider  — volume / brightness / mic / keyboard backlight (pill, vertical or horizontal)
//   lock    — Caps / Num Lock toast
//   power   — power mode & charger toast
//   message — small messages (`nova-shell toast "Copied" clip`)
// The windows take no input: they never get in the way of clicks.
#include "notifications.hpp"
#include "novaipc.hpp"
#include "services.hpp"
#include "windows.hpp"

namespace nova {

using namespace ui;

static double sizeK() {
    std::string s = cfg().s("osdSize", "M");
    return s == "S" ? 0.8 : s == "L" ? 1.22 : 1.0;
}

struct Osd::Impl {
    Screen *screen;
    Connections conns;
    Timer settle;                        // ignore the values services report at startup
    std::string sliderKind;
    std::unique_ptr<FitWindow> slider;
    Slider *sliderW = nullptr;
    Timer sliderT;
    struct Toast { std::unique_ptr<FitWindow> win; Timer timer; };
    std::map<std::string, Toast> toasts;
    std::string lastProfile;
    bool lastOnBattery = false, batteryKnown = false;

    void placeWin(FitWindow &w, const std::string &kind) {
        Placement pl = placementFor(cfg().osd(kind), theme().panelHeight);
        w.place(pl.anchors, pl.mt, pl.mr, pl.mb, pl.ml);
        Size scr = screen->output ? screen->output->logical() : Size{};
        w.resized.connect([&w, pl, scr](Size sz) {
            double x = (pl.anchors & AnchorLeft) ? pl.ml - w.margin : (pl.anchors & AnchorRight) ? scr.w - sz.w - (pl.mr - w.margin) : (scr.w - sz.w) / 2;
            double y = (pl.anchors & AnchorTop) ? pl.mt - w.margin : (pl.anchors & AnchorBottom) ? scr.h - sz.h - (pl.mb - w.margin) : (scr.h - sz.h) / 2;
            setBackdrop(w, scr, {x, y, sz.w, sz.h});
        });
    }

    void refreshSlider() {
        if (!sliderW) return;
        auto &a = Audio::get();
        const std::string &k = sliderKind;
        sliderW->iconName = k == "brightness" ? "sun" : k == "kbd" ? "kbl" : k == "mic" ? (a.micMuted ? "mute" : "mic") : (a.muted ? "mute" : "volume");
        double v = k == "brightness" ? Brightness::get().value
                 : k == "kbd" ? (Brightness::get().kbdMax ? (double)Brightness::get().kbdLevel / Brightness::get().kbdMax : 0)
                 : k == "mic" ? a.micVolume : a.volume;
        sliderW->maxValue = k == "volume" ? a.maxVolume() : 1.0;
        sliderW->setValue(((k == "volume" && a.muted) || (k == "mic" && a.micMuted)) ? 0 : v);
        sliderW->update();
    }

    void showSlider(const std::string &kind) {
        if (!indicatorOnScreen(screen->name())) return;
        sliderKind = kind;
        if (!slider) {
            json o = cfg().osd("slider");
            bool vert = o.value("dir", std::string("up")) != "across";
            double k = sizeK();
            slider = std::make_unique<FitWindow>("nova-slider", Layer::Overlay, screen->output, 24);
            slider->clickThrough = true;
            auto *card = slider->root()->add<Card>(Dir::Column, 0);
            card->fixedW = std::round((vert ? 60 : 300) * k);
            card->fixedH = std::round((vert ? 220 : 60) * k);
            card->radius = std::min(card->fixedW, card->fixedH) / 2;
            card->padding(5);
            card->shadowBlur = 24;
            card->shadowY = 8;
            sliderW = card->add<Slider>(vert);
            sliderW->grow = 1;
            sliderW->interactive = false;
            sliderW->thick = true;
            placeWin(*slider, "slider");
            slider->fit();
            slider->show();
        }
        refreshSlider();
        sliderT.setInterval(cfg().i("osdTimeout", 2000));
        sliderT.start();
    }

    void toast(const std::string &slot, const std::string &icon, const std::string &text, bool on) {
        if (!indicatorOnScreen(screen->name())) return;
        Toast &t = toasts[slot];
        json o = cfg().osd(slot);
        bool vert = o.value("dir", std::string("across")) == "up";
        double k = sizeK();
        const Theme &th = theme();
        t.win = std::make_unique<FitWindow>("nova-" + slot, Layer::Overlay, screen->output, 24);
        t.win->clickThrough = true;
        auto *card = t.win->root()->add<Card>(vert ? Dir::Column : Dir::Row, vert ? 10 : 14);
        card->padding(9);
        card->shadowBlur = 24;
        card->shadowY = 8;
        if (vert) {
            card->fixedW = std::round(64 * k);
            card->fixedH = std::round(150 * k);
            card->radius = card->fixedW / 2;
            card->crossAlign = Align::Center;
        } else {
            card->fixedH = std::round(56 * k);
            card->radius = card->fixedH / 2;
            card->pr = 20;
        }
        auto *dot = card->add<Box>(Dir::Row);
        dot->fixedW = dot->fixedH = std::round(38 * k);
        dot->radius = dot->fixedW / 2;
        dot->bg = on ? th.accent : th.surface3;
        dot->justify = Justify::Center;
        dot->fill = false;
        dot->alignSelf = Align::Center;
        dot->add<IconW>(icon.empty() ? "check" : icon, 18 * k, on ? Role::OnAccent : Role::Text)->fill = false;
        // across: icon + text; up: icon on top, the last word under it
        std::string shownText = text;
        if (vert) { auto w = split(text, ' '); shownText = w.empty() ? text : w.back(); }
        auto *l = card->add<Label>(shownText, std::round((vert ? 12 : 14.5) * k), Weight::Medium);
        l->fill = false;
        l->alignSelf = Align::Center;
        placeWin(*t.win, slot);
        t.win->fit();
        t.win->show();
        std::string s = slot;
        t.timer.setup(cfg().i("osdTimeout", 2000) + (slot == "message" ? 500 : 0), [this, s] { toasts[s].win.reset(); });
        t.timer.start();
    }
};

Osd::Osd(Screen *s) : screen(s), d(std::make_unique<Impl>()) {
    d->screen = s;
    d->settle.setup(1500, [] {});
    d->settle.start();
    d->sliderT.setup(2000, [this] { d->slider.reset(); d->sliderW = nullptr; });
    Impl *I = d.get();
    I->conns.on(Audio::get().changed, [this, I](const std::string &what) {
        if (I->settle.active()) return;
        showSlider(what == "mic" ? "mic" : "volume");
    });
    I->conns.on(Brightness::get().changed, [this, I] { if (!I->settle.active()) showSlider("brightness"); });
    I->conns.on(Brightness::get().kbdChanged, [this, I] { if (!I->settle.active()) showSlider("kbd"); });
    I->conns.on(Replay::get().saved, [this](const std::string &) { toast("message", "record", "Replay saved to Videos/Replays", true); });
    I->conns.on(Notifications::get().missedSummary, [this](int n) {
        toast("message", "bell", std::to_string(n) + (n == 1 ? " notification" : " notifications") + " while you were in fullscreen", true);
    });
    I->conns.on(ipc().ledToggled, [this](const std::string &which, bool on) {
        if (!cfg().b("lockToast", true)) return;
        toast("lock", which == "caps" ? "caps" : "hash", std::string(which == "caps" ? "Caps Lock " : "Num Lock ") + (on ? "on" : "off"), on);
    });
    I->lastProfile = Power::get().profile;
    I->conns.on(Power::get().changed, [this, I] {
        const std::string &p = Power::get().profile;
        if (p == I->lastProfile) return;
        I->lastProfile = p;
        if (I->settle.active()) return;
        toast("power", p == "power-saver" ? "leaf" : p == "performance" ? "bolt" : "gauge",
              p == "power-saver" ? "Power saver" : p == "performance" ? "Performance" : "Balanced", true);
    });
    I->conns.on(Battery::get().changed, [this, I] {
        auto &b = Battery::get();
        if (!b.present) return;
        if (I->batteryKnown && b.onBattery != I->lastOnBattery && !I->settle.active())
            toast("power", "bolt", b.onBattery ? "On battery" : "Charging", !b.onBattery);
        I->lastOnBattery = b.onBattery;
        I->batteryKnown = true;
    });
    // indicator placement changed in Settings: drop the open ones (rebuilt on next show)
    I->conns.on(cfg().changed, [I] {
        I->slider.reset();
        I->sliderW = nullptr;
        I->toasts.clear();
    });
}
Osd::~Osd() = default;

void Osd::toast(const std::string &slot, const std::string &icon, const std::string &text, bool on) { d->toast(slot, icon, text, on); }
void Osd::showSlider(const std::string &kind) { d->showSlider(kind); }

void broadcastToast(const std::string &text, const std::string &icon) {
    for (auto &s : shell().screens)
        if (s->osd) s->osd->toast("message", icon.empty() ? "check" : icon, text, true);
}

}  // namespace nova
