#include "dbus.hpp"

#include <cstdarg>
#include <poll.h>
#include <ctime>
#include <cstring>

namespace nova {

Bus &Bus::session() {
    static Bus b(false);
    return b;
}
Bus &Bus::system() {
    static Bus b(true);
    return b;
}
Bus::Bus(bool sys) {
    int r = sys ? sd_bus_open_system(&bus_) : sd_bus_open_user(&bus_);
    if (r < 0) {
        fprintf(stderr, "nova-shell: can't connect to the %s bus (%s)\n", sys ? "system" : "session", strerror(-r));
        bus_ = nullptr;
        return;
    }
    watch_ = ui::Loop::get().addFd(sd_bus_get_fd(bus_), POLLIN, [this](int, short) { process(); });
    // sd-bus may want POLLOUT or a timeout; refresh before every poll
    ui::Loop::get().addPrePoll([this] { updateWatch(); });
}
void Bus::process() {
    if (!bus_) return;
    while (sd_bus_process(bus_, nullptr) > 0) {}
}
void Bus::updateWatch() {
    if (!bus_) return;
    int ev = sd_bus_get_events(bus_);
    ui::Loop::get().setFdEvents(watch_, (short)(ev < 0 ? POLLIN : ev));
    uint64_t usec = 0;
    if (sd_bus_get_timeout(bus_, &usec) >= 0 && usec != UINT64_MAX) {
        timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);   // sd-bus timeouts are absolute CLOCK_MONOTONIC
        uint64_t now = (uint64_t)ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
        int ms = usec > now ? (int)((usec - now) / 1000) + 1 : 0;
        if (timer_) ui::Loop::get().removeTimer(timer_);
        timer_ = ui::Loop::get().addTimer(ms, [this] { timer_ = 0; process(); });
    }
}
void Bus::flushSoon() {
    if (bus_) sd_bus_flush(bus_);
}

namespace {
struct CallCtx { Bus::Reply cb; };
int callDone(sd_bus_message *m, void *userdata, sd_bus_error *) {
    auto *c = static_cast<CallCtx *>(userdata);
    const sd_bus_error *e = sd_bus_message_get_error(m);
    if (e) c->cb(nullptr, e->message ? e->message : (e->name ? e->name : "error"));
    else c->cb(m, "");
    delete c;
    return 1;
}
}  // namespace

void Bus::call(const std::string &dest, const std::string &path, const std::string &iface, const std::string &method, Reply cb,
               std::function<void(sd_bus_message *)> args) {
    if (!bus_) { if (cb) cb(nullptr, "no bus"); return; }
    sd_bus_message *m = nullptr;
    if (sd_bus_message_new_method_call(bus_, &m, dest.c_str(), path.c_str(), iface.c_str(), method.c_str()) < 0) {
        if (cb) cb(nullptr, "bad call");
        return;
    }
    if (args) args(m);
    auto *ctx = new CallCtx{cb ? std::move(cb) : [](sd_bus_message *, const std::string &) {}};
    if (sd_bus_call_async(bus_, nullptr, m, callDone, ctx, 25 * 1000 * 1000) < 0) {
        ctx->cb(nullptr, "call failed");
        delete ctx;
    }
    sd_bus_message_unref(m);
}

void Bus::getAll(const std::string &dest, const std::string &path, const std::string &iface, std::function<void(sd_bus_message *)> cb) {
    call(dest, path, "org.freedesktop.DBus.Properties", "GetAll",
         [cb](sd_bus_message *r, const std::string &) { cb(r); },
         [iface](sd_bus_message *m) { sd_bus_message_append(m, "s", iface.c_str()); });
}

void Bus::setProperty(const std::string &dest, const std::string &path, const std::string &iface, const std::string &prop, const char *type, ...) {
    if (!bus_) return;
    sd_bus_message *m = nullptr;
    if (sd_bus_message_new_method_call(bus_, &m, dest.c_str(), path.c_str(), "org.freedesktop.DBus.Properties", "Set") < 0) return;
    sd_bus_message_append(m, "ss", iface.c_str(), prop.c_str());
    sd_bus_message_open_container(m, 'v', type);
    va_list ap;
    va_start(ap, type);
    sd_bus_message_appendv(m, type, ap);
    va_end(ap);
    sd_bus_message_close_container(m);
    sd_bus_call_async(bus_, nullptr, m, nullptr, nullptr, 0);
    sd_bus_message_unref(m);
}

static int matchCb(sd_bus_message *m, void *userdata, sd_bus_error *) {
    auto *fn = static_cast<std::function<void(sd_bus_message *)> *>(userdata);
    (*fn)(m);
    return 0;
}
int Bus::match(const std::string &rule, std::function<void(sd_bus_message *)> cb) {
    if (!bus_) return 0;
    auto s = std::make_unique<Slot>();
    s->id = ++next_;
    s->fn = std::move(cb);
    if (sd_bus_add_match(bus_, &s->slot, rule.c_str(), matchCb, &s->fn) < 0) return 0;
    slots_.push_back(std::move(s));
    return next_;
}
void Bus::unsubscribe(int id) {
    for (auto it = slots_.begin(); it != slots_.end(); ++it)
        if ((*it)->id == id) {
            sd_bus_slot_unref((*it)->slot);
            slots_.erase(it);
            return;
        }
}
int Bus::watchName(const std::string &name, std::function<void(bool)> cb) {
    int id = match("type='signal',sender='org.freedesktop.DBus',interface='org.freedesktop.DBus',member='NameOwnerChanged',arg0='" + name + "'",
                   [cb](sd_bus_message *m) {
                       const char *n, *oldo, *newo;
                       if (sd_bus_message_read(m, "sss", &n, &oldo, &newo) >= 0) cb(newo && *newo);
                   });
    call("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "NameHasOwner",
         [cb](sd_bus_message *r, const std::string &) {
             int has = 0;
             if (r) sd_bus_message_read(r, "b", &has);
             cb(has);
         },
         [name](sd_bus_message *m) { sd_bus_message_append(m, "s", name.c_str()); });
    return id;
}
void Bus::listNames(std::function<void(const std::vector<std::string> &)> cb) {
    call("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "ListNames", [cb](sd_bus_message *r, const std::string &) {
        std::vector<std::string> out;
        if (r && sd_bus_message_enter_container(r, 'a', "s") >= 0) {
            const char *s;
            while (sd_bus_message_read(r, "s", &s) > 0) out.push_back(s);
            sd_bus_message_exit_container(r);
        }
        cb(out);
    });
}
bool Bus::requestName(const std::string &name) {
    if (!bus_) return false;
    return sd_bus_request_name(bus_, name.c_str(), 0) >= 0;
}

// ---------------------------------------------------------------- readers --
void forEachProperty(sd_bus_message *m, const std::function<void(const std::string &, sd_bus_message *)> &fn) {
    if (!m || sd_bus_message_enter_container(m, 'a', "{sv}") < 0) return;
    while (sd_bus_message_enter_container(m, 'e', "sv") > 0) {
        const char *name = nullptr;
        sd_bus_message_read(m, "s", &name);
        fn(name ? name : "", m);
        sd_bus_message_exit_container(m);
    }
    sd_bus_message_exit_container(m);
}
void skipVariant(sd_bus_message *m) { sd_bus_message_skip(m, "v"); }

std::string readVariantString(sd_bus_message *m) {
    const char *contents = nullptr;
    char type = 0;
    std::string out;
    if (sd_bus_message_peek_type(m, &type, &contents) < 0 || type != 'v' || !contents) { sd_bus_message_skip(m, nullptr); return out; }
    std::string c = contents;
    if (c == "s" || c == "o" || c == "g") {
        const char *s = nullptr;
        sd_bus_message_read(m, "v", c.c_str(), &s);
        if (s) out = s;
    } else {
        double d = readVariantNumber(m);
        out = std::to_string(d);
    }
    return out;
}
double readVariantNumber(sd_bus_message *m) {
    const char *contents = nullptr;
    char type = 0;
    if (sd_bus_message_peek_type(m, &type, &contents) < 0 || type != 'v' || !contents) { sd_bus_message_skip(m, nullptr); return 0; }
    std::string c = contents;
    if (c == "d") { double v = 0; sd_bus_message_read(m, "v", "d", &v); return v; }
    if (c == "i") { int32_t v = 0; sd_bus_message_read(m, "v", "i", &v); return v; }
    if (c == "u") { uint32_t v = 0; sd_bus_message_read(m, "v", "u", &v); return v; }
    if (c == "x") { int64_t v = 0; sd_bus_message_read(m, "v", "x", &v); return (double)v; }
    if (c == "t") { uint64_t v = 0; sd_bus_message_read(m, "v", "t", &v); return (double)v; }
    if (c == "y") { uint8_t v = 0; sd_bus_message_read(m, "v", "y", &v); return v; }
    if (c == "b") { int v = 0; sd_bus_message_read(m, "v", "b", &v); return v; }
    if (c == "n") { int16_t v = 0; sd_bus_message_read(m, "v", "n", &v); return v; }
    if (c == "q") { uint16_t v = 0; sd_bus_message_read(m, "v", "q", &v); return v; }
    sd_bus_message_skip(m, "v");
    return 0;
}
bool readVariantBool(sd_bus_message *m) { return readVariantNumber(m) != 0; }
std::vector<std::string> readVariantStrings(sd_bus_message *m) {
    std::vector<std::string> out;
    const char *contents = nullptr;
    char type = 0;
    if (sd_bus_message_peek_type(m, &type, &contents) < 0 || type != 'v' || !contents || std::string(contents) != "as") {
        sd_bus_message_skip(m, "v");
        return out;
    }
    sd_bus_message_enter_container(m, 'v', "as");
    sd_bus_message_enter_container(m, 'a', "s");
    const char *s;
    while (sd_bus_message_read(m, "s", &s) > 0) out.push_back(s);
    sd_bus_message_exit_container(m);
    sd_bus_message_exit_container(m);
    return out;
}

}  // namespace nova
