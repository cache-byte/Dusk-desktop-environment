// Installed apps (.desktop files), open windows (wlr-foreign-toplevel), idle timers
// (ext-idle-notify), clipboard history (cliphist) and password checks (PAM, in a child).
#pragma once
#include "config.hpp"

struct zwlr_foreign_toplevel_handle_v1;
struct ext_idle_notification_v1;

namespace nova {

// ------------------------------------------------------------------- apps --
struct App {
    std::string id;             // firefox, org.gnome.Nautilus
    std::string name, genericName, comment, icon, exec, path, wmClass;
    std::vector<std::string> keywords, categories;
    bool terminal = false, noDisplay = false;
    bool isGame() const;
    bool isGameLauncher() const;
};

class Apps {
public:
    static Apps &get();
    void start();
    const std::vector<App> &all() const { return apps_; }
    const App *byId(const std::string &id) const;
    const App *lookup(const std::string &appId) const;   // window app id / pinned id -> app (fuzzy)
    void launch(const App &a, bool onDedicatedGpu = false);
    // search ranking: name first (exact > starts with > word starts > contains), then generic
    // name and keywords; descriptions only when nothing else matches
    std::vector<const App *> search(const std::string &query) const;
    ui::Signal<> changed;
private:
    std::vector<App> apps_;
    void scan();
};

// -------------------------------------------------------------- toplevels --
struct Toplevel {
    zwlr_foreign_toplevel_handle_v1 *handle = nullptr;
    std::string appId, title;
    bool activated = false, minimized = false, maximized = false, fullscreen = false;
    bool done = false;
    void activate();
    void setMinimized(bool m);
    void close();
};

class Toplevels {
public:
    static Toplevels &get();
    void start();
    std::vector<std::unique_ptr<Toplevel>> list;
    std::vector<Toplevel *> forApp(const std::string &appId) const;   // matching windows (fuzzy ids)
    ui::Signal<> changed;
};

// ------------------------------------------------------------------- idle --
// Dim, lock and sleep after inactivity, separately on battery and plugged in.
class Idle {
public:
    static Idle &get();
    void start();
    bool caffeine = false;
    void setCaffeine(bool on);
    ui::Signal<> changed;
    // used by the protocol callbacks
    void idled(int which);
    void resumed(int which);
private:
    ext_idle_notification_v1 *n_[3] = {nullptr, nullptr, nullptr};
    int mins_[3] = {0, 0, 0};
    double savedBrightness_ = -1;
    void apply();
};

// -------------------------------------------------------------- clipboard --
struct ClipItem {
    std::string id, preview;
    bool image = false;
};
class ClipHistory {
public:
    static ClipHistory &get();
    void refresh(std::function<void()> done = {});
    std::vector<ClipItem> items;
    void copy(const ClipItem &i);
    void remove(const ClipItem &i);
    void wipe();
};

// ------------------------------------------------------------------- auth --
// Checks the user's password with PAM ("nova-lock" service) in a child process so the UI
// never blocks (PAM waits ~2 s after a wrong password).
void checkPassword(const std::string &password, std::function<void(bool ok, const std::string &msg)> done);

}  // namespace nova
