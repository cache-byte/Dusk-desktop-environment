#include "services.hpp"
#include "dbus.hpp"
#include "novaipc.hpp"

#include <dirent.h>
#include <filesystem>
#include <functional>

namespace fs = std::filesystem;

namespace nova {

using ui::Loop;
using ui::Process;

// ===================================================================== Audio ==
Audio &Audio::get() { static Audio a; return a; }
void Audio::start() {
    refresh(false);
    // PipeWire's pulse server reports every change; re-read on sink/source events
    if (ui::haveProgram("pactl"))
        sub_ = Process::lines({"pactl", "subscribe"}, [this](const std::string &l) {
            if (l.find("sink") == std::string::npos && l.find("source") == std::string::npos && l.find("server") == std::string::npos) return;
            if (debounce_ && Loop::get().timerActive(debounce_)) return;
            debounce_ = Loop::get().addTimer(30, [this] { refresh(true); });
        });
    else Loop::get().addTimer(1500, [this] { refresh(true); }, true);
}
static void parseWpctl(const std::string &out, double &vol, bool &muted) {
    // "Volume: 0.45 [MUTED]"
    auto p = out.find("Volume:");
    if (p == std::string::npos) return;
    vol = atof(out.c_str() + p + 7);
    muted = out.find("MUTED") != std::string::npos;
}
void Audio::refresh(bool notify) {
    Process::run({"wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"}, [this, notify](int, const std::string &out) {
        double v = volume;
        bool m = muted;
        parseWpctl(out, v, m);
        bool ch = v != volume || m != muted;
        volume = v; muted = m; ready = true;
        if (ch && notify) changed.emit("volume");
        else if (ch) changed.emit("");
    });
    Process::run({"wpctl", "get-volume", "@DEFAULT_AUDIO_SOURCE@"}, [this, notify](int, const std::string &out) {
        double v = micVolume;
        bool m = micMuted;
        parseWpctl(out, v, m);
        bool ch = v != micVolume || m != micMuted;
        bool muteCh = m != micMuted;
        micVolume = v; micMuted = m;
        if (ch) changed.emit(notify && muteCh ? "mic" : "");
    });
}
void Audio::setVolume(double v) {
    v = std::clamp(v, 0.0, maxVolume());
    volume = v;
    muted = false;
    char buf[32];
    snprintf(buf, sizeof buf, "%.3f", v);
    ui::spawn({"wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "0"});
    ui::spawn({"wpctl", "set-volume", "-l", "1.5", "@DEFAULT_AUDIO_SINK@", buf});
    changed.emit("volume");
}
void Audio::setMicVolume(double v) {
    v = std::clamp(v, 0.0, 1.0);
    micVolume = v;
    char buf[32];
    snprintf(buf, sizeof buf, "%.3f", v);
    ui::spawn({"wpctl", "set-volume", "@DEFAULT_AUDIO_SOURCE@", buf});
    changed.emit("");
}
void Audio::toggleMute() {
    muted = !muted;
    ui::spawn({"wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"});
    changed.emit("volume");
}
void Audio::toggleMic() {
    micMuted = !micMuted;
    ui::spawn({"wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", "toggle"});
    changed.emit("mic");
}

// ================================================================ Brightness ==
Brightness &Brightness::get() { static Brightness b; return b; }
static std::string firstEntry(const std::string &dir, const std::string &contains = "") {
    std::error_code ec;
    for (auto &e : fs::directory_iterator(dir, ec)) {
        std::string n = e.path().filename().string();
        if (contains.empty() || n.find(contains) != std::string::npos) return n;
    }
    return "";
}
static int readInt(const std::string &path, int fallback = 0) {
    bool ok = false;
    std::string t = ui::readFile(path, &ok);
    return ok ? atoi(t.c_str()) : fallback;
}
void Brightness::start() {
    device_ = firstEntry("/sys/class/backlight");
    if (!device_.empty()) max_ = std::max(1, readInt("/sys/class/backlight/" + device_ + "/max_brightness", 1));
    kbdDevice_ = firstEntry("/sys/class/leds", "kbd_backlight");
    if (!kbdDevice_.empty()) kbdMax = readInt("/sys/class/leds/" + kbdDevice_ + "/max_brightness", 0);
    poll();
    // sysfs files can't be watched; a tiny read every 300 ms is enough for the OSD
    Loop::get().addTimer(300, [this] { poll(); }, true);
}
void Brightness::poll() {
    if (!device_.empty()) {
        int c = readInt("/sys/class/backlight/" + device_ + "/brightness", cur_);
        if (c != cur_) {
            bool first = cur_ < 0;
            cur_ = c;
            value = (double)c / max_;
            if (!first) changed.emit();
        }
    }
    if (!kbdDevice_.empty()) {
        int k = readInt("/sys/class/leds/" + kbdDevice_ + "/brightness", kbdLevel);
        if (k != kbdLevel) { kbdLevel = k; kbdChanged.emit(); }
    }
}
void Brightness::set(double v) {
    v = std::clamp(v, 0.01, 1.0);
    value = v;
    ui::spawn({"brightnessctl", "-q", "set", std::to_string((int)std::lround(v * 100)) + "%"});
}
void Brightness::setKbd(int level) {
    if (kbdDevice_.empty()) return;
    ui::spawn({"brightnessctl", "-q", "--device=" + kbdDevice_, "set", std::to_string(std::clamp(level, 0, kbdMax))});
}

// ======================================================================= Net ==
Net &Net::get() { static Net n; return n; }
void Net::start() {
    refresh();
    if (ui::haveProgram("nmcli"))
        monitor_ = Process::lines({"nmcli", "monitor"}, [this](const std::string &) {
            if (debounce_ && Loop::get().timerActive(debounce_)) return;
            debounce_ = Loop::get().addTimer(400, [this] { refresh(); });
        });
    Loop::get().addTimer(15000, [this] { refresh(); }, true);   // signal strength
}
void Net::refresh() {
    Process::run({"sh", "-c", "nmcli radio wifi; nmcli radio wwan 2>/dev/null; nmcli -t -f ACTIVE,SSID,SIGNAL dev wifi 2>/dev/null | grep '^yes'; "
                              "nmcli -t -f TYPE,STATE dev | grep '^ethernet:connected'"},
                 [this](int, const std::string &out) {
                     auto lines = ui::split(out, '\n');
                     wifiEnabled = !lines.empty() && ui::trim(lines[0]) == "enabled";
                     ssid.clear();
                     signal = 0;
                     wired = false;
                     for (auto &l : lines) {
                         if (ui::startsWith(l, "yes:")) {
                             // SSIDs may contain ':' (escaped as \:)
                             auto rest = l.substr(4);
                             auto p = rest.rfind(':');
                             ssid = ui::replaceAll(rest.substr(0, p), "\\:", ":");
                             signal = atoi(rest.c_str() + p + 1);
                         }
                         if (ui::startsWith(l, "ethernet:connected")) wired = true;
                     }
                     changed.emit();
                 });
}
void Net::setWifi(bool on) {
    wifiEnabled = on;
    ui::spawn({"nmcli", "radio", "wifi", on ? "on" : "off"});
    changed.emit();
    Loop::get().addTimer(1200, [this] { refresh(); });
}
void Net::setAirplane(bool on) {
    airplane = on;
    ui::spawn({"nmcli", "radio", "all", on ? "off" : "on"});
    if (on) Bluetooth::get().setPowered(false);
    changed.emit();
    Loop::get().addTimer(1200, [this] { refresh(); });
}

// =================================================================== Battery ==
Battery &Battery::get() { static Battery b; return b; }
void Battery::start() {
    load();
    Bus &sys = Bus::system();
    sys.match("type='signal',sender='org.freedesktop.UPower',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged'",
              [this](sd_bus_message *) { load(); });
}
void Battery::load() {
    Bus &sys = Bus::system();
    sys.getAll("org.freedesktop.UPower", "/org/freedesktop/UPower/devices/DisplayDevice", "org.freedesktop.UPower.Device", [this](sd_bus_message *m) {
        if (!m) return;
        uint32_t type = 0, state = 0;
        bool isPresent = false;
        forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
            if (k == "Percentage") percentage = readVariantNumber(v);
            else if (k == "State") state = (uint32_t)readVariantNumber(v);
            else if (k == "Type") type = (uint32_t)readVariantNumber(v);
            else if (k == "IsPresent") isPresent = readVariantBool(v);
            else if (k == "TimeToEmpty") timeToEmpty = (int64_t)readVariantNumber(v);
            else if (k == "TimeToFull") timeToFull = (int64_t)readVariantNumber(v);
            else skipVariant(v);
        });
        present = isPresent && type == 2;
        charging = state == 1 || state == 5;
        full = state == 4;
        changed.emit();
    });
    sys.getAll("org.freedesktop.UPower", "/org/freedesktop/UPower", "org.freedesktop.UPower", [this](sd_bus_message *m) {
        if (!m) return;
        forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
            if (k == "OnBattery") onBattery = readVariantBool(v);
            else skipVariant(v);
        });
        changed.emit();
    });
}

// ================================================================= Bluetooth ==
Bluetooth &Bluetooth::get() { static Bluetooth b; return b; }
void Bluetooth::start() {
    Bus &sys = Bus::system();
    sys.watchName("org.bluez", [this](bool present) {
        available = present;
        if (present) load();
        else { powered = false; changed.emit(); }
    });
    sys.match("type='signal',sender='org.bluez',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged'",
              [this](sd_bus_message *) { load(); });
}
void Bluetooth::load() {
    // adapters and devices via the object manager
    Bus::system().call("org.bluez", "/", "org.freedesktop.DBus.ObjectManager", "GetManagedObjects", [this](sd_bus_message *r, const std::string &) {
        if (!r) return;
        std::string adapter, connected;
        bool pw = false;
        if (sd_bus_message_enter_container(r, 'a', "{oa{sa{sv}}}") < 0) return;
        while (sd_bus_message_enter_container(r, 'e', "oa{sa{sv}}") > 0) {
            const char *path;
            sd_bus_message_read(r, "o", &path);
            sd_bus_message_enter_container(r, 'a', "{sa{sv}}");
            while (sd_bus_message_enter_container(r, 'e', "sa{sv}") > 0) {
                const char *iface;
                sd_bus_message_read(r, "s", &iface);
                std::string ifc = iface;
                std::string name;
                bool conn = false;
                forEachProperty(r, [&](const std::string &k, sd_bus_message *v) {
                    if (ifc == "org.bluez.Adapter1" && k == "Powered") pw = readVariantBool(v);
                    else if (ifc == "org.bluez.Device1" && k == "Connected") conn = readVariantBool(v);
                    else if (ifc == "org.bluez.Device1" && (k == "Alias" || k == "Name")) { std::string n = readVariantString(v); if (name.empty() || k == "Alias") name = n; }
                    else skipVariant(v);
                });
                if (ifc == "org.bluez.Adapter1" && adapter.empty()) adapter = path;
                if (ifc == "org.bluez.Device1" && conn && connected.empty()) connected = name;
                sd_bus_message_exit_container(r);
            }
            sd_bus_message_exit_container(r);
            sd_bus_message_exit_container(r);
        }
        adapter_ = adapter;
        available = !adapter.empty();
        powered = pw;
        connectedName = connected;
        changed.emit();
    });
}
void Bluetooth::setPowered(bool on) {
    if (adapter_.empty()) return;
    powered = on;
    Bus::system().setProperty("org.bluez", adapter_, "org.bluez.Adapter1", "Powered", "b", (int)on);
    changed.emit();
}

// ===================================================================== Power ==
Power &Power::get() { static Power p; return p; }
void Power::start() {
    refresh();
    Bus::system().match("type='signal',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged',path='/org/freedesktop/UPower/PowerProfiles'",
                        [this](sd_bus_message *) { refresh(); });
    Bus::system().match("type='signal',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged',path='/net/hadess/PowerProfiles'",
                        [this](sd_bus_message *) { refresh(); });
}
void Power::refresh() {
    Process::run({"nova-power", "get"}, [this](int code, const std::string &out) {
        std::string p = ui::trim(out);
        available = code == 0 && !p.empty();
        if (available && p != profile) { profile = p; changed.emit(); }
        else if (available) changed.emit();
    });
}
void Power::set(const std::string &p) {
    profile = p;
    ui::spawn({"nova-power", "set", p});
    changed.emit();
}

// ===================================================================== Media ==
Media &Media::get() { static Media m; return m; }
double Player::positionNow() const {
    if (!playing) return position;
    return std::min(length > 0 ? length : 1e9, position + (ui::nowMs() - positionAt) / 1000.0);
}
std::string Media::fmt(double sec) {
    if (!std::isfinite(sec) || sec < 0) return "0:00";
    int m = (int)sec / 60, s = (int)sec % 60;
    char b[16];
    snprintf(b, sizeof b, "%d:%02d", m, s);
    return b;
}
Player *Media::player() {
    auto find = [&](auto pred) -> Player * { for (auto &p : players) if (pred(p)) return &p; return nullptr; };
    if (Player *p = find([&](Player &x) { return x.bus == chosen_; })) return p;
    if (Player *p = find([&](Player &x) { return x.playing && x.bus == last_; })) return p;
    if (Player *p = find([](Player &x) { return x.playing; })) return p;
    if (Player *p = find([&](Player &x) { return x.bus == last_; })) return p;
    return players.empty() ? nullptr : &players[0];
}
void Media::start() {
    Bus &b = Bus::session();
    b.listNames([this](const std::vector<std::string> &names) {
        for (auto &n : names) if (ui::startsWith(n, "org.mpris.MediaPlayer2.")) addPlayer(n);
    });
    b.match("type='signal',sender='org.freedesktop.DBus',interface='org.freedesktop.DBus',member='NameOwnerChanged',arg0namespace='org.mpris.MediaPlayer2'",
            [this](sd_bus_message *m) {
                const char *n, *o, *nw;
                if (sd_bus_message_read(m, "sss", &n, &o, &nw) < 0) return;
                if (nw && *nw) addPlayer(n);
                else removePlayer(n);
            });
    b.match("type='signal',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged',path='/org/mpris/MediaPlayer2'",
            [this](sd_bus_message *m) {
                // the sender is a unique name: refresh the player that owns it
                std::string sender = sd_bus_message_get_sender(m) ? sd_bus_message_get_sender(m) : "";
                for (auto &p : players) {
                    Bus::session().call("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "GetNameOwner",
                                        [this, sender, bus = p.bus](sd_bus_message *r, const std::string &) {
                                            const char *owner = nullptr;
                                            if (r && sd_bus_message_read(r, "s", &owner) >= 0 && owner && sender == owner) loadProps(bus);
                                        },
                                        [bus = p.bus](sd_bus_message *mm) { sd_bus_message_append(mm, "s", bus.c_str()); });
                }
            });
    b.match("type='signal',interface='org.mpris.MediaPlayer2.Player',member='Seeked'", [this](sd_bus_message *) {
        for (auto &p : players) loadProps(p.bus);
    });
    // MPRIS doesn't push the position: re-sync once a second while something plays
    Loop::get().addTimer(1000, [this] { positionTick(); }, true);
}
void Media::addPlayer(const std::string &bus) {
    for (auto &p : players) if (p.bus == bus) return;
    Player p;
    p.bus = bus;
    p.identity = bus.substr(strlen("org.mpris.MediaPlayer2."));
    players.push_back(p);
    loadProps(bus);
    Bus::session().getAll(bus, "/org/mpris/MediaPlayer2", "org.mpris.MediaPlayer2", [this, bus](sd_bus_message *m) {
        if (!m) return;
        forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
            if (k == "Identity") { std::string id = readVariantString(v); for (auto &p : players) if (p.bus == bus) p.identity = id; }
            else skipVariant(v);
        });
        changed.emit();
    });
}
void Media::removePlayer(const std::string &bus) {
    std::erase_if(players, [&](const Player &p) { return p.bus == bus; });
    if (chosen_ == bus) chosen_.clear();
    changed.emit();
    loadArt();
}
void Media::parseProps(Player &p, sd_bus_message *m) {
    forEachProperty(m, [&](const std::string &k, sd_bus_message *v) {
        if (k == "PlaybackStatus") {
            bool was = p.playing;
            p.playing = readVariantString(v) == "Playing";
            if (p.playing && !was) { last_ = p.bus; if (chosen_ != last_) chosen_.clear(); }
        } else if (k == "CanSeek") p.canSeek = readVariantBool(v);
        else if (k == "CanGoNext") p.canNext = readVariantBool(v);
        else if (k == "CanGoPrevious") p.canPrev = readVariantBool(v);
        else if (k == "Position") { p.position = readVariantNumber(v) / 1e6; p.positionAt = ui::nowMs(); }
        else if (k == "Metadata") {
            p.title.clear(); p.artist.clear(); p.album.clear(); p.artUrl.clear(); p.url.clear(); p.length = 0;
            if (sd_bus_message_enter_container(v, 'v', "a{sv}") < 0) { skipVariant(v); return; }
            forEachProperty(v, [&](const std::string &mk, sd_bus_message *mv) {
                if (mk == "xesam:title") p.title = readVariantString(mv);
                else if (mk == "xesam:album") p.album = readVariantString(mv);
                else if (mk == "mpris:artUrl") p.artUrl = readVariantString(mv);
                else if (mk == "xesam:url") p.url = readVariantString(mv);
                else if (mk == "mpris:trackid") p.trackId = readVariantString(mv);
                else if (mk == "mpris:length") p.length = readVariantNumber(mv) / 1e6;
                else if (mk == "xesam:artist") {
                    auto a = readVariantStrings(mv);
                    std::string s;
                    for (auto &x : a) s += (s.empty() ? "" : ", ") + x;
                    p.artist = s;
                } else skipVariant(mv);
            });
            sd_bus_message_exit_container(v);
        } else skipVariant(v);
    });
}
void Media::loadProps(const std::string &bus) {
    Bus::session().getAll(bus, "/org/mpris/MediaPlayer2", "org.mpris.MediaPlayer2.Player", [this, bus](sd_bus_message *m) {
        if (!m) return;
        for (auto &p : players)
            if (p.bus == bus) parseProps(p, m);
        changed.emit();
        loadArt();
    });
}
void Media::positionTick() {
    for (auto &p : players)
        if (p.playing) {
            std::string bus = p.bus;
            Bus::session().call(bus, "/org/mpris/MediaPlayer2", "org.freedesktop.DBus.Properties", "Get",
                                [this, bus](sd_bus_message *r, const std::string &) {
                                    if (!r) return;
                                    double pos = readVariantNumber(r) / 1e6;
                                    for (auto &x : players) if (x.bus == bus) { x.position = pos; x.positionAt = ui::nowMs(); }
                                },
                                [](sd_bus_message *mm) { sd_bus_message_append(mm, "ss", "org.mpris.MediaPlayer2.Player", "Position"); });
        }
}
static void playerCall(const std::string &bus, const char *method) {
    Bus::session().call(bus, "/org/mpris/MediaPlayer2", "org.mpris.MediaPlayer2.Player", method, nullptr);
}
void Media::playPause() { if (Player *p = player()) playerCall(p->bus, "PlayPause"); }
void Media::next() { if (Player *p = player()) playerCall(p->bus, "Next"); }
void Media::previous() { if (Player *p = player()) playerCall(p->bus, "Previous"); }
void Media::seek(double seconds) {
    Player *p = player();
    if (!p || !p->canSeek) return;
    std::string track = p->trackId.empty() ? "/org/mpris/MediaPlayer2/TrackList/NoTrack" : p->trackId;
    int64_t us = (int64_t)(seconds * 1e6);
    Bus::session().call(p->bus, "/org/mpris/MediaPlayer2", "org.mpris.MediaPlayer2.Player", "SetPosition", nullptr,
                        [track, us](sd_bus_message *m) { sd_bus_message_append(m, "ox", track.c_str(), us); });
    p->position = seconds;
    p->positionAt = ui::nowMs();
    changed.emit();
}
void Media::loadArt() {
    Player *p = player();
    std::string url = p ? p->artUrl : "";
    if (url == artFor_) return;
    artFor_ = url;
    if (url.empty()) { art.reset(); changed.emit(); return; }
    if (ui::startsWith(url, "file://")) {
        std::string path = url.substr(7);
        art = std::make_shared<ui::Image>(path, 256, 256);
        changed.emit();
        return;
    }
    // http(s): download once into the cache
    std::string dir = ui::homeDir() + "/.cache/nova/art";
    fs::create_directories(dir);
    std::string file = dir + "/" + std::to_string(std::hash<std::string>{}(url));
    if (fs::exists(file)) { art = std::make_shared<ui::Image>(file, 256, 256); changed.emit(); return; }
    Process::run({"curl", "-fsSL", "--max-time", "8", "-o", file, url}, [this, file, url](int code, const std::string &) {
        if (code != 0 || url != artFor_) return;
        art = std::make_shared<ui::Image>(file, 256, 256);
        changed.emit();
    });
}

// ==================================================================== Lyrics ==
Lyrics &Lyrics::get() { static Lyrics l; return l; }
void Lyrics::start() {
    Media::get().changed.connect([this] { check(); });
    cfg().changed.connect([this] { check(); });
}
void Lyrics::check() {
    Player *p = Media::get().player();
    std::string k = p ? p->artist + "|" + p->title : "";
    if (k == key_) return;
    key_ = k;
    lines.clear(); plain.clear(); source.clear();
    changed.emit();
    if (timer_) Loop::get().removeTimer(timer_);
    timer_ = Loop::get().addTimer(400, [this] { load(); });
}
void Lyrics::load() {
    Player *p = Media::get().player();
    if (!wanted() || !p || p->title.empty()) return;
    loading = true;
    std::vector<std::string> argv = {"nova-lyrics", "--title", p->title, "--artist", p->artist, "--album", p->album,
                                     "--duration", std::to_string((int)std::lround(p->length)), "--url", p->url};
    if (cfg().b("lyricsSongRec", true)) argv.push_back("--songrec");
    std::string forKey = key_;
    Process::run(argv, [this, forKey](int, const std::string &out) {
        loading = false;
        if (forKey != key_) return;    // the song changed meanwhile
        try {
            json d = json::parse(out);
            lines.clear();
            for (auto &l : d.value("synced", json::array()))
                if (l.is_array() && l.size() >= 2) lines.push_back({l[0].get<double>(), l[1].get<std::string>()});
            plain = d.value("plain", "");
            source = d.value("source", "");
        } catch (...) {}
        changed.emit();
    });
}
int Lyrics::current() const {
    Player *p = Media::get().player();
    if (!p) return -1;
    double t = p->positionNow() + cfg().d("lyricsOffset", 0);
    int i = -1;
    for (size_t k = 0; k < lines.size(); k++) {
        if (lines[k].first <= t) i = (int)k;
        else break;
    }
    return i;
}
double Lyrics::progress() const {
    int c = current();
    Player *p = Media::get().player();
    if (c < 0 || !p) return 0;
    double t = p->positionNow() + cfg().d("lyricsOffset", 0);
    double start = lines[c].first, end = c + 1 < (int)lines.size() ? lines[c + 1].first : start + 4;
    return std::clamp((t - start) / std::max(0.5, end - start), 0.0, 1.0);
}

// ====================================================================== Cava ==
Cava &Cava::get() { static Cava c; return c; }
void Cava::use(int d) {
    users_ = std::max(0, users_ + d);
    restart();
}
void Cava::restart() {
    bool want = users_ > 0 && Media::get().playing() && ui::haveProgram("cava");
    static int conn = 0;
    if (!conn) conn = Media::get().changed.connect([this] {
        bool want2 = users_ > 0 && Media::get().playing();
        if (want2 != (proc_ && proc_->running())) restart();
    });
    if (proc_) { proc_->kill(); proc_.reset(); }
    values.clear();
    if (!want) { frame.emit(); return; }
    int bars = cfg().i("vizBars", 32);
    int fps = Battery::get().onBattery ? 20 : 30;
    int sens = (int)std::lround(40 + cfg().d("vizSensitivity", 0.55) * 160);
    std::string conf = "[general]\nbars = " + std::to_string(bars) + "\nframerate = " + std::to_string(fps) +
                       "\nsensitivity = " + std::to_string(sens) +
                       "\n[input]\nmethod = pipewire\nsource = auto\n[output]\nmethod = raw\nraw_target = /dev/stdout\n"
                       "data_format = ascii\nascii_max_range = 1000\nbar_delimiter = 59\nframe_delimiter = 10\n"
                       "[smoothing]\nnoise_reduction = 66\n";
    std::string path = ui::runtimeDir() + "/nova-cava.conf";
    ui::writeFile(path, conf);
    proc_ = Process::lines({"cava", "-p", path}, [this, bars](const std::string &l) {
        std::vector<double> v;
        for (auto &x : ui::split(l, ';')) if (!x.empty() && isdigit((unsigned char)x[0])) v.push_back(atoi(x.c_str()) / 1000.0);
        if ((int)v.size() < bars / 2) return;   // a torn line: keep the last good frame
        values = std::move(v);
        frame.emit();
    });
}

// ================================================================= Recorder ==
Recorder &Recorder::get() { static Recorder r; return r; }
void Recorder::start() {
    // nova-record keeps a pid file while recording
    Loop::get().addTimer(1000, [this] {
        std::string pidf = ui::runtimeDir() + "/nova-record.pid";
        bool ok = false;
        std::string pid = ui::trim(ui::readFile(pidf, &ok));
        bool rec = ok && !pid.empty() && fs::exists("/proc/" + pid);
        if (rec != recording) { recording = rec; changed.emit(); }
    }, true);
}

// =================================================================== Replay ==
Replay &Replay::get() { static Replay r; return r; }
void Replay::start() {
    apply();
    cfg().changed.connect([this] { apply(); });
    ipc().shellAction.connect([this](const std::string &a) { if (a == "save-replay") save(); });
}
void Replay::apply() {
    bool want = cfg().b("replayEnabled", false) && ui::haveProgram("gpu-screen-recorder");
    static std::string running;
    std::string sig = std::to_string(cfg().i("replaySeconds", 30)) + cfg().s("recordFormat", "mp4") + (cfg().b("recordMic", false) ? "m" : "");
    if (want && proc_ && proc_->running() && sig == running) return;
    if (proc_) { proc_->kill(2); proc_.reset(); }
    if (!want) return;
    running = sig;
    std::string dir = ui::homeDir() + "/Videos/Replays";
    fs::create_directories(dir);
    std::vector<std::string> argv = {"gpu-screen-recorder", "-w", "screen", "-f", "60", "-c", cfg().s("recordFormat", "mp4") == "mkv" ? "mkv" : "mp4",
                                     "-a", "default_output", "-r", std::to_string(cfg().i("replaySeconds", 30)), "-o", dir};
    if (cfg().b("recordMic", false)) { argv.push_back("-a"); argv.push_back("default_input"); }
    proc_ = Process::lines(argv, [this](const std::string &l) {
        std::string t = ui::trim(l);
        if (ui::startsWith(t, "/")) saved.emit(t);
    });
}
void Replay::save() {
    if (proc_ && proc_->running()) kill(proc_->pid(), SIGUSR1);
}

// =================================================================== Gaming ==
Gaming &Gaming::get() { static Gaming g; return g; }
void Gaming::start() {
    ipc().fullscreenChanged.connect([this](bool fs) {
        if (fs && cfg().b("gameModeAuto", true)) {
            if (!timer_) timer_ = Loop::get().addTimer(4000, [this] { check(); }, true);
            check();
        } else {
            if (timer_) { Loop::get().removeTimer(timer_); timer_ = 0; }
            setActive(false);
        }
    });
}
void Gaming::check() {
    Process::run({"sh", "-c", "gamemoded -s 2>/dev/null"}, [this](int, const std::string &out) { setActive(out.find("is active") != std::string::npos); });
}
void Gaming::setActive(bool on) {
    if (on == active) return;
    active = on;
    changed.emit();
    if (on) {
        saved_ = Power::get().profile;
        Power::get().set("performance");
    } else if (!saved_.empty()) {
        Power::get().set(saved_);
    }
}

}  // namespace nova
