// Settings shared with the Settings app: ~/.config/nova/settings.json on top of
// /usr/share/nova/defaults.json. Watched for changes; the shell writes back a few keys
// (do not disturb, control-centre layout, pinned apps…).
#pragma once
#include "ui/core.hpp"

#include <nlohmann/json.hpp>

namespace nova {

using json = nlohmann::json;

class Config {
public:
    static Config &get();
    void load();
    const json &all() const { return merged_; }
    // typed access with a fallback
    template <typename T> T value(const std::string &key, T fallback) const {
        auto it = merged_.find(key);
        if (it == merged_.end() || it->is_null()) return fallback;
        try { return it->get<T>(); } catch (...) { return fallback; }
    }
    bool b(const std::string &k, bool f = false) const { return value<bool>(k, f); }
    double d(const std::string &k, double f = 0) const { return value<double>(k, f); }
    int i(const std::string &k, int f = 0) const { return (int)value<double>(k, f); }
    std::string s(const std::string &k, const std::string &f = "") const { return value<std::string>(k, f); }
    json j(const std::string &k) const { auto it = merged_.find(k); return it == merged_.end() ? json() : *it; }
    void set(const std::string &key, const json &v);     // saves settings.json
    // popup placement (Settings > Popups & indicators), with Nova's defaults filled in
    json osd(const std::string &kind) const;
    json defaultValue(const std::string &k) const { auto it = defaults_.find(k); return it == defaults_.end() ? json() : *it; }
    static std::string dir();          // ~/.config/nova
    ui::Signal<> changed;
private:
    json defaults_, user_, merged_;
    int64_t ownWrite_ = 0;
    void applyTheme();
};

inline Config &cfg() { return Config::get(); }

}  // namespace nova
