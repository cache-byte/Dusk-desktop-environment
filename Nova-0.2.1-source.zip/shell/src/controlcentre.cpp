#include <set>
#include <map>
// Control centre. Tiles live on a 6 × 10 grid stored in settings.json (ccLayout).
// Pencil -> edit mode: drag to move (snaps to cells), drag the corner to resize,
// the red badge removes, chips at the bottom add tiles.
#include "apps.hpp"
#include "services.hpp"
#include "windows.hpp"

#include <ctime>

namespace nova {

using namespace ui;

struct TileMeta { std::string icon, label; int minW, minH, maxW, maxH; };
static const std::vector<std::pair<std::string, TileMeta>> &catalog() {
    static const std::vector<std::pair<std::string, TileMeta>> c = {
        {"wifi", {"wifi", "Wi-Fi", 2, 1, 6, 1}}, {"bluetooth", {"bt", "Bluetooth", 2, 1, 6, 1}},
        {"brightness", {"sun", "Brightness", 1, 2, 6, 5}}, {"volume", {"volume", "Volume", 1, 2, 6, 5}},
        {"micvol", {"mic", "Microphone", 1, 2, 6, 5}}, {"dnd", {"moon", "Do not disturb", 1, 1, 3, 1}},
        {"nightlight", {"sunset", "Night light", 1, 1, 3, 1}}, {"airplane", {"plane", "Airplane", 1, 1, 3, 1}},
        {"darkmode", {"contrast", "Dark mode", 1, 1, 3, 1}}, {"mic", {"mic", "Mic mute", 1, 1, 3, 1}},
        {"screenshot", {"shot", "Screenshot", 1, 1, 3, 1}}, {"caffeine", {"coffee", "Keep awake", 1, 1, 3, 1}},
        {"record", {"record", "Screen record", 1, 1, 3, 1}}, {"hotspot", {"hotspot", "Hotspot", 1, 1, 3, 1}},
        {"kbl", {"kbl", "Keyboard light", 1, 1, 3, 1}}, {"power", {"gauge", "Power mode", 3, 1, 6, 1}}};
    return c;
}
static TileMeta metaFor(const std::string &id) {
    for (auto &[k, m] : catalog()) if (k == id) return m;
    return {"square", id, 1, 1, 4, 4};
}

struct Tile { std::string id; int x = 0, y = 0, w = 1, h = 1; };

static bool nightOn = false;

static bool isOn(const std::string &id) {
    if (id == "wifi") return Net::get().wifiEnabled;
    if (id == "bluetooth") return Bluetooth::get().powered;
    if (id == "dnd") return cfg().b("dnd", false);
    if (id == "nightlight") return nightOn;
    if (id == "airplane") return Net::get().airplane || (!Net::get().wifiEnabled && !Bluetooth::get().powered);
    if (id == "darkmode") return cfg().s("mode", "dark") != "light";
    if (id == "mic") return !Audio::get().micMuted;
    if (id == "caffeine") return Idle::get().caffeine;
    if (id == "record") return Recorder::get().recording;
    if (id == "kbl") return Brightness::get().kbdLevel > 0;
    return false;
}
static std::string subtitle(const std::string &id) {
    if (id == "wifi") {
        auto &n = Net::get();
        return n.wired ? "Wired" : !n.ssid.empty() ? n.ssid : n.wifiEnabled ? "Not connected" : "Off";
    }
    if (id == "bluetooth") {
        auto &b = Bluetooth::get();
        return !b.powered ? "Off" : !b.connectedName.empty() ? b.connectedName : "On";
    }
    return "";
}
static void press(const std::string &id) {
    if (id == "wifi") Net::get().setWifi(!Net::get().wifiEnabled);
    else if (id == "bluetooth") Bluetooth::get().setPowered(!Bluetooth::get().powered);
    else if (id == "dnd") cfg().set("dnd", !cfg().b("dnd", false));
    else if (id == "nightlight") {
        nightOn = !nightOn;
        spawnShell(nightOn ? "pkill gammastep; gammastep -O " + std::to_string(cfg().i("nightTemp", 4200)) + " >/dev/null 2>&1 &" : "pkill gammastep");
    } else if (id == "airplane") {
        bool on = !isOn("airplane");
        Net::get().setAirplane(on);
        Bluetooth::get().setPowered(!on);
    } else if (id == "darkmode") {
        std::string m = cfg().s("mode", "dark") == "light" ? "dark" : "light";
        cfg().set("mode", m);
        spawn({"nova-theme", m});
    } else if (id == "mic") Audio::get().toggleMic();
    else if (id == "screenshot") { shell().close(); spawnShell("sleep 0.3; nova-record shot edit"); }
    else if (id == "caffeine") Idle::get().setCaffeine(!Idle::get().caffeine);
    else if (id == "record") {
        bool rec = Recorder::get().recording;
        shell().close();
        spawnShell(rec ? "nova-record stop" : "sleep 0.3; nova-record start screen");
    } else if (id == "hotspot") spawn({"nmcli", "dev", "wifi", "hotspot"});
    else if (id == "kbl") {
        auto &b = Brightness::get();
        int mx = std::max(1, b.kbdMax);
        b.setKbd((b.kbdLevel + 1) % (mx + 1));
    }
}

// The tile grid. Tiles are placed by hand (cells); in edit mode the grid itself handles
// dragging, resizing, removing, and paints the empty cells and the snap ghost.
class CcGrid : public Widget {
public:
    std::vector<Tile> layout;
    bool editing = false;
    std::function<void()> changed;     // layout edited (rebuild tiles)
    const Theme &t = theme();
    double cell() const { return t.gridCell; }
    double gap() const { return t.gridGap; }
    int cols() const { return t.gridCols; }
    int maxRows() const { return t.gridRows; }
    int rows() const {
        int r = 1;
        for (auto &x : layout) r = std::max(r, x.y + x.h);
        return std::min(maxRows(), r + (editing ? 1 : 0));
    }
    Rect cellRect(int x, int y, int w, int h) const {
        double s = cell() + gap();
        return {geom.x + x * s, geom.y + y * s, w * cell() + (w - 1) * gap(), h * cell() + (h - 1) * gap()};
    }
    bool overlaps(const Tile &a, int skip) const {
        if (a.x < 0 || a.y < 0 || a.x + a.w > cols() || a.y + a.h > maxRows()) return true;
        for (size_t i = 0; i < layout.size(); i++) {
            if ((int)i == skip) continue;
            auto &b = layout[i];
            if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) return true;
        }
        return false;
    }
    Size sizeHint(double, double) override {
        int r = rows();
        return {cols() * cell() + (cols() - 1) * gap(), r * cell() + (r - 1) * gap()};
    }
    void arrange() override {
        for (size_t i = 0; i < children_.size() && i < layout.size(); i++) {
            auto &L = layout[i];
            Rect r = cellRect(L.x, L.y, L.w, L.h);
            if ((int)i == drag_) r = r.translated(dragOff_.x, dragOff_.y);
            if ((int)i == resize_) { r.w = std::max(cell(), r.w + dragOff_.x); r.h = std::max(cell(), r.h + dragOff_.y); }
            children_[i]->setGeometry(r);
        }
    }
    // ---- edit mode: the grid takes the pointer instead of the tiles ----
    Widget *hitTest(Point p) override {
        if (!editing) return Widget::hitTest(p);
        return geom.contains(p) || hitBadge(p) >= 0 ? this : nullptr;
    }
    int hitBadge(Point p) const {
        for (size_t i = 0; i < layout.size(); i++) {
            Rect r = cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
            if (std::hypot(p.x - (r.right() - 4), p.y - (r.y + 4)) <= 13) return (int)i;
        }
        return -1;
    }
    int hitTile(Point p) const {
        for (size_t i = 0; i < layout.size(); i++)
            if (cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h).contains(p)) return (int)i;
        return -1;
    }
    bool pointerPress(Point p, int button) override {
        if (!editing || button != 1) return false;
        if (int b = hitBadge(p); b >= 0) {
            layout.erase(layout.begin() + b);
            if (changed) changed();
            return true;
        }
        int i = hitTile(p);
        if (i < 0) return true;
        Rect r = cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
        start_ = p;
        dragOff_ = {0, 0};
        if (p.x > r.right() - 26 && p.y > r.bottom() - 26) resize_ = i; else drag_ = i;
        window()->setCursor(resize_ >= 0 ? Cursor::ResizeNWSE : Cursor::Grabbing);
        return true;
    }
    void pointerMove(Point p) override {
        if (drag_ < 0 && resize_ < 0) {
            if (editing && window()) {
                int i = hitTile(p);
                Cursor c = Cursor::Default;
                if (hitBadge(p) >= 0) c = Cursor::Pointer;
                else if (i >= 0) {
                    Rect r = cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
                    c = p.x > r.right() - 26 && p.y > r.bottom() - 26 ? Cursor::ResizeNWSE : Cursor::Grab;
                }
                window()->setCursor(c);
            }
            return;
        }
        dragOff_ = {p.x - start_.x, p.y - start_.y};
        arrange();
        update();
    }
    Tile target() const {
        double s = cell() + gap();
        if (drag_ >= 0) {
            Tile t = layout[drag_];
            t.x = std::clamp((int)std::lround(t.x + dragOff_.x / s), 0, cols() - t.w);
            t.y = std::clamp((int)std::lround(t.y + dragOff_.y / s), 0, maxRows() - t.h);
            return t;
        }
        Tile t = layout[resize_];
        TileMeta m = metaFor(t.id);
        t.w = std::clamp(t.w + (int)std::lround(dragOff_.x / s), m.minW, m.maxW);
        t.h = std::clamp(t.h + (int)std::lround(dragOff_.y / s), m.minH, m.maxH);
        return t;
    }
    void pointerRelease(Point, int) override {
        if (drag_ < 0 && resize_ < 0) return;
        Tile t = target();
        int i = drag_ >= 0 ? drag_ : resize_;
        if (!overlaps(t, i)) layout[i] = t;    // else it snaps back
        drag_ = resize_ = -1;
        dragOff_ = {0, 0};
        if (changed) changed();
    }
    void paint(Painter &p) override {
        if (!editing) return;
        // empty cells
        for (int y = 0; y < rows(); y++)
            for (int x = 0; x < cols(); x++) {
                bool used = false;
                for (auto &L : layout) if (x >= L.x && x < L.x + L.w && y >= L.y && y < L.y + L.h) used = true;
                if (used) continue;
                Rect r = cellRect(x, y, 1, 1);
                p.stroke(r.inset(0.75), Color{1, 1, 1, 0.14}, 1.5, 16);
                p.icon("plus", r.center(), 18, t.text3);
            }
        // snap ghost
        if (drag_ >= 0 || resize_ >= 0) {
            Tile g = target();
            if (!overlaps(g, drag_ >= 0 ? drag_ : resize_)) {
                Rect r = cellRect(g.x, g.y, g.w, g.h);
                p.fill(r, t.accentSoft, 16);
                p.stroke(r.inset(1), t.accent, 2, 16);
            }
        }
    }
    void paintOver(Painter &p) override {
        if (!editing) return;
        for (size_t i = 0; i < layout.size(); i++) {
            Rect r = children_.size() > i ? children_[i]->geom : cellRect(layout[i].x, layout[i].y, layout[i].w, layout[i].h);
            bool active = (int)i == drag_ || (int)i == resize_;
            p.stroke(r.inset(0.75), active ? t.accent : Color{1, 1, 1, 0.22}, 1.5, 16);
            p.fillCircle({r.right() - 4, r.y + 4}, 11, t.danger);
            p.icon("minus", Point{r.right() - 4, r.y + 4}, 13, Color{1, 1, 1, 1});
            p.icon("resize", Point{r.right() - 12, r.bottom() - 12}, 14, t.accent);
        }
    }
private:
    int drag_ = -1, resize_ = -1;
    Point start_, dragOff_;
};

std::unique_ptr<Widget> makeCcDetail(const std::string &id, std::function<void()> back);

class ControlCentre : public Card {
public:
    explicit ControlCentre(Screen *s) : Card(Dir::Column, 14), screen(s) {
        const Theme &t = theme();
        fixedW = t.gridWidth();
        padding(t.gridPad);
        radius = t.radius;
        load();
        for (auto *sig : {&Net::get().changed, &Bluetooth::get().changed, &Brightness::get().kbdChanged, &Recorder::get().changed,
                          &Idle::get().changed, &Power::get().changed})
            conns.on(*sig, [this] { conns.later([this] { refresh(); }); });
        // sliders follow the value without a rebuild (a rebuild would drop the slider being dragged)
        conns.on(Audio::get().changed, [this](const std::string &) {
            conns.later([this] {
                refreshSliders();
                if (Audio::get().micMuted != lastMicMuted) { lastMicMuted = Audio::get().micMuted; refresh(); }
            });
        });
        lastMicMuted = Audio::get().micMuted;
        conns.on(Brightness::get().changed, [this] { conns.later([this] { refreshSliders(); }); });
        conns.on(cfg().changed, [this] { conns.later([this] { if (!shell().ccEditing) { load(); build(); } else refresh(); }); });
        conns.on(shell().changed, [this] { if (editing != shell().ccEditing) conns.later([this] { editing = shell().ccEditing; build(); }); });
        editing = shell().ccEditing;
        build();
    }
    Screen *screen;
    std::vector<Tile> layout;
    bool editing = false, lastMicMuted = false;
    Connections conns;
    CcGrid *grid = nullptr;
    std::vector<std::pair<std::string, Slider *>> sliders;

    void load() {
        layout.clear();
        json l = cfg().j("ccLayout");
        if (!l.is_array()) l = cfg().defaultValue("ccLayout");
        if (!l.is_array()) return;
        for (auto &o : l)
            if (o.is_object()) layout.push_back({o.value("id", std::string()), o.value("x", 0), o.value("y", 0), o.value("w", 1), o.value("h", 1)});
    }
    void save() {
        json a = json::array();
        for (auto &t : layout) a.push_back({{"id", t.id}, {"x", t.x}, {"y", t.y}, {"w", t.w}, {"h", t.h}});
        cfg().set("ccLayout", a);
    }
    void refreshSliders() {
        for (auto &[id, s] : sliders) {
            auto &a = Audio::get();
            if (id == "brightness") s->setValue(Brightness::get().value);
            else if (id == "volume") { s->maxValue = a.maxVolume(); s->setValue(a.volume); s->iconName = a.muted ? "mute" : "volume"; }
            else s->setValue(a.micVolume);
        }
    }
    // tiles change colour / text without rebuilding the grid (keeps sliders being dragged alive)
    void refresh() { build(); }

    // ---- details: Wi-Fi networks, Bluetooth devices, sound outputs, night light ----
    std::string detail;
    static bool hasDetail(const std::string &id) {
        return id == "wifi" || id == "bluetooth" || id == "volume" || id == "micvol" || id == "nightlight" || id == "brightness" || id == "power";
    }
    void openDetail(const std::string &id) {
        detail = id == "brightness" ? "nightlight" : id;
        conns.later([this] { build(); });
    }
    void build() {
        const Theme &t = theme();
        clear();
        sliders.clear();
        if (!detail.empty() && !editing) {
            adopt(makeCcDetail(detail, [this] { detail.clear(); conns.later([this] { build(); }); }));
            relayout();
            return;
        }
        // ---- header ----
        auto *head = row(this, 8);
        auto *hc = col(head, 2);
        hc->grow = 1;
        time_t now = time(nullptr);
        tm lt;
        localtime_r(&now, &lt);
        char day[32], date[32];
        strftime(day, sizeof day, "%A", &lt);
        strftime(date, sizeof date, "%e %B", &lt);
        hc->add<Label>(editing ? "Drag to move · corner to resize" : day, 13, Weight::Normal, Role::Text2);
        hc->add<Label>(editing ? "Edit controls" : trim(date), 24, Weight::DemiBold);
        if (!editing) {
            auto *pen = head->add<IconButton>("pencil", 36, 17);
            pen->onClick = [] { shell().ccEditing = true; shell().changed.emit(); };
        } else {
            auto *reset = head->add<TextButton>("Reset");
            reset->fixedH = 34;
            reset->radius = 11;
            reset->bg = t.surface3;
            reset->onClick = [this] {
                json d = cfg().defaultValue("ccLayout");
                layout.clear();
                if (d.is_array())
                    for (auto &o : d) layout.push_back({o.value("id", std::string()), o.value("x", 0), o.value("y", 0), o.value("w", 1), o.value("h", 1)});
                conns.later([this] { build(); });
            };
            auto *done = head->add<TextButton>("Done", "check", true);
            done->fixedH = 34;
            done->radius = 11;
            done->onClick = [this] { save(); shell().ccEditing = false; shell().changed.emit(); };
        }

        // ---- tiles ----
        grid = add<CcGrid>();
        grid->fill = false;
        grid->layout = layout;
        grid->editing = editing;
        grid->changed = [this] { layout = grid->layout; conns.later([this] { build(); }); };
        for (auto &L : layout) buildTile(grid, L);

        // ---- add-tile drawer ----
        if (editing) {
            add<Separator>();
            auto *h = add<Label>("ADD CONTROLS", 12, Weight::DemiBold, Role::Text3);
            h->font.letterSpacing = 0.7;
            Box *line = nullptr;
            double used = 0, avail = t.gridWidth() - 2 * t.gridPad;
            for (auto &[id, m] : catalog()) {
                if (std::any_of(layout.begin(), layout.end(), [&](const Tile &x) { return x.id == id; })) continue;
                double w = measureText(m.label, Font{"", 13}).w + 15 + 7 + 24;
                if (!line || used + w > avail) { line = row(this, 8); used = 0; }
                used += w + 8;
                auto *chip = line->add<Button>(Dir::Row, 7);
                chip->fixedH = 34;
                chip->radius = 17;
                chip->padding(12, 0);
                chip->bg = t.surface3;
                chip->fill = false;
                chip->add<IconW>(m.icon, 15);
                chip->add<Label>(m.label, 13)->fill = false;
                std::string idc = id;
                TileMeta mc = m;
                chip->onClick = [this, idc, mc] {
                    for (int y = 0; y <= theme().gridRows - mc.minH; y++)
                        for (int x = 0; x <= theme().gridCols - mc.minW; x++) {
                            Tile nt{idc, x, y, mc.minW, mc.minH};
                            if (!grid->overlaps(nt, -1)) {
                                layout.push_back(nt);
                                conns.later([this] { build(); });
                                return;
                            }
                        }
                };
            }
        }
        relayout();
    }

    void buildTile(Widget *parent, const Tile &L) {
        const Theme &t = theme();
        TileMeta m = metaFor(L.id);
        bool on = isOn(L.id);
        std::string id = L.id;
        if (id == "brightness" || id == "volume" || id == "micvol") {
            auto *s = parent->add<Slider>(L.h >= L.w);
            s->thick = true;
            s->interactive = !editing;
            auto &a = Audio::get();
            s->iconName = id == "brightness" ? "sun" : id == "volume" ? (a.muted ? "mute" : "volume") : "mic";
            if (id == "volume") s->maxValue = a.maxVolume();
            s->setValue(id == "brightness" ? Brightness::get().value : id == "volume" ? a.volume : a.micVolume);
            s->onChanged = [id](double v) {
                if (id == "brightness") Brightness::get().set(v);
                else if (id == "volume") Audio::get().setVolume(v);
                else Audio::get().setMicVolume(v);
            };
            sliders.push_back({id, s});
            return;
        }
        if (id == "power") {
            auto *b = parent->add<Box>(Dir::Row, 4);
            b->radius = 16;
            b->bg = t.surface2;
            b->padding(4);
            double w = L.w * t.gridCell + (L.w - 1) * t.gridGap;
            for (auto [prof, icon, label] : std::vector<std::tuple<std::string, std::string, std::string>>{
                     {"power-saver", "leaf", "Saver"}, {"balanced", "gauge", "Balanced"}, {"performance", "bolt", "Performance"}}) {
                bool sel = Power::get().profile == prof;
                auto *o = b->add<Button>(Dir::Row, 7);
                o->grow = 1;
                o->fixedW = 0;          // three equal parts whatever the labels
                o->tooltip = label;
                o->radius = 12;
                o->justify = Justify::Center;
                o->bg = sel ? t.accent : Color{0, 0, 0, 0};
                o->hoverBg = sel ? t.accentBright : t.surface3;
                o->add<IconW>(icon, 16, sel ? Role::OnAccent : Role::Text2);
                if (w > 330) o->add<Label>(label, 13, sel ? Weight::DemiBold : Weight::Normal, sel ? Role::OnAccent : Role::Text2)->fill = false;
                std::string p = prof;
                o->onClick = [p] { Power::get().set(p); };
            }
            return;
        }
        if (L.w >= 2) {
            auto *b = parent->add<Button>(Dir::Row, 12);
            b->radius = 16;
            b->bg = t.surface2;
            b->hoverBg = t.surface3;
            b->pl = 14;
            b->pr = 12;
            auto *ic = b->add<Box>(Dir::Row);
            ic->fixedW = ic->fixedH = 36;
            ic->radius = 12;
            ic->bg = on ? t.accent : t.surface3;
            ic->justify = Justify::Center;
            ic->fill = false;
            ic->add<IconW>(m.icon, 19, on ? Role::OnAccent : Role::Text)->fill = false;
            auto *tc = col(b, 1);
            tc->grow = 1;
            tc->justify = Justify::Center;
            tc->add<Label>(m.label, 14, Weight::DemiBold);
            std::string sub = subtitle(id);
            if (!sub.empty()) tc->add<Label>(sub, 12, Weight::Normal, Role::Text2);
            if (id == "wifi" || id == "bluetooth") {
                auto *more = b->add<IconButton>("chevr", 28, 16);
                more->bg = Color{0, 0, 0, 0};
                more->icon->role = Role::Text3;
                more->tooltip = id == "wifi" ? "Networks" : "Devices";
                more->onClick = [this, id] { openDetail(id); };
            }
            b->onClick = [id] { press(id); };
            if (hasDetail(id)) b->onRightClick = [this, id] { openDetail(id); };
            b->tooltip = m.label + (hasDetail(id) ? "  ·  right-click for options" : "");
            return;
        }
        auto *b = parent->add<Button>(Dir::Row, 0);
        b->radius = 16;
        b->bg = on ? t.accent : t.surface2;
        b->hoverBg = on ? t.accentBright : t.surface3;
        b->justify = Justify::Center;
        b->tooltip = m.label;
        b->add<IconW>(m.icon, 20, on ? Role::OnAccent : Role::Text)->fill = false;
        b->onClick = [id] { press(id); };
        b->tooltip = m.label + (hasDetail(id) ? "  ·  right-click for options" : "");
        if (hasDetail(id)) b->onRightClick = [this, id] { openDetail(id); };
    }
};

std::unique_ptr<Widget> makeControlCentre(Screen *s) { return std::make_unique<ControlCentre>(s); }

}  // namespace nova

// =============================================================== details ==
namespace nova {
namespace {

// one row in a detail list: icon, title / subtitle, optional trailing text
Button *detailRow(Box *list, const std::string &icon, const std::string &title, const std::string &sub, bool active) {
    const Theme &t = theme();
    auto *b = list->add<Button>(Dir::Row, 12);
    b->fixedH = sub.empty() ? 42 : 52;
    b->radius = 12;
    b->padding(12, 0);
    b->bg = active ? t.accentSoft : Color{0, 0, 0, 0};
    b->border = active ? t.accentLine : Color{0, 0, 0, 0};
    b->hoverBg = t.surface3;
    b->add<IconW>(icon, 18, active ? Role::AccentBright : Role::Text2);
    auto *c = col(b, 1);
    c->grow = 1;
    c->justify = Justify::Center;
    c->add<Label>(title, 14, active ? Weight::DemiBold : Weight::Normal);
    if (!sub.empty()) c->add<Label>(sub, 12, Weight::Normal, Role::Text3);
    return b;
}

class CcDetail : public Box {
public:
    CcDetail(std::string id, std::function<void()> back) : Box(Dir::Column, 10), id_(std::move(id)), back_(std::move(back)) {
        const Theme &t = theme();
        auto *head = row(this, 8);
        auto *bk = head->add<IconButton>("chevd", 34, 16);
        bk->icon->rotation.set(90);
        bk->tooltip = "Back";
        bk->onClick = [this] { back_(); };
        std::string title = id_ == "wifi" ? "Wi-Fi" : id_ == "bluetooth" ? "Bluetooth" : id_ == "volume" ? "Sound output" :
                            id_ == "micvol" ? "Microphone" : id_ == "power" ? "Power mode" : "Night light";
        head->add<Label>(title, 17, Weight::DemiBold)->grow = 1;
        status_ = head->add<Label>("", 12, Weight::Normal, Role::Text3);
        status_->fill = false;
        auto *sv = add<ScrollView>();
        sv->fixedH = t.gridHeight(5) - 2 * t.gridPad;
        list_ = sv->add<Box>(Dir::Column, 4);
        auto *foot = row(this, 8);
        stretch(foot);
        auto *more = foot->add<TextButton>("More settings", "settings");
        more->fixedH = 32;
        more->radius = 10;
        std::string page = id_ == "wifi" || id_ == "bluetooth" ? "Connections" : id_ == "power" ? "Power" : id_ == "nightlight" ? "Display" : "Sound";
        more->onClick = [page] { spawn({"nova-settings", "--page", page}); shell().close(); };
        load();
    }

private:
    std::string id_;
    std::function<void()> back_;
    Label *status_ = nullptr;
    Box *list_ = nullptr;
    Connections conns_;
    std::string askFor_;     // Wi-Fi network waiting for a password

    void setStatus(const std::string &s) { status_->setText(s); relayout(); }
    void later(std::function<void()> f) { conns_.later(std::move(f)); }
    void reloadSoon(int ms = 600) { conns_.after(ms, [this] { load(); }); }

    void load() {
        if (id_ == "wifi") loadWifi();
        else if (id_ == "bluetooth") loadBluetooth();
        else if (id_ == "volume" || id_ == "micvol") loadAudio(id_ == "micvol");
        else if (id_ == "power") loadPower();
        else loadNight();
    }

    // ---- Wi-Fi: scan, connect (asks for the password here) ----
    void loadWifi() {
        setStatus("Scanning…");
        Process::run({"nmcli", "-t", "-e", "yes", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", "auto"},
                     [this, alive = conns_.token()](int, const std::string &out) {
            if (!*alive) return;
            list_->clear();
            std::set<std::string> seen;
            int n = 0;
            for (auto &l : split(out, '\n')) {
                // fields are ':'-separated with '\:' escapes
                std::vector<std::string> f(1);
                for (size_t i = 0; i < l.size(); i++) {
                    if (l[i] == '\\' && i + 1 < l.size()) { f.back() += l[++i]; continue; }
                    if (l[i] == ':') { f.emplace_back(); continue; }
                    f.back() += l[i];
                }
                if (f.size() < 4 || f[1].empty() || seen.count(f[1])) continue;
                seen.insert(f[1]);
                bool inUse = f[0] == "*";
                std::string ssid = f[1], sec = f[3];
                int sig = atoi(f[2].c_str());
                auto *b = detailRow(list_, sig > 66 ? "wifi" : sig > 33 ? "wifi" : "wifi", ssid,
                                    std::string(inUse ? "Connected" : sec.empty() || sec == "--" ? "Open" : "Secured") + "  ·  " + std::to_string(sig) + "%", inUse);
                bool secured = !(sec.empty() || sec == "--");
                b->onClick = [this, ssid, inUse, secured] {
                    if (inUse) { Process::run({"nmcli", "con", "down", "id", ssid}, [this](int, const std::string &) { reloadSoon(); }); setStatus("Disconnecting…"); return; }
                    connectWifi(ssid, secured, "");
                };
                if (ssid == askFor_) {
                    auto *pr = row(list_, 8);
                    pr->ml = 42;
                    auto *pw = pr->add<TextInput>();
                    pw->password = true;
                    pw->placeholder = "Password for " + ssid;
                    pw->grow = 1;
                    pw->fixedH = 38;
                    auto go = [this, ssid, pw] { std::string p = pw->text(); connectWifi(ssid, true, p); };
                    pw->onSubmit = [go](const std::string &) { go(); };
                    auto *c = pr->add<TextButton>("Connect", "", true);
                    c->fixedH = 38;
                    c->onClick = go;
                    later([this, pw] { if (window()) window()->setFocus(pw); });
                }
                if (++n >= 30) break;
            }
            if (!n) list_->add<Label>(Net::get().wifiEnabled ? "No networks found" : "Wi-Fi is off", 13, Weight::Normal, Role::Text3)->mt = 10;
            setStatus("");
            relayout();
        });
    }
    void connectWifi(const std::string &ssid, bool secured, const std::string &password) {
        setStatus("Connecting…");
        // a saved connection first; a new one needs the password
        Process::run({"sh", "-c", "nmcli -t -f NAME con show | grep -Fxq -- \"$1\"", "sh", ssid}, [this, ssid, secured, password](int known, const std::string &) {
            std::vector<std::string> argv;
            if (known == 0 && password.empty()) argv = {"nmcli", "con", "up", "id", ssid};
            else if (secured && password.empty()) { askFor_ = ssid; load(); return; }
            else {
                argv = {"nmcli", "dev", "wifi", "connect", ssid};
                if (!password.empty()) { argv.push_back("password"); argv.push_back(password); }
            }
            Process::run(argv, [this, ssid](int code, const std::string &) {
                askFor_.clear();
                setStatus(code == 0 ? "Connected" : "Couldn't connect");
                if (code != 0) askFor_ = ssid;   // wrong password: ask again
                reloadSoon(800);
            });
        });
    }

    // ---- Bluetooth: paired + nearby devices, click to connect / disconnect ----
    void loadBluetooth() {
        if (!Bluetooth::get().powered) {
            list_->clear();
            list_->add<Label>("Bluetooth is off", 13, Weight::Normal, Role::Text3)->mt = 10;
            auto *on = list_->add<TextButton>("Turn on", "bt", true);
            on->fill = false;
            on->onClick = [this] { Bluetooth::get().setPowered(true); reloadSoon(1200); };
            relayout();
            return;
        }
        setStatus("Looking…");
        Process::run({"sh", "-c", "bluetoothctl devices Connected | sed 's/^/C /'; bluetoothctl devices Paired | sed 's/^/P /'; bluetoothctl devices | sed 's/^/A /'"},
                     [this, alive = conns_.token()](int, const std::string &out) {
            if (!*alive) return;
            list_->clear();
            std::set<std::string> conn, paired, seen;
            std::vector<std::pair<std::string, std::string>> all;
            for (auto &l : split(out, '\n')) {
                auto w = split(l, ' ');
                if (w.size() < 4 || w[1] != "Device") continue;
                std::string mac = w[2], name;
                for (size_t i = 3; i < w.size(); i++) name += (i > 3 ? " " : "") + w[i];
                if (w[0] == "C") conn.insert(mac);
                else if (w[0] == "P") paired.insert(mac);
                else if (!seen.count(mac)) { seen.insert(mac); all.push_back({mac, name}); }
            }
            std::stable_sort(all.begin(), all.end(), [&](auto &a, auto &b) {
                int ra = conn.count(a.first) ? 0 : paired.count(a.first) ? 1 : 2, rb = conn.count(b.first) ? 0 : paired.count(b.first) ? 1 : 2;
                return ra < rb;
            });
            for (auto &[mac, name] : all) {
                bool c = conn.count(mac), p = paired.count(mac);
                auto *b = detailRow(list_, "bt", name, c ? "Connected" : p ? "Paired" : "Nearby", c);
                std::string m = mac;
                b->onClick = [this, m, c, p] {
                    setStatus(c ? "Disconnecting…" : "Connecting…");
                    std::string cmd = c ? "bluetoothctl disconnect " + m : p ? "bluetoothctl connect " + m
                                                                         : "bluetoothctl pair " + m + " && bluetoothctl trust " + m + " && bluetoothctl connect " + m;
                    Process::run({"sh", "-c", cmd}, [this](int code, const std::string &) { setStatus(code == 0 ? "" : "Didn't work"); reloadSoon(800); });
                };
            }
            if (all.empty()) list_->add<Label>("No devices yet", 13, Weight::Normal, Role::Text3)->mt = 10;
            auto *scan = list_->add<TextButton>("Search for devices", "search");
            scan->fill = false;
            scan->mt = 6;
            scan->onClick = [this] {
                setStatus("Searching (10 s)…");
                Process::run({"bluetoothctl", "--timeout", "10", "scan", "on"}, [this](int, const std::string &) { load(); });
            };
            setStatus("");
            relayout();
        });
    }

    // ---- sound outputs / inputs (PipeWire through pactl) ----
    void loadAudio(bool mic) {
        std::string kind = mic ? "sources" : "sinks";
        Process::run({"sh", "-c", "pactl get-default-" + std::string(mic ? "source" : "sink") + "; pactl list short " + kind + " | cut -f2; echo ---; pactl list " + kind + " | grep -E '^\\s*(Name|Description):'"},
                     [this, mic, alive = conns_.token()](int, const std::string &out) {
            if (!*alive) return;
            list_->clear();
            auto lines = split(out, '\n');
            std::string def = lines.empty() ? "" : trim(lines[0]);
            std::map<std::string, std::string> desc;
            std::string lastName;
            bool after = false;
            for (auto &l : lines) {
                if (trim(l) == "---") { after = true; continue; }
                if (!after) continue;
                std::string t = trim(l);
                if (startsWith(t, "Name: ")) lastName = t.substr(6);
                else if (startsWith(t, "Description: ") && !lastName.empty()) desc[lastName] = t.substr(13);
            }
            int n = 0;
            for (auto &[name, d] : desc) {
                if (mic && endsWith(name, ".monitor")) continue;   // speaker monitors aren't microphones
                bool on = name == def;
                auto *b = detailRow(list_, mic ? "mic" : "volume", d, "", on);
                std::string nm = name;
                b->onClick = [this, nm, mic] { Process::run({"pactl", mic ? "set-default-source" : "set-default-sink", nm}, [this](int, const std::string &) { reloadSoon(200); }); };
                n++;
            }
            if (!n) list_->add<Label>("No devices found", 13, Weight::Normal, Role::Text3)->mt = 10;
            relayout();
        });
    }

    // ---- power mode ----
    void loadPower() {
        list_->clear();
        for (auto [prof, icon, label, sub] : std::vector<std::tuple<std::string, std::string, std::string, std::string>>{
                 {"power-saver", "leaf", "Power saver", "Longer battery, slower"}, {"balanced", "gauge", "Balanced", "The usual"},
                 {"performance", "bolt", "Performance", "Fastest, more heat and noise"}}) {
            auto *b = detailRow(list_, icon, label, sub, Power::get().profile == prof);
            std::string p = prof;
            b->onClick = [this, p] { Power::get().set(p); reloadSoon(300); };
        }
        relayout();
    }

    // ---- night light: warmth ----
    void loadNight() {
        const Theme &t = theme();
        list_->clear();
        int k = cfg().i("nightTemp", 4200);
        auto *l = list_->add<Label>("Warmth  ·  " + std::to_string(k) + " K", 13, Weight::DemiBold, Role::Text2);
        auto *s = list_->add<Slider>(false);
        s->fixedH = 44;
        s->thick = true;
        s->iconName = "sunset";
        // left = warmer
        s->setValue((6500.0 - k) / (6500.0 - 2500.0));
        s->onChanged = [l](double v) {
            int kk = (int)std::lround((6500 - v * 4000) / 100) * 100;
            l->setText("Warmth  ·  " + std::to_string(kk) + " K");
        };
        s->onReleased = [](double v) {
            int kk = (int)std::lround((6500 - v * 4000) / 100) * 100;
            cfg().set("nightTemp", kk);
            nightOn = true;
            spawnShell("pkill gammastep; gammastep -O " + std::to_string(kk) + " >/dev/null 2>&1 &");
        };
        auto *hint = list_->add<Label>("Moving the slider turns night light on at that warmth.", 12, Weight::Normal, Role::Text3);
        hint->maxLines = 0;
        (void)t;
        relayout();
    }
};

}  // namespace

std::unique_ptr<Widget> makeCcDetail(const std::string &id, std::function<void()> back) {
    return std::make_unique<CcDetail>(id, std::move(back));
}

}  // namespace nova
