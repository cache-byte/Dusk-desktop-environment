// Building blocks for the Settings pages: cards, "label ...... control ↺" rows bound to
// settings.json or nova.conf, sliders with a value read-out, the minutes stepper.
#pragma once
#include "backend.hpp"
#include "ui/widget.hpp"
#include "ui/window.hpp"

namespace settings {

using ui::Box;
using ui::Widget;

// Signal connections dropped together with the page
class Connections {
public:
    ~Connections() { *alive_ = false; clear(); }
    template <typename S, typename F> void on(S &sig, F f) {
        int id = sig.connect(std::move(f));
        drops_.push_back([&sig, id] { sig.disconnect(id); });
    }
    void later(std::function<void()> f) {
        auto a = alive_;
        ui::Loop::get().defer([a, f = std::move(f)] { if (*a) f(); });
    }
    void after(int ms, std::function<void()> f) {
        auto a = alive_;
        ui::Loop::get().addTimer(ms, [a, f = std::move(f)] { if (*a) f(); });
    }
    std::shared_ptr<bool> token() const { return alive_; }
    void clear() { for (auto &d : drops_) d(); drops_.clear(); }
private:
    std::vector<std::function<void()>> drops_;
    std::shared_ptr<bool> alive_ = std::make_shared<bool>(true);
};

// A page: its widgets plus everything it listens to
class Page : public Box {
public:
    Page() : Box(ui::Dir::Column, 18) {}
    Connections conns;
    std::vector<std::unique_ptr<ui::Timer>> timers;
    ui::Timer *timer(int ms, std::function<void()> fn, bool repeat = false) {
        timers.push_back(std::make_unique<ui::Timer>(ms, std::move(fn), repeat));
        return timers.back().get();
    }
    void rebuildSoon();                  // rebuild this page on the next loop pass
    std::function<void()> rebuild;       // set by the window
private:
    bool pending_ = false;
};

// card with an optional header (icon, title, subtitle, extra controls on the right)
struct Card {
    Box *box = nullptr, *header = nullptr, *extra = nullptr, *body = nullptr;
    ui::Label *subtitle = nullptr;
};
Card card(Widget *parent, const std::string &title = "", const std::string &icon = "", const std::string &subtitle = "");

// two cards side by side when there is room, stacked otherwise
class Columns : public Widget {
public:
    double spacing = 18, threshold = 900;
    std::vector<int> spans;             // per child: 2 = full width
    Widget *full(Widget *w) { spans.resize(children_.size(), 1); spans.back() = 2; (void)w; return w; }
    ui::Size sizeHint(double aw, double ah) override;
    void arrange() override;
private:
    template <typename F> double layout(double w, F place);
};

// small ↺ button that shows when `isChanged` says the value differs from the default
class ResetButton : public ui::IconButton {
public:
    ResetButton(std::function<bool()> isChanged, std::function<void()> reset, const std::string &icon = "restart");
    ~ResetButton() override;
    std::function<bool()> isChanged;
    void refresh();
    void paint(ui::Painter &p) override;
private:
    int conn_ = 0;
};

// "Label / hint ....... [slot] ↺". Give key (settings.json) or section+confKey (nova.conf).
struct RowOpts {
    std::string key, section, confKey, hint;
};
Box *row2(Widget *parent, const std::string &label, const RowOpts &o = {});

// controls bound to settings
ui::Toggle *toggleKey(Widget *slot, const std::string &key);
ui::Toggle *toggleConf(Widget *slot, const std::string &section, const std::string &key, const std::string &fallback = "false");
ui::Segmented *segKey(Widget *slot, const std::string &key, const std::vector<json> &values, const std::vector<std::string> &labels = {});
ui::Dropdown *dropKey(Widget *slot, const std::string &key, const std::vector<std::string> &values, const std::vector<std::string> &labels = {},
                      std::function<void()> after = {});

// slider with a read-out: value in [from, to]
class RangeSlider : public Box {
public:
    RangeSlider(double from, double to, double value, std::function<std::string(double)> fmt = {});
    double from, to;
    std::function<std::string(double)> fmt;
    std::function<void(double)> onMoved;       // while dragging
    std::function<void(double)> onReleased;
    double value() const;
    void setValue(double v);
    ui::Slider *slider;
    ui::Label *readout = nullptr;
};
RangeSlider *sliderKey(Widget *slot, const std::string &key, double from, double to, std::function<std::string(double)> fmt = {},
                       double roundTo = 0.01, double width = 260);

// − 5 min + for idle times; 0 shows "Off"
Widget *minutesKey(Widget *slot, const std::string &key);

// a button
ui::TextButton *btn(Widget *parent, const std::string &text, const std::string &icon = "", bool accent = false);
// small grey caption
ui::Label *caption(Widget *parent, const std::string &text);
// pill choice chips (toggle a value in a list)
ui::Button *chip(Widget *parent, const std::string &label, bool on, std::function<void()> fn);
// a single-line text field (with placeholder)
ui::TextInput *field(Widget *parent, const std::string &text, const std::string &placeholder = "", double width = -1);

// wraps children onto new lines
class FlowRow : public Widget {
public:
    double spacing = 8, lineSpacing = 8;
    ui::Size sizeHint(double aw, double ah) override;
    void arrange() override;
};

}  // namespace settings
