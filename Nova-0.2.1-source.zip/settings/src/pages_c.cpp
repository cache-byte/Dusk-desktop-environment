// Updates (in-app updater fed by `nova-update --gui`) and About (system info, reset).
#include "pages.hpp"

#include <regex>
#include <set>

namespace settings {

using namespace ui;

// ================================================================== Updates ==
struct UpdateState {
    json info;
    bool healthRunning = false;
    std::string health;               // nova-doctor output (empty until you run it)
    bool checking = false;
    std::string ustate = "idle";      // idle | running | done | failed
    int phase = 0, step = 0, total = 1;
    std::string stepTitle, task;
    std::vector<std::pair<std::string, std::string>> steps;   // title, state (now | ok | fail)
    std::vector<std::string> log;
    json notes = json::array();
    bool showLog = false, removeDeps = false, purge = false, confirm = false;
    double progress() const {
        if (phase <= 1) return 0.1 * step / std::max(1, total);
        return 0.1 + 0.9 * std::max(0.0, step - 1 + (ustate == "done" ? 1 : 0.5)) / std::max(1, total);
    }
};

// lives as long as the app: an update keeps running when you switch pages
static std::shared_ptr<UpdateState> updateState() {
    static auto s = std::make_shared<UpdateState>();
    return s;
}

static void buildUpdates(Page *p);

static void checkUpdates(Page *p) {
    auto st = updateState();
    st->checking = true;
    auto alive = p->conns.token();
    Backend::runAsync({"nova-update", "--check"}, [st, p, alive](const std::string &out) {
        try { st->info = json::parse(out); } catch (...) { st->info = {{"ok", false}, {"installed", backend().installedVersion()}}; }
        if (!st->info.is_object()) st->info = {{"ok", false}, {"installed", backend().installedVersion()}};
        if (st->ustate == "idle") st->notes = st->info.value("notes", json::array());
        st->checking = false;
        if (*alive) p->rebuildSoon();
    });
}

static void handleLine(const std::string &line) {
    auto st = updateState();
    st->log.push_back(line);
    if (st->log.size() > 400) st->log.erase(st->log.begin());
    std::smatch m;
    if (!std::regex_match(line, m, std::regex("^::(\\w+)\\s?(.*)$"))) return;
    std::string kind = m[1], rest = m[2];
    if (kind == "start") { st->phase++; st->step = 0; }
    else if (kind == "step") {
        std::smatch s;
        if (!std::regex_match(rest, s, std::regex("^(\\d+) (\\d+) (.*)$"))) return;
        st->step = atoi(s[1].str().c_str());
        st->total = atoi(s[2].str().c_str());
        st->stepTitle = s[3];
        if (st->phase >= 2) {
            for (auto &x : st->steps) if (x.second == "now") x.second = "ok";
            st->steps.push_back({s[3], "now"});
        }
    } else if (kind == "task") st->task = rest;
    else if (kind == "notes") { try { st->notes = json::parse(rest); } catch (...) {} }
    else if (kind == "fail") st->task = "Failed: " + rest;
    else if (kind == "done") { st->stepTitle = rest; st->task.clear(); }
}

static void startUpdate(Page *p, bool force) {
    auto st = updateState();
    st->ustate = "running";
    st->phase = st->step = 0;
    st->total = 1;
    st->steps.clear();
    st->log.clear();
    st->task = "Starting…";
    auto alive = p->conns.token();
    bool ok = backend().startUpdate(force,
        [p, alive](const std::string &line) { handleLine(line); if (*alive) p->rebuildSoon(); },
        [p, alive](int code) {
            auto s = updateState();
            s->ustate = code == 0 ? "done" : "failed";
            for (auto &x : s->steps) if (x.second == "now") x.second = code == 0 ? "ok" : "fail";
            if (code != 0 && s->task.empty()) s->task = code == 126 ? "Permission wasn't given" : "Something went wrong — see the details";
            if (*alive) checkUpdates(p);
        });
    if (!ok) st->ustate = "idle";
    p->rebuildSoon();
}

static std::string logLine(const std::string &l) {
    static const std::map<std::string, std::string> pre = {{"step", "▸ "}, {"task", "  … "}, {"ok", "  ✓ "}, {"fail", "  ✗ "}, {"warn", "  ! "},
                                                           {"info", "  · "}, {"log", "    │ "}, {"done", "★ "}, {"start", "◆ "}};
    std::smatch m;
    if (std::regex_match(l, m, std::regex("^::(\\w+) ?(.*)$"))) {
        auto it = pre.find(m[1]);
        return (it != pre.end() ? it->second : "") + m[2].str();
    }
    return l;
}

static void buildUpdates(Page *p) {
    p->clear();
    const Theme &t = theme();
    auto st = updateState();
    std::string installed = st->info.value("installed", backend().installedVersion());
    std::string latest = st->info.value("latest", std::string());
    bool hasUpdate = st->info.value("update", false);

    if (st->ustate == "idle") {
        auto c = card(p);
        auto *r = row(c.body, 18);
        auto *ic = r->add<Box>(Dir::Row);
        ic->fixedW = ic->fixedH = 64;
        ic->radius = 18;
        ic->bg = t.accentSoft;
        ic->justify = Justify::Center;
        ic->fill = false;
        ic->add<IconW>(hasUpdate ? "restart" : "check", 30, Role::Accent)->fill = false;
        auto *tc = col(r, 4);
        tc->grow = 1;
        tc->add<Label>(st->checking ? "Checking GitHub…" : hasUpdate ? "Nova " + latest + " is available"
                       : st->info.value("ok", true) == false ? "Couldn't reach GitHub" : "Nova is up to date", 19, Weight::DemiBold);
        tc->add<Label>("Installed: " + installed + (latest.empty() ? "" : "   ·   On GitHub: " + latest), 13, Weight::Normal, Role::Text2);
        btn(r, "Check again")->onClick = [p] { checkUpdates(p); p->rebuildSoon(); };
        if (hasUpdate) btn(r, "Update now", "restart", true)->onClick = [p] { startUpdate(p, false); };
        caption(c.body, "Nova downloads the newest version from GitHub, builds it and installs it. You'll be asked for your password once. "
                        "Fedora packages and Flatpaks are updated by GNOME Software as usual.");
    } else {
        auto c = card(p);
        auto *r = row(c.body, 18);
        auto *ic = r->add<Box>(Dir::Row);
        ic->fixedW = ic->fixedH = 64;
        ic->radius = 18;
        ic->bg = st->ustate == "failed" ? Color{0.9, 0.28, 0.3, 0.15} : t.accentSoft;
        ic->justify = Justify::Center;
        ic->fill = false;
        auto *icon = ic->add<IconW>(st->ustate == "done" ? "check" : st->ustate == "failed" ? "x" : "restart", 30,
                                    st->ustate == "failed" ? Role::Danger : Role::Accent);
        icon->fill = false;
        if (st->ustate == "running") icon->startAnim(icon->rotation, 360 * 40, 1400 * 40, Ease::Linear);
        auto *tc = col(r, 4);
        tc->grow = 1;
        tc->add<Label>(st->ustate == "done" ? "Nova " + installed + " is installed" : st->ustate == "failed" ? "The update didn't finish"
                       : st->phase <= 1 ? "Getting Nova " + latest : "Installing Nova " + latest, 19, Weight::DemiBold);
        tc->add<Label>(st->ustate == "done" ? "Log out and back in to start using it." : !st->task.empty() ? st->task : st->stepTitle, 13, Weight::Normal, Role::Text2);
        if (st->ustate == "running")
            r->add<Label>(std::to_string((int)std::lround(st->progress() * 100)) + "%", 15, Weight::DemiBold, Role::AccentBright)->fill = false;
        // progress bar
        class Bar : public Widget {
        public:
            double v = 0;
            bool failed = false;
            Bar() { fixedH = 8; }
            void paint(Painter &p) override {
                p.fill(geom, theme().surface3, 4);
                p.fill({geom.x, geom.y, geom.w * std::clamp(v, 0.0, 1.0), geom.h}, failed ? theme().danger : theme().accent, 4);
            }
        };
        auto *bar = c.body->add<Bar>();
        bar->v = st->ustate == "done" ? 1 : st->progress();
        bar->failed = st->ustate == "failed";
        if (!st->steps.empty()) {
            auto *g = c.body->add<Columns>();
            g->threshold = 500;
            g->spacing = 8;
            for (auto &[title, state] : st->steps) {
                auto *sr = row(g, 10);
                auto *dot = sr->add<Box>(Dir::Row);
                dot->fixedW = dot->fixedH = 22;
                dot->radius = 11;
                dot->justify = Justify::Center;
                dot->fill = false;
                if (state == "now") { dot->border = t.accent; dot->borderWidth = 2; }
                else {
                    dot->bg = state == "fail" ? t.danger : t.accent;
                    dot->add<IconW>(state == "fail" ? "x" : "check", 13, Role::OnAccent)->fill = false;
                }
                sr->add<Label>(title, 14, state == "now" ? Weight::DemiBold : Weight::Normal, state == "now" ? Role::Text : Role::Text2)->grow = 1;
            }
        }
        auto *br = row(c.body, 10);
        btn(br, st->showLog ? "Hide details" : "Show details", "terminal")->onClick = [p, st] { st->showLog = !st->showLog; p->rebuildSoon(); };
        stretch(br);
        if (st->ustate == "running") btn(br, "Cancel")->onClick = [] { backend().cancelUpdate(); };
        if (st->ustate == "failed") {
            btn(br, "Try again")->onClick = [p] { startUpdate(p, false); };
            btn(br, "Open in terminal")->onClick = [] { backend().runUpdate(false); };
        }
        if (st->ustate == "done") btn(br, "Log out now", "", true)->onClick = [] { Backend::runDetached({"novactl", "dispatch", "exit"}); };
        if (st->ustate != "running") btn(br, "Close")->onClick = [p, st] { st->ustate = "idle"; p->rebuildSoon(); };
        if (st->showLog) {
            auto *sv = c.body->add<ScrollView>();
            sv->fixedH = 220;
            auto *lb = sv->add<Box>(Dir::Column, 0);
            lb->radius = 12;
            lb->bg = Color{0, 0, 0, 0.35};
            lb->padding(12);
            for (auto &l : st->log) {
                auto *x = lb->add<Label>(logLine(l), 12, Weight::Normal, startsWith(l, "::fail") ? Role::Danger : startsWith(l, "::ok") ? Role::Text : Role::Text2);
                x->font.mono = true;
                x->maxLines = 0;
            }
            p->conns.later([sv] { sv->scrollTo(1e9, false); });
        }
    }

    // ---- what's new ----
    json current = st->info.value("current", json::array());
    bool upcoming = st->notes.is_array() && !st->notes.empty();
    if (!st->checking && (upcoming || (st->ustate == "idle" && current.is_array() && !current.empty()))) {
        auto wn = card(p, upcoming ? (st->ustate == "done" ? "What's new in this update" : "What's new") : "In Nova " + installed, "nova");
        json groups = upcoming ? st->notes : json::array({{{"version", ""}, {"items", current}}});
        for (auto &g : groups) {
            std::string v = g.value("version", std::string());
            if (!v.empty()) wn.body->add<Label>("Nova " + v, 13, Weight::DemiBold, Role::AccentBright);
            for (auto &it : g.value("items", json::array())) {
                if (!it.is_string()) continue;
                auto *r = row(wn.body, 10);
                r->crossAlign = Align::Start;
                auto *d = r->add<Box>();
                d->fixedW = d->fixedH = 6;
                d->radius = 3;
                d->bg = t.accent;
                d->fill = false;
                d->alignSelf = Align::Start;
                d->mt = 7;
                auto *l = r->add<Label>(it.get<std::string>(), 14);
                l->maxLines = 0;
                l->grow = 1;
            }
        }
    }

    auto us = card(p, "Update settings", "settings");
    segKey(row2(us.body, "Channel", {.key = "updateChannel", .hint = "Release: the highest version number.  Latest: the newest upload, even a test build."}),
           "updateChannel", {"release", "latest"}, {"Release", "Latest"});
    auto *re = btn(row2(us.body, "Reinstall this version", {.hint = "Rebuilds and reinstalls Nova if something seems broken"}), "Reinstall");
    if (st->ustate == "running") { re->interactive = false; re->opacity.set(0.4); }
    re->onClick = [p] { startUpdate(p, true); };
    btn(row2(us.body, "Use the terminal instead", {.hint = "nova-update · shows the same steps in a terminal window"}), "Open terminal", "terminal")->onClick =
        [] { backend().runUpdate(false); };

    auto rm = card(p, "Remove Nova", "trash", "Puts your previous login screen and system files back. Your apps and files are not touched.");
    rm.body->add<Spacer>(0, 0);
    auto *d1 = row2(rm.body, "Also remove packages Nova installed", {.hint = "Only ones nothing else needs"})->add<Toggle>(st->removeDeps);
    d1->onToggled = [st](bool v) { st->removeDeps = v; };
    auto *d2 = row2(rm.body, "Also delete my Nova settings", {.hint = "~/.config/nova — otherwise kept in case you come back"})->add<Toggle>(st->purge);
    d2->onToggled = [st](bool v) { st->purge = v; };
    auto *ur = row(rm.body, 10);
    stretch(ur);
    btn(ur, "Uninstall Nova…", "trash")->onClick = [p, st] { st->confirm = true; p->rebuildSoon(); };
    if (st->confirm) {
        auto *cf = row(rm.body, 12);
        cf->radius = 14;
        cf->bg = Color{0.9, 0.28, 0.3, 0.12};
        cf->border = Color{0.9, 0.28, 0.3, 0.4};
        cf->padding(14);
        auto *l = cf->add<Label>("A terminal opens and asks for your password. Reboot afterwards to get your old login screen.", 13);
        l->maxLines = 0;
        l->grow = 1;
        btn(cf, "Cancel")->onClick = [p, st] { st->confirm = false; p->rebuildSoon(); };
        btn(cf, "Uninstall", "", true)->onClick = [p, st] { st->confirm = false; backend().uninstall(st->removeDeps, st->purge); p->rebuildSoon(); };
    }

    // ---- health check: only when you ask, output can be copied ----
    std::string sub = st->healthRunning ? "Checking…" : st->health.empty() ? "Checks drivers, services and settings (nova-doctor)" : "";
    int problems = 0;
    for (size_t i = st->health.find("✗"); i != std::string::npos; i = st->health.find("✗", i + 1)) problems++;
    if (!st->health.empty() && !st->healthRunning)
        sub = problems == 0 ? "Everything is healthy" : std::to_string(problems) + (problems == 1 ? " thing needs" : " things need") + " attention";
    auto hc = card(p, "Health check", "shield", sub);
    auto *hr = row(hc.body, 10);
    stretch(hr);
    if (!st->health.empty()) {
        btn(hr, "Copy", "copy")->onClick = [st, p] {
            if (Window *w = p->window()) w->setClipboard(st->health);
        };
    }
    auto *run = btn(hr, st->health.empty() ? "Run check" : "Run again", "restart", st->health.empty());
    if (st->healthRunning) { run->interactive = false; run->opacity.set(0.4); }
    run->onClick = [p, st] {
        st->healthRunning = true;
        p->rebuildSoon();
        auto alive = p->conns.token();
        Backend::runAsync({"nova-doctor"}, [st, p, alive](const std::string &o) {
            st->healthRunning = false;
            st->health = std::regex_replace(o, std::regex("\x1b\\[[0-9;]*m"), "");
            if (st->health.empty()) st->health = "nova-doctor isn't installed";
            if (*alive) p->rebuildSoon();
        });
    };
    if (!st->health.empty()) {
        auto *box = hc.body->add<Box>(Dir::Column);
        box->radius = 12;
        box->bg = theme().surface;
        box->padding(14);
        auto *out = box->add<Label>(st->health, 12, Weight::Normal, Role::Text2);
        out->font.mono = true;
        out->maxLines = 0;
    }
    p->relayout();
}

void pageUpdates(Page *p) {
    auto st = updateState();
    if (st->info.is_null()) st->info = {{"installed", backend().installedVersion()}};
    p->rebuild = [p] { buildUpdates(p); };
    if (st->ustate == "idle" && !st->checking) checkUpdates(p);
    buildUpdates(p);
}

// ==================================================================== About ==
void pageAbout(Page *p) {
    const Theme &t = theme();
    json info = backend().systemInfo();
    auto head = card(p);
    auto *r = row(head.body, 18);
    auto *ic = r->add<Box>(Dir::Row);
    ic->fixedW = ic->fixedH = 72;
    ic->radius = 20;
    ic->bg = t.accentSoft;
    ic->justify = Justify::Center;
    ic->fill = false;
    ic->add<IconW>("nova", 40, Role::Accent)->fill = false;
    auto *tc = col(r, 3);
    tc->add<Label>("Nova", 26, Weight::DemiBold);
    tc->add<Label>(info.value("os", std::string()), 14, Weight::Normal, Role::Text2);

    auto sys = card(p, "System");
    for (auto [k, v] : std::vector<std::pair<std::string, std::string>>{
             {"Device name", info.value("host", std::string())},
             {"Processor", info.value("cpu", std::string()) + " × " + std::to_string(info.value("cores", 0))},
             {"Memory", info.value("memory", std::string())}, {"Graphics", info.value("gpu", std::string())},
             {"Kernel", info.value("kernel", std::string())}, {"Desktop", info.value("desktop", std::string())}}) {
        auto *rr = row(sys.body, 0);
        auto *kl = rr->add<Label>(k, 14, Weight::Normal, Role::Text3);
        kl->fixedW = 180;
        rr->add<Label>(v.empty() ? "—" : v, 14)->grow = 1;
    }
    auto cr = card(p, "Credits", "nova");
    auto *cl = cr.body->add<Label>("Nova " + backend().installedVersion() + " — a Wayland desktop for Fedora, released into the public domain (Unlicense).\n"
                                   "Built on wlroots, SceneFX, Cairo and Pango. Icons: Papirus. Cursor: Bibata. Fonts: Inter and JetBrains Mono. "
                                   "Lyrics from LRCLIB, song recognition by SongRec, visualizer by cava, recording by gpu-screen-recorder.",
                                   13, Weight::Normal, Role::Text2);
    cl->maxLines = 0;

    // ---- reset ----
    static std::set<std::string> picked;
    static std::string doneText;
    auto rs = card(p, "Reset settings", "restart", "Tick what to reset. Everything else stays as it is. A backup is saved first.");
    auto *g = rs.body->add<Columns>();
    g->threshold = 600;
    g->spacing = 8;
    for (auto &grp : backend().resetGroups()) {
        std::string id = grp["id"];
        bool on = picked.count(id) > 0;
        auto *b = g->add<Button>(Dir::Row, 12);
        b->fixedH = 54;
        b->radius = 12;
        b->padding(12, 0);
        b->bg = on ? t.accentSoft : t.surface3;
        b->border = on ? t.accentLine : t.border;
        auto *cb = b->add<Checkbox>();
        cb->checked = on;
        cb->interactive = false;
        auto *tc2 = col(b, 1);
        tc2->grow = 1;
        tc2->justify = Justify::Center;
        tc2->add<Label>(grp.value("label", id), 14);
        tc2->add<Label>(grp.value("hint", std::string()), 12, Weight::Normal, Role::Text3);
        b->onClick = [p, id] { if (picked.count(id)) picked.erase(id); else picked.insert(id); p->rebuildSoon(); };
    }
    auto *br = row(rs.body, 10);
    btn(br, "Select all")->onClick = [p] { for (auto &grp : backend().resetGroups()) picked.insert(grp["id"].get<std::string>()); p->rebuildSoon(); };
    btn(br, "Select none")->onClick = [p] { picked.clear(); p->rebuildSoon(); };
    stretch(br);
    if (!doneText.empty()) br->add<Label>(doneText, 13, Weight::Normal, Role::Text3)->fill = false;
    size_t n = picked.size();
    auto *go = btn(br, n ? "Reset " + std::to_string(n) + (n == 1 ? " item" : " items") : "Reset", "restart", true);
    if (!n) { go->interactive = false; go->opacity.set(0.4); }
    go->onClick = [p] {
        std::vector<std::string> v(picked.begin(), picked.end());
        std::string dir = backend().resetSelected(v);
        auto pos = dir.find("/backup/");
        doneText = "Done · backup in " + (pos == std::string::npos ? dir : dir.substr(pos + 1));
        picked.clear();
        p->rebuildSoon();
    };
    auto backups = backend().resetBackups();
    if (!backups.empty()) {
        auto *ur = row(rs.body, 10);
        std::string when = backups[0];
        auto pos = when.find("reset-");
        when = pos == std::string::npos ? when : replaceAll(when.substr(pos + 6), "_", " ");
        ur->add<Label>("Undo the last reset (" + when + ")", 13, Weight::Normal, Role::Text3)->grow = 1;
        std::string dir = backups[0];
        btn(ur, "Restore backup")->onClick = [dir] { backend().restoreBackup(dir); };
    }
}

}  // namespace settings
