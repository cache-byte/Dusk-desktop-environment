#include "widgets.hpp"

namespace settings {

using namespace ui;

void Page::rebuildSoon() {
    if (pending_) return;          // several changes in one pass rebuild once
    pending_ = true;
    conns.later([this] {
        pending_ = false;
        if (rebuild) rebuild();
    });
}

// ------------------------------------------------------------------- card --
class CardBox : public Box {
public:
    CardBox() : Box(Dir::Column, 14) {
        radius = 18;
        pl = pr = 20;
        pt = pb = 18;
    }
    void paint(Painter &p) override {
        bg = theme().surface2;
        border = theme().border;
        Box::paint(p);
    }
};

Card card(Widget *parent, const std::string &title, const std::string &icon, const std::string &subtitle) {
    Card c;
    c.box = parent->add<CardBox>();
    if (!title.empty() || !icon.empty()) {
        c.header = row(c.box, 10);
        if (!icon.empty()) c.header->add<IconW>(icon, 20);
        auto *t = col(c.header, 3);
        t->grow = 1;
        if (!title.empty()) t->add<Label>(title, 15, Weight::DemiBold);
        c.subtitle = t->add<Label>(subtitle, 13, Weight::Normal, Role::Text3);
        c.subtitle->maxLines = 0;
        c.subtitle->visible = !subtitle.empty();
        c.extra = row(c.header, 10);
        c.extra->fill = false;
    }
    c.body = col(c.box, 12);
    return c;
}

// ---------------------------------------------------------------- columns --
template <typename F> double Columns::layout(double w, F place) {
    spans.resize(children_.size(), 1);
    bool two = w >= threshold;
    double cw = two ? (w - spacing) / 2 : w;
    double y = 0;
    size_t i = 0;
    while (i < children_.size()) {
        Widget *a = children_[i].get();
        if (!a->visible) { i++; continue; }
        if (!two || spans[i] == 2) {
            double h = a->hint(w, kInf).h;
            place(a, Rect{0, y, w, h});
            y += h + spacing;
            i++;
            continue;
        }
        // pair with the next visible half-width child
        size_t j = i + 1;
        while (j < children_.size() && !children_[j]->visible) j++;
        if (j < children_.size() && spans[j] != 2) {
            Widget *b = children_[j].get();
            double ha = a->hint(cw, kInf).h, hb = b->hint(cw, kInf).h;
            place(a, Rect{0, y, cw, ha});
            place(b, Rect{cw + spacing, y, cw, hb});
            y += std::max(ha, hb) + spacing;
            i = j + 1;
        } else {
            double h = a->hint(cw, kInf).h;
            place(a, Rect{0, y, cw, h});
            y += h + spacing;
            i = j;
        }
    }
    return std::max(0.0, y - spacing);
}
Size Columns::sizeHint(double aw, double) {
    double h = layout(aw, [](Widget *, Rect) {});
    return {aw, h};
}
void Columns::arrange() {
    layout(geom.w, [this](Widget *w, Rect r) { w->setGeometry(r.translated(geom.x, geom.y)); });
}

// ---------------------------------------------------------------- flow row --
Size FlowRow::sizeHint(double aw, double) {
    double x = 0, y = 0, lh = 0, mw = 0;
    for (auto &c : children_) {
        if (!c->visible) continue;
        Size s = c->hint(aw, kInf);
        if (x > 0 && x + s.w > aw) { x = 0; y += lh + lineSpacing; lh = 0; }
        x += s.w + spacing;
        mw = std::max(mw, x - spacing);
        lh = std::max(lh, s.h);
    }
    return {std::min(aw, mw), y + lh};
}
void FlowRow::arrange() {
    double x = 0, y = 0, lh = 0;
    for (auto &c : children_) {
        if (!c->visible) continue;
        Size s = c->hint(geom.w, kInf);
        if (x > 0 && x + s.w > geom.w) { x = 0; y += lh + lineSpacing; lh = 0; }
        c->setGeometry({geom.x + x, geom.y + y, s.w, s.h});
        x += s.w + spacing;
        lh = std::max(lh, s.h);
    }
}

// ------------------------------------------------------------ reset button --
ResetButton::ResetButton(std::function<bool()> changed, std::function<void()> reset, const std::string &iconName)
    : IconButton(iconName, 28, 15), isChanged(std::move(changed)) {
    radius = 9;
    bg = Color{0, 0, 0, 0};
    icon->role = Role::Text3;
    tooltip = "Reset to default";
    onClick = [this, reset] { if (!isChanged || isChanged()) reset(); };
    conn_ = backend().changed.connect([this] { refresh(); });
    refresh();
}
ResetButton::~ResetButton() { backend().changed.disconnect(conn_); }
void ResetButton::refresh() {
    bool on = !isChanged || isChanged();
    // keeps its space when hidden so rows stay aligned
    opacity.set(on ? 1 : 0);
    interactive = on;
    cursor = on ? Cursor::Pointer : Cursor::Default;
    update();
}
void ResetButton::paint(Painter &p) {
    icon->role = hovered ? Role::AccentBright : Role::Text3;
    if (hovered && interactive) p.fill(geom, theme().surface3, radius);
}

// --------------------------------------------------------------------- rows --
Box *row2(Widget *parent, const std::string &label, const RowOpts &o) {
    auto *r = row(parent, 16);
    auto *t = col(r, 2);
    t->grow = 1;
    t->minW = 160;
    t->fill = false;            // centred against the control
    t->add<Label>(label, 14);
    if (!o.hint.empty()) {
        auto *h = t->add<Label>(o.hint, 12, Weight::Normal, Role::Text3);
        h->maxLines = 0;
    }
    auto *slot = row(r, 10);
    slot->fill = false;
    if (!o.key.empty()) {
        std::string k = o.key;
        r->add<ResetButton>([k] { return !backend().isDefault(k); }, [k] { backend().reset(k); });
    } else if (!o.confKey.empty()) {
        std::string s = o.section, k = o.confKey;
        r->add<ResetButton>([s, k] { return !backend().isConfDefault(s, k); }, [s, k] { backend().resetConf(s, k); });
    }
    return slot;
}

Toggle *toggleKey(Widget *slot, const std::string &key) {
    auto *t = slot->add<Toggle>(backend().b(key));
    t->onToggled = [key](bool v) { backend().set(key, v); };
    return t;
}
Toggle *toggleConf(Widget *slot, const std::string &section, const std::string &key, const std::string &fallback) {
    auto *t = slot->add<Toggle>(backend().conf(section, key, fallback) == "true");
    t->onToggled = [section, key](bool v) { backend().setConf(section, key, v ? "true" : "false"); };
    return t;
}

static std::string jkey(const json &v) { return v.is_string() ? v.get<std::string>() : v.dump(); }

Segmented *segKey(Widget *slot, const std::string &key, const std::vector<json> &values, const std::vector<std::string> &labels) {
    auto *s = slot->add<Segmented>();
    s->small = true;
    s->fill = false;
    for (size_t i = 0; i < values.size(); i++)
        s->options.push_back({jkey(values[i]), i < labels.size() ? labels[i] : jkey(values[i]), ""});
    s->value = jkey(backend().value(key));
    s->onPicked = [key, values, s](const std::string &v) {
        for (auto &x : values) if (jkey(x) == v) backend().set(key, x);
        s->value = v;
        s->update();
    };
    return s;
}

Dropdown *dropKey(Widget *slot, const std::string &key, const std::vector<std::string> &values, const std::vector<std::string> &labels,
                  std::function<void()> after) {
    auto *d = slot->add<Dropdown>();
    for (size_t i = 0; i < values.size(); i++) d->items.push_back({values[i], i < labels.size() ? labels[i] : values[i]});
    d->setValue(backend().s(key));
    d->onPicked = [key, after](const std::string &v) { backend().set(key, v); if (after) after(); };
    return d;
}

// ----------------------------------------------------------------- slider --
RangeSlider::RangeSlider(double from, double to, double value, std::function<std::string(double)> fmt)
    : Box(Dir::Row, 12), from(from), to(to), fmt(std::move(fmt)) {
    slider = add<Slider>();
    slider->thick = false;
    slider->grow = 1;
    slider->minW = 120;
    if (this->fmt) {
        readout = add<Label>("", 13, Weight::Normal, Role::Text2);
        readout->fixedW = 52;
        readout->hAlign = Align::End;
    }
    setValue(value);
    slider->onChanged = [this](double) {
        double v = this->value();
        if (readout) readout->setText(this->fmt(v));
        if (onMoved) onMoved(v);
    };
    slider->onReleased = [this](double) { if (onReleased) onReleased(this->value()); };
}
double RangeSlider::value() const { return from + slider->value() * (to - from); }
void RangeSlider::setValue(double v) {
    slider->setValue(to > from ? std::clamp((v - from) / (to - from), 0.0, 1.0) : 0);
    if (readout) readout->setText(fmt(v));
}

RangeSlider *sliderKey(Widget *slot, const std::string &key, double from, double to, std::function<std::string(double)> fmt, double roundTo,
                       double width) {
    auto *s = slot->add<RangeSlider>(from, to, backend().d(key, from), fmt);
    s->fixedW = width;
    auto put = [key, roundTo](double v) {
        if (roundTo > 0) v = std::round(v / roundTo) * roundTo;
        backend().set(key, v);
    };
    s->onReleased = put;
    return s;
}

// ---------------------------------------------------------------- minutes --
class Minutes : public Box {
public:
    explicit Minutes(const std::string &key) : Box(Dir::Row, 0), key(key) {
        fixedW = 150;
        fixedH = 36;
        radius = 11;
        clip = true;
        clipRadius = 11;
        auto *minus = add<IconButton>("minus", 34, 15);
        minus->radius = 0;
        minus->fixedH = 36;
        minus->bg = Color{1, 1, 1, 0.04};
        minus->onClick = [this] { move(-1); };
        label = add<Label>("", 14);
        label->grow = 1;
        label->hAlign = Align::Center;
        auto *plus = add<IconButton>("plus", 34, 15);
        plus->radius = 0;
        plus->fixedH = 36;
        plus->bg = Color{1, 1, 1, 0.04};
        plus->onClick = [this] { move(1); };
        conn = backend().changed.connect([this] { refresh(); });
        refresh();
    }
    ~Minutes() override { backend().changed.disconnect(conn); }
    std::string key;
    Label *label;
    int conn = 0;
    int value() const { return (int)backend().d(key, 0); }
    void refresh() {
        int v = value();
        label->setText(v == 0 ? "Off" : std::to_string(v) + " min");
        label->role = v == 0 ? Role::Text3 : Role::Text;
        update();
    }
    void move(int d) {
        static const std::vector<int> steps = {0, 1, 2, 3, 5, 6, 10, 15, 20, 30, 45, 60, 90, 120};
        int v = value();
        int i = (int)(std::find(steps.begin(), steps.end(), v) - steps.begin());
        if (i >= (int)steps.size()) {
            i = 0;
            while (i < (int)steps.size() && steps[i] <= v) i++;
            i -= d > 0 ? 1 : 0;
        }
        backend().set(key, steps[std::clamp(i + d, 0, (int)steps.size() - 1)]);
    }
    void paint(Painter &p) override {
        bg = theme().surface3;
        border = theme().border;
        Box::paint(p);
    }
};
Widget *minutesKey(Widget *slot, const std::string &key) { return slot->add<Minutes>(key); }

// ------------------------------------------------------------------ small --
TextButton *btn(Widget *parent, const std::string &text, const std::string &icon, bool accent) {
    auto *b = parent->add<TextButton>(text, icon, accent);
    b->fixedH = 36;
    b->radius = 11;
    b->fill = false;
    if (!accent) b->bg = theme().surface3;
    return b;
}
Label *caption(Widget *parent, const std::string &text) {
    auto *l = parent->add<Label>(text, 12, Weight::Normal, Role::Text3);
    l->maxLines = 0;
    return l;
}
Button *chip(Widget *parent, const std::string &label, bool on, std::function<void()> fn) {
    const Theme &t = theme();
    auto *b = parent->add<Button>(Dir::Row, 0);
    b->fixedH = 32;
    b->radius = 16;
    b->padding(13, 0);
    b->bg = on ? t.accent : t.surface2;
    b->hoverBg = on ? t.accentBright : t.surface3;
    b->fill = false;
    b->add<Label>((on ? "✓ " : "") + label, 13, on ? Weight::DemiBold : Weight::Normal, on ? Role::OnAccent : Role::Text2)->fill = false;
    b->onClick = std::move(fn);
    return b;
}
TextInput *field(Widget *parent, const std::string &text, const std::string &placeholder, double width) {
    auto *f = parent->add<TextInput>();
    f->setText(text);
    f->placeholder = placeholder;
    f->fixedH = 40;
    if (width > 0) f->fixedW = width;
    return f;
}

}  // namespace settings
