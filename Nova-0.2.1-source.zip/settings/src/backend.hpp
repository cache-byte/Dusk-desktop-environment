// Everything the Settings app needs from the system: settings.json (shared with the shell),
// nova.conf (the compositor), defaults & reset, connections, displays, updates, shortcuts.
#pragma once
#include "ui/core.hpp"
#include "ui/sys.hpp"

#include <nlohmann/json.hpp>

namespace settings {

using json = nlohmann::json;

struct RunResult { int code = -1; std::string out, err; };

class Backend {
public:
    static Backend &get();
    void load();

    // ~/.config/nova/settings.json
    const json &settings() const { return settings_; }
    json value(const std::string &key) const;                 // user value, else default
    bool b(const std::string &k) const { auto v = value(k); return v.is_boolean() ? v.get<bool>() : false; }
    double d(const std::string &k, double f = 0) const { auto v = value(k); return v.is_number() ? v.get<double>() : f; }
    std::string s(const std::string &k, const std::string &f = "") const { auto v = value(k); return v.is_string() ? v.get<std::string>() : f; }
    void set(const std::string &key, const json &v);
    json defaultValue(const std::string &key) const;
    bool isDefault(const std::string &key) const;
    void reset(const std::string &key);

    // ~/.config/nova/nova.conf — the compositor reloads after each change
    std::string conf(const std::string &section, const std::string &key, const std::string &fallback = "") const;
    void setConf(const std::string &section, const std::string &key, const std::string &value);
    void setConfQuiet(const std::string &section, const std::string &key, const std::string &value);
    std::string confDefault(const std::string &section, const std::string &key) const;
    bool isConfDefault(const std::string &section, const std::string &key) const;
    void resetConf(const std::string &section, const std::string &key);

    // processes
    static RunResult runFull(const std::vector<std::string> &argv, int timeoutMs = 4000);
    static std::string run(const std::vector<std::string> &argv, int timeoutMs = 4000) { return runFull(argv, timeoutMs).out; }
    static void runDetached(const std::vector<std::string> &argv) { ui::spawn(argv); }
    // without freezing the window
    static void runAsync(const std::vector<std::string> &argv, std::function<void(const std::string &)> done);

    // appearance
    std::vector<std::string> iconThemes() const;
    std::vector<std::string> cursorThemes() const;
    std::vector<std::string> fonts(bool monospace) const;
    std::vector<std::string> listFonts(bool monospace) const;
    void prefetch();   // slow lists (fonts) in the background
    json wallpapers() const;                  // [{path, video, bundled}]
    std::string wallpaperDir() const;
    std::string accentFromImage(const std::string &path) const;
    void applyDesktopTheme();

    // connections
    json wifiNetworks(bool rescan) const;     // [{active, ssid, signal, secure}]
    bool wifiEnabled() const;
    std::string wifiConnect(const std::string &ssid, const std::string &password) const;   // "" or error
    json bluetoothDevices() const;            // [{mac, name, paired, connected, battery, icon}]
    bool bluetoothPowered() const;
    json vpnConnections() const;
    json wiredStatus() const;

    // displays (wlr-randr --json)
    json displays() const;
    std::string applyDisplay(const json &d);

    json systemInfo() const;

    // reset
    json resetGroups() const;
    std::string resetSelected(const std::vector<std::string> &groups);
    std::vector<std::string> resetBackups() const;
    void restoreBackup(const std::string &dir);

    // updates & uninstall
    std::string installedVersion() const;
    void openInTerminal(const std::string &cmd) const;
    void runUpdate(bool force) const { openInTerminal(force ? "nova-update --force" : "nova-update"); }
    bool startUpdate(bool force, std::function<void(const std::string &)> line, std::function<void(int)> finished);
    void cancelUpdate();
    bool updating() const { return update_ != nullptr; }
    void uninstall(bool removeDeps, bool purge) const;
    std::string gpuInfo() const { return ui::trim(run({"nova-gpu", "info"})); }

    // shortcuts ([bindings] in nova.conf)
    struct Binding { std::string combo, action; bool isDefault = false; };
    std::vector<Binding> bindings() const;
    std::vector<Binding> defaultBindings() const;
    std::string setBinding(const std::string &oldCombo, const std::string &newCombo, const std::string &action);
    void removeBinding(const std::string &combo);
    static std::string normalizeCombo(const std::string &combo);

    std::string trimVideo(const std::string &file, double start, double end, bool replace) const;

    std::string settingsPath() const;
    std::string confPath() const;

    ui::Signal<> changed;          // any setting written (reset buttons refresh)
    ui::Signal<> reloadPage;       // after a reset: rebuild the page so controls show restored values
private:
    json settings_ = json::object(), defaults_ = json::object(), groups_ = json::object(), confGroups_ = json::object();
    std::shared_ptr<ui::Process> update_;
    int watch_ = 0;
    int64_t ownWrite_ = 0;
    void writeSettings();
};

inline Backend &backend() { return Backend::get(); }

}  // namespace settings
