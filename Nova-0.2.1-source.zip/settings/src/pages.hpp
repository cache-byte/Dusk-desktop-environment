#pragma once
#include "widgets.hpp"

namespace settings {

void pageForYou(Page *p);
void pageAppearance(Page *p);
void pageConnections(Page *p);
void pageDisplay(Page *p);
void pageSound(Page *p);
void pagePower(Page *p);
void pageNotifications(Page *p);
void pagePopups(Page *p);
void pageMusic(Page *p);
void pageGaming(Page *p);
void pageWindows(Page *p);
void pageKeyboard(Page *p);
void pageMouse(Page *p);
void pagePanel(Page *p);
void pageUsers(Page *p);
void pageUpdates(Page *p);
void pageAbout(Page *p);

// helpers shared by pages
std::shared_ptr<ui::Image> thumbnail(const std::string &path, int w);
void pickFile(const std::string &title, const std::string &filter, std::function<void(const std::string &)> done);
std::string wallpaperOrDefault();

}  // namespace settings
