// For you, Appearance, Connections, Display
#include "pages.hpp"
#include "ui/sys.hpp"

#include <cmath>
#include <ctime>
#include <map>
#include <regex>
#include <set>

namespace settings {

using namespace ui;

std::shared_ptr<Image> thumbnail(const std::string &path, int w) {
    static std::map<std::string, std::shared_ptr<Image>> cache;
    std::string k = path + "@" + std::to_string(w);
    auto it = cache.find(k);
    if (it != cache.end()) return it->second;
    auto img = std::make_shared<Image>(path, w, w);
    if (cache.size() > 200) cache.clear();
    cache[k] = img;
    return img;
}

void pickFile(const std::string &title, const std::string &filter, std::function<void(const std::string &)> done) {
    std::vector<std::string> argv;
    if (haveProgram("zenity")) argv = {"zenity", "--file-selection", "--title=" + title, "--file-filter=" + filter};
    else if (haveProgram("kdialog")) argv = {"kdialog", "--getopenfilename", homeDir(), filter};
    else { spawn({"xdg-open", homeDir()}); return; }
    Process::run(argv, [done](int code, const std::string &out) {
        std::string f = trim(out);
        if (code == 0 && !f.empty()) done(f);
    });
}

static bool isVideo(const std::string &p) {
    std::string l = lower(p);
    for (const char *e : {".mp4", ".webm", ".mkv", ".mov"}) if (endsWith(l, e)) return true;
    return false;
}

std::string wallpaperOrDefault() {
    std::string w = backend().s("wallpaper");
    if (startsWith(w, "file://")) w = w.substr(7);
    if (!w.empty() && !isVideo(w)) return w;
    return std::string("/usr/share/nova/shell/assets/wallpapers/nova-") + (theme().dark ? "dark" : "light") + ".jpg";
}

// =================================================================== For you ==
void pageForYou(Page *p) {
    const Theme &t = theme();
    auto hello = card(p);
    auto *r = row(hello.body, 18);
    auto *logo = r->add<Box>(Dir::Row);
    logo->fixedW = logo->fixedH = 64;
    logo->radius = 18;
    logo->bg = t.accent;
    logo->justify = Justify::Center;
    logo->fill = false;
    logo->add<IconW>("nova", 34, Role::OnAccent)->fill = false;
    auto *tc = col(r, 4);
    tc->grow = 1;
    time_t now = time(nullptr);
    tm lt;
    localtime_r(&now, &lt);
    tc->add<Label>(lt.tm_hour < 12 ? "Good morning" : lt.tm_hour < 18 ? "Good afternoon" : "Good evening", 22, Weight::DemiBold);
    auto *status = tc->add<Label>("Checking your system…", 14, Weight::Normal, Role::Text2);

    auto keys = card(p, "Shortcuts worth knowing", "keyboard");
    auto *cols = keys.body->add<Columns>();
    cols->threshold = 500;
    cols->spacing = 10;
    for (auto [k, what] : std::vector<std::pair<std::string, std::string>>{
             {"Super", "Find any app or file"}, {"Super + Tab", "See all windows"}, {"Super + ←/→", "Snap to half"}, {"Super + G", "Game overlay"},
             {"Super + V", "Clipboard history"}, {"Super + L", "Lock"}, {"Print", "Screenshot"}, {"Super + Alt + R", "Save instant replay"}}) {
        auto *kr = row(cols, 12);
        auto *kb = kr->add<Box>(Dir::Row);
        kb->fixedH = 28;
        kb->radius = 8;
        kb->padding(9, 0);
        kb->bg = t.surface3;
        kb->border = t.border;
        kb->fill = false;
        kb->add<Label>(k, 12, Weight::DemiBold)->fill = false;
        kr->add<Label>(what, 13, Weight::Normal, Role::Text2)->grow = 1;
    }

    auto health = card(p, "Health check", "shield", "Running nova-doctor…");
    auto *out = health.body->add<Label>("", 12, Weight::Normal, Role::Text2);
    out->font.mono = true;
    out->maxLines = 0;
    auto alive = p->conns.token();
    Backend::runAsync({"nova-doctor"}, [alive, out, status, sub = health.subtitle](const std::string &o) {
        if (!*alive) return;
        std::string clean = std::regex_replace(o, std::regex("\x1b\\[[0-9;]*m"), "");
        int problems = 0;
        for (size_t i = clean.find("✗"); i != std::string::npos; i = clean.find("✗", i + 1)) problems++;
        out->setText(clean.empty() ? "nova-doctor isn't installed" : clean);
        status->setText(problems == 0 ? "Everything is healthy" : std::to_string(problems) + (problems == 1 ? " thing needs" : " things need") + " attention below");
        sub->setText(problems == 0 ? "All checks passed" : "Run nova-doctor in a terminal for details");
    });
}

// ================================================================ Appearance ==
class WallPreview : public Widget {
public:
    std::shared_ptr<Image> img;
    Size sizeHint(double aw, double) override { return {aw, std::round(aw * 9 / 16)}; }
    void paint(Painter &p) override {
        p.save();
        p.clip(geom, 14);
        p.fill(geom, Color{0, 0, 0, 1});
        if (img && img->valid()) p.image(*img, geom);
        p.fill({geom.x, geom.bottom() - geom.h * 0.07, geom.w, geom.h * 0.07}, Color{0.06, 0.06, 0.09, 0.75});
        p.restore();
    }
};

class ModeTile : public Button {
public:
    ModeTile(const std::string &mode, const std::string &label, bool on) : Button(Dir::Column, 8), mode(mode), on(on) {
        fixedH = 112;
        radius = 14;
        padding(8);
        grow = 1;
        stretch(this);       // the preview is painted above the label
        auto *l = add<Label>(label, 13);
        l->hAlign = Align::Center;
    }
    std::string mode;
    bool on;
    void paint(Painter &p) override {
        const Theme &t = theme();
        p.fill(geom, on ? t.accentSoft : t.surface3, radius);
        if (on) p.stroke(geom.inset(1), t.accent, 2, radius);
        Rect pv{geom.x + 8, geom.y + 8, geom.w - 16, geom.h - 16 - 26};
        Color light = Color::hex("#f2efe8"), dark = Color::hex("#17161f");
        p.save();
        p.clip(pv, 9);
        p.fill(pv, mode == "light" ? light : dark);
        if (mode == "auto") p.fill({pv.x, pv.y, pv.w / 2, pv.h}, light);
        else {
            Rect w{pv.x + pv.w * 0.12, pv.y + pv.h * 0.18, pv.w * 0.56, pv.h * 0.56};
            p.fill(w, mode == "light" ? Color{1, 1, 1, 1} : Color::hex("#24232e"), 6);
            p.fill({w.x + 8, w.y + 8, w.w * 0.4, 5}, t.accent, 3);
        }
        p.restore();
    }
};

class Swatch : public Widget {
public:
    Swatch(Color c, bool on) : c(c), on(on) { interactive = true; cursor = Cursor::Pointer; }
    Color c;
    bool on;
    Size sizeHint(double, double) override { return {38, 38}; }
    void paint(Painter &p) override {
        Point m = geom.center();
        if (on) p.strokeCircle(m, 18, c, 2);
        p.fillCircle(m, on ? 13 : 15, c);
    }
};

void pageAppearance(Page *p) {
    const Theme &t = theme();
    auto set = [](const std::string &k, const json &v, bool desktop) {
        backend().set(k, v);
        if (desktop) backend().applyDesktopTheme();
    };
    auto pickWallpaper = [p, set](const std::string &path) {
        set("wallpaper", path, false);
        if (backend().b("accentFromWallpaper") && !isVideo(path)) set("accent", backend().accentFromImage(path), false);
        p->rebuildSoon();
    };

    auto *top = p->add<Columns>();
    // ---- wallpaper ----
    auto wp = card(top, "Wallpaper");
    auto *prev = wp.body->add<WallPreview>();
    prev->img = thumbnail(wallpaperOrDefault(), 960);
    auto *wr = row(wp.body, 8);
    auto *fill = dropKey(wr, "wallpaperFill", {"fill", "fit", "center"}, {"Fill", "Fit", "Center"});
    fill->grow = 1;
    fill->fill = true;
    btn(wr, "Browse…", "image")->onClick = [pickWallpaper] {
        pickFile("Choose a wallpaper", "Images and videos | *.png *.jpg *.jpeg *.webp *.mp4 *.webm *.mkv", pickWallpaper);
    };
    // ---- library ----
    auto lib = card(top, "Library");
    std::string dir = backend().wallpaperDir();
    if (startsWith(dir, homeDir())) dir = "~" + dir.substr(homeDir().size());
    lib.extra->add<Label>(dir, 12, Weight::Normal, Role::Text3)->fill = false;
    json papers = backend().wallpapers();
    auto *grid = lib.body->add<Columns>();   // 3 per row via nested rows
    grid->threshold = 1e9;
    grid->spacing = 10;
    Box *line = nullptr;
    std::string cur = backend().s("wallpaper");
    for (size_t i = 0; i < papers.size(); i++) {
        if (i % 3 == 0) line = row(grid, 10);
        std::string path = papers[i]["path"];
        bool video = papers[i].value("video", false);
        auto *b = line->add<Button>(Dir::Column, 0);
        b->grow = 1;
        b->fixedH = 76;
        b->radius = 12;
        b->bg = t.surface3;
        b->justify = Justify::Center;
        b->clip = true;
        b->clipRadius = 12;
        if (path == cur) { b->border = t.accent; b->borderWidth = 2.5; }
        if (!video) {
            auto *im = b->add<ImageW>();
            im->image = thumbnail(path, 320);
            im->radius = 12;
            im->grow = 1;
        } else {
            b->add<IconW>("play", 22, Role::Text2)->fill = false;
            b->add<Label>("Video", 11, Weight::Normal, Role::Text2)->fill = false;
        }
        b->tooltip = path;
        b->onClick = [pickWallpaper, path] { pickWallpaper(path); };
    }
    if (line) while (line->children().size() < 3) line->add<Spacer>()->grow = 1;
    caption(lib.body, papers.size() > 2 ? "Images and video wallpapers (.mp4, .webm) are picked up automatically."
                                        : "Put images or videos in this folder and they'll show up here.");

    // ---- mode & accent ----
    auto mode = card(top, "Mode");
    auto *modes = row(mode.body, 12);
    std::string m = backend().s("mode", "dark");
    for (auto [id, label] : std::vector<std::pair<std::string, std::string>>{{"light", "Light"}, {"dark", "Dark"}, {"auto", "Auto"}}) {
        auto *tile = modes->add<ModeTile>(id, label, m == id);
        std::string v = id;
        tile->onClick = [p, set, v] { set("mode", v, true); p->rebuildSoon(); };
    }
    auto *acc = mode.body->add<Label>("Accent", 15, Weight::DemiBold);
    acc->mt = 8;
    auto *sw = row(mode.body, 6);
    std::string accent = lower(backend().s("accent", "#c8b64a"));
    for (std::string c : {"#c8b64a", "#e0894a", "#e8604c", "#e26aa0", "#9a7bff", "#5b8cff", "#46c2ae", "#7fd18b"}) {
        auto *s = sw->add<Swatch>(Color::hex(c), accent == c);
        s->onClick = [p, set, c] { set("accent", c, false); p->rebuildSoon(); };
    }
    auto *ar = row(mode.body, 10);
    auto *hex = field(ar, backend().s("accent", "#c8b64a"), "#rrggbb", 140);
    hex->onSubmit = [p, set](const std::string &v) {
        std::string x = lower(trim(v));
        if (std::regex_match(x, std::regex("#[0-9a-f]{6}"))) { set("accent", x, false); p->rebuildSoon(); }
    };
    btn(ar, "Pick", "pipette")->onClick = [p, set] {
        if (!haveProgram("zenity")) return;
        Process::run({"zenity", "--color-selection", "--color=" + backend().s("accent", "#c8b64a")}, [p, set](int code, const std::string &out) {
            std::smatch mm;
            std::string o = trim(out);
            if (code != 0) return;
            if (std::regex_search(o, mm, std::regex("rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)"))) {
                Color c{atoi(mm[1].str().c_str()) / 255.0, atoi(mm[2].str().c_str()) / 255.0, atoi(mm[3].str().c_str()) / 255.0, 1};
                set("accent", c.toHex(), false);
            } else if (startsWith(o, "#")) set("accent", o.substr(0, 7), false);
            p->rebuildSoon();
        });
    };
    stretch(ar);
    ar->add<Label>("From wallpaper", 13)->fill = false;
    auto *fw = ar->add<Toggle>(backend().b("accentFromWallpaper"));
    fw->onToggled = [p, set](bool v) {
        set("accentFromWallpaper", v, false);
        std::string w = backend().s("wallpaper");
        if (v && !w.empty() && !isVideo(w)) set("accent", backend().accentFromImage(w), false);
        p->rebuildSoon();
    };

    // ---- blur & transparency ----
    auto blur = card(top, "Blur & transparency");
    auto *bh = row(blur.body, 26);
    bh->add<Label>("Blur", 12, Weight::DemiBold, Role::Text3)->grow = 1;
    bh->add<Label>("Transparency", 12, Weight::DemiBold, Role::Text3)->grow = 1;
    auto pct = [](double v) { return std::to_string((int)std::lround(v * 100)) + " %"; };
    for (auto [label, suffix] : std::vector<std::pair<std::string, std::string>>{{"UI & popups", "Ui"}, {"Panel", "Panel"}, {"Settings & apps", "Apps"}}) {
        auto *l = blur.body->add<Label>(label, 14, Weight::Medium);
        l->mt = 6;
        auto *r = row(blur.body, 26);
        auto *a = sliderKey(r, "blur" + suffix, 0, 1, pct);
        a->fixedW = -1;
        a->grow = 1;
        auto *b = sliderKey(r, "transparency" + suffix, 0, 1, pct);
        b->fixedW = -1;
        b->grow = 1;
    }
    caption(blur.body, "Set blur to 0 % on low-power GPUs.");

    // ---- icons, cursor, fonts ----
    auto *mid = p->add<Columns>();
    auto icons = card(mid, "Icons", "grid");
    auto *ir = row(icons.body, 10);
    auto it = backend().iconThemes();
    auto *idd = dropKey(ir, "iconTheme", it, {}, [] { backend().applyDesktopTheme(); });
    idd->grow = 1;
    idd->fill = true;
    auto *isz = ir->add<Stepper>();
    isz->value = backend().d("iconSize", 24);
    isz->min = 16;
    isz->max = 64;
    isz->step = 4;
    isz->onChanged = [](double v) { backend().set("iconSize", (int)v); };

    auto cursor = card(mid, "Cursor", "cursor");
    auto *cr = row(cursor.body, 10);
    auto *cdd = dropKey(cr, "cursorTheme", backend().cursorThemes(), {}, [] { backend().applyDesktopTheme(); });
    cdd->grow = 1;
    cdd->fill = true;
    auto *csz = cr->add<Stepper>();
    csz->value = backend().d("cursorSize", 24);
    csz->min = 16;
    csz->max = 96;
    csz->step = 4;
    csz->onChanged = [](double v) { backend().set("cursorSize", (int)v); backend().applyDesktopTheme(); };

    auto fonts = card(p, "Fonts", "type");
    auto *fc = fonts.body->add<Columns>();
    fc->threshold = 600;
    fc->spacing = 20;
    for (int mono = 0; mono < 2; mono++) {
        auto *c = col(fc, 8);
        c->add<Label>(mono ? "Terminal & monospace" : "Interface", 12, Weight::DemiBold, Role::Text3);
        auto *r = row(c, 10);
        auto *d = dropKey(r, mono ? "monoFont" : "font", backend().fonts(mono), {}, [p] { backend().applyDesktopTheme(); p->rebuildSoon(); });
        d->grow = 1;
        d->fill = true;
        d->searchable = true;
        d->previewFonts = true;
        auto *st = r->add<Stepper>();
        st->value = backend().d(mono ? "monoSize" : "fontSize", 14);
        st->min = 9;
        st->max = 24;
        std::string key = mono ? "monoSize" : "fontSize";
        st->onChanged = [key, mono](double v) { backend().set(key, (int)v); if (!mono) backend().applyDesktopTheme(); };
        // preview
        auto *pv = col(c, 6);
        pv->radius = 12;
        pv->bg = Color{0, 0, 0, mono ? 0.3 : 0.18};
        pv->padding(18);
        pv->fixedH = 170;
        pv->add<Label>("Preview", 12, Weight::DemiBold, Role::Text3);
        if (!mono) {
            auto *big = pv->add<Label>("The quick brown fox", backend().d("fontSize", 14) * 1.85, Weight::DemiBold);
            big->font.family = backend().s("font", "Inter");
            auto *small = pv->add<Label>("jumps over the lazy dog. 0123456789 — Settings, buttons and panels use this face.", backend().d("fontSize", 14),
                                         Weight::Normal, Role::Text2);
            small->font.family = backend().s("font", "Inter");
            small->maxLines = 0;
        } else {
            for (std::string l : {"user@fedora:~$ ls -la", "drwxr-xr-x  user  4.0K  Projects", "-rw-r--r--  user  1.2K  nova.conf", "{ } [ ] ( ) => != 0O 1lI"}) {
                auto *x = pv->add<Label>(l, backend().d("monoSize", 14), Weight::Normal, Role::Text2);
                x->font.family = backend().s("monoFont", "JetBrains Mono");
            }
        }
    }

    auto motion = card(p, "Windows & motion", "square");
    auto *mr = row(motion.body, 28);
    auto *rc = col(mr, 6);
    rc->add<Label>("Corner radius", 12, Weight::DemiBold, Role::Text3);
    auto *rad = rc->add<Stepper>();
    rad->value = backend().d("cornerRadius", 14);
    rad->max = 32;
    rad->step = 2;
    rad->onChanged = [](double v) { backend().set("cornerRadius", (int)v); };
    auto *sc = col(mr, 6);
    sc->grow = 1;
    sc->add<Label>("Animation speed", 12, Weight::DemiBold, Role::Text3);
    auto *speed = sliderKey(sc, "animationSpeed", 0.25, 2, [](double v) { char b[16]; snprintf(b, sizeof b, "%.2f×", v); return std::string(b); }, 0.05);
    speed->fixedW = -1;
    auto *sc2 = col(mr, 6);
    sc2->add<Label>("Screen corners", 12, Weight::DemiBold, Role::Text3);
    auto *corner = sc2->add<Stepper>();
    corner->value = backend().d("screenCorners", 12);
    corner->max = 24;
    corner->step = 2;
    corner->onChanged = [](double v) { backend().set("screenCorners", (int)v); };
    auto *shadows = col(mr, 0);
    shadows->fixedW = 300;
    toggleKey(row2(shadows, "Soft window shadows", {.key = "windowShadows"}), "windowShadows");
}

// =============================================================== Connections ==
static std::string btIcon(const std::string &icon) {
    if (icon.find("audio") != std::string::npos || icon.find("head") != std::string::npos) return "headphones";
    if (icon.find("mouse") != std::string::npos || icon.find("input") != std::string::npos) return "mouse";
    if (icon.find("phone") != std::string::npos) return "phone";
    return "bt";
}

void pageConnections(Page *p) {
    const Theme &t = theme();
    auto &B = backend();
    json nets = B.wifiNetworks(false), bt = B.bluetoothDevices(), vpns = B.vpnConnections(), wired = B.wiredStatus();
    bool wifiOn = B.wifiEnabled(), btOn = B.bluetoothPowered();
    p->timer(10000, [p] { p->rebuildSoon(); }, true)->start();
    auto *cols = p->add<Columns>();

    // ---- Wi-Fi ----
    std::string activeSsid;
    for (auto &n : nets) if (n.value("active", false)) activeSsid = n["ssid"];
    auto wifi = card(cols, "Wi-Fi", "wifi", !wifiOn ? "Off" : !activeSsid.empty() ? "Connected to " + activeSsid : "Not connected");
    auto *wt = wifi.extra->add<Toggle>(wifiOn);
    wt->onToggled = [p](bool v) { Backend::run({"nmcli", "radio", "wifi", v ? "on" : "off"}); p->rebuildSoon(); };
    auto *err = wifi.body->add<Label>("", 12);
    err->role = Role::Custom;
    err->color = Color::hex("#ff8a7a");
    err->maxLines = 0;
    err->visible = false;
    if (wifiOn) {
        for (auto &n : nets) {
            std::string ssid = n["ssid"];
            bool active = n.value("active", false), secure = n.value("secure", false);
            int signal = n.value("signal", 0);
            auto *wrap = col(wifi.body, 6);
            auto *b = wrap->add<Button>(Dir::Row, 14);
            b->fixedH = 50;
            b->radius = 12;
            b->padding(12, 0);
            b->bg = active ? t.accentSoft : Color{0, 0, 0, 0};
            b->hoverBg = active ? t.accentSoft : t.surface3;
            auto *ic = b->add<IconW>("wifi", 20, active ? Role::AccentBright : Role::Text);
            ic->opacity.set(0.35 + signal / 150.0);
            b->add<Label>(ssid, 14, active ? Weight::DemiBold : Weight::Normal)->grow = 1;
            if (active) b->add<Label>("Connected", 13, Weight::Normal, Role::AccentBright)->fill = false;
            if (secure) b->add<IconW>("lock", 15, Role::Text3);
            else b->add<Label>("Open", 13, Weight::Normal, Role::Text3)->fill = false;
            // password row (hidden until needed)
            auto *pw = row(wrap, 8);
            pw->visible = false;
            auto *pf = pw->add<TextInput>();
            pf->password = true;
            pf->grow = 1;
            pf->placeholder = "Password for " + ssid;
            auto *go = btn(pw, "Connect", "", true);
            auto connect = [p, pf, ssid, err, pw] {
                std::string e = backend().wifiConnect(ssid, pf->text());
                pf->setText("");
                if (e.empty()) { pw->visible = false; p->rebuildSoon(); }
                else { err->setText(e); err->visible = true; err->relayout(); }
            };
            go->onClick = connect;
            pf->onSubmit = [connect](const std::string &) { connect(); };
            b->onClick = [p, ssid, active, secure, pw, pf, err] {
                if (active) { Backend::run({"nmcli", "con", "down", "id", ssid}); p->rebuildSoon(); return; }
                std::string e = backend().wifiConnect(ssid, "");
                if (!e.empty() && secure) { pw->visible = true; pw->relayout(); if (pf->window()) pf->window()->setFocus(pf); }
                else if (!e.empty()) { err->setText(e); err->visible = true; err->relayout(); }
                else p->rebuildSoon();
            };
        }
    }
    auto *wb = row(wifi.body, 8);
    btn(wb, "Hidden network", "plus")->onClick = [] { Backend::runDetached({"nm-connection-editor"}); };
    btn(wb, "Rescan", "restart")->onClick = [p] { backend().wifiNetworks(true); p->rebuildSoon(); };

    // ---- Bluetooth ----
    auto blue = card(cols, "Bluetooth", "bt", btOn ? "Visible as “" + B.systemInfo().value("host", std::string()) + "”" : "Off");
    auto *bt_t = blue.extra->add<Toggle>(btOn);
    bt_t->onToggled = [p](bool v) { Backend::run({"bluetoothctl", "power", v ? "on" : "off"}); p->rebuildSoon(); };
    if (btOn) {
        for (int pass = 0; pass < 2; pass++) {
            blue.body->add<Label>(pass == 0 ? "My devices" : "Nearby", 12, Weight::DemiBold, Role::Text3);
            for (auto &d : bt) {
                bool paired = d.value("paired", false), connected = d.value("connected", false);
                if (paired != (pass == 0)) continue;
                std::string mac = d["mac"];
                auto *r = row(blue.body, 14);
                r->fixedH = 52;
                r->radius = 12;
                r->padding(12, 0);
                r->bg = connected ? t.accentSoft : Color{0, 0, 0, 0};
                r->add<IconW>(btIcon(d.value("icon", std::string())), 20, connected ? Role::AccentBright : Role::Text);
                auto *tc = col(r, 1);
                tc->grow = 1;
                tc->add<Label>(d.value("name", mac), 14, connected ? Weight::DemiBold : Weight::Normal);
                tc->add<Label>(connected ? "Connected" : paired ? "Not connected" : "Available", 12, Weight::Normal, Role::Text3);
                int batt = d.value("battery", -1);
                if (batt >= 0) r->add<Label>(std::to_string(batt) + "%", 13, Weight::Normal, Role::Text3)->fill = false;
                auto *b = btn(r, connected ? "Disconnect" : paired ? "Connect" : "Pair");
                b->fixedH = 30;
                b->onClick = [p, mac, paired, connected] {
                    if (paired) Backend::run({"bluetoothctl", connected ? "disconnect" : "connect", mac}, 20000);
                    else Backend::run({"sh", "-c", "bluetoothctl pair \"$1\" && bluetoothctl trust \"$1\" && bluetoothctl connect \"$1\"", "sh", mac}, 20000);
                    p->rebuildSoon();
                };
            }
        }
        btn(blue.body, "Scan for devices", "search")->onClick = [p] {
            Backend::runDetached({"bluetoothctl", "--timeout", "10", "scan", "on"});
            p->conns.after(6000, [p] { p->rebuildSoon(); });
        };
    }

    // ---- wired / VPN ----
    std::string dev = wired.value("device", std::string());
    bool wcon = wired.value("connected", false);
    auto w = card(cols, "Wired", "net", dev.empty() ? "No ethernet adapter" : wcon ? "Connected · " + wired.value("connection", std::string()) : "Cable unplugged");
    auto *wtog = w.extra->add<Toggle>(wcon);
    if (dev.empty()) { wtog->interactive = false; wtog->opacity.set(0.4); }
    wtog->onToggled = [p, dev](bool v) { Backend::run({"nmcli", "dev", v ? "connect" : "disconnect", dev}); p->rebuildSoon(); };

    int activeV = 0;
    for (auto &v : vpns) if (v.value("active", false)) activeV++;
    auto vpn = card(cols, "VPN", "shield", vpns.empty() ? "No VPN connections" : std::to_string(activeV) + " of " + std::to_string(vpns.size()) + " active");
    btn(vpn.extra, "Add", "plus")->onClick = [] { Backend::runDetached({"nm-connection-editor"}); };
    for (auto &v : vpns) {
        std::string name = v["name"];
        auto *slot = row2(vpn.body, name, {.hint = v.value("type", std::string()) == "wireguard" ? "WireGuard" : "VPN"});
        auto *tg = slot->add<Toggle>(v.value("active", false));
        tg->onToggled = [p, name](bool on) { Backend::run({"nmcli", "con", on ? "up" : "down", "id", name}, 15000); p->rebuildSoon(); };
    }

    // ---- hotspot / airplane ----
    auto misc = card(p);
    auto *mr = misc.body->add<Columns>();
    mr->threshold = 600;
    auto *hs = row2(mr, "Hotspot", {.hint = "Share this connection over Wi-Fi"});
    hs->add<Toggle>(false)->onToggled = [](bool v) {
        Backend::runDetached(v ? std::vector<std::string>{"nmcli", "dev", "wifi", "hotspot"} : std::vector<std::string>{"nmcli", "con", "down", "Hotspot"});
    };
    auto *ap = row2(mr, "Airplane mode", {.hint = "Turns off Wi-Fi and Bluetooth"});
    ap->add<Toggle>(!wifiOn && !btOn)->onToggled = [p](bool v) {
        Backend::run({"nmcli", "radio", "all", v ? "off" : "on"});
        Backend::run({"bluetoothctl", "power", v ? "off" : "on"});
        p->rebuildSoon();
    };
}

// ================================================================== Display ==
// Arrange monitors by dragging (edges snap), then pick resolution, refresh, scale and
// rotation for the selected one. Applied with wlr-randr.
struct DisplayState {
    json outs = json::array();
    int sel = 0;
    std::string error;
};

static Size logicalSize(const json &o) {
    json m = o.value("mode", json{{"width", 1920}, {"height", 1080}});
    std::string tr = o.value("transform", std::string("normal"));
    bool rot = tr.find("90") != std::string::npos || tr.find("270") != std::string::npos;
    double s = std::max(0.1, o.value("scale", 1.0));
    double w = m.value("width", 1920), h = m.value("height", 1080);
    return {(rot ? h : w) / s, (rot ? w : h) / s};
}

class Arrangement : public Widget {
public:
    std::shared_ptr<DisplayState> st;
    std::function<void()> changed;
    Arrangement() { interactive = true; fixedH = 300; }
    Rect bounds() const {
        double x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        for (auto &o : st->outs) {
            if (!o.value("enabled", false)) continue;
            Size s = logicalSize(o);
            double x = o.value("x", 0), y = o.value("y", 0);
            x0 = std::min(x0, x); y0 = std::min(y0, y); x1 = std::max(x1, x + s.w); y1 = std::max(y1, y + s.h);
        }
        return x0 > x1 ? Rect{0, 0, 1920, 1080} : Rect{x0, y0, x1 - x0, y1 - y0};
    }
    double k() const { Rect b = bounds(); return std::min((geom.w - 160) / b.w, (geom.h - 90) / b.h); }
    Point origin() const {
        Rect b = bounds();
        double kk = k();
        return {geom.x + (geom.w - b.w * kk) / 2 - b.x * kk, geom.y + (geom.h - b.h * kk) / 2 - b.y * kk - 10};
    }
    Rect rectOf(int i) const {
        const json &o = st->outs[i];
        Size s = logicalSize(o);
        double kk = k();
        Point org = origin();
        Rect r{org.x + o.value("x", 0) * kk, org.y + o.value("y", 0) * kk, s.w * kk, s.h * kk};
        if (i == drag_) r = r.translated(off_.x, off_.y);
        return r;
    }
    void paint(Painter &p) override {
        const Theme &t = theme();
        p.save();
        p.clip(geom, 12);
        p.fill(geom, Color{1, 1, 1, 0.02});
        for (double x = 0; x < geom.w; x += 24) p.fill({geom.x + x, geom.y, 1, geom.h}, Color{1, 1, 1, 0.035});
        for (double y = 0; y < geom.h; y += 24) p.fill({geom.x, geom.y + y, geom.w, 1}, Color{1, 1, 1, 0.035});
        for (int i = 0; i < (int)st->outs.size(); i++) {
            const json &o = st->outs[i];
            if (!o.value("enabled", false)) continue;
            Rect r = rectOf(i);
            bool on = i == st->sel;
            p.fill(r, on ? t.accentSoft : Color{1, 1, 1, 0.06}, 12);
            p.stroke(r.inset(1), on ? t.accent : Color{1, 1, 1, 0.22}, on ? 2 : 1.5, 12);
            Font f;
            f.size = 14;
            f.weight = Weight::DemiBold;
            std::string title = o.value("builtin", false) ? "Built-in display" : o.value("model", std::string()).empty() ? o.value("name", std::string()) : o.value("model", std::string());
            Text tt(title, f, r.w - 60);
            p.text(tt, {r.x + 12, r.y + 12}, t.text);
            p.fillCircle({r.right() - 24, r.y + 24}, 12, on ? t.accent : t.surface3);
            Font nf;
            nf.size = 13;
            nf.weight = Weight::Bold;
            Text nt(std::to_string(i + 1), nf);
            p.textIn(nt, {r.right() - 36, r.y + 12, 24, 24}, on ? t.onAccent : t.text, Align::Center);
            if (o.contains("mode")) {
                char b[64];
                snprintf(b, sizeof b, "%d × %d · %d Hz", o["mode"].value("width", 0), o["mode"].value("height", 0), (int)std::lround(o["mode"].value("refresh", 0.0)));
                Font sf;
                sf.size = 12;
                Text st2(b, sf, r.w - 24);
                p.text(st2, {r.x + 12, r.bottom() - 12 - st2.size().h}, t.text2);
            }
        }
        Font cf;
        cf.size = 12;
        Text hint("Drag screens to arrange them · edges snap together", cf);
        p.text(hint, {geom.x + 14, geom.bottom() - 14 - hint.size().h}, t.text3);
        p.restore();
    }
    bool pointerPress(Point pt, int button) override {
        for (int i = (int)st->outs.size() - 1; i >= 0; i--)
            if (st->outs[i].value("enabled", false) && rectOf(i).contains(pt)) {
                st->sel = i;
                if (st->outs.size() > 1) { drag_ = i; start_ = pt; off_ = {0, 0}; }
                if (changed) changed();
                return true;
            }
        return true;
    }
    void pointerMove(Point pt) override {
        if (drag_ < 0) return;
        off_ = {pt.x - start_.x, pt.y - start_.y};
        update();
    }
    void pointerRelease(Point, int) override {
        if (drag_ < 0) return;
        int i = drag_;
        drag_ = -1;
        double kk = k();
        json &me = st->outs[i];
        double nx = me.value("x", 0) + off_.x / kk, ny = me.value("y", 0) + off_.y / kk;
        Size ms = logicalSize(me);
        off_ = {0, 0};
        // snap to the nearest edge of another output, keeping the edges overlapping
        double bestD = 1e18, bx = nx, by = ny;
        for (int j = 0; j < (int)st->outs.size(); j++) {
            const json &o = st->outs[j];
            if (j == i || !o.value("enabled", false)) continue;
            Size s = logicalSize(o);
            double ox = o.value("x", 0), oy = o.value("y", 0);
            std::vector<Point> cands = {{ox + s.w, ny}, {ox - ms.w, ny}, {nx, oy + s.h}, {nx, oy - ms.h}};
            for (size_t c = 0; c < cands.size(); c++) {
                Point q = cands[c];
                if (c < 2) q.y = std::clamp(q.y, oy - ms.h + 40, oy + s.h - 40);
                else q.x = std::clamp(q.x, ox - ms.w + 40, ox + s.w - 40);
                double d = std::hypot(q.x - nx, q.y - ny);
                if (d < bestD) { bestD = d; bx = q.x; by = q.y; }
            }
        }
        me["x"] = (int)std::lround(bx);
        me["y"] = (int)std::lround(by);
        update();
        if (changed) changed();
    }
private:
    int drag_ = -1;
    Point start_, off_;
};

static void buildDisplay(Page *p, std::shared_ptr<DisplayState> st) {
    p->clear();
    const Theme &t = theme();
    auto arr = card(p);
    auto *a = arr.body->add<Arrangement>();
    a->st = st;
    a->changed = [p, st] { p->conns.later([p, st] { buildDisplay(p, st); }); };
    auto *br = row(arr.body, 8);
    if (!st->error.empty()) {
        auto *e = br->add<Label>(st->error, 12);
        e->role = Role::Custom;
        e->color = Color::hex("#ff8a7a");
        e->grow = 1;
    } else stretch(br);
    btn(br, "Identify")->onClick = [st] {
        for (size_t i = 0; i < st->outs.size(); i++)
            Backend::runDetached({"notify-send", "-a", "Display", "Display " + std::to_string(i + 1),
                                  st->outs[i].value("name", std::string()) + " — " + st->outs[i].value("description", std::string())});
    };
    btn(br, "Apply", "", true)->onClick = [p, st] {
        st->error.clear();
        for (auto &o : st->outs) { std::string e = backend().applyDisplay(o); if (!e.empty()) st->error = e; }
        int sel = st->sel;
        st->outs = backend().displays();
        st->sel = std::min(sel, std::max(0, (int)st->outs.size() - 1));
        p->conns.later([p, st] { buildDisplay(p, st); });
    };

    if (st->outs.empty()) {
        caption(p, "No displays found (wlr-randr isn't installed or the compositor doesn't support output management).");
        p->relayout();
        return;
    }
    json &cur = st->outs[st->sel];
    std::string title = cur.value("builtin", false) ? "Built-in display" : trim(cur.value("make", std::string()) + " " + cur.value("model", std::string()));
    if (title.empty()) title = cur.value("name", std::string());
    std::string sub;
    if (!cur.value("inches", std::string()).empty()) sub += cur.value("inches", std::string()) + "″ · ";
    sub += cur.value("name", std::string());
    if (st->sel == 0) sub += " · primary";
    auto det = card(p, title, "monitor", sub);
    det.extra->add<Label>("Enabled", 13)->fill = false;
    auto *en = det.extra->add<Toggle>(cur.value("enabled", false));
    auto rebuild = [p, st] { p->conns.later([p, st] { buildDisplay(p, st); }); };
    en->onToggled = [st, rebuild](bool v) { st->outs[st->sel]["enabled"] = v; rebuild(); };

    auto *g = det.body->add<Columns>();
    g->threshold = 600;
    g->spacing = 18;
    // resolutions
    std::vector<std::string> res;
    std::string curRes;
    if (cur.contains("mode")) curRes = std::to_string(cur["mode"].value("width", 0)) + " × " + std::to_string(cur["mode"].value("height", 0));
    for (auto &m : cur["modes"]) {
        std::string r = std::to_string(m.value("width", 0)) + " × " + std::to_string(m.value("height", 0));
        if (std::find(res.begin(), res.end(), r) == res.end()) res.push_back(r);
    }
    auto *rc = col(g, 6);
    rc->add<Label>("Resolution", 12, Weight::DemiBold, Role::Text3);
    auto *rd = rc->add<Dropdown>();
    for (auto &r : res) {
        bool pref = false;
        for (auto &m : cur["modes"])
            if (m.value("preferred", false) && std::to_string(m.value("width", 0)) + " × " + std::to_string(m.value("height", 0)) == r) pref = true;
        rd->items.push_back({r, pref ? r + " (recommended)" : r});
    }
    rd->setValue(curRes);
    rd->onPicked = [st, rebuild](const std::string &r) {
        json &c = st->outs[st->sel];
        json best;
        for (auto &m : c["modes"])
            if (std::to_string(m.value("width", 0)) + " × " + std::to_string(m.value("height", 0)) == r && (best.is_null() || m.value("refresh", 0.0) > best.value("refresh", 0.0)))
                best = m;
        if (!best.is_null()) c["mode"] = best;
        rebuild();
    };
    // refresh rates
    auto *fc = col(g, 6);
    fc->add<Label>("Refresh rate", 12, Weight::DemiBold, Role::Text3);
    auto *fd = fc->add<Dropdown>();
    std::vector<json> rates;
    for (auto &m : cur["modes"])
        if (std::to_string(m.value("width", 0)) + " × " + std::to_string(m.value("height", 0)) == curRes) rates.push_back(m);
    std::sort(rates.begin(), rates.end(), [](const json &a, const json &b) { return a.value("refresh", 0.0) > b.value("refresh", 0.0); });
    for (size_t i = 0; i < rates.size(); i++) {
        double r = rates[i].value("refresh", 0.0);
        char b[32];
        snprintf(b, sizeof b, std::fmod(r, 1) > 0.05 ? "%.2f Hz" : "%.0f Hz", r);
        fd->items.push_back({std::to_string(i), b});
        if (cur.contains("mode") && std::fabs(r - cur["mode"].value("refresh", 0.0)) < 0.01) fd->setValue(std::to_string(i));
    }
    fd->onPicked = [st, rates, rebuild](const std::string &v) { st->outs[st->sel]["mode"] = rates[atoi(v.c_str())]; rebuild(); };
    // scale
    auto *sc = col(g, 6);
    sc->add<Label>("Scale", 12, Weight::DemiBold, Role::Text3);
    auto *sr = row(sc, 6);
    double scale = cur.value("scale", 1.0);
    for (double s : {1.0, 1.25, 1.5, 1.75, 2.0}) {
        bool on = std::fabs(scale - s) < 0.01;
        auto *b = sr->add<Button>(Dir::Row, 0);
        b->fixedW = 58;
        b->fixedH = 32;
        b->radius = 16;
        b->bg = on ? t.accent : t.surface2;
        b->hoverBg = on ? t.accentBright : t.surface3;
        b->justify = Justify::Center;
        b->add<Label>(std::to_string((int)std::lround(s * 100)) + "%", 13, on ? Weight::DemiBold : Weight::Normal, on ? Role::OnAccent : Role::Text2)->fill = false;
        b->onClick = [st, s, rebuild] { st->outs[st->sel]["scale"] = s; rebuild(); };
    }
    auto *ss = sr->add<Stepper>();
    ss->value = std::lround(scale * 100);
    ss->min = 100;
    ss->max = 200;
    ss->step = 5;
    ss->suffix = " %";
    ss->onChanged = [st](double v) { st->outs[st->sel]["scale"] = v / 100; };
    // rotation
    auto *tc = col(g, 6);
    tc->add<Label>("Rotation", 12, Weight::DemiBold, Role::Text3);
    auto *td = tc->add<Dropdown>();
    std::vector<std::string> vals = {"normal", "90", "180", "270", "flipped", "flipped-90", "flipped-180", "flipped-270"};
    std::vector<std::string> names = {"Normal", "90° counter-clockwise", "Upside down", "90° clockwise", "Flipped", "Flipped 90°", "Flipped 180°", "Flipped 270°"};
    for (size_t i = 0; i < vals.size(); i++) td->items.push_back({vals[i], names[i]});
    td->setValue(cur.value("transform", std::string("normal")));
    td->onPicked = [st, rebuild](const std::string &v) { st->outs[st->sel]["transform"] = v; rebuild(); };
    auto *vrr = row2(g, "Variable refresh rate", {.hint = "Smoother games and video on supported screens"});
    vrr->add<Toggle>(cur.value("adaptiveSync", false))->onToggled = [st](bool v) { st->outs[st->sel]["adaptiveSync"] = v; };
    if (st->outs.size() > 1) {
        int other = st->sel == 0 ? 1 : 0;
        auto *mir = row2(g, "Mirror to display " + std::to_string(other + 1));
        mir->add<Toggle>(false)->onToggled = [st, other](bool v) {
            json &o = st->outs[other];
            const json &c = st->outs[st->sel];
            o["x"] = v ? c.value("x", 0) : o.value("x", 0) + 1;
            o["y"] = v ? c.value("y", 0) : o.value("y", 0);
        };
    }
    p->relayout();
}

void pageDisplay(Page *p) {
    auto st = std::make_shared<DisplayState>();
    st->outs = backend().displays();
    for (size_t i = 0; i < st->outs.size(); i++) if (st->outs[i].value("builtin", false)) { st->sel = (int)i; break; }
    buildDisplay(p, st);
}

}  // namespace settings
