// nova-settings: Settings for the Nova desktop, drawn with the same toolkit as the shell.
//   nova-settings [--page NAME] [--trim FILE]
#include "pages.hpp"
#include "ui/wayland.hpp"

#include <csignal>
#include <poll.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <cstring>
#include <filesystem>

using namespace settings;
using namespace ui;

namespace settings {
int runTrim(const std::string &file);   // trim.cpp
}

static void applyTheme() {
    auto &B = backend();
    Theme &t = theme();
    t.dark = B.s("mode", "dark") != "light";
    t.accent = Color::hex(B.s("accent", "#c8b64a"), Color::hex("#c8b64a"));
    t.font = B.s("font", "Inter");
    t.mono = B.s("monoFont", "JetBrains Mono");
    t.transparencyUi = B.d("transparencyUi", 0.8);
    t.transparencyPanel = B.d("transparencyPanel", 0.8);
    t.transparencyApps = B.d("transparencyApps", 0.8);
    t.blurUi = B.d("blurUi", 0.8);
    t.blurPanel = B.d("blurPanel", 0.8);
    t.blurApps = B.d("blurApps", 0.8);
    t.animationSpeed = B.d("animationSpeed", 1.0);
    const char *rb = getenv("NOVA_REAL_BLUR");
    t.realBlur = rb && std::string(rb) == "1";
    setIconTheme(B.s("iconTheme", t.dark ? "Papirus-Dark" : "Papirus"));
    t.rebuild();
    t.changed.emit();
}

struct PageDef { std::string icon, name; void (*build)(Page *); };
static const std::vector<PageDef> &pageDefs() {
    static const std::vector<PageDef> d = {
        {"palette", "Appearance", pageAppearance}, {"wifi", "Connections", pageConnections}, {"monitor", "Display", pageDisplay},
        {"volume", "Sound", pageSound}, {"battery", "Power", pagePower}, {"bell", "Notifications", pageNotifications},
        {"frame", "Popups & indicators", pagePopups}, {"music", "Music & lyrics", pageMusic}, {"", "", nullptr},
        {"game", "Gaming", pageGaming}, {"square", "Windows & tiling", pageWindows}, {"keyboard", "Keyboard", pageKeyboard},
        {"mouse", "Mouse & touchpad", pageMouse}, {"grid", "Panel & launcher", pagePanel}, {"user", "Users", pageUsers},
        {"restart", "Updates", pageUpdates}, {"info", "About", pageAbout}};
    return d;
}

// translucent window background over the (blurred) wallpaper
class Frame : public Box {
public:
    explicit Frame(ToplevelWindow *w) : Box(Dir::Row, 0), win(w) { interactive = true; }
    ToplevelWindow *win;
    bool maximized = false;
    static constexpr double kBorder = 7;
    // xdg_toplevel resize edges under p (0 = none)
    uint32_t edgesAt(Point p) const {
        if (maximized) return 0;
        uint32_t e = 0;
        if (p.y < geom.y + kBorder) e |= 1;
        if (p.y > geom.bottom() - kBorder) e |= 2;
        if (p.x < geom.x + kBorder) e |= 4;
        if (p.x > geom.right() - kBorder) e |= 8;
        return e;
    }
    Widget *hitTest(Point p) override {
        if (!geom.contains(p)) return nullptr;
        uint32_t e = edgesAt(p);
        if (e) {
            cursor = (e == 1 || e == 2) ? Cursor::ResizeNS : (e == 4 || e == 8) ? Cursor::ResizeEW
                   : (e == 5 || e == 10) ? Cursor::ResizeNWSE : Cursor::ResizeNESW;
            return this;
        }
        cursor = Cursor::Default;
        return Box::hitTest(p);
    }
    bool pointerPress(Point p, int button) override {
        uint32_t e = edgesAt(p);
        if (button != 1 || !e) return false;
        win->startResize(e);
        return true;
    }
    std::shared_ptr<Image> backdrop;
    void paint(Painter &p) override {
        const Theme &t = theme();
        double r = maximized ? 0 : 16;
        p.save();
        p.clip(geom, r);
        if (!t.realBlur && backdrop && backdrop->valid() && t.blurApps > 0.02) p.image(*backdrop, geom);
        p.fill(geom, t.window);
        p.restore();
        p.stroke(geom.inset(0.5), t.border, 1, r);
    }
};

class Sidebar : public Box {
public:
    Sidebar() : Box(Dir::Column, 2) {}
    void paint(Painter &p) override {
        const Theme &t = theme();
        p.fill(geom, t.dark ? Color{0, 0, 0, 0.16} : Color{1, 1, 1, 0.25});
        p.fill({geom.right() - 1, geom.y, 1, geom.h}, t.border);
    }
};

// header strip: drag to move, double click to maximise
class DragArea : public Box {
public:
    explicit DragArea(ToplevelWindow *w) : Box(Dir::Row, 6), win(w) { interactive = true; }
    ToplevelWindow *win;
    int64_t last = 0;
    bool pointerPress(Point, int button) override {
        if (button != 1) return false;
        int64_t now = nowMs();
        if (now - last < 350) { win->setMaximized(!win->maximized()); last = 0; return true; }
        last = now;
        win->startMove();
        return true;
    }
};

class Grip : public Widget {
public:
    explicit Grip(ToplevelWindow *w) : win(w) { interactive = true; cursor = Cursor::ResizeNWSE; fixedW = fixedH = 18; }
    ToplevelWindow *win;
    bool pointerPress(Point, int) override { win->startResize(10); return true; }   // bottom-right
};

class SettingsWindow : public ToplevelWindow {
public:
    explicit SettingsWindow(const std::string &start) : ToplevelWindow("Settings", "nova-settings", {1240, 780}) {
        setMinSize(900, 600);
        build();
        showPage(start.empty() ? "Appearance" : start);
        conns_.on(backend().changed, [this] {
            // mode / accent / transparency: repaint with the new theme
            std::string sig = backend().s("mode") + backend().s("accent") + std::to_string(backend().d("transparencyApps")) +
                              std::to_string(backend().d("blurApps")) + backend().s("wallpaper") + backend().s("iconTheme") +
                              backend().s("font") + backend().s("monoFont");
            if (sig != themeSig_) {
                themeSig_ = sig;
                applyTheme();
                updateBackdrop();
                buildNav();
                // every label re-measures in the new font / theme
                conns_.later([this] { showPage(page_, true); });
                update();
            }
        });
        conns_.on(backend().reloadPage, [this] { conns_.later([this] { showPage(page_, true); }); });
        themeSig_ = backend().s("mode") + backend().s("accent") + std::to_string(backend().d("transparencyApps")) +
                    std::to_string(backend().d("blurApps")) + backend().s("wallpaper") + backend().s("iconTheme") +
                    backend().s("font") + backend().s("monoFont");
        // the compositor blurs whatever is behind the whole window (SceneFX); the cards inside
        // don't need their own blur on top of that
        blurProvider = [this]() -> std::vector<std::pair<Rect, double>> {
            if (backend().d("blurApps", 0.8) < 0.02) return {};
            return {{{0, 0, size().w, size().h}, maximized() ? 0.0 : 16.0}};
        };
        resized.connect([this](Size) {
            frame_->maximized = maximized();
            updateBackdrop();
        });
    }
    ~SettingsWindow() override { page_ = ""; }
    void openPage(const std::string &name) { showPage(name); }

private:
    Connections conns_;
    std::string page_, filter_, themeSig_;
    Frame *frame_ = nullptr;
    Box *nav_ = nullptr;
    Label *title_ = nullptr;
    ScrollView *scroll_ = nullptr;
    Box *holder_ = nullptr;
    Page *current_ = nullptr;

    void updateBackdrop() {
        if (theme().realBlur) { frame_->backdrop.reset(); return; }
        Image src(wallpaperOrDefault(), 960, 540);
        if (!src.valid()) return;
        double b = theme().blurApps;
        frame_->backdrop = std::make_shared<Image>(src.blurred((int)std::lround(8 + b * 30), 0.15 + 0.85 * (1 - b)));
    }

    void build() {
        frame_ = setRoot<Frame>(this);
        // ---- sidebar ----
        auto *side = frame_->add<Sidebar>();
        side->fixedW = 268;
        side->padding(14);
        side->pt = 22;
        auto *drag = side->add<DragArea>(this);
        auto *h = drag->add<Label>("Settings", 20, Weight::DemiBold);
        h->ml = 10;
        drag->mb = 12;
        auto *search = side->add<TextInput>();
        search->leadingIcon = "search";
        search->placeholder = "Search settings";
        search->fixedH = 38;
        search->mb = 12;
        search->onChanged = [this](const std::string &s) { filter_ = lower(s); conns_.later([this] { buildNav(); }); };
        search->onSubmit = [this](const std::string &) {
            for (auto &d : pageDefs()) if (d.build && lower(d.name).find(filter_) != std::string::npos) { showPage(d.name); break; }
        };
        auto *sv = side->add<ScrollView>();
        sv->grow = 1;
        nav_ = sv->add<Box>(Dir::Column, 2);
        buildNav();

        // ---- content ----
        auto *content = col(frame_, 0);
        content->grow = 1;
        auto *head = content->add<DragArea>(this);
        head->fixedH = 68;
        head->pl = 34;
        head->pr = 14;
        title_ = head->add<Label>("", 26, Weight::DemiBold, Role::AccentBright);
        title_->grow = 1;
        auto *wb = row(head, 6);
        wb->alignSelf = Align::Start;
        wb->fill = false;
        wb->mt = 12;
        auto winBtn = [&](const std::string &icon, std::function<void()> fn, bool danger) {
            auto *b = wb->add<IconButton>(icon, 30, 16);
            b->radius = 9;
            b->bg = Color{0, 0, 0, 0};
            b->hoverBg = danger ? theme().danger : theme().surface3;
            b->icon->role = Role::Text2;
            b->onHover = [b, danger](bool hv) { b->icon->role = hv && danger ? Role::Custom : Role::Text2; b->icon->color = Color{1, 1, 1, 1}; };
            b->onClick = std::move(fn);
        };
        winBtn("minus", [this] { minimize(); }, false);
        winBtn("square", [this] { setMaximized(!maximized()); }, false);
        winBtn("x", [this] { close(); }, true);

        scroll_ = content->add<ScrollView>();
        scroll_->grow = 1;
        holder_ = scroll_->add<Box>(Dir::Column, 0);
        holder_->pl = holder_->pr = 34;
        holder_->pb = 24;
        auto *grip = content->add<Grip>(this);
        grip->fill = false;
        grip->alignSelf = Align::End;
        grip->mt = -18;
    }

    void buildNav() {
        if (!nav_) return;
        const Theme &t = theme();
        nav_->clear();
        for (auto &d : pageDefs()) {
            if (!d.build) {
                if (!filter_.empty()) continue;
                auto *s = nav_->add<Separator>(false, 10);
                s->mt = s->mb = 6;
                continue;
            }
            if (!filter_.empty() && lower(d.name).find(filter_) == std::string::npos) continue;
            bool on = d.name == page_;
            auto *b = nav_->add<Button>(Dir::Row, 12);
            b->fixedH = 36;
            b->radius = 11;
            b->pl = 12;
            b->bg = on ? t.accentSoft : Color{0, 0, 0, 0};
            b->hoverBg = on ? t.accentSoft : t.surface2;
            if (on) {
                auto *bar = b->add<Box>();
                bar->fixedW = 3;
                bar->fixedH = 20;
                bar->radius = 2;
                bar->bg = t.accent;
                bar->fill = false;
                bar->ml = -9;
                bar->mr = -6;
            }
            b->add<IconW>(d.icon, 18, on ? Role::AccentBright : Role::Text2);
            b->add<Label>(d.name, 14, on ? Weight::DemiBold : Weight::Normal, on ? Role::AccentBright : Role::Text2)->grow = 1;
            std::string n = d.name;
            b->onClick = [this, n] { conns_.later([this, n] { showPage(n); }); };
        }
        nav_->relayout();
    }

public:
    void showPage(const std::string &name, bool keepScroll = false) {
        const PageDef *def = nullptr;
        for (auto &d : pageDefs()) if (d.build && d.name == name) def = &d;
        if (!def) def = &pageDefs()[0];
        bool same = page_ == def->name;
        page_ = def->name;
        double y = scroll_->offset();
        onKey = nullptr;              // a page (shortcut editor) may have taken the keyboard
        holder_->clear();
        current_ = holder_->add<Page>();
        Page *pg = current_;
        std::string n = page_;
        pg->rebuild = [this, n] { conns_.later([this, n] { showPage(n, true); }); };
        def->build(pg);
        title_->setText(page_);
        buildNav();
        relayout();
        if (keepScroll && same) conns_.later([this, y] { scroll_->scrollTo(y, false); });
        else scroll_->scrollTo(0, false);
    }
    void close() override { Loop::get().quit(); }
};

// ---- single instance: a second launch hands its page to the first and quits ----
static std::string instanceSocketPath() {
    const char *rt = getenv("XDG_RUNTIME_DIR");
    std::string dir = rt && *rt ? rt : "/tmp";
    const char *wd = getenv("WAYLAND_DISPLAY");
    return dir + "/nova-settings-" + (wd && *wd ? wd : "wayland-0") + ".sock";
}
static bool fillAddr(sockaddr_un &a, const std::string &path) {
    memset(&a, 0, sizeof a);
    a.sun_family = AF_UNIX;
    if (path.size() >= sizeof a.sun_path) return false;
    memcpy(a.sun_path, path.c_str(), path.size());
    return true;
}
// true when another Settings is running and took the request
static bool forwardToRunning(const std::string &page) {
    sockaddr_un a;
    if (!fillAddr(a, instanceSocketPath())) return false;
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) return false;
    if (connect(fd, (sockaddr *)&a, sizeof a) != 0) { close(fd); return false; }
    std::string msg = page + "\n";
    bool ok = write(fd, msg.data(), msg.size()) == (ssize_t)msg.size();
    close(fd);
    return ok;
}
static void listenForInstances(std::function<void(const std::string &)> onPage) {
    std::string path = instanceSocketPath();
    sockaddr_un a;
    if (!fillAddr(a, path)) return;
    unlink(path.c_str());   // nobody answered, so it's stale
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (fd < 0) return;
    if (bind(fd, (sockaddr *)&a, sizeof a) != 0 || listen(fd, 4) != 0) { close(fd); return; }
    Loop::get().addFd(fd, POLLIN, [onPage](int lfd, short) {
        int c = accept4(lfd, nullptr, nullptr, SOCK_CLOEXEC);
        if (c < 0) return;
        // the message is tiny and sent in one write right after connecting
        pollfd pf{c, POLLIN, 0};
        std::string line;
        if (poll(&pf, 1, 200) > 0) {
            char buf[512];
            ssize_t n = read(c, buf, sizeof buf);
            if (n > 0) line.assign(buf, (size_t)n);
        }
        close(c);
        while (!line.empty() && (line.back() == '\n' || line.back() == '\r')) line.pop_back();
        onPage(line);
    });
}

int main(int argc, char **argv) {
    std::string page, trimFile;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if ((a == "--page" || a == "-p") && i + 1 < argc) page = argv[++i];
        else if (startsWith(a, "--page=")) page = a.substr(7);
        else if (a == "--trim" && i + 1 < argc) trimFile = argv[++i];
        else if (a == "--help" || a == "-h") { printf("usage: nova-settings [--page NAME] [--trim FILE]\n"); return 0; }
    }
    signal(SIGPIPE, SIG_IGN);
    if (trimFile.empty() && forwardToRunning(page)) return 0;
    if (!Wayland::get().connect()) { fprintf(stderr, "nova-settings: needs a Wayland session\n"); return 1; }
    std::string assets = "/usr/share/nova/shell";
    if (const char *d = getenv("NOVA_ASSETS"); d && *d) assets = d;
    setIconSearchPath(assets + "/icons");
    backend();
    backend().prefetch();
    applyTheme();
    if (!trimFile.empty()) return runTrim(trimFile);
    SettingsWindow w(page);
    w.show();
    listenForInstances([&w](const std::string &pg) {
        if (!pg.empty()) w.openPage(pg);
        ui::spawn({"novactl", "dispatch", "focus-app", "nova-settings"});
    });
    Loop::get().run();
    return 0;
}
