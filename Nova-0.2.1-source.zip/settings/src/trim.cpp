// Trim a screen recording: drag the two handles over the film strip, preview the cut
// (mpv), then save a copy or replace the file (ffmpeg, no re-encode).
#include "pages.hpp"
#include "ui/sys.hpp"
#include "ui/wayland.hpp"

#include <filesystem>
#include <unistd.h>

namespace settings {

using namespace ui;

static std::string fmtTime(double t) {
    char b[32];
    int m = (int)(t / 60);
    snprintf(b, sizeof b, "%d:%04.1f", m, t - m * 60);
    return b;
}

class Range : public Widget {
public:
    double dur = 1, a = 0, b = 1;
    std::vector<std::shared_ptr<Image>> strip;
    std::function<void(double)> moved;    // time under the handle being dragged
    std::function<void()> released;
    Range() { interactive = true; fixedH = 64; cursor = Cursor::ResizeEW; }
    double k() const { return geom.w / std::max(0.01, dur); }
    void paint(Painter &p) override {
        const Theme &t = theme();
        p.save();
        p.clip(geom, 12);
        p.fill(geom, t.surface2);
        if (!strip.empty()) {
            double w = geom.w / strip.size();
            for (size_t i = 0; i < strip.size(); i++)
                if (strip[i] && strip[i]->valid()) p.image(*strip[i], {geom.x + i * w, geom.y, w + 1, geom.h});
        }
        // dim what gets cut
        p.fill({geom.x, geom.y, a * k(), geom.h}, Color{0, 0, 0, 0.6});
        p.fill({geom.x + b * k(), geom.y, geom.w - b * k(), geom.h}, Color{0, 0, 0, 0.6});
        p.restore();
        Rect sel{geom.x + a * k(), geom.y, (b - a) * k(), geom.h};
        p.stroke(sel.inset(1), t.accent, 2, 12);
        for (double x : {a, b}) p.fill({geom.x + x * k() - 7, geom.y - 4, 14, geom.h + 8}, t.accent, 7);
    }
    bool pointerPress(Point pt, int) override {
        double t = (pt.x - geom.x) / k();
        which_ = std::fabs(t - a) < std::fabs(t - b) ? 0 : 1;
        pointerMove(pt);
        return true;
    }
    void pointerMove(Point pt) override {
        if (which_ < 0) return;
        double t = std::clamp((pt.x - geom.x) / k(), 0.0, dur);
        if (which_ == 0) a = std::min(t, b - 0.5);
        else b = std::max(t, a + 0.5);
        update();
        if (moved) moved(which_ == 0 ? a : b);
    }
    void pointerRelease(Point, int) override { which_ = -1; if (released) released(); }
private:
    int which_ = -1;
};

class TrimWindow : public ToplevelWindow {
public:
    explicit TrimWindow(const std::string &file) : ToplevelWindow("Trim recording", "nova-settings", {980, 700}), file(file) {
        setMinSize(720, 520);
        std::string d = Backend::run({"ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", file}, 8000);
        dur = std::max(0.5, atof(trim(d).c_str()));
        tmp = runtimeDir() + "/nova-trim-" + std::to_string(getpid());
        std::filesystem::create_directories(tmp);
        build();
        loadStrip();
        frameAt(0);
    }
    ~TrimWindow() override { std::error_code ec; std::filesystem::remove_all(tmp, ec); }
    void close() override { Loop::get().quit(); }

private:
    std::string file, tmp, status;
    double dur = 1;
    Range *range = nullptr;
    ImageW *frame = nullptr;
    Label *times = nullptr, *statusL = nullptr;
    std::shared_ptr<Process> frameProc;
    int frameSeq = 0;

    class Bg : public Box {
    public:
        Bg() : Box(Dir::Column, 16) { padding(22); }
        void paint(Painter &p) override { Color c = theme().window; c.a = 1; p.fill(geom, c); }
    };

    void build() {
        const Theme &t = theme();
        auto *root = setRoot<Bg>();
        auto *h = row(root, 10);
        h->add<Label>("Trim recording", 22, Weight::DemiBold, Role::AccentBright)->grow = 1;
        auto *fn = h->add<Label>(std::filesystem::path(file).filename().string(), 13, Weight::Normal, Role::Text3);
        fn->elide = Elide::Middle;
        fn->maxW = 420;
        fn->fill = false;
        frame = root->add<ImageW>();
        frame->grow = 1;
        frame->cover = false;
        frame->radius = 16;
        frame->placeholder = Color{0, 0, 0, 1};
        range = root->add<Range>();
        range->dur = dur;
        range->b = dur;
        range->moved = [this](double tt) { refreshTimes(); frameAt(tt); };
        auto *br = row(root, 10);
        btn(br, "Preview", "play")->onClick = [this] {
            char a[32], b[32];
            snprintf(a, sizeof a, "--start=%.2f", range->a);
            snprintf(b, sizeof b, "--end=%.2f", range->b);
            if (haveProgram("mpv")) Backend::runDetached({"mpv", "--really-quiet", a, b, file});
            else Backend::runDetached({"xdg-open", file});
        };
        times = br->add<Label>("", 14, Weight::Normal, Role::Text2);
        times->grow = 1;
        statusL = br->add<Label>("", 13, Weight::Normal, Role::Text3);
        statusL->fill = false;
        btn(br, "Save as copy")->onClick = [this] { save(false); };
        btn(br, "Replace", "", true)->onClick = [this] { save(true); };
        refreshTimes();
        (void)t;
    }
    void refreshTimes() {
        times->setText(fmtTime(range->a) + " → " + fmtTime(range->b) + "   ·   " + fmtTime(range->b - range->a));
    }
    // one still frame at time t (latest request wins)
    void frameAt(double t) {
        int seq = ++frameSeq;
        std::string out = tmp + "/frame-" + std::to_string(seq % 2) + ".jpg";
        char ts[32];
        snprintf(ts, sizeof ts, "%.2f", std::min(t, std::max(0.0, dur - 0.05)));
        if (frameProc) frameProc->kill();
        frameProc = Process::run({"ffmpeg", "-y", "-loglevel", "error", "-ss", ts, "-i", file, "-frames:v", "1", "-vf", "scale=960:-2", out},
                                 [this, seq, out](int code, const std::string &) {
                                     if (code != 0 || seq != frameSeq) return;
                                     frame->image = std::make_shared<Image>(out, 960, 540);
                                     frame->update();
                                 });
    }
    void loadStrip() {
        int n = 10;
        range->strip.assign(n, nullptr);
        for (int i = 0; i < n; i++) {
            char ts[32];
            snprintf(ts, sizeof ts, "%.2f", dur * (i + 0.5) / n);
            std::string out = tmp + "/strip-" + std::to_string(i) + ".jpg";
            Process::run({"ffmpeg", "-y", "-loglevel", "error", "-ss", ts, "-i", file, "-frames:v", "1", "-vf", "scale=160:-2", out},
                         [this, i, out](int code, const std::string &) {
                             if (code != 0) return;
                             range->strip[i] = std::make_shared<Image>(out, 160, 90);
                             range->update();
                         });
        }
    }
    void save(bool replace) {
        statusL->setText("Saving…");
        std::string out = backend().trimVideo(file, range->a, range->b, replace);
        statusL->setText(out.empty() ? "Couldn't trim (is ffmpeg installed?)" : "Saved " + std::filesystem::path(out).filename().string());
        if (!out.empty() && replace) Loop::get().addTimer(600, [] { Loop::get().quit(); });
    }
};

int runTrim(const std::string &file) {
    if (!std::filesystem::exists(file)) { fprintf(stderr, "nova-settings: %s doesn't exist\n", file.c_str()); return 1; }
    TrimWindow w(file);
    w.show();
    Loop::get().run();
    return 0;
}

}  // namespace settings
