#include "mediaview.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <unistd.h>

#include "anim.hpp"
#include "audiolevel.hpp"
#include "glyphs.hpp"
#include "lyrics.hpp"
#include "popover.hpp"
#include "server.hpp"
#include "system.hpp"

namespace dusk {

std::string media_clock(double seconds) {
	const long s = std::max(0L, static_cast<long>(seconds));
	char buf[24];
	if (s >= 3600) {
		std::snprintf(buf, sizeof buf, "%ld:%02ld:%02ld", s / 3600, s / 60 % 60, s % 60);
	} else {
		std::snprintf(buf, sizeof buf, "%ld:%02ld", s / 60, s % 60);
	}
	return buf;
}

namespace {

// "spotify" -> "Spotify"; browsers' instance names ("firefox.instance_2_31") cut short.
std::string player_label(const std::string &player) {
	if (player.empty()) return "This computer";
	std::string p = player.substr(0, player.find('.'));
	static const std::pair<const char *, const char *> kNames[] = {
		{"firefox", "Firefox"}, {"chromium", "Chromium"}, {"chrome", "Chrome"}, {"brave", "Brave"},
		{"spotify", "Spotify"}, {"vlc", "VLC"}, {"mpv", "mpv"}, {"rhythmbox", "Rhythmbox"},
		{"elisa", "Elisa"}, {"amberol", "Amberol"}, {"io", "Music"}, {"edge", "Edge"}, {"msedge", "Edge"},
	};
	for (const auto &[k, v] : kNames) {
		if (p == k) return v;
	}
	if (!p.empty()) p[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(p[0])));
	return p;
}

// The title: a step bigger than text, semibold (like Samsung's).
const char *title_font() {
	static std::string f;
	std::string fam = theme::font_store[0];
	const size_t sp = fam.rfind(' ');
	double size = 10;
	if (sp != std::string::npos) {
		size = std::atof(fam.c_str() + sp + 1);
		fam = fam.substr(0, sp);
	}
	char buf[32];
	std::snprintf(buf, sizeof buf, " Semibold %.1f", size + 2);
	f = fam + buf;
	return f.c_str();
}

void paint_cover(cairo_t *cr, cairo_surface_t *img, double x, double y, double w, double h) {
	const double iw = cairo_image_surface_get_width(img), ih = cairo_image_surface_get_height(img);
	const double s = std::max(w / iw, h / ih);
	cairo_save(cr);
	cairo_translate(cr, x + (w - iw * s) / 2, y + (h - ih * s) / 2);
	cairo_scale(cr, s, s);
	cairo_set_source_surface(cr, img, 0, 0);
	cairo_pattern_set_filter(cairo_get_source(cr), CAIRO_FILTER_GOOD);
	cairo_pattern_set_extend(cairo_get_source(cr), CAIRO_EXTEND_PAD);
	cairo_paint(cr);
	cairo_restore(cr);
}

// The art, or a quiet placeholder, in a rounded square.
void draw_thumb(cairo_t *cr, IconLoader &icons, cairo_surface_t *art, double x, double y, double s, double r,
		const Color &bg, const Color &fg, float scale) {
	cairo_save(cr);
	rounded_rect(cr, x, y, s, s, r);
	cairo_clip(cr);
	if (art) {
		paint_cover(cr, art, x, y, s, s);
	} else {
		set_color(cr, bg);
		cairo_paint(cr);
		const double is = s * 0.42;
		draw_named_icon(cr, icons, "disc-3", x + (s - is) / 2, y + (s - is) / 2, is, fg, scale);
	}
	cairo_restore(cr);
}

} // namespace

MediaView::MediaView(Server *server) : server_(server) {}

MediaView::~MediaView() {
	set_shown(false);
	if (art_bg_) cairo_surface_destroy(art_bg_);
	if (art_) cairo_surface_destroy(art_);
}

void MediaView::set_shown(bool shown) {
	shown_ = shown;
	const bool want = shown && server_->status && server_->status->media_playing &&
		server_->config.media_wave_beat && server_->audio_level;
	if (want != listening_) {
		listening_ = want;
		if (want) server_->audio_level->acquire();
		else if (server_->audio_level) server_->audio_level->release();
	}
}

void MediaView::load_art(float scale) {
	const SystemStatus &st = *server_->status;
	const int px = static_cast<int>(std::lround(120 * scale));
	if (st.media_art == art_path_ && art_px_ >= px) return;
	art_path_ = st.media_art;
	art_px_ = px;
	if (art_bg_) cairo_surface_destroy(art_bg_);
	if (art_) cairo_surface_destroy(art_);
	art_bg_ = art_ = nullptr;
	if (!art_path_.empty()) {
		art_ = load_image_sized(art_path_, px, px);
		art_bg_ = load_image_sized(art_path_, 40, 40);   // stretched over the card: soft
	}
	// The progress bar's colour: the art's average colour, made light and a
	// little more colourful (peach on warm art, pale blue on cool art...).
	art_tint_ = Color{0, 0, 0, 0};
	if (art_bg_) {
		cairo_surface_flush(art_bg_);
		const unsigned char *d = cairo_image_surface_get_data(art_bg_);
		const int iw = cairo_image_surface_get_width(art_bg_), ih = cairo_image_surface_get_height(art_bg_);
		const int stride = cairo_image_surface_get_stride(art_bg_);
		double r = 0, g = 0, b = 0, n = 0;
		for (int yy = 0; d && yy < ih; yy++) {
			for (int xx = 0; xx < iw; xx++) {
				const uint32_t px = *reinterpret_cast<const uint32_t *>(d + yy * stride + xx * 4);
				const double a = ((px >> 24) & 0xff) / 255.0;
				if (a < 0.5) continue;
				r += ((px >> 16) & 0xff) / 255.0 / a;
				g += ((px >> 8) & 0xff) / 255.0 / a;
				b += (px & 0xff) / 255.0 / a;
				n++;
			}
		}
		if (n > 0) {
			Color avg{r / n, g / n, b / n, 1};
			const double grey = (avg.r + avg.g + avg.b) / 3;
			avg = Color{std::clamp(grey + (avg.r - grey) * 1.8, 0.0, 1.0), std::clamp(grey + (avg.g - grey) * 1.8, 0.0, 1.0),
				std::clamp(grey + (avg.b - grey) * 1.8, 0.0, 1.0), 1};
			art_tint_ = mix(avg, rgb(0xffffff), 0.5);
		}
	}
}

double MediaView::position() const {
	const SystemStatus &st = *server_->status;
	if (drag_s_ >= 0) return drag_s_;
	double p = st.media_position;
	if (st.media_playing) p += (now_ms() - st.media_read_at) / 1000.0;
	return st.media_length > 0 ? std::clamp(p, 0.0, st.media_length) : std::max(0.0, p);
}

void MediaView::drag(double x) {
	const SystemStatus &st = *server_->status;
	if (st.media_length <= 0 || seek_.width <= 0) return;
	drag_s_ = std::clamp((x - seek_.x) / seek_.width, 0.0, 1.0) * st.media_length;
}

void MediaView::end_drag() {
	if (drag_s_ >= 0) server_->status->seek(drag_s_);
	drag_s_ = -1;
}

bool MediaView::moving() const {
	const SystemStatus &st = *server_->status;
	return shown_ && st.media_available && (st.media_playing || marquee_on_ || amp_ > 0.05);
}

bool MediaView::step(double dt) {
	const SystemStatus &st = *server_->status;
	set_shown(shown_);   // starts / stops listening as playback starts and stops
	if (!shown_ || !st.media_available) return false;
	dt = std::min(dt, 100.0);
	const bool anim = server_->config.animations;
	AudioLevel *al = server_->audio_level.get();
	const bool live = listening_ && al && al->live();
	const double target_level = live ? al->level() : 0;
	// The hills are the music's recent past: every 40 ms how hard it hits
	// (mostly the bass, so kicks stand up), flowing away to the left from the
	// knob. Without sound to listen to, a slow sway.
	level_ += (target_level - level_) * std::min(1.0, dt / 120.0);
	double target_amp = st.media_playing && anim ? 1.0 : 0.0;
	amp_ += (target_amp - amp_) * std::min(1.0, dt / 220.0);
	if (st.media_playing && anim) {
		phase_ += dt / 1000.0 * 0.12;
		sample_t_ += dt;
		while (sample_t_ >= kSampleMs) {
			sample_t_ -= kSampleMs;
			double v;
			if (live) {
				const double hit = std::max(al->pulse(), 0.85 * al->beat());
				v = std::clamp(0.12 + 0.30 * level_ + 0.75 * hit, 0.0, 1.0);
			} else {
				// Nothing to listen to: gentle made-up hills.
				const double k = static_cast<double>(samples_++) * 0.22;
				v = 0.32 + 0.18 * std::sin(k) + 0.12 * std::sin(k * 2.7 + 1.0);
			}
			history_.push_front(v);
			if (history_.size() > 96) history_.pop_back();
		}
	}
	// The visualizer: the music's spectrum (24 bars, already smoothed), or
	// Arqen's made-up beat when there's nothing to hear (a kick about twice a
	// second, a shimmer on top); paused, everything rests low and still.
	{
		const double rest = 0.06;
		std::array<double, 24> raw{};
		if (st.media_playing && anim) {
			if (live) {
				for (int i = 0; i < 24; i++) raw[static_cast<size_t>(i)] = std::max(rest, al->bar(i, 24));
			} else {
				fake_t_ += dt / 1000.0;
				const double kick = std::pow(std::max(0.0, std::sin(fake_t_ * M_PI * 4)), 5);
				for (int i = 0; i < 24; i++) {
					const double low = 1 - i / 34.0;
					raw[static_cast<size_t>(i)] = std::min(1.0, 0.1 + kick * low * 0.9 +
						0.3 * std::fabs(std::sin(fake_t_ * (2.5 + i * 0.45) + i * 1.3)) * (0.35 + i / 40.0));
				}
			}
		} else {
			raw.fill(rest);
		}
		// Quick up, slow down (live bars are smoothed already: only a touch more).
		const double up = 1 - std::pow(live ? 0.1 : 0.35, dt / 33.0), down = 1 - std::pow(live ? 0.6 : 0.84, dt / 33.0);
		for (size_t i = 0; i < 24; i++) {
			const double v = raw[i], o = viz_[i];
			viz_[i] = o + (v - o) * (v > o ? up : down);
		}
	}

	// What the hills show: the music's hit right now, quick up and gently down.
	{
		double now = 0;
		if (st.media_playing && anim) {
			now = live ? std::clamp(0.10 + 0.30 * level_ + 0.80 * std::max(al->pulse(), 0.85 * al->beat()), 0.0, 1.0)
				: (history_.empty() ? 0.3 : history_[0]);
		}
		energy_ += (now - energy_) * std::min(1.0, dt / (now > energy_ ? 35.0 : 190.0));
		energy_slow_ += (now - energy_slow_) * std::min(1.0, dt / (now > energy_slow_ ? 80.0 : 360.0));
	}

	if (marquee_on_ && anim) {
		if (marquee_wait_ > 0) {
			marquee_wait_ -= dt;
		} else {
			marquee_off_ += dt / 1000.0 * 34;
			if (marquee_off_ >= marquee_w_ + 48) {
				marquee_off_ = 0;
				marquee_wait_ = 2200;
			}
		}
	}
	return moving();
}

// The title: as it is when it fits; otherwise sliding along, faded at the ends.
void MediaView::draw_title(cairo_t *cr, const std::string &text, double x, double y, double w, double h,
		const char *font, const Color &color) {
	if (text != marquee_text_) {
		marquee_text_ = text;
		marquee_off_ = 0;
		marquee_wait_ = 2200;
	}
	const int tw = text_width(text, font);
	marquee_w_ = tw;
	marquee_on_ = server_->config.media_marquee && tw > w + 1;
	if (!marquee_on_) {
		draw_text(cr, text, x, y, w, h, font, color);
		return;
	}
	cairo_save(cr);
	cairo_rectangle(cr, x, y, w, h);
	cairo_clip(cr);
	cairo_push_group(cr);
	const double gap = 48;
	draw_text(cr, text, x - marquee_off_, y, tw + 4, h, font, color);
	draw_text(cr, text, x - marquee_off_ + tw + gap, y, tw + 4, h, font, color);
	cairo_pop_group_to_source(cr);
	// Soft edges: the text fades out at the right, and at the left while moving.
	cairo_pattern_t *mask = cairo_pattern_create_linear(x, 0, x + w, 0);
	const double edge = std::min(0.12, 18.0 / w);
	cairo_pattern_add_color_stop_rgba(mask, 0, 0, 0, 0, marquee_off_ > 0.5 ? 0 : 1);
	cairo_pattern_add_color_stop_rgba(mask, edge, 0, 0, 0, 1);
	cairo_pattern_add_color_stop_rgba(mask, 1 - edge, 0, 0, 0, 1);
	cairo_pattern_add_color_stop_rgba(mask, 1, 0, 0, 0, 0);
	cairo_mask(cr, mask);
	cairo_pattern_destroy(mask);
	cairo_restore(cr);
}

// Bar i of n from the 24 (fewer: the loudest of each group; more: in between).
double MediaView::viz_value(int i, int n) const {
	const int len = 24;
	if (n == len) return viz_[static_cast<size_t>(i)];
	if (n < len) {
		const double per = static_cast<double>(len) / n;
		const int a = static_cast<int>(i * per), b = std::max(a + 1, static_cast<int>((i + 1) * per));
		double m = 0;
		for (int k = a; k < b && k < len; k++) m = std::max(m, viz_[static_cast<size_t>(k)]);
		return m;
	}
	const double pos = std::clamp((i + 0.5) / n * len - 0.5, 0.0, len - 1.0);
	const int a = static_cast<int>(pos);
	const double f = pos - a;
	return viz_[static_cast<size_t>(a)] * (1 - f) + viz_[static_cast<size_t>(std::min(len - 1, a + 1))] * f;
}

// Behind everything on the card, like Arqen's media card: the beat drawn as
// bars (or a mirror, dots, a wave). Nothing moves sideways: each bar has its
// place and only its height follows the music.
void MediaView::draw_sound(cairo_t *cr, double x, double y, double w, double h) {
	const std::string &kind = server_->config.media_viz;
	if (kind == "off") return;
	if (kind == "hills") {
		draw_hills(cr, x, y, w, h);
		return;
	}
	const std::string &tint_kind = server_->config.media_viz_color;
	const Color art = art_tint_.a > 0 ? art_tint_ : mix(theme::accent, rgb(0xffffff), 0.45);
	auto col = [&](int i, int n) -> Color {
		if (tint_kind == "rainbow") {
			// hsl(i/n, 75%, 62%)
			const double hh = static_cast<double>(i) / std::max(1, n) * 6, s = 0.75, l = 0.62;
			const double c = (1 - std::fabs(2 * l - 1)) * s, xx = c * (1 - std::fabs(std::fmod(hh, 2.0) - 1)), m = l - c / 2;
			double r = 0, g = 0, b = 0;
			if (hh < 1) { r = c; g = xx; } else if (hh < 2) { r = xx; g = c; } else if (hh < 3) { g = c; b = xx; }
			else if (hh < 4) { g = xx; b = c; } else if (hh < 5) { r = xx; b = c; } else { r = c; b = xx; }
			return Color{r + m, g + m, b + m, 1};
		}
		if (tint_kind == "accent") return theme::accent;
		if (tint_kind == "text") return plain_ ? theme::text : rgb(0xffffff);
		return art;
	};
	// A band along the bottom, inset like Arqen's (8 px), most of the card tall.
	const double inset = 8;
	const double bx = x + inset, bw = w - 2 * inset;
	const double bh = (h - 2 * inset) * (plain_ ? 0.7 : 0.62), by = y + h - inset - bh;
	const double alpha = 0.30;
	cairo_save(cr);
	cairo_push_group(cr);
	if (kind == "bars" || kind == "mirror") {
		const int n = w < 260 ? 10 : 12;
		const double gap = std::max(2.0, std::min(4.0, bw / (n * 4.0)));
		const double barw = std::max(2.0, (bw - gap * (n - 1)) / n);
		for (int i = 0; i < n; i++) {
			const double v = viz_value(i, n);
			const double bhh = std::max(barw, v * bh);
			const double px = bx + i * (barw + gap);
			const double py = kind == "mirror" ? by + (bh - bhh) / 2 : by + bh - bhh;
			fill_rounded(cr, px, py, barw, bhh, barw / 2, col(i, n));
		}
	} else if (kind == "dots") {
		const int n = 12;
		int rows = static_cast<int>(bh / 9);
		if (rows % 2 == 0) rows--;
		rows = std::clamp(rows, 3, 9);
		const double dd = std::max(2.0, std::min(bw / n * 0.7, bh / rows * 0.78));
		const double mid = (rows - 1) / 2.0;
		for (int c = 0; c < n; c++) {
			const double v = viz_value(c, n);
			const Color k = col(c, n);
			for (int r = 0; r < rows; r++) {
				const double lit = std::clamp(v * (mid + 1) + 0.15 - std::fabs(r - mid), 0.0, 1.0);
				cairo_new_path(cr);
				cairo_arc(cr, bx + (c + 0.5) * (bw / n), by + (r + 0.5) * (bh / rows), dd / 2, 0, 2 * M_PI);
				cairo_set_source_rgba(cr, k.r, k.g, k.b, 0.14 + 0.86 * lit);
				cairo_fill(cr);
			}
		}
	} else if (kind == "wave") {
		// One smooth line through every bar's place, swinging up and down
		// (and crossing the middle between them) as far as the beat says.
		const int n = 9, steps = 6, cnt = (n - 1) * steps;
		const double lw = std::max(2.0, std::min(4.0, bh * 0.16));
		const double amp = std::max(1.0, (bh - lw) / 2);
		cairo_new_path(cr);
		for (int j = 0; j <= cnt; j++) {
			const double f = static_cast<double>(j) / steps;
			const int i = std::min(n - 2, static_cast<int>(f));
			const double t = f - i, e = (1 - std::cos(t * M_PI)) / 2;
			const double a = viz_value(i, n), b = viz_value(i + 1, n);
			const double level = a + (b - a) * e;
			const double swing = std::cos(f * M_PI);
			const double px = bx + static_cast<double>(j) / cnt * bw, py = by + bh / 2 - swing * level * amp;
			if (j == 0) cairo_move_to(cr, px, py);
			else cairo_line_to(cr, px, py);
		}
		const Color k = col(n / 2, n);
		cairo_set_source_rgba(cr, k.r, k.g, k.b, 1);
		cairo_set_line_width(cr, lw);
		cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND);
		cairo_set_line_join(cr, CAIRO_LINE_JOIN_ROUND);
		cairo_stroke(cr);
	}
	cairo_pop_group_to_source(cr);
	cairo_paint_with_alpha(cr, (kind == "wave" ? 0.55 : kind == "dots" ? 0.45 : alpha + 0.12) * (plain_ ? 0.55 : 1.0));
	cairo_restore(cr);
}

// The older look: soft see-through hills of sound across the card's lower
// part. They stay where they are and rise and fall with the music.
void MediaView::draw_hills(cairo_t *cr, double x, double y, double w, double h) {
	if (amp_ < 0.02) return;
	const Color tint = art_tint_.a > 0 ? art_tint_ : mix(theme::accent, rgb(0xffffff), 0.45);
	const double base = y + h;
	const double tall = h * 0.46 * amp_;
	// Fixed hills: where each one is, how wide, how tall at most.
	struct Hill {
		double at, width, height;
	};
	static const Hill kFront[] = {{0.06, 0.16, 0.55}, {0.24, 0.14, 0.85}, {0.42, 0.18, 0.65}, {0.60, 0.13, 1.0},
		{0.78, 0.17, 0.7}, {0.95, 0.14, 0.5}};
	static const Hill kBack[] = {{0.15, 0.2, 0.7}, {0.34, 0.16, 0.95}, {0.52, 0.2, 0.6}, {0.70, 0.17, 0.9},
		{0.88, 0.2, 0.65}};
	for (int layer = 1; layer >= 0; layer--) {
		// The back hills follow the music a moment more slowly.
		const double e = layer ? energy_slow_ : energy_;
		const Hill *hills = layer ? kBack : kFront;
		const int count = layer ? 5 : 6;
		cairo_move_to(cr, x - 2, base);
		for (double px = x - 2; px <= x + w + 2; px += 2) {
			const double u = (px - x) / w;
			double v = 0;
			for (int i = 0; i < count; i++) {
				const double d = (u - hills[i].at) / hills[i].width;
				// Each hill reacts a little differently, so they don't move as one block.
				const double k = 0.35 + 0.65 * std::clamp(e * (0.75 + 0.5 * std::sin(i * 1.7 + layer)), 0.0, 1.0);
				v = std::max(v, hills[i].height * k * std::exp(-d * d * 2.2));
			}
			cairo_line_to(cr, px, base - tall * v * (layer ? 0.8 : 1.0));
		}
		cairo_line_to(cr, x + w + 2, base);
		cairo_close_path(cr);
		cairo_pattern_t *g = cairo_pattern_create_linear(0, base - tall, 0, base);
		const double a = layer ? 0.16 : 0.24;
		cairo_pattern_add_color_stop_rgba(g, 0, tint.r, tint.g, tint.b, 0.0);
		cairo_pattern_add_color_stop_rgba(g, 0.45, tint.r, tint.g, tint.b, a);
		cairo_pattern_add_color_stop_rgba(g, 1, tint.r, tint.g, tint.b, a * 1.3);
		cairo_set_source(cr, g);
		cairo_fill(cr);
		cairo_pattern_destroy(g);
	}
}

// The progress line, like Samsung's: a thick bar, the part played in a light
// colour taken from the album art, and a round knob.
void MediaView::draw_wave(cairo_t *cr, double x0, double y, double w, const Color &played, const Color &rest,
		std::vector<MediaHot> *hots) {
	const SystemStatus &st = *server_->status;
	seek_ = wlr_box{static_cast<int>(x0), static_cast<int>(y - 14), static_cast<int>(w), 28};
	const double frac = st.media_length > 0 ? std::clamp(position() / st.media_length, 0.0, 1.0) : 0;
	const double th = 7;                 // the bar's thickness
	const double kx = x0 + w * frac;
	const Color tint = art_tint_.a > 0 ? art_tint_ : mix(theme::accent, rgb(0xffffff), 0.45);
	(void)played;
	// The rest of the song.
	fill_rounded(cr, x0, y - th / 2, w, th, th / 2, rest);
	if (kx > x0 + 1) {
		fill_rounded(cr, x0, y - th / 2, std::max(th, kx - x0 + th / 2), th, th / 2, tint);
	}
	// The knob.
	const double kr = dragging() ? 9.5 : 8;
	cairo_new_path(cr);
	cairo_arc(cr, kx, y, kr, 0, 2 * M_PI);
	set_color(cr, mix(tint, rgb(0xffffff), 0.55));
	cairo_fill_preserve(cr);
	set_color(cr, rgb(0x000000, 0.25));
	cairo_set_line_width(cr, 1);
	cairo_stroke(cr);
	if (hots && st.media_length > 0) {
		hots->push_back(MediaHot{"mp:seek", wlr_box{static_cast<int>(x0 - 8), static_cast<int>(y - 16),
			static_cast<int>(w + 16), 32}, -1});
	}
}

void MediaView::draw(cairo_t *cr, double x, double y, double w, double h, double radius, float scale, Look look,
		std::vector<MediaHot> *hots) {
	load_art(scale);
	if (look == Look::Samsung) {
		draw_samsung(cr, x, y, w, h, radius, scale, hots);
	} else {
		draw_plain(cr, x, y, w, h, radius, scale, look, hots);
	}
}

void MediaView::draw_samsung(cairo_t *cr, double x, double y, double w, double h, double r, float scale,
		std::vector<MediaHot> *hots) {
	const SystemStatus &st = *server_->status;
	IconLoader &icons = server_->icons;
	const Color white = rgb(0xffffff), soft = rgb(0xffffff, 0.72);

	// The art fills the card, softened and darkened so white reads on it.
	cairo_save(cr);
	rounded_rect(cr, x, y, w, h, r);
	cairo_clip(cr);
	if (art_bg_ && st.media_available) {
		paint_cover(cr, art_bg_, x - 6, y - 6, w + 12, h + 12);
	} else {
		const Color &a = theme::accent;
		cairo_pattern_t *g = cairo_pattern_create_linear(x, y, x + w, y + h);
		cairo_pattern_add_color_stop_rgb(g, 0, a.r * 0.62, a.g * 0.62, a.b * 0.66);
		cairo_pattern_add_color_stop_rgb(g, 1, a.r * 0.26, a.g * 0.26, a.b * 0.32);
		cairo_set_source(cr, g);
		cairo_paint(cr);
		cairo_pattern_destroy(g);
	}
	cairo_pattern_t *shade = cairo_pattern_create_linear(0, y, 0, y + h);
	cairo_pattern_add_color_stop_rgba(shade, 0, 0, 0, 0, 0.30);
	cairo_pattern_add_color_stop_rgba(shade, 1, 0, 0, 0, 0.58);
	cairo_set_source(cr, shade);
	cairo_paint(cr);
	cairo_pattern_destroy(shade);
	if (st.media_available && h >= 84 && w >= 170) draw_sound(cr, x, y, w, h);
	cairo_restore(cr);

	const bool lyrics = server_->lyrics && server_->config.lyrics && st.media_available;
	const bool found = lyrics && server_->lyrics->available();
	const std::string title = st.media_available ? (st.media_title.empty() ? "Playing" : st.media_title)
		: "Nothing playing";
	const double pad = h >= 140 ? 18 : 14;

	auto control_row = [&](double cx, double cy, double gap, double big, double small) {
		if (!st.media_available) return;
		const struct {
			const char *id, *icon;
			double dx, size;
		} kButtons[] = {
			{"mp:previous", "previous", -gap, small},
			{"mp:play-pause", st.media_playing ? "pause" : "play", 0, big},
			{"mp:next", "next", gap, small},
		};
		for (const auto &b : kButtons) {
			if (b.size <= 0) continue;   // only play / pause
			draw_named_icon(cr, icons, b.icon, cx + b.dx - b.size / 2, cy - b.size / 2, b.size, white, scale);
			if (hots) {
				const double hit = b.size + 18;
				hots->push_back(MediaHot{b.id, wlr_box{static_cast<int>(cx + b.dx - hit / 2),
					static_cast<int>(cy - hit / 2), static_cast<int>(hit), static_cast<int>(hit)}, hit / 2});
			}
		}
	};

	if (w < 170) {
		// Small: just the art, play / pause in the middle (and next / previous
		// above and below when it's tall), the progress along the bottom.
		const double cx = x + w / 2, cy = y + h / 2;
		if (!st.media_available) {
			draw_named_icon(cr, icons, "disc-3", cx - 12, cy - 12, 24, soft, scale);
		} else if (h >= 150) {
			const struct {
				const char *id, *icon;
				double dy, size;
			} kButtons[] = {
				{"mp:previous", "previous", -h / 3.2, 20}, {"mp:play-pause", st.media_playing ? "pause" : "play", 0, 26},
				{"mp:next", "next", h / 3.2, 20},
			};
			for (const auto &bt : kButtons) {
				draw_named_icon(cr, icons, bt.icon, cx - bt.size / 2, cy + bt.dy - bt.size / 2, bt.size, white, scale);
				if (hots) {
					const double hit = std::min(w, bt.size + 18);
					hots->push_back(MediaHot{bt.id, wlr_box{static_cast<int>(cx - hit / 2), static_cast<int>(cy + bt.dy - hit / 2),
						static_cast<int>(hit), static_cast<int>(hit)}, hit / 2});
				}
			}
		} else {
			control_row(cx, cy, 0, 26, 0);
		}
		if (st.media_available && st.media_length > 0) {
			const double frac = std::clamp(position() / st.media_length, 0.0, 1.0);
			const double bw = w - 24, by = y + h - 12;
			fill_rounded(cr, x + 12, by, bw, 4, 2, rgb(0xffffff, 0.3));
			fill_rounded(cr, x + 12, by, std::max(4.0, bw * frac), 4, 2, white);
		}
	} else if (h >= 140) {
		// Full: app and output on top, title and artist, the wave and times,
		// the controls along the bottom.
		const double top = y + pad - 2;
		// The media source: the app's icon and name, a chip that picks
		// another player when several are playing.
		const std::string from = player_label(st.media_player);
		const size_t count = st.player_list().size();
		const int cw = text_width(from, theme::font_small) + 16 + 8 + (count > 1 ? 16 : 0) + 14;
		fill_rounded(cr, x + pad - 6, top - 4, cw, 26, 13, rgb(0xffffff, 0.12));
		const std::string base = st.media_player.substr(0, st.media_player.find('.'));
		const std::string icon = base.empty() ? "" : server_->apps.icon_for(base);
		if (!icon.empty()) draw_icon(cr, icons, icon, from, x + pad, top + 1, 16, scale);
		else draw_named_icon(cr, icons, "play", x + pad + 3, top + 4, 10, soft, scale);
		draw_text(cr, from, x + pad + 22, top - 4, cw - 28, 26, theme::font_small, white);
		if (count > 1) {
			draw_named_icon(cr, icons, "chevron-down", x + pad - 6 + cw - 22, top + 2, 14, soft, scale);
		}
		if (hots) {
			hots->push_back(MediaHot{"mp:source", wlr_box{static_cast<int>(x + pad - 6), static_cast<int>(top - 4),
				cw, 26}, 13});
		}
		const std::string out = "Media output";
		const int ow = text_width(out, theme::font_small) + 24;
		const double ox = x + w - pad - ow;
		fill_rounded(cr, ox, top - 4, ow, 26, 13, rgb(0xffffff, 0.16));
		draw_text(cr, out, ox, top - 4, ow, 26, theme::font_small, white, Align::Center);
		if (hots) hots->push_back(MediaHot{"mp:output", wlr_box{static_cast<int>(ox), static_cast<int>(top - 4), ow, 26}, 13});
		if (lyrics) {
			const double lx = ox - 32;
			cairo_new_path(cr);
			cairo_arc(cr, lx + 13, top + 9, 13, 0, 2 * M_PI);
			const bool lit = server_->config.lyrics_show && found;
			set_color(cr, lit ? rgb(0xffffff, 0.85) : rgb(0xffffff, 0.16));
			cairo_fill(cr);
			draw_named_icon(cr, icons, "mic-vocal", lx + 6, top + 2, 14,
				lit ? rgb(0x15141a) : found ? white : rgb(0xffffff, 0.45), scale);
			if (hots) hots->push_back(MediaHot{"mp:lyrics", wlr_box{static_cast<int>(lx), static_cast<int>(top - 4), 26, 26}, 13});
		}
		const double ty = top + 26;
		draw_title(cr, title, x + pad, ty, w - 2 * pad, 24, title_font(), white);
		draw_text(cr, st.media_artist, x + pad, ty + 24, w - 2 * pad, 18, theme::font_small, soft);
		const double wy = y + h - 64;
		if (st.media_available && st.media_length > 0) {
			draw_wave(cr, x + pad + 2, wy, w - 2 * pad - 4, white, rgb(0xffffff, 0.30), hots);
			draw_text(cr, media_clock(position()), x + pad, wy + 9, 60, 14, theme::font_small, soft);
			draw_text(cr, media_clock(st.media_length), x + w - pad - 60, wy + 9, 60, 14, theme::font_small, soft,
				Align::Right);
		} else if (st.media_available) {
			draw_wave(cr, x + pad + 2, wy, w - 2 * pad - 4, white, rgb(0xffffff, 0.30), nullptr);
		}
		control_row(x + w / 2, y + h - 24, 64, 26, 22);
	} else if (h >= 84) {
		// Medium: title and artist with the controls beside them, the wave under.
		const double ctl_w = st.media_available ? 120 : 0;
		draw_title(cr, title, x + pad, y + pad - 4, w - 2 * pad - ctl_w, 22, theme::font_bold, white);
		draw_text(cr, st.media_artist, x + pad, y + pad + 17, w - 2 * pad - ctl_w, 16, theme::font_small, soft);
		control_row(x + w - pad - ctl_w / 2, y + pad + 12, 38, 22, 18);
		if (st.media_available) {
			draw_wave(cr, x + pad + 2, y + h - pad - 4, w - 2 * pad - 4, white, rgb(0xffffff, 0.30),
				st.media_length > 0 ? hots : nullptr);
		}
	} else {
		// One row: the cover, title and artist, play/pause; a thin wave along the bottom.
		const double as = h - 16;
		draw_thumb(cr, icons, art_, x + 8, y + 8, as, std::max(6.0, r - 8), rgb(0xffffff, 0.14), soft, scale);
		const double tx = x + 8 + as + 10;
		const double ctl = st.media_available ? (w >= 220 ? 104 : 40) : 0;
		const double tw = x + w - tx - ctl - 6;
		draw_title(cr, title, tx, y + h / 2 - 18, tw, 20, theme::font_bold, white);
		draw_text(cr, st.media_artist, tx, y + h / 2 + 1, tw, 16, theme::font_small, soft);
		if (st.media_available) {
			if (w >= 220) control_row(x + w - 6 - ctl / 2, y + h / 2 - 2, 34, 20, 16);
			else control_row(x + w - 6 - ctl / 2, y + h / 2 - 2, 0, 20, 0);
			if (st.media_length > 0) {
				const double frac = std::clamp(position() / st.media_length, 0.0, 1.0);
				cairo_save(cr);
				rounded_rect(cr, x, y, w, h, r);
				cairo_clip(cr);
				cairo_rectangle(cr, x, y + h - 3, w * frac, 3);
				set_color(cr, rgb(0xffffff, 0.8));
				cairo_fill(cr);
				cairo_restore(cr);
			}
		}
	}
	if (hots && st.media_available) {
		// The rest of the card: right-click options, a click does nothing.
		hots->insert(hots->begin(), MediaHot{"mp:card", wlr_box{static_cast<int>(x), static_cast<int>(y),
			static_cast<int>(w), static_cast<int>(h)}, -2});
	}
}

// The other looks: on the card colours of their control centre.
void MediaView::draw_plain(cairo_t *cr, double x, double y, double w, double h, double r, float scale, Look look,
		std::vector<MediaHot> *hots) {
	const SystemStatus &st = *server_->status;
	IconLoader &icons = server_->icons;
	const std::string title = st.media_available ? (st.media_title.empty() ? "Playing" : st.media_title)
		: look == Look::Mac ? "Not Playing" : "Nothing playing";
	auto button = [&](const char *id, const char *icon, double cx, double cy, double size, bool round, const Color &fg) {
		if (round) {
			cairo_new_path(cr);
			cairo_arc(cr, cx, cy, size * 0.9, 0, 2 * M_PI);
			set_color(cr, theme::tile_off);
			cairo_fill(cr);
		}
		draw_named_icon(cr, icons, icon, cx - size / 2, cy - size / 2, size, fg, scale);
		if (hots) {
			const double hit = size + 16;
			hots->push_back(MediaHot{id, wlr_box{static_cast<int>(cx - hit / 2), static_cast<int>(cy - hit / 2),
				static_cast<int>(hit), static_cast<int>(hit)}, hit / 2});
		}
	};
	const char *play = st.media_playing ? "pause" : "play";
	fill_rounded(cr, x, y, w, h, r, theme::card_bg);
	// The beat behind it too, when the card is big enough.
	if (st.media_available && h >= 84 && w >= 170 && look != Look::Gnome) {
		cairo_save(cr);
		rounded_rect(cr, x, y, w, h, r);
		cairo_clip(cr);
		plain_ = true;
		draw_sound(cr, x, y, w, h);
		plain_ = false;
		cairo_restore(cr);
	}
	if (look == Look::Windows) {
		// Windows 11: the app on top, title and artist, the cover at the right,
		// the controls centred underneath.
		const double pad = 16, as = std::min(64.0, h - 64);
		draw_text(cr, player_label(st.media_player), x + pad, y + 10, w / 2, 18, theme::font_small, theme::text_dim);
		draw_thumb(cr, icons, art_, x + w - pad - as, y + 14, as, 6, theme::tile_off, theme::text_dim, scale);
		draw_title(cr, title, x + pad, y + 32, w - 3 * pad - as, 22, theme::font_bold, theme::text);
		draw_text(cr, st.media_artist, x + pad, y + 54, w - 3 * pad - as, 18, theme::font_small, theme::text_dim);
		if (st.media_available) {
			const double cy = y + h - 24;
			button("mp:previous", "previous", x + w / 2 - 56, cy, 16, false, theme::text);
			button("mp:play-pause", play, x + w / 2, cy, 18, false, theme::text);
			button("mp:next", "next", x + w / 2 + 56, cy, 16, false, theme::text);
		}
	} else if (look == Look::Gnome) {
		// GNOME: one row: cover, title over artist, small controls at the end.
		const double as = std::min(44.0, h - 16);
		draw_thumb(cr, icons, art_, x + 10, y + (h - as) / 2, as, 8, theme::tile_off, theme::text_dim, scale);
		const double tx = x + 10 + as + 12, ctl = st.media_available ? 104 : 0;
		draw_title(cr, title, tx, y + h / 2 - 19, x + w - tx - ctl - 8, 20, theme::font_bold, theme::text);
		draw_text(cr, st.media_artist, tx, y + h / 2 + 1, x + w - tx - ctl - 8, 18, theme::font_small, theme::text_dim);
		if (st.media_available) {
			const double cx = x + w - 10 - ctl / 2, cy = y + h / 2;
			button("mp:previous", "previous", cx - 34, cy, 15, false, theme::text);
			button("mp:play-pause", play, cx, cy, 16, false, theme::text);
			button("mp:next", "next", cx + 34, cy, 15, false, theme::text);
		}
	} else {
		// macOS: the cover at the top left, title and artist, controls below.
		const double pad = 14, as = std::min(46.0, h * 0.34);
		draw_thumb(cr, icons, art_, x + pad, y + pad, as, 8, theme::tile_off, theme::text_dim, scale);
		draw_title(cr, title, x + pad, y + pad + as + 6, w - 2 * pad, 20, theme::font_bold, theme::text);
		draw_text(cr, st.media_artist, x + pad, y + pad + as + 25, w - 2 * pad, 17, theme::font_small, theme::text_dim);
		const double cy = y + h - 22;
		const Color fg = st.media_available ? theme::text : theme::text_dim;
		button("mp:previous", "previous", x + w / 2 - 38, cy, 16, false, fg);
		button("mp:play-pause", play, x + w / 2, cy, 20, false, fg);
		button("mp:next", "next", x + w / 2 + 38, cy, 16, false, fg);
	}
	if (hots && st.media_available) {
		hots->insert(hots->begin(), MediaHot{"mp:card", wlr_box{static_cast<int>(x), static_cast<int>(y),
			static_cast<int>(w), static_cast<int>(h)}, -2});
	}
}

// Where sound goes: the outputs PipeWire knows, the one in use ticked.
void sound_output_menu(Server *srv, Output *out, double lx, double ly) {
	srv->run_capture("wpctl status 2>/dev/null", [srv, out, lx, ly](const std::string &text) {
		std::vector<MenuItem> items;
		items.push_back(MenuItem::header("Play sound on"));
		bool audio = false, sinks = false;
		std::istringstream in(text);
		std::string line;
		while (std::getline(in, line)) {
			if (line == "Audio") audio = true;
			else if (line == "Video" || line == "Settings") audio = false;
			if (!audio) continue;
			if (line.find("Sinks:") != std::string::npos) {
				sinks = true;
				continue;
			}
			if (sinks && (line.find("├─") != std::string::npos || line.find("└─") != std::string::npos)) {
				sinks = false;
			}
			if (!sinks) continue;
			// " │  *   57. Built-in Audio Analog Stereo        [vol: 0.40]"
			const bool current = line.find('*') != std::string::npos;
			size_t i = 0;
			while (i < line.size() && !std::isdigit(static_cast<unsigned char>(line[i]))) i++;
			const size_t dot = line.find('.', i);
			if (i >= line.size() || dot == std::string::npos) continue;
			const std::string id = line.substr(i, dot - i);
			std::string name = line.substr(dot + 1);
			name = name.substr(0, name.find(" [vol"));
			while (!name.empty() && name.front() == ' ') name.erase(0, 1);
			while (!name.empty() && name.back() == ' ') name.pop_back();
			if (name.empty()) continue;
			items.push_back(MenuItem::radio(name, current, [srv, id] {
				srv->run_capture("wpctl set-default " + id + " >/dev/null 2>&1",
					[srv](const std::string &) { srv->status->refresh(); });
			}));
		}
		if (items.size() == 1) items.push_back(MenuItem::action("No sound outputs found", [] {}));
		items.push_back(MenuItem::separator());
		for (const char *mixer : {"pwvucontrol", "pavucontrol"}) {
			if (access((std::string("/usr/bin/") + mixer).c_str(), X_OK) == 0) {
				items.push_back(MenuItem::action("Sound settings…", [srv, m = std::string(mixer)] { srv->spawn(m); }, "gear"));
				break;
			}
		}
		srv->menu->show(out, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point", std::move(items));
	});
}

// The players: pick which one the cards show (and control), or open its window.
void media_source_menu(Server *srv, Output *out, double lx, double ly) {
	const SystemStatus &st = *srv->status;
	std::vector<MenuItem> items;
	items.push_back(MenuItem::header("Media source"));
	for (const auto &[name, title] : st.player_list()) {
		const std::string label = player_label(name) + (title.empty() ? "" : " · " + title);
		items.push_back(MenuItem::radio(label, name == st.media_player, [srv, n = name] { srv->status->pick_player(n); }));
	}
	if (!st.media_player.empty()) {
		items.push_back(MenuItem::separator());
		items.push_back(MenuItem::action("Open " + player_label(st.media_player), [srv] { open_player_window(srv); }, "open"));
	}
	srv->menu->show(out, wlr_box{static_cast<int>(lx), static_cast<int>(ly), 1, 1}, "point", std::move(items));
}

bool open_player_window(Server *srv) {
	const std::string player = srv->status->media_player.substr(0, srv->status->media_player.find('.'));
	if (player.empty()) return false;
	for (View *v : srv->views) {
		std::string app = v->app_id();
		std::transform(app.begin(), app.end(), app.begin(), ::tolower);
		if (app.find(player) != std::string::npos) {
			srv->close_popups();
			if (v->minimized) v->restore_from_minimize();
			else srv->focus(v);
			return true;
		}
	}
	return false;
}

} // namespace dusk
