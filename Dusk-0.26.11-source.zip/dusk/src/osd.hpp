// On-screen display for volume, microphone, brightness, Caps/Num Lock and
// keyboard layout changes. The level bar is a row of slanted segments,
// inspired by the LED light strips and cockpit gauges of sports cars.
#pragma once

#include <string>

#include "server.hpp"

namespace dusk {

class Osd {
public:
	enum class Kind { Volume, Mic, Brightness, CapsLock, NumLock, Layout };

	explicit Osd(Server *server);
	~Osd();
	Osd(const Osd &) = delete;
	Osd &operator=(const Osd &) = delete;

	// `level` 0..100, or -1 for no bar. `off` greys it out (muted, lock off).
	void show(Kind kind, int level, bool off, const std::string &text = "");
	void hide();

private:
	static int handle_timeout(void *data);
	void redraw();
	void place();

	Server *server_;
	wlr_scene_tree *tree_;
	wlr_scene_blur *blur_;
	wlr_scene_buffer *buffer_;
	double radius_ = 0;
	wl_event_source *timer_;
	uint64_t anim_ = 0;
	bool visible_ = false;
	double alpha_ = 0;

	Kind kind_ = Kind::Volume;
	int level_ = 0;
	bool off_ = false;
	std::string text_;
	int width_ = 0, height_ = 0;
};

} // namespace dusk
