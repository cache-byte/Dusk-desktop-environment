#include <cstdio>
#include <string>
#include <sys/stat.h>

#include "audiolevel.hpp"
#include "ccentre.hpp"
#include "lyrics.hpp"
#include "recorder.hpp"
#include "clipboard.hpp"
#include "desktop.hpp"
#include "shot.hpp"
#include "wallpaper.hpp"
#include "tray.hpp"
#include "overview.hpp"
#include "trash.hpp"
#include "launcher.hpp"
#include "notify.hpp"
#include "osd.hpp"
#include "panel.hpp"
#include "popover.hpp"
#include "system.hpp"
#include "server.hpp"
#include "session.hpp"
#include "crash.hpp"
#include "lock.hpp"
#include "osk.hpp"

namespace {

void print_help() {
	std::puts(
		"Dusk - a floating desktop\n"
		"\n"
		"Usage: dusk [options]\n"
		"  -s, --startup <command>  run a command once Dusk has started\n"
		"  -d, --debug              verbose logging\n"
		"  -h, --help               show this help\n"
		"\n"
		"Dusk also runs ~/.config/dusk/autostart (if it exists and is executable).");
}

} // namespace

int main(int argc, char **argv) {
	std::string startup;
	bool debug = false;
	for (int i = 1; i < argc; i++) {
		const std::string arg = argv[i];
		if ((arg == "-s" || arg == "--startup") && i + 1 < argc) {
			startup = argv[++i];
		} else if (arg == "-d" || arg == "--debug") {
			debug = true;
		} else if (arg == "-h" || arg == "--help") {
			print_help();
			return 0;
		} else {
			std::fprintf(stderr, "Unknown option: %s\n\n", arg.c_str());
			print_help();
			return 1;
		}
	}

	dusk::install_crash_log();
	wlr_log_init(debug ? WLR_DEBUG : WLR_INFO, nullptr);

	dusk::Server server;
	if (!server.start()) {
		return 1;
	}

	// As the real desktop (not in a window): the keyring, the admin
	// password prompt and the apps set to start at login.
	if (server.session) {
		dusk::start_keyring(server);
		dusk::start_polkit_agent(server);
		if (server.config.autostart) {
			// A moment after starting: the tray, the portals and the rest are
			// ready by then (apps like Steam look for the tray once, at start).
			wl_event_source *later = wl_event_loop_add_timer(server.loop, [](void *data) {
				dusk::run_autostart(*static_cast<dusk::Server *>(data));
				return 0;
			}, &server);
			wl_event_source_timer_update(later, 1500);
		}
	}
	if (!startup.empty()) {
		server.spawn(startup);
	}
	if (const char *home = getenv("HOME"); home) {
		const char *config = getenv("XDG_CONFIG_HOME");
		std::string autostart = (config && *config) ? std::string(config)
			: std::string(home) + "/.config";
		autostart += "/dusk/autostart";
		if (access(autostart.c_str(), X_OK) == 0) {
			server.spawn("\"" + autostart + "\"");
		}
	}

	server.run();
	server.shutdown();
	return 0;
}
