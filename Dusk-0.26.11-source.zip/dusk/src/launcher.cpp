#include "launcher.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <linux/input-event-codes.h>

#include "draw.hpp"
#include "glyphs.hpp"
#include "panel.hpp"

namespace dusk {

namespace {

constexpr int kWidth = 420;
constexpr int kHeight = 540;
constexpr int kPad = 14;
constexpr int kSearchHeight = 40;
constexpr int kListTop = kPad + kSearchHeight + 12;
constexpr int kRowHeight = 42;
constexpr int kFooterHeight = 52;

std::string lower(std::string s) {
	for (char &c : s) {
		c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
	}
	return s;
}

} // namespace

Launcher::Launcher(Server *server)
		: server_(server), layer_(server->layer_menu, &tag),
		fx_(server->anim.get(), [this] { if (open_ || alpha_ > 0) redraw(); }),
		sel_(layer_, server->anim.get()), hl_(layer_, server->anim.get()) {
	layer_.set_enabled(false);
	fx_.set_speed(55);
}

Launcher::~Launcher() {
	if (anim_) {
		server_->anim->cancel(anim_);
	}
}

void Launcher::filter() {
	const auto &apps = server_->apps.apps();
	shown_.clear();
	const std::string q = lower(query_);
	std::vector<int> starts, contains;
	for (int i = 0; i < static_cast<int>(apps.size()); i++) {
		const AppInfo &app = apps[static_cast<size_t>(i)];
		if (!app.visible) {
			continue;
		}
		const std::string name = lower(app.name);
		if (q.empty() || name.rfind(q, 0) == 0) {
			starts.push_back(i);
		} else if (name.find(q) != std::string::npos ||
				lower(app.comment).find(q) != std::string::npos ||
				lower(app.exec).find(q) != std::string::npos) {
			contains.push_back(i);
		}
	}
	shown_ = starts;
	shown_.insert(shown_.end(), contains.begin(), contains.end());
	selected_ = 0;
	first_row_ = 0;
	// A new list: no gliding from where the old one was.
	fx_.snap("scroll", 0);
}

int Launcher::visible_rows() const {
	return (kHeight - kListTop - kFooterHeight - 4) / kRowHeight;
}

// Next to the menu button, on the side away from its panel's screen edge
// (or in the middle of the screen when opened from the keyboard with no
// panel). Slides a little while fading in/out.
void Launcher::place() {
	if (!output_) {
		return;
	}
	const wlr_box o = output_->box();
	const wlr_box u = output_->usable();
	const int gap = 8;
	int x, y;
	if (anchor_.width <= 0) {
		x = o.x + (o.width - kWidth) / 2;
		y = o.y + (o.height - kHeight) / 2;
	} else if (edge_ == "top" || edge_ == "bottom") {
		x = anchor_.x;
		y = edge_ == "top" ? anchor_.y + anchor_.height + gap + 6 : anchor_.y - kHeight - gap - 6;
	} else {
		y = anchor_.y;
		x = edge_ == "left" ? anchor_.x + anchor_.width + gap + 6 : anchor_.x - kWidth - gap - 6;
	}
	x = std::clamp(x, u.x + gap, std::max(u.x + gap, u.x + u.width - kWidth - gap));
	y = std::clamp(y, u.y + gap, std::max(u.y + gap, u.y + u.height - kHeight - gap));
	box_ = wlr_box{x, y, kWidth, kHeight};
	// It grows out of the corner nearest the menu button.
	double ox = kWidth / 2.0, oy = kHeight / 2.0;
	if (anchor_.width > 0) {
		ox = std::clamp<double>(anchor_.x + anchor_.width / 2.0 - x, 0, kWidth);
		oy = std::clamp<double>(anchor_.y + anchor_.height / 2.0 - y, 0, kHeight);
		if (edge_ == "bottom") oy = kHeight;
		else if (edge_ == "top") oy = 0;
		else if (edge_ == "left") ox = 0;
		else ox = kWidth;
	}
	const double t = std::clamp(alpha_, 0.0, 1.1);
	layer_.show(x, y, std::min(1.0, t * 1.3), 0.9 + 0.1 * t, ox, oy);
}

void Launcher::open(Output *output, wlr_box anchor, const std::string &edge) {
	if (!output) {
		return;
	}
	output_ = output;
	anchor_ = anchor;
	edge_ = edge;
	open_ = true;
	query_.clear();
	hover_row_ = -1;
	server_->apps.reload();   // picks up newly installed apps
	filter();
	redraw();
	place();
	layer_.set_enabled(true);
	layer_.raise();

	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 1.0, c.animate(c.anim_menu) ? c.ms(230) : 0,
		[this] { place(); }, [this] { anim_ = 0; });
	server_->redraw_panels();   // menu button shows as pressed
}

void Launcher::close() {
	if (!open_) {
		return;
	}
	open_ = false;
	const Config &c = server_->config;
	server_->anim->cancel(anim_);
	anim_ = server_->anim->tween(alpha_, 0.0, c.animate(c.anim_menu) ? c.ms(160) : 0,
		[this] { place(); },
		[this] {
			anim_ = 0;
			if (!open_) {
				layer_.set_enabled(false);
			}
		});
	server_->redraw_panels();
}

void Launcher::toggle(Output *output, wlr_box anchor, const std::string &edge) {
	if (open_) {
		close();
	} else {
		open(output, anchor, edge);
	}
}

void Launcher::toggle(Output *output) {
	if (open_ || !output) {
		close();
		return;
	}
	for (const auto &panel : output->panels) {
		const auto &w = panel->config().widgets;
		if (std::find(w.begin(), w.end(), "menu") != w.end()) {
			open(output, panel->anchor("menu"), panel->config().edge);
			return;
		}
	}
	open(output, wlr_box{}, "bottom");
}

void Launcher::output_gone(Output *output) {
	if (output_ == output) {
		open_ = false;
		server_->anim->cancel(anim_);
		anim_ = 0;
		alpha_ = 0;
		layer_.set_enabled(false);
		output_ = nullptr;
	}
}

bool Launcher::contains(double lx, double ly) const {
	return open_ && lx >= box_.x && lx < box_.x + box_.width &&
		ly >= box_.y && ly < box_.y + box_.height;
}

int Launcher::row_at(double px, double py) const {
	if (px < kPad || px >= kWidth - kPad || py < kListTop) {
		return -1;
	}
	if (py >= kListTop + visible_rows() * kRowHeight) {
		return -1;
	}
	// Rows as drawn, while the list may still be gliding.
	const double scroll = const_cast<Fades &>(fx_).get("scroll", first_row_ * kRowHeight);
	const int row = static_cast<int>(std::floor((py - kListTop + scroll) / kRowHeight));
	return row >= 0 && row < static_cast<int>(shown_.size()) ? row : -1;
}

bool Launcher::on_power(double px, double py) const {
	const int fy = kHeight - kFooterHeight;
	return server_->config.menu_power && px >= kWidth - kPad - 36 && px < kWidth - kPad &&
		py >= fy + 8 && py < fy + 44;
}

bool Launcher::on_settings(double px, double py) const {
	const int fy = kHeight - kFooterHeight;
	return px >= kPad && px < kPad + 130 && py >= fy + 8 && py < fy + 44;
}

void Launcher::motion(double lx, double ly) {
	const double px = lx - box_.x, py = ly - box_.y;
	const int row = row_at(px, py);
	const bool power = on_power(px, py);
	const bool settings = on_settings(px, py);
	if (row != hover_row_ || power != hover_power_ || settings != hover_settings_) {
		hover_row_ = row;
		hover_power_ = power;
		hover_settings_ = settings;
		update_highlights();   // no redraw needed
	}
}

void Launcher::leave() {
	if (open_ && (hover_row_ != -1 || hover_power_ || hover_settings_)) {
		hover_row_ = -1;
		hover_power_ = false;
		hover_settings_ = false;
		update_highlights();
	}
}

// The selection and hover highlights, where the rows are drawn right now.
void Launcher::update_highlights() {
	const double scroll = fx_.get("scroll", first_row_ * kRowHeight);
	const double row_r = inner_radius(theme::ui_radius, kPad);
	const int rh = kRowHeight - 4;
	const double list_bottom = kListTop + visible_rows() * kRowHeight;
	auto row_box = [&](int row, wlr_box *out) {
		const double ry = kListTop + row * kRowHeight - scroll;
		if (row < 0 || row >= static_cast<int>(shown_.size()) || ry < kListTop - rh / 2.0 ||
				ry + rh > list_bottom + rh / 2.0) {
			return false;
		}
		*out = wlr_box{kPad, static_cast<int>(std::lround(ry)), kWidth - 2 * kPad, rh};
		return true;
	};
	wlr_box b;
	if (row_box(selected_, &b)) {
		sel_.show(b, row_r, with_alpha(theme::accent, theme::dark ? 0.30 : 0.22));
	} else {
		sel_.hide();
	}
	const Color hover = with_alpha(theme::text, theme::dark ? 0.08 : 0.06);
	const int fy = kHeight - kFooterHeight;
	if (hover_row_ >= 0 && hover_row_ != selected_ && row_box(hover_row_, &b)) {
		hl_.show(b, row_r, hover);
	} else if (hover_settings_) {
		hl_.show(wlr_box{kPad, fy + 8, 130, 36}, 18, hover);
	} else if (hover_power_) {
		hl_.show(wlr_box{kWidth - kPad - 36, fy + 8, 36, 36}, 18, hover);
	} else {
		hl_.hide();
	}
}

// The scroll bar's track (a bit wider than it's drawn, so it's easy to hit).
bool Launcher::on_bar(double px, double py) const {
	const int rows = visible_rows();
	return static_cast<int>(shown_.size()) > rows && px >= kWidth - 18 && px < kWidth &&
		py >= kListTop && py < kListTop + rows * kRowHeight;
}

void Launcher::drag_bar(double lx, double ly) {
	(void)lx;
	const int rows = visible_rows();
	const int total = static_cast<int>(shown_.size());
	if (total <= rows) return;
	const double track = rows * kRowHeight;
	const double thumb = std::max(24.0, track * rows / total);
	const double frac = std::clamp((ly - box_.y - kListTop - thumb / 2) / std::max(1.0, track - thumb), 0.0, 1.0);
	const int first = static_cast<int>(std::lround(frac * (total - rows)));
	if (first != first_row_) {
		first_row_ = first;
		redraw();
	}
}

void Launcher::click(double lx, double ly, uint32_t button) {
	if (button != BTN_LEFT) {
		return;
	}
	const double px = lx - box_.x, py = ly - box_.y;
	if (on_bar(px, py)) {
		bar_drag_ = true;
		drag_bar(lx, ly);
		return;
	}
	if (on_settings(px, py)) {
		close();
		server_->open_settings();
		return;
	}
	if (on_power(px, py)) {
		const int fy = kHeight - kFooterHeight;
		// Right by the button (under it, or over it when there's no room),
		// wherever the app menu is.
		server_->show_power_menu(output_, wlr_box{box_.x + kWidth - kPad - 36, box_.y + fy + 8, 36, 36},
			"below");
		return;
	}
	const int row = row_at(px, py);
	if (row >= 0) {
		launch(row);
	}
}

void Launcher::scroll(double delta, bool wheel) {
	// A mouse wheel moves a row per notch (15 units, or a part of one for
	// high-resolution wheels); a touchpad moves with the fingers.
	scroll_accum_ += wheel ? delta * (kRowHeight / 15.0) : delta * 1.4;
	int steps = 0;
	while (scroll_accum_ >= kRowHeight * 0.75) { scroll_accum_ -= kRowHeight; steps++; }
	while (scroll_accum_ <= -kRowHeight * 0.75) { scroll_accum_ += kRowHeight; steps--; }
	if (steps == 0) {
		return;
	}
	const int max_first = std::max(0, static_cast<int>(shown_.size()) - visible_rows());
	first_row_ = std::clamp(first_row_ + steps, 0, max_first);
	redraw();
}

void Launcher::keep_selection_visible() {
	if (selected_ < first_row_) {
		first_row_ = selected_;
	} else if (selected_ >= first_row_ + visible_rows()) {
		first_row_ = selected_ - visible_rows() + 1;
	}
}

bool Launcher::handle_key(xkb_keysym_t sym, const std::string &text) {
	const int count = static_cast<int>(shown_.size());
	switch (sym) {
	case XKB_KEY_Escape:
		close();
		return true;
	case XKB_KEY_Return:
	case XKB_KEY_KP_Enter:
		if (count > 0) {
			launch(selected_);
		}
		return true;
	case XKB_KEY_Down:
		if (count > 0) selected_ = std::min(selected_ + 1, count - 1);
		break;
	case XKB_KEY_Up:
		selected_ = std::max(selected_ - 1, 0);
		break;
	case XKB_KEY_Page_Down:
		if (count > 0) selected_ = std::min(selected_ + visible_rows(), count - 1);
		break;
	case XKB_KEY_Page_Up:
		selected_ = std::max(selected_ - visible_rows(), 0);
		break;
	case XKB_KEY_BackSpace:
		if (!query_.empty()) {
			// Remove one whole UTF-8 character.
			size_t cut = query_.size() - 1;
			while (cut > 0 && (static_cast<unsigned char>(query_[cut]) & 0xc0) == 0x80) {
				cut--;
			}
			query_.erase(cut);
			filter();
		}
		break;
	default:
		if (!text.empty() && static_cast<unsigned char>(text[0]) >= 0x20 && text[0] != 0x7f) {
			query_ += text;
			filter();
		}
		break;
	}
	keep_selection_visible();
	redraw();
	return true;   // the menu takes all keys while open
}

void Launcher::launch(int row) {
	if (row < 0 || row >= static_cast<int>(shown_.size())) {
		return;
	}
	const AppInfo &app = server_->apps.apps()[static_cast<size_t>(shown_[static_cast<size_t>(row)])];
	if (app.id.rfind("org.dusk.Settings", 0) == 0) {
		server_->open_settings("");   // the one that's open comes forward
		close();
		return;
	}
	server_->spawn(app.exec);
	close();
}

void Launcher::redraw() {
	if (!output_ || drawing_) {
		return;
	}
	drawing_ = true;
	const auto &apps = server_->apps.apps();
	const float scale = output_->output->scale;
	Canvas canvas(kWidth, kHeight, scale);
	cairo_t *cr = canvas.cr();
	const double radius = theme::ui_radius;
	ui_card(cr, 0, 0, kWidth, kHeight, radius, theme::menu_bg);

	// Search field: a pill, its ends following the card's corners.
	fill_rounded(cr, kPad, kPad, kWidth - 2 * kPad, kSearchHeight,
		std::min<double>(kSearchHeight / 2.0, inner_radius(radius, kPad)), theme::field_bg);
	// Magnifying glass.
	draw_named_icon(cr, server_->icons, "search", kPad + 13, kPad + kSearchHeight / 2.0 - 9, 18, theme::text_dim, scale);
	const int text_x = kPad + 38;
	if (query_.empty()) {
		draw_text(cr, "Type to search…", text_x, kPad, kWidth - 2 * kPad - 52,
			kSearchHeight, theme::font_large, theme::text_dim);
	} else {
		draw_text(cr, query_, text_x, kPad, kWidth - 2 * kPad - 52, kSearchHeight,
			theme::font_large, theme::text);
	}
	const int caret_x = text_x + (query_.empty() ? 0 : text_width(query_, theme::font_large)) + 1;
	if (caret_x < kWidth - kPad - 16) {
		cairo_rectangle(cr, caret_x, kPad + 11, 2, kSearchHeight - 22);
		set_color(cr, theme::accent);
		cairo_fill(cr);
	}

	// App list: it scrolls smoothly and the selection glides between rows.
	const int rows = visible_rows();
	const double row_r = inner_radius(radius, kPad);
	if (shown_.empty()) {
		draw_text(cr, apps.empty() ? "No apps found" : "No matches", kPad, kListTop,
			kWidth - 2 * kPad, kRowHeight * 2, theme::font, theme::text_dim, Align::Center);
	}
	fx_.set("scroll", first_row_ * kRowHeight, 0);
	const double scroll = fx_.get("scroll");
	const double list_h = rows * kRowHeight;
	cairo_save(cr);
	cairo_rectangle(cr, 0, kListTop - 2, kWidth, list_h + 2);
	cairo_clip(cr);
	const double rh = kRowHeight - 4;
	(void)row_r;
	const int first = std::max(0, static_cast<int>(scroll / kRowHeight));
	for (int row = first; row < static_cast<int>(shown_.size()) && row <= first + rows + 1; row++) {
		const int index = shown_[static_cast<size_t>(row)];
		const AppInfo &app = apps[static_cast<size_t>(index)];
		const double ry = kListTop + row * kRowHeight - scroll;
		draw_icon(cr, server_->icons, app.icon, app.name, kPad + 10, ry + (rh - 26) / 2.0, 26,
			scale);
		draw_text(cr, app.name, kPad + 46, ry, kWidth - 2 * kPad - 56, rh, theme::font, theme::text);
	}
	cairo_restore(cr);

	// Scroll indicator.
	const int total = static_cast<int>(shown_.size());
	if (total > rows) {
		const double track = rows * kRowHeight;
		const double thumb = std::max(24.0, track * rows / total);
		const double pos = (track - thumb) * (scroll / kRowHeight) / std::max(1, total - rows);
		fill_rounded(cr, kWidth - 9, kListTop + pos, 4, thumb, 2, with_alpha(theme::text, 0.3));
	}

	// Footer: Settings and log out.
	const int fy = kHeight - kFooterHeight;
	cairo_rectangle(cr, kPad, fy, kWidth - 2 * kPad, 1);
	set_color(cr, theme::divider);
	cairo_fill(cr);

	draw_named_icon(cr, server_->icons, "gear", kPad + 12, fy + 16, 20, theme::text, scale);
	draw_text(cr, "Settings", kPad + 40, fy + 8, 84, 36, theme::font, theme::text);
	if (server_->config.menu_power) {
		// The power button: a round button with the power symbol, its menu
		// set in Settings > Power.
		const double px = kWidth - kPad - 36, py = fy + 8;
		fill_rounded(cr, px, py, 36, 36, 18, theme::field_bg);
		draw_named_icon(cr, server_->icons, "power", px + 8, py + 8, 20, theme::text, scale);
	}
	layer_.present(canvas, wlr_box{0, 0, kWidth, kHeight}, radius);
	drawing_ = false;
	update_highlights();
}

} // namespace dusk
