// The app menu: lists installed apps (from .desktop files), type to search.
#pragma once

#include <string>
#include <vector>

#include "server.hpp"
#include "ui.hpp"

namespace dusk {

class Launcher {
public:
	explicit Launcher(Server *server);
	~Launcher();
	Launcher(const Launcher &) = delete;
	Launcher &operator=(const Launcher &) = delete;

	bool is_open() const { return open_; }
	bool is_open_on(const Output *output) const { return open_ && output_ == output; }
	// Opens next to `anchor` (the menu button) on a panel at `edge`.
	void open(Output *output, wlr_box anchor, const std::string &edge);
	void close();
	void toggle(Output *output, wlr_box anchor, const std::string &edge);
	// From the keyboard: next to the first menu button on that screen.
	void toggle(Output *output);
	void output_gone(Output *output);

	bool contains(double lx, double ly) const;
	void motion(double lx, double ly);
	void leave();
	void click(double lx, double ly, uint32_t button);
	void scroll(double delta, bool wheel = true);
	// The scroll bar: press on it and drag (or click the track to jump there).
	bool dragging_bar() const { return bar_drag_; }
	void drag_bar(double lx, double ly);
	void end_drag() { bar_drag_ = false; }
	// Returns true if the key was used by the menu.
	bool handle_key(xkb_keysym_t sym, const std::string &text);

	NodeTag tag{NodeTag::Kind::Launcher, this};

private:
	void filter();
	void redraw();
	void place();
	void launch(int row);
	void keep_selection_visible();
	int visible_rows() const;
	int row_at(double px, double py) const;
	bool on_power(double px, double py) const;
	bool on_settings(double px, double py) const;

	Server *server_;
	UiLayer layer_;
	Fades fx_;
	Highlight sel_;    // the selected row (keyboard)
	Highlight hl_;     // under the pointer
	void update_highlights();
	bool drawing_ = false;
	Output *output_ = nullptr;
	bool open_ = false;
	wlr_box box_{};
	wlr_box anchor_{};
	std::string edge_ = "bottom";
	uint64_t anim_ = 0;
	double alpha_ = 0.0;

	std::vector<int> shown_;   // indexes into server_->apps.apps()
	std::string query_;
	int selected_ = 0;
	int first_row_ = 0;
	int hover_row_ = -1;
	bool hover_power_ = false;
	bool hover_settings_ = false;
	double scroll_accum_ = 0;
	bool bar_drag_ = false;
	bool on_bar(double px, double py) const;
};

} // namespace dusk
