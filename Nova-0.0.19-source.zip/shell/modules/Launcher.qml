import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.services
import qs.components

Glass {
    id: root
    width: 580
    height: 720
    padding: 18

    property string tab: "apps"     // apps | files | run | settings
    property string query: ""
    property int current: 0
    property bool powerMenu: false

    onVisibleChanged: if (visible) { query = ""; search.text = ""; current = 0; search.forceActiveFocus() }
    MouseArea { anchors.fill: parent; z: -1 }   // swallow clicks so the overlay doesn't close

    readonly property var apps: {
        const q = query.toLowerCase();
        return DesktopEntries.applications.values
            .filter(e => !e.noDisplay && (!q || e.name.toLowerCase().includes(q) || (e.genericName || "").toLowerCase().includes(q)
                     || (e.keywords || []).some(k => k.toLowerCase().includes(q))))
            .sort((a, b) => a.name.localeCompare(b.name));
    }
    readonly property var settingsPages: ["For you", "Appearance", "Connections", "Display", "Sound", "Power", "Notifications", "Popups & indicators", "Music & lyrics", "Gaming", "Windows & tiling", "Keyboard", "Mouse & touchpad", "Panel & launcher", "Users", "Updates", "About"]
        .filter(p => p.toLowerCase().includes(query.toLowerCase()))
    property var files: []
    property string calc: ""        // qalc result for maths / unit conversions ("2^10", "5 km to mi")

    // Games (and Steam/Heroic/Lutris) start on the dedicated GPU with GameMode on hybrid laptops.
    function isGame(e) {
        const id = (e.id || "").toLowerCase();
        return (e.categories || []).includes("Game") || /steam|heroic|lutris|bottles|prismlauncher/.test(id);
    }
    function launch(e) {
        if (!e) return;
        if (Config.s.gamesOnDedicatedGpu && isGame(e) && (e.command || []).length) {
            const pre = ["nova-gpu", "run"].concat(Config.s.gameModeAuto ? ["gamemoderun"] : []);
            Quickshell.execDetached({ command: pre.concat(e.command), workingDirectory: e.workingDirectory || Quickshell.env("HOME"),
                                      environment: Config.s.mangohud ? { "MANGOHUD": "1" } : {} });
        } else e.execute();
    }
    Process {
        id: calcProc
        command: ["qalc", "-t", "-e", root.query]
        stdout: StdioCollector { onStreamFinished: {
            const r = text.trim();
            root.calc = (r && r !== root.query.trim() && !/error|warning/i.test(r)) ? r : "";
        } }
    }
    Timer { id: calcDebounce; interval: 160; onTriggered: if (/[0-9]/.test(root.query) && root.tab === "apps") calcProc.running = true; else root.calc = "" }

    Process {
        id: fileSearch
        command: ["sh", "-c", "command -v fd >/dev/null && fd -i -d 5 --max-results 40 -- \"$1\" \"$HOME\" || find \"$HOME\" -maxdepth 5 -iname \"*$1*\" -not -path '*/.*' 2>/dev/null | head -40", "sh", root.query]
        stdout: StdioCollector { onStreamFinished: root.files = text.split("\n").filter(x => x) }
    }
    Timer { id: debounce; interval: 220; onTriggered: if (root.tab === "files" && root.query.length > 1) fileSearch.running = true }
    onQueryChanged: { current = 0; debounce.restart(); calc = ""; calcDebounce.restart() }
    onTabChanged: { current = 0; debounce.restart() }

    function activate(i) {
        if (tab === "apps") {
            if (apps.length === 0 && query) Quickshell.execDetached(["xdg-open", "https://duckduckgo.com/?q=" + encodeURIComponent(query)]);
            else launch(apps[i]);
        }
        else if (tab === "files") { if (files[i]) Quickshell.execDetached(["xdg-open", files[i]]) }
        else if (tab === "run") { if (query) Quickshell.execDetached(["sh", "-c", query]) }
        else if (tab === "settings") { if (settingsPages[i]) Quickshell.execDetached(["nova-settings", "--page", settingsPages[i]]) }
        Shell.close();
    }
    readonly property int count: tab === "apps" ? apps.length : tab === "files" ? files.length : tab === "settings" ? settingsPages.length : 0

    ColumnLayout {
        anchors.fill: parent
        spacing: 16

        // search
        Rectangle {
            Layout.fillWidth: true; implicitHeight: 50; radius: 15
            color: Theme.surface2; border.color: Theme.border
            RowLayout {
                anchors.fill: parent; anchors.leftMargin: 16; anchors.rightMargin: 16; spacing: 12
                Icon { name: "search"; color: Theme.text2 }
                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: Theme.text; font.family: Theme.font; font.pixelSize: 15
                    cursorDelegate: Rectangle { width: 2; color: Theme.accent; radius: 1 }
                    selectionColor: Theme.accentLine
                    onTextChanged: root.query = text
                    Keys.onDownPressed: root.current = Math.min(root.count - 1, root.current + 1)
                    Keys.onUpPressed: root.current = Math.max(0, root.current - 1)
                    Keys.onReturnPressed: root.activate(root.current)
                    Keys.onTabPressed: root.tab = ["apps", "files", "run", "settings"][(["apps", "files", "run", "settings"].indexOf(root.tab) + 1) % 4]
                    Keys.onEscapePressed: Shell.close()
                    Text {
                        visible: !search.text
                        text: root.tab === "run" ? "Type a command and press Enter" : "Search apps, files, settings…"
                        color: Theme.text3; font: search.font
                    }
                }
            }
        }
        // tabs
        RowLayout {
            spacing: 6
            Repeater {
                model: [["apps", "grid", "Apps"], ["files", "file", "Files"], ["run", "terminal", "Run"], ["settings", "settings", "Settings"]]
                Rectangle {
                    required property var modelData
                    readonly property bool on: root.tab === modelData[0]
                    implicitHeight: 30; implicitWidth: tr.implicitWidth + 26; radius: 15
                    color: on ? Theme.accent : Theme.surface2
                    RowLayout { id: tr; anchors.centerIn: parent; spacing: 7
                        Icon { name: modelData[1]; size: 14; color: parent.parent.on ? Theme.onAccent : Theme.text2 }
                        Text { text: modelData[2]; color: parent.parent.on ? Theme.onAccent : Theme.text2; font.pixelSize: 13; font.weight: parent.parent.on ? Font.DemiBold : Font.Normal }
                    }
                    MouseArea { anchors.fill: parent; onClicked: { root.tab = modelData[0]; search.forceActiveFocus() } }
                }
            }
        }

        // favourites
        Text { visible: root.tab === "apps" && !root.query; text: "FAVOURITES"; color: Theme.text3; font.pixelSize: 12; font.weight: Font.DemiBold; font.letterSpacing: 0.7 }
        GridLayout {
            visible: root.tab === "apps" && !root.query
            Layout.fillWidth: true; columns: 6; columnSpacing: 4
            Repeater {
                model: Config.s.pinned.slice(0, 6)
                ColumnLayout {
                    required property string modelData
                    readonly property var entry: DesktopEntries.heuristicLookup(modelData)
                    Layout.fillWidth: true; spacing: 8
                    AppIcon { Layout.alignment: Qt.AlignHCenter; appId: parent.modelData; implicitSize: 44 }
                    Text { Layout.alignment: Qt.AlignHCenter; text: parent.entry?.name ?? parent.modelData; color: Theme.text2; font.pixelSize: 12; elide: Text.ElideRight; Layout.maximumWidth: 84 }
                    TapHandler { onTapped: { root.launch(parent.entry); Shell.close() } }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Text { text: root.tab === "apps" ? (root.query ? "RESULTS" : "ALL APPS") : root.tab.toUpperCase(); color: Theme.text3; font.pixelSize: 12; font.weight: Font.DemiBold; font.letterSpacing: 0.7 }
            Item { Layout.fillWidth: true }
            Row {
                visible: root.tab === "apps"
                spacing: 2
                Repeater {
                    model: ["list", "grid"]
                    Rectangle {
                        required property string modelData
                        width: 30; height: 24; radius: 7
                        color: Config.s.launcherView === modelData ? Theme.surface3 : "transparent"
                        Icon { anchors.centerIn: parent; name: modelData; size: 15; color: Config.s.launcherView === parent.modelData ? Theme.text : Theme.text3 }
                        MouseArea { anchors.fill: parent; onClicked: Config.s.launcherView = parent.modelData }
                    }
                }
            }
        }

        // calculator / unit conversion: click copies the answer
        Rectangle {
            visible: root.tab === "apps" && root.calc !== ""
            Layout.fillWidth: true; implicitHeight: 52; radius: 14; color: Theme.accentSoft
            RowLayout { anchors.fill: parent; anchors.leftMargin: 16; anchors.rightMargin: 16; spacing: 12
                Icon { name: "calc"; color: Theme.accent }
                Text { text: root.calc; color: Theme.text; font.pixelSize: 16; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
                Text { text: "Copy"; color: Theme.accent; font.pixelSize: 13 } }
            MouseArea { anchors.fill: parent; onClicked: { Quickshell.execDetached(["wl-copy", root.calc.replace(/^.*= /, "")]); Shell.close() } }
        }
        // nothing found: search the web or the software centre
        RowLayout {
            visible: root.tab === "apps" && root.query !== "" && root.apps.length === 0
            Layout.fillWidth: true; spacing: 8
            Repeater {
                model: [["globe", "Search the web", "web"], ["pkg", "Find in Software", "sw"]]
                Rectangle {
                    required property var modelData
                    Layout.fillWidth: true; implicitHeight: 46; radius: 13; color: Theme.surface2
                    RowLayout { anchors.centerIn: parent; spacing: 8
                        Icon { name: modelData[0]; size: 16; color: Theme.text2 }
                        Text { text: modelData[1] + " for “" + root.query + "”"; color: Theme.text; font.pixelSize: 13; elide: Text.ElideRight } }
                    MouseArea { anchors.fill: parent; onClicked: {
                        if (modelData[2] === "web") Quickshell.execDetached(["xdg-open", "https://duckduckgo.com/?q=" + encodeURIComponent(root.query)]);
                        else Quickshell.execDetached(["gnome-software", "--search", root.query]);
                        Shell.close() } }
                }
            }
        }
        // results
        GridView {
            id: results
            Layout.fillWidth: true; Layout.fillHeight: true
            clip: true
            readonly property bool grid: root.tab === "apps" && Config.s.launcherView === "grid"
            cellWidth: grid ? width / 5 : width
            cellHeight: grid ? 96 : 56
            currentIndex: root.current
            model: root.tab === "apps" ? root.apps : root.tab === "files" ? root.files : root.tab === "settings" ? root.settingsPages : []
            delegate: Item {
                id: d
                required property var modelData
                required property int index
                width: results.cellWidth; height: results.cellHeight
                readonly property bool hot: ma.containsMouse || root.current === index
                Rectangle {
                    anchors.fill: parent; anchors.margins: 1; radius: 13
                    color: d.hot ? Theme.accentSoft : "transparent"
                    border.color: d.hot ? Theme.accentLine : "transparent"
                }
                RowLayout {
                    visible: !results.grid
                    anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 12; spacing: 14
                    AppIcon {
                        implicitSize: 34
                        iconName: root.tab === "apps" ? (d.modelData.icon ?? "") : root.tab === "files" ? "text-x-generic" : "preferences-system"
                    }
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 2
                        Text { Layout.fillWidth: true; elide: Text.ElideRight; color: d.hot ? Theme.accentBright : Theme.text; font.pixelSize: 15; font.weight: Font.Medium
                               text: root.tab === "apps" ? d.modelData.name : root.tab === "files" ? d.modelData.split("/").pop() : d.modelData }
                        Text { Layout.fillWidth: true; elide: Text.ElideMiddle; color: Theme.text3; font.pixelSize: 12
                               text: root.tab === "apps" ? (d.modelData.comment || d.modelData.genericName || "") : root.tab === "files" ? d.modelData.replace(Quickshell.env("HOME"), "~") : "Settings" }
                    }
                    Icon { visible: d.hot; name: "arrow"; size: 18; color: Theme.accentBright }
                }
                ColumnLayout {
                    visible: results.grid
                    anchors.centerIn: parent; spacing: 8
                    AppIcon { Layout.alignment: Qt.AlignHCenter; implicitSize: 44; iconName: root.tab === "apps" ? (d.modelData.icon ?? "") : "" }
                    Text { Layout.alignment: Qt.AlignHCenter; Layout.maximumWidth: results.cellWidth - 10; elide: Text.ElideRight; text: root.tab === "apps" ? d.modelData.name : ""; color: Theme.text2; font.pixelSize: 12 }
                }
                MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; onClicked: root.activate(d.index) }
            }
        }

        // footer: user, uptime, settings, lock, power
        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.border }
        RowLayout {
            Layout.fillWidth: true; spacing: 12
            Rectangle {
                implicitWidth: 40; implicitHeight: 40; radius: 20; clip: true
                gradient: Gradient { GradientStop { position: 0; color: "#d9925a" } GradientStop { position: 1; color: "#7d3f6b" } }
                Image { anchors.fill: parent; source: "file://" + Quickshell.env("HOME") + "/.face"; fillMode: Image.PreserveAspectCrop }
            }
            ColumnLayout {
                Layout.fillWidth: true; spacing: 2
                Text { text: Quickshell.env("USER"); color: Theme.text; font.pixelSize: 14; font.weight: Font.DemiBold }
                RowLayout { spacing: 5
                    Icon { name: "clock"; size: 12; color: Theme.text3 }
                    Text { id: up; color: Theme.text3; font.pixelSize: 12 }
                }
                FileView {
                    path: "/proc/uptime"
                    onLoaded: {
                        const s = parseFloat(text().split(" ")[0]);
                        const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
                        up.text = "up " + (h ? h + " h " : "") + m + " min";
                    }
                }
            }
            IconButton { icon: "settings"; onClicked: { Quickshell.execDetached(["nova-settings"]); Shell.close() } }
            IconButton { icon: "lock"; onClicked: { Shell.close(); Nova.lockRequested() } }
            IconButton { icon: "power"; iconColor: "#ff8a7a"; onClicked: root.powerMenu = !root.powerMenu }
        }
        RowLayout {
            visible: root.powerMenu
            Layout.fillWidth: true; spacing: 8
            Repeater {
                model: [["Log out", "novactl dispatch exit"], ["Suspend", "systemctl suspend"], ["Restart", "systemctl reboot"], ["Shut down", "systemctl poweroff"]]
                Rectangle {
                    required property var modelData
                    Layout.fillWidth: true; implicitHeight: 36; radius: 11
                    color: index === 3 ? Qt.rgba(0.91, 0.38, 0.3, 0.2) : Theme.surface3
                    required property int index
                    Text { anchors.centerIn: parent; text: modelData[0]; color: index === 3 ? "#ff8a7a" : Theme.text; font.pixelSize: 13; font.weight: Font.DemiBold }
                    MouseArea { anchors.fill: parent; onClicked: Quickshell.execDetached(["sh", "-c", modelData[1]]) }
                }
            }
        }
    }
}
