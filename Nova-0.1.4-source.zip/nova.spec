Name:           nova
Version:        0.1.4
Release:        1%{?dist}
Summary:        Nova — a wlroots desktop environment for Fedora
License:        MIT
URL:            https://example.invalid/nova
Source0:        %{name}-%{version}.tar.gz

BuildRequires:  gcc-c++ meson ninja-build cmake pkgconfig(wayland-server) pkgconfig(wayland-protocols)
BuildRequires:  pkgconfig(xkbcommon) pkgconfig(libinput) pkgconfig(pixman-1) pkgconfig(xcb) pkgconfig(xcb-icccm)
BuildRequires:  (pkgconfig(wlroots-0.19) or pkgconfig(wlroots-0.18))
BuildRequires:  pkgconfig(cairo) pkgconfig(pangocairo) pkgconfig(librsvg-2.0) pkgconfig(libsystemd) pam-devel json-devel
Requires:       xorg-x11-server-Xwayland xdg-desktop-portal-wlr xdg-desktop-portal-gtk
Requires:       grim slurp wl-clipboard cliphist brightnessctl playerctl wireplumber NetworkManager bluez upower
Requires:       swayidle wlr-randr libnotify papirus-icon-theme rsms-inter-fonts
Recommends:     gammastep wf-recorder pavucontrol jetbrains-mono-fonts-all mpv mpvpaper zenity ffmpeg

%description
Nova is a desktop environment built on a wlroots compositor written in C++,
a C++ shell and settings app drawn with Cairo and Pango.

%prep
%autosetup

%build
%global _vpath_srcdir compositor
%global _vpath_builddir build-compositor
%meson
%meson_build
%global _vpath_srcdir .
%global _vpath_builddir build-desktop
%meson
%meson_build

%install
%global _vpath_builddir build-compositor
%meson_install
%global _vpath_builddir build-desktop
%meson_install
install -Dm755 session/nova-session  %{buildroot}%{_bindir}/nova-session
install -Dm755 session/nova-power    %{buildroot}%{_bindir}/nova-power
install -Dm755 session/nova-polkit-agent %{buildroot}%{_bindir}/nova-polkit-agent
install -Dm755 session/nova-doctor   %{buildroot}%{_bindir}/nova-doctor
install -Dm755 session/nova-theme %{buildroot}%{_bindir}/nova-theme
install -Dm755 session/nova-gpu %{buildroot}%{_bindir}/nova-gpu
install -Dm755 session/nova-update %{buildroot}%{_bindir}/nova-update
install -Dm755 session/nova-uninstall %{buildroot}%{_bindir}/nova-uninstall
install -Dm755 session/nova-lyrics %{buildroot}%{_bindir}/nova-lyrics
install -Dm755 session/nova-record %{buildroot}%{_bindir}/nova-record
install -Dm644 session/nova-update.desktop %{buildroot}%{_datadir}/applications/nova-update.desktop
install -d %{buildroot}%{_datadir}/nova/qt6ct && cp assets/qt6ct/* %{buildroot}%{_datadir}/nova/qt6ct/
install -Dm644 VERSION %{buildroot}%{_datadir}/nova/VERSION
install -Dm644 session/nova.desktop  %{buildroot}%{_datadir}/wayland-sessions/nova.desktop
install -Dm644 session/nova-portals.conf %{buildroot}%{_datadir}/xdg-desktop-portal/nova-portals.conf
install -Dm644 shell/pam/nova-lock   %{buildroot}%{_sysconfdir}/pam.d/nova-lock

%files
%{_bindir}/nova
%{_bindir}/novactl
%{_bindir}/nova-settings
%{_bindir}/nova-session
%{_bindir}/nova-shell
%{_bindir}/nova-power
%{_bindir}/nova-polkit-agent
%{_bindir}/nova-doctor
%{_bindir}/nova-theme
%{_bindir}/nova-gpu
%{_bindir}/nova-update
%{_bindir}/nova-uninstall
%{_bindir}/nova-lyrics
%{_bindir}/nova-record
%{_datadir}/applications/nova-update.desktop
%{_datadir}/nova/
%{_datadir}/applications/nova-settings.desktop
%{_datadir}/wayland-sessions/nova.desktop
%{_datadir}/xdg-desktop-portal/nova-portals.conf
%config(noreplace) %{_sysconfdir}/pam.d/nova-lock

%changelog
* Tue Nov 10 2026 Nova <nova@localhost> - 0.0.1-1
- First build
