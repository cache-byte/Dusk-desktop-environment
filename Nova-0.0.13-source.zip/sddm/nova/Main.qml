// SDDM greeter matching the Nova lock screen:
// glance (sharp wallpaper, clock) -> any key/click -> blurred, avatar, password.
import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import SddmComponents 2.0

Rectangle {
    id: root
    width: 1920; height: 1080
    color: "black"
    readonly property color accent: config.accent || "#c8b64a"
    readonly property color accentBright: Qt.lighter(accent, 1.25)
    readonly property color onAccent: Qt.darker(accent, 4.2)
    property bool auth: false
    property int userIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    property int sessionIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
    property string error: ""

    TextConstants { id: tc }
    Connections {
        target: sddm
        function onLoginFailed() { root.error = "Wrong password"; pass.text = ""; shake.restart() }
        function onLoginSucceeded() { root.error = "" }
    }

    Image { id: bg; anchors.fill: parent; source: config.background || "background.jpg"; fillMode: Image.PreserveAspectCrop }
    MultiEffect {
        anchors.fill: parent; source: bg; blurEnabled: true; blurMax: 64
        blur: root.auth ? 1 : 0; brightness: root.auth ? -0.25 : 0
        Behavior on blur { NumberAnimation { duration: 260 } }
    }
    MouseArea { anchors.fill: parent; onClicked: { root.auth = true; pass.forceActiveFocus() } }
    Item { anchors.fill: parent; focus: !root.auth
        Keys.onPressed: e => { root.auth = true; pass.forceActiveFocus(); if (e.text) pass.text += e.text } }

    Timer { id: tick; interval: 1000; running: true; repeat: true; property date now: new Date(); onTriggered: now = new Date() }

    // glance
    ColumnLayout {
        visible: !root.auth
        anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.23; spacing: 10
        Text { Layout.alignment: Qt.AlignHCenter; text: Qt.formatTime(tick.now, "HH:mm"); color: "white"; font.pixelSize: 176; font.weight: Font.ExtraLight; font.family: "Inter" }
        Text { Layout.alignment: Qt.AlignHCenter; text: Qt.formatDate(tick.now, "dddd d MMMM"); color: root.accentBright; font.pixelSize: 28; font.weight: Font.Medium; font.family: "Inter" }
    }
    Text { visible: !root.auth; anchors { bottom: parent.bottom; bottomMargin: 44; horizontalCenter: parent.horizontalCenter }
           text: "Press any key or click to sign in"; color: Qt.rgba(1, 1, 1, 0.62); font.pixelSize: 14; font.family: "Inter" }

    // auth
    Text { visible: root.auth; anchors { top: parent.top; topMargin: 34; horizontalCenter: parent.horizontalCenter }
           text: Qt.formatTime(tick.now, "HH:mm") + " · " + Qt.formatDate(tick.now, "ddd d MMM"); color: Qt.rgba(1, 1, 1, 0.8); font.pixelSize: 16; font.family: "Inter" }
    ColumnLayout {
        visible: root.auth
        anchors.centerIn: parent; spacing: 18
        Rectangle {
            Layout.alignment: Qt.AlignHCenter; implicitWidth: 132; implicitHeight: 132; radius: 66; clip: true
            border.width: 4; border.color: Qt.rgba(1, 1, 1, 0.12)
            gradient: Gradient { GradientStop { position: 0; color: "#d9925a" } GradientStop { position: 1; color: "#7d3f6b" } }
            Text { anchors.centerIn: parent; text: (users.currentItem?.uname ?? "?").charAt(0).toUpperCase(); color: "white"; font.pixelSize: 52; font.weight: Font.DemiBold }
            Image { anchors.fill: parent; anchors.margins: 4; source: users.currentItem?.uicon ?? ""; fillMode: Image.PreserveAspectCrop }
        }
        // user name (click to switch user)
        ListView {
            id: users
            Layout.alignment: Qt.AlignHCenter; implicitWidth: 380; implicitHeight: 36
            model: userModel; currentIndex: root.userIndex; interactive: false; clip: true
            highlightRangeMode: ListView.StrictlyEnforceRange; orientation: ListView.Horizontal
            delegate: Text {
                required property string name; required property string realName; required property string icon
                property string uname: name; property string uicon: icon
                width: 380; height: 36; horizontalAlignment: Text.AlignHCenter
                text: realName || name; color: "white"; font.pixelSize: 26; font.weight: Font.DemiBold; font.family: "Inter"
            }
            MouseArea { anchors.fill: parent; onClicked: root.userIndex = (root.userIndex + 1) % userModel.count }
        }
        Rectangle {
            id: field
            Layout.alignment: Qt.AlignHCenter; implicitWidth: 380; implicitHeight: 54; radius: 27
            color: Qt.rgba(0.08, 0.075, 0.11, 0.7); border.color: Qt.rgba(1, 1, 1, 0.08)
            RowLayout {
                anchors.fill: parent; anchors.leftMargin: 22; anchors.rightMargin: 6; spacing: 10
                TextInput {
                    id: pass; Layout.fillWidth: true
                    echoMode: TextInput.Password; passwordCharacter: "•"
                    color: "#eceae4"; font.pixelSize: 22; font.letterSpacing: 4
                    Keys.onReturnPressed: sddm.login(users.currentItem.uname, text, root.sessionIndex)
                }
                Rectangle { implicitWidth: 42; implicitHeight: 42; radius: 21; color: root.accent
                    Text { anchors.centerIn: parent; text: "→"; color: root.onAccent; font.pixelSize: 20; font.weight: Font.Bold }
                    MouseArea { anchors.fill: parent; onClicked: sddm.login(users.currentItem.uname, pass.text, root.sessionIndex) } }
            }
            SequentialAnimation on anchors.horizontalCenterOffset { id: shake; running: false
                NumberAnimation { to: -12; duration: 50 } NumberAnimation { to: 12; duration: 80 } NumberAnimation { to: 0; duration: 50 } }
        }
        Text { Layout.alignment: Qt.AlignHCenter; text: root.error || (keyboard.capsLock ? "Caps Lock is on" : "")
               color: root.error ? "#ff8a7a" : root.accentBright; font.pixelSize: 12.5; font.family: "Inter" }
    }

    ListView { id: sessions; visible: false; model: sessionModel; currentIndex: root.sessionIndex
        delegate: Item { required property string name; property string sname: name } }

    // bottom: session + layout, power
    Row {
        anchors { bottom: parent.bottom; bottomMargin: 32; horizontalCenter: parent.horizontalCenter }
        spacing: 10; visible: root.auth
        Chip { text: sessions.currentItem?.sname ?? "Session"
               onClicked: root.sessionIndex = (root.sessionIndex + 1) % sessions.count }
        Chip { text: keyboard.layouts.length ? keyboard.layouts[keyboard.currentLayout].longName : "Keyboard"
               onClicked: if (keyboard.layouts.length) keyboard.currentLayout = (keyboard.currentLayout + 1) % keyboard.layouts.length }
    }
    Row {
        anchors { right: parent.right; bottom: parent.bottom; margins: 32 }
        spacing: 4
        Chip { text: "Suspend"; visible: sddm.canSuspend; onClicked: sddm.suspend() }
        Chip { text: "Restart"; visible: sddm.canReboot; onClicked: sddm.reboot() }
        Chip { text: "Shut down"; visible: sddm.canPowerOff; onClicked: sddm.powerOff() }
    }

    component Chip: Rectangle {
        property alias text: t.text
        signal clicked()
        height: 40; width: t.implicitWidth + 32; radius: 20
        color: ma.containsMouse ? Qt.rgba(0.14, 0.13, 0.18, 0.85) : Qt.rgba(0.08, 0.075, 0.11, 0.7)
        border.color: Qt.rgba(1, 1, 1, 0.08)
        Text { id: t; anchors.centerIn: parent; color: "#eceae4"; font.pixelSize: 13; font.family: "Inter" }
        MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; onClicked: parent.clicked() }
    }
}
