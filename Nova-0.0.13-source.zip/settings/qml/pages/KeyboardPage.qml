import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    spacing: 18
    Card {
        title: "Layout"; icon: "keyboard"; subtitle: "Comma-separate several layouts and switch with the options below (e.g. grp:alt_shift_toggle)"
        GridLayout { Layout.fillWidth: true; columns: 3; columnSpacing: 14
            Repeater { model: [["layout", "Layouts", "us"], ["variant", "Variants", ""], ["options", "Options", ""]]
                ColumnLayout { required property var modelData; Layout.fillWidth: true
                    Label2 { text: modelData[1] }
                    Rectangle { Layout.fillWidth: true; implicitHeight: 40; radius: 11; color: Theme.surface3; border.color: Theme.border
                        TextInput { anchors.fill: parent; anchors.leftMargin: 12; verticalAlignment: Text.AlignVCenter; color: Theme.text; font.pixelSize: 13.5
                            text: Backend.conf("input", parent.parent.modelData[0], parent.parent.modelData[2])
                            onEditingFinished: Backend.setConf("input", parent.parent.modelData[0], text) } } } } }
    }
    Card {
        title: "Typing"
        Row2 { confKey: ["input", "repeat_delay"]; label: "Repeat delay"
            PillSlider { id: delay; implicitWidth: 300; from: 150; to: 1000; value: parseInt(Backend.conf("input", "repeat_delay", "300")); format: v => Math.round(v) + " ms"
                onMoved: v => rd.restart() } }
        Row2 { confKey: ["input", "repeat_rate"]; label: "Repeat rate"
            PillSlider { id: rate; implicitWidth: 300; from: 10; to: 80; value: parseInt(Backend.conf("input", "repeat_rate", "30")); format: v => Math.round(v) + " /s"
                onMoved: v => rd.restart() } }
        Timer { id: rd; interval: 400; onTriggered: { Backend.setConf("input", "repeat_delay", Math.round(delay.value)); Backend.setConf("input", "repeat_rate", Math.round(rate.value)) } }
    }
    Card {
        title: "Shortcuts"; icon: "keyboard"
        subtitle: "Click a shortcut and press the new keys. A tap of Super on its own opens the launcher."
        ShortcutEditor { Layout.fillWidth: true }
    }
}
