import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Dialogs
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    readonly property var s: Backend.settings
    function set(k, v, desktop) { Backend.set(k, v); if (desktop) Backend.applyDesktopTheme() }
    spacing: 18

    property var library: Backend.wallpapers()
    FileDialog {
        id: browse
        nameFilters: ["Images and videos (*.png *.jpg *.jpeg *.webp *.mp4 *.webm *.mkv)"]
        onAccepted: page.pickWallpaper(selectedFile.toString().replace("file://", ""))
    }
    ColorDialog { id: picker; selectedColor: page.s.accent ?? "#c8b64a"; onAccepted: page.set("accent", selectedColor.toString(), false) }
    function pickWallpaper(p) {
        set("wallpaper", p, false);
        if (s.accentFromWallpaper && !/\.(mp4|webm|mkv|mov)$/i.test(p)) set("accent", Backend.accentFromImage(p), false);
    }

    GridLayout {
        Layout.fillWidth: true; columns: 2; columnSpacing: 18; rowSpacing: 18

        Card {
            title: "Wallpaper"
            Layout.preferredWidth: 5; Layout.alignment: Qt.AlignTop
            Rectangle {
                Layout.fillWidth: true; Layout.preferredHeight: width * 9 / 16; radius: 14; clip: true; color: "black"
                Image { anchors.fill: parent; fillMode: Image.PreserveAspectCrop; asynchronous: true
                        source: page.s.wallpaper && !/\.(mp4|webm|mkv|mov)$/i.test(page.s.wallpaper) ? "file://" + page.s.wallpaper : "file:///usr/share/nova/shell/assets/wallpapers/nova-" + (Theme.dark ? "dark" : "light") + ".jpg" }
                Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: parent.height * 0.07; color: Qt.rgba(0.06, 0.06, 0.09, 0.75) }
            }
            RowLayout {
                Layout.fillWidth: true; spacing: 8
                Dropdown { Layout.fillWidth: true; model: ["fill", "fit", "center"]; currentIndex: Math.max(0, model.indexOf(page.s.wallpaperFill ?? "fill")); onActivated: i => page.set("wallpaperFill", model[i], false)
                           displayText: currentText.charAt(0).toUpperCase() + currentText.slice(1) }
                Btn { icon: "image"; text: "Browse…"; onClicked: browse.open() }
            }
        }
        Card {
            title: "Library"; Layout.preferredWidth: 4; Layout.alignment: Qt.AlignTop
            headerExtra: [ Text { text: Backend.wallpaperDir().replace(/^\/home\/[^/]+/, "~"); color: Theme.text3; font.pixelSize: 12 } ]
            GridLayout {
                Layout.fillWidth: true; columns: 3; columnSpacing: 10; rowSpacing: 10
                Repeater {
                    model: page.library
                    Rectangle {
                        required property var modelData
                        readonly property bool on: page.s.wallpaper === modelData.path
                        Layout.fillWidth: true; Layout.preferredHeight: width * 10 / 16; radius: 12; clip: true; color: Theme.surface3
                        border.width: on ? 2.5 : 0; border.color: Theme.accent
                        Image { anchors.fill: parent; anchors.margins: parent.on ? 2.5 : 0; visible: !parent.modelData.video; source: "file://" + parent.modelData.path; sourceSize.width: 320; fillMode: Image.PreserveAspectCrop; asynchronous: true }
                        Rectangle { visible: parent.modelData.video; anchors.left: parent.left; anchors.bottom: parent.bottom; anchors.margins: 7; height: 20; width: vr.implicitWidth + 14; radius: 6; color: Qt.rgba(0, 0, 0, 0.55)
                            Row { id: vr; anchors.centerIn: parent; spacing: 4; Icon { name: "video"; size: 12; color: "white" } Text { text: "Video"; color: "white"; font.pixelSize: 10.5 } } }
                        Icon { visible: parent.modelData.video; anchors.centerIn: parent; name: "play"; size: 22; color: Theme.text2 }
                        MouseArea { anchors.fill: parent; onClicked: page.pickWallpaper(parent.modelData.path) }
                    }
                }
            }
            Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.text3; font.pixelSize: 12
                   text: page.library.length ? "Images and video wallpapers (.mp4, .webm) are picked up automatically." : "Put images or videos in this folder and they'll show up here." }
        }

        Card {
            title: "Mode"; Layout.preferredWidth: 5; Layout.alignment: Qt.AlignTop
            RowLayout {
                Layout.fillWidth: true; spacing: 12
                Repeater {
                    model: [["light", "Light"], ["dark", "Dark"], ["auto", "Auto"]]
                    Rectangle {
                        required property var modelData
                        readonly property bool on: (page.s.mode ?? "dark") === modelData[0]
                        Layout.fillWidth: true; implicitHeight: 112; radius: 14
                        color: on ? Theme.accentSoft : Theme.surface3; border.width: on ? 2 : 0; border.color: Theme.accent
                        ColumnLayout { anchors.fill: parent; anchors.margins: 8; spacing: 8
                            Rectangle { Layout.fillWidth: true; Layout.fillHeight: true; radius: 9; clip: true
                                color: parent.parent.modelData[0] === "light" ? "#f2efe8" : "#17161f"
                                Rectangle { visible: parent.parent.parent.modelData[0] === "auto"; width: parent.width / 2; height: parent.height; color: "#f2efe8" }
                                Rectangle { visible: parent.parent.parent.modelData[0] !== "auto"; x: parent.width * 0.12; y: parent.height * 0.18; width: parent.width * 0.56; height: parent.height * 0.56; radius: 6
                                    color: parent.parent.parent.modelData[0] === "light" ? "white" : "#24232e"
                                    Rectangle { x: 8; y: 8; width: parent.width * 0.4; height: 5; radius: 3; color: Theme.accent } } }
                            Text { Layout.alignment: Qt.AlignHCenter; text: parent.parent.modelData[1]; color: Theme.text; font.pixelSize: 13 } }
                        MouseArea { anchors.fill: parent; onClicked: page.set("mode", parent.modelData[0], true) }
                    }
                }
            }
            Text { text: "Accent"; color: Theme.text; font.pixelSize: 15; font.weight: Font.DemiBold; Layout.topMargin: 8 }
            RowLayout {
                spacing: 12
                Repeater {
                    model: ["#c8b64a", "#e0894a", "#e8604c", "#e26aa0", "#9a7bff", "#5b8cff", "#46c2ae", "#7fd18b"]
                    Rectangle {
                        required property string modelData
                        width: 30; height: 30; radius: 15; color: modelData
                        border.width: (page.s.accent ?? "#c8b64a").toLowerCase() === modelData ? 3 : 0; border.color: Theme.window
                        Rectangle { visible: parent.border.width > 0; anchors.centerIn: parent; width: 38; height: 38; radius: 19; color: "transparent"; border.width: 2; border.color: parent.modelData }
                        MouseArea { anchors.fill: parent; onClicked: page.set("accent", parent.modelData, false) }
                    }
                }
            }
            RowLayout {
                Layout.fillWidth: true; spacing: 10
                Rectangle { implicitWidth: 140; implicitHeight: 40; radius: 11; color: Theme.surface3; border.color: Theme.border
                    RowLayout { anchors.fill: parent; anchors.leftMargin: 12; spacing: 8
                        Rectangle { width: 14; height: 14; radius: 4; color: Theme.accent }
                        TextInput { Layout.fillWidth: true; text: (page.s.accent ?? "#c8b64a").toUpperCase(); color: Theme.text; font.family: Theme.mono; font.pixelSize: 13
                            validator: RegularExpressionValidator { regularExpression: /#[0-9a-fA-F]{6}/ }
                            onEditingFinished: page.set("accent", text.toLowerCase(), false) } } }
                Btn { icon: "pipette"; text: "Pick"; onClicked: picker.open() }
                Item { Layout.fillWidth: true }
                Text { text: "From wallpaper"; color: Theme.text; font.pixelSize: 13 }
                Toggle { checked: page.s.accentFromWallpaper ?? false
                    onToggled: v => { page.set("accentFromWallpaper", v, false); if (v && page.s.wallpaper) page.set("accent", Backend.accentFromImage(page.s.wallpaper), false) } }
            }
        }

        Card {
            title: "Blur & transparency"; Layout.preferredWidth: 4; Layout.alignment: Qt.AlignTop
            GridLayout {
                Layout.fillWidth: true; columns: 2; columnSpacing: 26; rowSpacing: 10
                Label2 { text: "Blur" } Label2 { text: "Transparency" }
                Repeater {
                    model: [["UI & popups", "Ui"], ["Panel", "Panel"], ["Settings & apps", "Apps"]]
                    delegate: Item { required property var modelData; Layout.columnSpan: 2; Layout.fillWidth: true; implicitHeight: g.implicitHeight
                        GridLayout { id: g; width: parent.width; columns: 2; columnSpacing: 26; rowSpacing: 6
                            Text { Layout.columnSpan: 2; text: modelData[0]; color: Theme.text; font.pixelSize: 13.5; font.weight: Font.Medium; Layout.topMargin: 6 }
                            PillSlider { Layout.fillWidth: true; value: page.s["blur" + modelData[1]] ?? 0.6; onMoved: v => page.set("blur" + modelData[1], v, false) }
                            PillSlider { Layout.fillWidth: true; value: page.s["transparency" + modelData[1]] ?? 0.25; onMoved: v => page.set("transparency" + modelData[1], v, false) } } }
                }
            }
            Text { text: "Set blur to 0 % on low-power GPUs."; color: Theme.text3; font.pixelSize: 12 }
        }
    }

    GridLayout {
        Layout.fillWidth: true; columns: 2; columnSpacing: 18; rowSpacing: 18
        Card {
            title: "Icons"; icon: "grid"; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
            RowLayout { Layout.fillWidth: true; spacing: 10
                Dropdown { Layout.fillWidth: true; model: Backend.iconThemes(); currentIndex: model.indexOf(page.s.iconTheme ?? "Papirus-Dark"); onActivated: i => page.set("iconTheme", model[i], true) }
                Stepper { value: page.s.iconSize ?? 24; step: 4; min: 16; max: 64; onChanged: v => page.set("iconSize", v, false) } }
        }
        Card {
            title: "Cursor"; icon: "cursor"; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
            RowLayout { Layout.fillWidth: true; spacing: 10
                Dropdown { Layout.fillWidth: true; model: Backend.cursorThemes(); currentIndex: model.indexOf(page.s.cursorTheme ?? "Bibata-Modern-Classic"); onActivated: i => page.set("cursorTheme", model[i], true) }
                Stepper { value: page.s.cursorSize ?? 24; step: 4; min: 16; max: 96; onChanged: v => page.set("cursorSize", v, true) } }
        }
        Card {
            title: "Fonts"; icon: "type"; Layout.columnSpan: 2
            GridLayout {
                Layout.fillWidth: true; columns: 2; columnSpacing: 20; rowSpacing: 12
                ColumnLayout { Label2 { text: "Interface" }
                    RowLayout { Layout.fillWidth: true; spacing: 10
                        Dropdown { Layout.fillWidth: true; model: Backend.fonts(false); currentIndex: model.indexOf(page.s.font ?? "Inter"); onActivated: i => page.set("font", model[i], true) }
                        Stepper { value: page.s.fontSize ?? 14; min: 9; max: 24; onChanged: v => page.set("fontSize", v, true) } } }
                ColumnLayout { Label2 { text: "Terminal & monospace" }
                    RowLayout { Layout.fillWidth: true; spacing: 10
                        Dropdown { Layout.fillWidth: true; model: Backend.fonts(true); currentIndex: model.indexOf(page.s.monoFont ?? "JetBrains Mono"); onActivated: i => page.set("monoFont", model[i], true) }
                        Stepper { value: page.s.monoSize ?? 14; min: 9; max: 24; onChanged: v => page.set("monoSize", v, false) } } }
                Rectangle { Layout.fillWidth: true; implicitHeight: 170; radius: 12; color: Qt.rgba(0, 0, 0, 0.18)
                    ColumnLayout { anchors.fill: parent; anchors.margins: 18; spacing: 6
                        Label2 { text: "Preview" }
                        Text { text: "The quick brown fox"; color: Theme.text; font.family: page.s.font ?? "Inter"; font.pixelSize: (page.s.fontSize ?? 14) * 1.85; font.weight: Font.DemiBold }
                        Text { Layout.fillWidth: true; wrapMode: Text.Wrap; text: "jumps over the lazy dog. 0123456789 — Settings, buttons and panels use this face."; color: Theme.text2; font.family: page.s.font ?? "Inter"; font.pixelSize: page.s.fontSize ?? 14 } } }
                Rectangle { Layout.fillWidth: true; implicitHeight: 170; radius: 12; color: Qt.rgba(0, 0, 0, 0.3)
                    ColumnLayout { anchors.fill: parent; anchors.margins: 18; spacing: 3
                        Label2 { text: "Preview" }
                        Repeater { model: ["<font color='" + Theme.accentBright + "'>user@fedora</font>:~$ ls -la", "drwxr-xr-x  user  4.0K  Projects", "-rw-r--r--  user  1.2K  nova.conf", "{ } [ ] ( ) => != 0O 1lI"]
                            Text { required property string modelData; text: modelData; textFormat: Text.StyledText; color: Theme.text2; font.family: page.s.monoFont ?? "JetBrains Mono"; font.pixelSize: page.s.monoSize ?? 14 } } } }
            }
        }
        Card {
            title: "Windows & motion"; icon: "square"; Layout.columnSpan: 2
            RowLayout { Layout.fillWidth: true; spacing: 28
                ColumnLayout { Label2 { text: "Corner radius" } Stepper { value: page.s.cornerRadius ?? 14; max: 32; step: 2; onChanged: v => page.set("cornerRadius", v, false) } }
                ColumnLayout { Layout.fillWidth: true; Label2 { text: "Animation speed" }
                    PillSlider { Layout.fillWidth: true; from: 0.25; to: 2; value: page.s.animationSpeed ?? 1; format: v => v.toFixed(2) + "×"; onMoved: v => page.set("animationSpeed", Math.round(v * 20) / 20, false) } }
                Row2 { Layout.preferredWidth: 300; label: "Soft window shadows"; Toggle { checked: page.s.windowShadows ?? true; onToggled: v => page.set("windowShadows", v, false) } }
            }
        }
    }
    Item { implicitHeight: 24 }
}
