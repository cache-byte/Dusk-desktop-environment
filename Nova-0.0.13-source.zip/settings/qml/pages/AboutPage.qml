import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    spacing: 18
    readonly property var info: Backend.systemInfo()
    Card {
        RowLayout { spacing: 18
            Rectangle { implicitWidth: 72; implicitHeight: 72; radius: 20; color: Theme.accentSoft
                Icon { anchors.centerIn: parent; name: "nova"; size: 40; color: Theme.accent } }
            ColumnLayout { spacing: 3
                Text { text: "Nova"; color: Theme.text; font.pixelSize: 26; font.weight: Font.DemiBold }
                Text { text: info.os; color: Theme.text2; font.pixelSize: 14 } } }
    }
    Card {
        title: "System"
        Repeater {
            model: [["Device name", info.host], ["Processor", (info.cpu ?? "") + " × " + info.cores], ["Memory", info.memory], ["Graphics", info.gpu], ["Kernel", info.kernel], ["Desktop", info.desktop]]
            RowLayout { required property var modelData; Layout.fillWidth: true
                Text { Layout.preferredWidth: 180; text: modelData[0]; color: Theme.text3; font.pixelSize: 13.5 }
                Text { Layout.fillWidth: true; text: modelData[1] ?? "—"; color: Theme.text; font.pixelSize: 13.5; elide: Text.ElideRight } }
        }
    }
    Card {
        title: "Credits"; icon: "nova"
        Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.text2; font.pixelSize: 13; lineHeight: 1.3
               text: "Nova " + Backend.installedVersion() + " — a Wayland desktop for Fedora, released into the public domain (Unlicense).\n" +
                     "Built on wlroots, Quickshell and Qt. Icons: Papirus. Cursor: Bibata. Fonts: Inter and JetBrains Mono. " +
                     "Lyrics from LRCLIB, song recognition by SongRec, visualizer by cava, recording by gpu-screen-recorder." }
    }
    Card {
        id: resetCard
        title: "Reset settings"; icon: "restart"
        subtitle: "Tick what to reset. Everything else stays as it is. A backup is saved first."
        property var picked: ({})
        readonly property var groups: Backend.resetGroups()
        readonly property int count: Object.keys(picked).filter(k => picked[k]).length
        function toggle(id) { const p = Object.assign({}, picked); p[id] = !p[id]; picked = p }
        function setAll(on) { const p = {}; for (const g of groups) p[g.id] = on; picked = p }
        GridLayout {
            Layout.fillWidth: true; columns: 2; columnSpacing: 12; rowSpacing: 8
            Repeater {
                model: resetCard.groups
                Rectangle {
                    required property var modelData
                    readonly property bool on: !!resetCard.picked[modelData.id]
                    Layout.fillWidth: true; implicitHeight: 54; radius: 12
                    color: on ? Theme.accentSoft : Theme.surface2; border.color: on ? Theme.accentLine : Theme.border
                    RowLayout { anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 12; spacing: 12
                        Rectangle { implicitWidth: 20; implicitHeight: 20; radius: 6
                            color: parent.parent.on ? Theme.accent : "transparent"; border.width: parent.parent.on ? 0 : 2; border.color: Theme.text3
                            Icon { visible: parent.parent.parent.on; anchors.centerIn: parent; name: "check"; size: 14; color: Theme.onAccent } }
                        ColumnLayout { Layout.fillWidth: true; spacing: 1
                            Text { text: modelData.label; color: Theme.text; font.pixelSize: 13.5; elide: Text.ElideRight; Layout.fillWidth: true }
                            Text { text: modelData.hint; color: Theme.text3; font.pixelSize: 11.5; elide: Text.ElideRight; Layout.fillWidth: true } } }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: resetCard.toggle(modelData.id) }
                }
            }
        }
        RowLayout { Layout.fillWidth: true; spacing: 10
            Btn { text: "Select all"; onClicked: resetCard.setAll(true) }
            Btn { text: "Select none"; onClicked: resetCard.setAll(false) }
            Item { Layout.fillWidth: true }
            Text { id: done; color: Theme.text3; font.pixelSize: 12.5 }
            Btn { accent: true; icon: "restart"; enabled: resetCard.count > 0; opacity: enabled ? 1 : 0.4
                  text: resetCard.count > 0 ? "Reset " + resetCard.count + (resetCard.count === 1 ? " item" : " items") : "Reset"
                  onClicked: { const dir = Backend.resetSelected(Object.keys(resetCard.picked).filter(k => resetCard.picked[k]));
                               done.text = "Done · backup in " + dir.replace(/^.*\/backup\//, "backup/"); resetCard.setAll(false) } }
        }
        RowLayout {
            visible: Backend.resetBackups().length > 0
            Layout.fillWidth: true; spacing: 10
            Text { Layout.fillWidth: true; color: Theme.text3; font.pixelSize: 12.5; elide: Text.ElideRight
                   text: "Undo the last reset (" + (Backend.resetBackups()[0] ?? "").replace(/^.*reset-/, "").replace("_", " ") + ")" }
            Btn { text: "Restore backup"; onClicked: Backend.restoreBackup(Backend.resetBackups()[0]) }
        }
    }
}
