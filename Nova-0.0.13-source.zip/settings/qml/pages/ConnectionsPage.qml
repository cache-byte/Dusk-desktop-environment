import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: page
    spacing: 18
    property var nets: Backend.wifiNetworks(false)
    property bool wifiOn: Backend.wifiEnabled()
    property var bt: Backend.bluetoothDevices()
    property bool btOn: Backend.bluetoothPowered()
    property var vpns: Backend.vpnConnections()
    property var wired: Backend.wiredStatus()
    property string asking: ""          // SSID waiting for a password
    property string error: ""
    function refresh(rescan) { nets = Backend.wifiNetworks(rescan); wifiOn = Backend.wifiEnabled(); bt = Backend.bluetoothDevices(); btOn = Backend.bluetoothPowered(); vpns = Backend.vpnConnections(); wired = Backend.wiredStatus() }
    Timer { interval: 10000; running: true; repeat: true; onTriggered: page.refresh(false) }

    GridLayout {
        Layout.fillWidth: true; columns: 2; columnSpacing: 18; rowSpacing: 18

        Card {
            title: "Wi-Fi"; icon: "wifi"; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
            subtitle: { const a = page.nets.find(n => n.active); return !page.wifiOn ? "Off" : a ? "Connected to " + a.ssid : "Not connected" }
            headerExtra: [ Toggle { checked: page.wifiOn; onToggled: v => { Backend.run(["nmcli", "radio", "wifi", v ? "on" : "off"]); page.refresh(false) } } ]
            Repeater {
                model: page.wifiOn ? page.nets : []
                ColumnLayout {
                    required property var modelData
                    Layout.fillWidth: true; spacing: 6
                    Rectangle {
                        Layout.fillWidth: true; implicitHeight: 50; radius: 12
                        color: modelData.active ? Theme.accentSoft : nm.containsMouse ? Theme.surface2 : "transparent"
                        RowLayout { anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 12; spacing: 14
                            Icon { name: "wifi"; opacity: 0.35 + parent.parent.parent.modelData.signal / 150; color: parent.parent.parent.modelData.active ? Theme.accentBright : Theme.text }
                            Text { Layout.fillWidth: true; text: parent.parent.parent.modelData.ssid; elide: Text.ElideRight; color: Theme.text; font.pixelSize: 14; font.weight: parent.parent.parent.modelData.active ? Font.DemiBold : Font.Normal }
                            Text { visible: parent.parent.parent.modelData.active; text: "Connected"; color: Theme.accentBright; font.pixelSize: 12.5 }
                            Text { visible: !parent.parent.parent.modelData.secure; text: "Open"; color: Theme.text3; font.pixelSize: 12.5 }
                            Icon { visible: parent.parent.parent.modelData.secure; name: "lock"; size: 15; color: Theme.text3 } }
                        MouseArea { id: nm; anchors.fill: parent; hoverEnabled: true
                            onClicked: {
                                const n = parent.parent.modelData;
                                if (n.active) { Backend.run(["nmcli", "con", "down", "id", n.ssid]); page.refresh(false); return }
                                const err = Backend.wifiConnect(n.ssid, "");
                                if (err && n.secure) page.asking = n.ssid; else page.error = err;
                                page.refresh(false);
                            } }
                    }
                    RowLayout {
                        visible: page.asking === modelData.ssid
                        Layout.fillWidth: true; spacing: 8
                        Rectangle { Layout.fillWidth: true; implicitHeight: 38; radius: 10; color: Theme.surface3; border.color: Theme.accentLine
                            TextInput { id: pw; anchors.fill: parent; anchors.leftMargin: 12; verticalAlignment: Text.AlignVCenter; echoMode: TextInput.Password; color: Theme.text; font.pixelSize: 13
                                Keys.onReturnPressed: go.clicked() } }
                        Btn { id: go; text: "Connect"; accent: true
                            onClicked: { page.error = Backend.wifiConnect(page.asking, pw.text); if (!page.error) page.asking = ""; pw.text = ""; page.refresh(false) } }
                    }
                }
            }
            Text { visible: page.error !== ""; text: page.error; color: "#ff8a7a"; font.pixelSize: 12; wrapMode: Text.Wrap; Layout.fillWidth: true }
            RowLayout { spacing: 8
                Btn { icon: "plus"; text: "Hidden network"; onClicked: Backend.runDetached(["nm-connection-editor"]) }
                Btn { icon: "restart"; text: "Rescan"; onClicked: page.refresh(true) } }
        }

        Card {
            title: "Bluetooth"; icon: "bt"; Layout.preferredWidth: 1; Layout.alignment: Qt.AlignTop
            subtitle: page.btOn ? "Visible as “" + Backend.systemInfo().host + "”" : "Off"
            headerExtra: [ Toggle { checked: page.btOn; onToggled: v => { Backend.run(["bluetoothctl", "power", v ? "on" : "off"]); page.refresh(false) } } ]
            Label2 { visible: page.btOn; text: "My devices" }
            Repeater {
                model: page.btOn ? page.bt.filter(d => d.paired) : []
                DeviceRow { required property var modelData; dev: modelData }
            }
            Label2 { visible: page.btOn; text: "Nearby" }
            Repeater {
                model: page.btOn ? page.bt.filter(d => !d.paired) : []
                DeviceRow { required property var modelData; dev: modelData }
            }
            Btn { visible: page.btOn; icon: "search"; text: "Scan for devices"; onClicked: { Backend.runDetached(["bluetoothctl", "--timeout", "10", "scan", "on"]); scanT.start() } }
            Timer { id: scanT; interval: 6000; onTriggered: page.refresh(false) }
        }

        Card {
            title: "Wired"; icon: "net"; Layout.preferredWidth: 1
            subtitle: page.wired.device === "" ? "No ethernet adapter" : page.wired.connected ? "Connected · " + page.wired.connection : "Cable unplugged"
            headerExtra: [ Toggle { enabled: page.wired.device !== ""; checked: page.wired.connected
                onToggled: v => { Backend.run(["nmcli", "dev", v ? "connect" : "disconnect", page.wired.device]); page.refresh(false) } } ]
        }
        Card {
            title: "VPN"; icon: "shield"; Layout.preferredWidth: 1
            subtitle: page.vpns.length ? page.vpns.filter(v => v.active).length + " of " + page.vpns.length + " active" : "No VPN connections"
            headerExtra: [ Btn { icon: "plus"; text: "Add"; onClicked: Backend.runDetached(["nm-connection-editor"]) } ]
            Repeater {
                model: page.vpns
                Row2 { required property var modelData; label: modelData.name; hint: modelData.type === "wireguard" ? "WireGuard" : "VPN"
                    Toggle { checked: parent.modelData.active; onToggled: v => { Backend.run(["nmcli", "con", v ? "up" : "down", "id", parent.modelData.name], 15000); page.refresh(false) } } }
            }
        }
        Card {
            Layout.columnSpan: 2
            RowLayout { Layout.fillWidth: true; spacing: 16
                Row2 { label: "Hotspot"; hint: "Share this connection over Wi-Fi"
                    Toggle { onToggled: v => Backend.runDetached(v ? ["nmcli", "dev", "wifi", "hotspot"] : ["nmcli", "con", "down", "Hotspot"]) } }
                Rectangle { width: 1; implicitHeight: 36; color: Theme.border }
                Row2 { label: "Airplane mode"; hint: "Turns off Wi-Fi and Bluetooth"
                    Toggle { checked: !page.wifiOn && !page.btOn
                        onToggled: v => { Backend.run(["nmcli", "radio", "all", v ? "off" : "on"]); Backend.run(["bluetoothctl", "power", v ? "off" : "on"]); page.refresh(false) } } }
            }
        }
    }

    component DeviceRow: Rectangle {
        property var dev
        Layout.fillWidth: true; implicitHeight: 52; radius: 12
        color: dev.connected ? Theme.accentSoft : "transparent"
        RowLayout { anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 12; spacing: 14
            Icon { name: /audio|head/.test(dev.icon) ? "headphones" : /mouse|input/.test(dev.icon) ? "mouse" : /phone/.test(dev.icon) ? "phone" : "bt"; color: dev.connected ? Theme.accentBright : Theme.text }
            ColumnLayout { Layout.fillWidth: true; spacing: 1
                Text { text: dev.name; color: Theme.text; font.pixelSize: 14; font.weight: dev.connected ? Font.DemiBold : Font.Normal; elide: Text.ElideRight; Layout.fillWidth: true }
                Text { text: dev.connected ? "Connected" : dev.paired ? "Not connected" : "Available"; color: Theme.text3; font.pixelSize: 12 } }
            Text { visible: dev.battery >= 0; text: dev.battery + "%"; color: Theme.text3; font.pixelSize: 12.5 }
            Btn { text: dev.connected ? "Disconnect" : dev.paired ? "Connect" : "Pair"; implicitHeight: 30
                onClicked: { Backend.run(dev.paired ? ["bluetoothctl", dev.connected ? "disconnect" : "connect", dev.mac] : ["sh", "-c", "bluetoothctl pair \"$1\" && bluetoothctl trust \"$1\" && bluetoothctl connect \"$1\"", "sh", dev.mac], 20000); page.refresh(false) } }
        }
    }
}
