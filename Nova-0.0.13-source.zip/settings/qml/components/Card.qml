import QtQuick
import Nova.Settings
import QtQuick.Layouts

Rectangle {
    id: root
    property string title
    property string subtitle
    property string icon
    default property alias content: body.data
    property alias headerExtra: extra.data
    Layout.fillWidth: true
    implicitHeight: col.implicitHeight + 36
    radius: 18
    color: Theme.surface2
    border.color: Theme.border
    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 18; leftMargin: 20; rightMargin: 20 }
        spacing: 14
        RowLayout {
            visible: root.title !== ""
            Layout.fillWidth: true
            spacing: 10
            Icon { visible: root.icon !== ""; name: root.icon }
            ColumnLayout { spacing: 3; Layout.fillWidth: true
                Text { text: root.title; color: Theme.text; font.family: Theme.font; font.pixelSize: 15; font.weight: Font.DemiBold }
                Text { visible: root.subtitle !== ""; text: root.subtitle; color: Theme.text3; font.pixelSize: 12.5 } }
            RowLayout { id: extra; spacing: 10 }
        }
        ColumnLayout { id: body; Layout.fillWidth: true; spacing: 12 }
    }
}
