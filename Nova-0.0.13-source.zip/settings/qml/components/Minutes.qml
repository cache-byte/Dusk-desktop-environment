// − 5 min + stepper for idle times; 0 shows "Off".
import QtQuick
import Nova.Settings
import QtQuick.Layouts

Rectangle {
    id: root
    property string key
    readonly property int value: Backend.settings[key] ?? Backend.defaultValue(key) ?? 0
    readonly property var steps: [0, 1, 2, 3, 5, 6, 10, 15, 20, 30, 45, 60, 90, 120]
    function move(d) {
        let i = steps.indexOf(value); if (i < 0) i = steps.findIndex(s => s > value) - (d > 0 ? 1 : 0);
        Backend.set(key, steps[Math.max(0, Math.min(steps.length - 1, i + d))]);
    }
    implicitHeight: 36; implicitWidth: 150; radius: 11; color: Theme.surface3; border.color: Theme.border; clip: true
    RowLayout { anchors.fill: parent; spacing: 0
        Rectangle { implicitWidth: 34; Layout.fillHeight: true; color: Qt.rgba(1, 1, 1, 0.04)
            Icon { anchors.centerIn: parent; name: "minus"; size: 15; color: Theme.text2 }
            MouseArea { anchors.fill: parent; onClicked: root.move(-1) } }
        Text { Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; text: root.value === 0 ? "Off" : root.value + " min"
               color: root.value === 0 ? Theme.text3 : Theme.text; font.pixelSize: 13.5 }
        Rectangle { implicitWidth: 34; Layout.fillHeight: true; color: Qt.rgba(1, 1, 1, 0.04)
            Icon { anchors.centerIn: parent; name: "plus"; size: 15; color: Theme.text2 }
            MouseArea { anchors.fill: parent; onClicked: root.move(1) } }
    }
}
