// Segmented choice bound to a settings.json key: Segmented { key: "vizColour"; values: [...]; labels: [...] }
import QtQuick
import Nova.Settings

Rectangle {
    id: root
    property string key
    property var values: []
    property var labels: values
    readonly property var cur: Backend.settings[key] ?? Backend.defaultValue(key)
    signal picked(var value)
    implicitHeight: 34; implicitWidth: segRow.implicitWidth + 6; radius: 11; color: Theme.surface2
    Row {
        id: segRow; anchors.centerIn: parent; spacing: 2
        Repeater {
            model: root.values.length
            Rectangle {
                required property int index
                readonly property bool on: JSON.stringify(root.cur) === JSON.stringify(root.values[index])
                height: 28; width: t.implicitWidth + 24; radius: 8
                color: on ? Theme.surface3 : "transparent"
                Text { id: t; anchors.centerIn: parent; text: root.labels[parent.index]; font.pixelSize: 12.5
                       color: parent.on ? Theme.text : Theme.text2; font.weight: parent.on ? Font.DemiBold : Font.Normal }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                    onClicked: { if (root.key) Backend.set(root.key, root.values[parent.index]); root.picked(root.values[parent.index]) } }
            }
        }
    }
}
