// Every key binding in nova.conf: click a shortcut to change it (press the new keys),
// ↺ puts back Nova's default, × removes it, "Add shortcut" makes a new one.
import QtQuick
import QtQuick.Layouts
import Nova.Settings

ColumnLayout {
    id: ed
    spacing: 10
    property var list: { Backend.settings; return Backend.bindings() }
    readonly property var defaults: Backend.defaultBindings()
    property string filter: ""
    property string recording: ""        // combo being changed ("" = none, "+new" = adding)
    property string error: ""
    property string newAction: "exec "

    readonly property var names: ({
        "shell launcher": "Open the launcher", "shell overview": "Overview", "shell controlcentre": "Control centre",
        "shell notifications": "Notifications", "shell clipboard": "Clipboard history", "lock": "Lock the screen",
        "shell capture": "Screenshot / record bar", "shell save-replay": "Save instant replay", "shell gameoverlay": "Game overlay",
        "close": "Close window", "fullscreen": "Fullscreen", "maximize": "Maximise", "restore": "Restore / minimise",
        "tile-left": "Snap left", "tile-right": "Snap right", "minimize": "Minimise", "cycle": "Next window",
        "cycle-reverse": "Previous window", "workspace next": "Next workspace", "workspace prev": "Previous workspace",
        "move-to-output next": "Move window to other monitor", "exec $terminal": "Terminal", "exec nautilus": "Files",
        "reload": "Reload Nova settings"
    })
    function label(a) {
        if (names[a]) return names[a];
        let m = a.match(/^workspace (\d)$/); if (m) return "Workspace " + m[1];
        m = a.match(/^move-to-workspace (\d)$/); if (m) return "Move window to workspace " + m[1];
        if (a.startsWith("exec nova-record shot")) return "Screenshot (" + a.split(" ").slice(3).join(" ") + ")";
        if (a.startsWith("exec nova-record toggle")) return "Start / stop recording";
        if (a.startsWith("exec ")) return "Run: " + a.slice(5);
        return a;
    }
    function defaultFor(action) { return defaults.filter(d => d.action === action).map(d => d.combo) }

    // Qt key event -> nova.conf key name
    function keyName(e) {
        const k = e.key;
        if (k >= Qt.Key_A && k <= Qt.Key_Z) return String.fromCharCode(k);
        if (k >= Qt.Key_0 && k <= Qt.Key_9) return String.fromCharCode(k);
        if (k >= Qt.Key_F1 && k <= Qt.Key_F24) return "F" + (k - Qt.Key_F1 + 1);
        const map = {
            [Qt.Key_Return]: "Return", [Qt.Key_Enter]: "Return", [Qt.Key_Space]: "Space", [Qt.Key_Tab]: "Tab", [Qt.Key_Backtab]: "Tab",
            [Qt.Key_Left]: "Left", [Qt.Key_Right]: "Right", [Qt.Key_Up]: "Up", [Qt.Key_Down]: "Down",
            [Qt.Key_Print]: "Print", [Qt.Key_Delete]: "Delete", [Qt.Key_Home]: "Home", [Qt.Key_End]: "End",
            [Qt.Key_PageUp]: "Prior", [Qt.Key_PageDown]: "Next", [Qt.Key_Insert]: "Insert", [Qt.Key_Backspace]: "BackSpace",
            [Qt.Key_Minus]: "minus", [Qt.Key_Equal]: "equal", [Qt.Key_Comma]: "comma", [Qt.Key_Period]: "period", [Qt.Key_Slash]: "slash",
            [Qt.Key_Semicolon]: "semicolon", [Qt.Key_Apostrophe]: "apostrophe", [Qt.Key_BracketLeft]: "bracketleft",
            [Qt.Key_BracketRight]: "bracketright", [Qt.Key_Backslash]: "backslash", [Qt.Key_QuoteLeft]: "grave",
            [Qt.Key_VolumeUp]: "XF86AudioRaiseVolume", [Qt.Key_VolumeDown]: "XF86AudioLowerVolume", [Qt.Key_VolumeMute]: "XF86AudioMute",
            [Qt.Key_MediaPlay]: "XF86AudioPlay", [Qt.Key_MediaTogglePlayPause]: "XF86AudioPlay", [Qt.Key_MediaNext]: "XF86AudioNext",
            [Qt.Key_MediaPrevious]: "XF86AudioPrev", [Qt.Key_MonBrightnessUp]: "XF86MonBrightnessUp", [Qt.Key_MonBrightnessDown]: "XF86MonBrightnessDown"
        };
        return map[k] ?? "";
    }
    function comboFrom(e) {
        const mods = [];
        if (e.modifiers & Qt.MetaModifier) mods.push("Super");
        if (e.modifiers & Qt.ControlModifier) mods.push("Ctrl");
        if (e.modifiers & Qt.AltModifier) mods.push("Alt");
        if (e.modifiers & Qt.ShiftModifier) mods.push("Shift");
        const k = keyName(e);
        return k ? mods.concat([k]).join("+") : "";
    }

    // key catcher while recording
    Item {
        id: catcher
        focus: ed.recording !== ""
        Keys.onPressed: e => {
            e.accepted = true;
            if (e.key === Qt.Key_Escape) { ed.recording = ""; ed.error = ""; return }
            if (e.key === Qt.Key_Meta || e.key === Qt.Key_Super_L || e.key === Qt.Key_Super_R || e.key === Qt.Key_Control
                || e.key === Qt.Key_Alt || e.key === Qt.Key_Shift) return;   // wait for the real key
            const c = ed.comboFrom(e);
            if (!c) { ed.error = "That key can't be used"; return }
            const old = ed.recording === "+new" ? "" : ed.recording;
            const act = ed.recording === "+new" ? ed.newAction : (ed.list.find(b => b.combo === old)?.action ?? "");
            ed.error = Backend.setBinding(old, c, act);
            if (!ed.error) ed.recording = "";
        }
    }

    RowLayout {
        Layout.fillWidth: true; spacing: 10
        Rectangle {
            Layout.fillWidth: true; implicitHeight: 38; radius: 11; color: Theme.surface3; border.color: Theme.border
            RowLayout { anchors.fill: parent; anchors.leftMargin: 12; spacing: 8
                Icon { name: "search"; size: 15; color: Theme.text3 }
                TextInput { id: q; Layout.fillWidth: true; color: Theme.text; font.pixelSize: 13; onTextChanged: ed.filter = text.toLowerCase()
                    Text { visible: !q.text; text: "Search shortcuts"; color: Theme.text3; font: q.font } } }
        }
        Btn { icon: "plus"; text: "Add shortcut"; onClicked: { adding.visible = !adding.visible; ed.error = "" } }
    }
    Text { visible: ed.error !== ""; text: ed.error; color: Theme.danger; font.pixelSize: 12.5 }
    Text { visible: ed.recording !== ""; text: "Press the new keys…  (Esc cancels)"; color: Theme.accentBright; font.pixelSize: 12.5 }

    // new shortcut
    Rectangle {
        id: adding
        visible: false
        Layout.fillWidth: true; implicitHeight: ar.implicitHeight + 24; radius: 14; color: Theme.accentSoft; border.color: Theme.accentLine
        RowLayout { id: ar; anchors.fill: parent; anchors.margins: 12; spacing: 10
            Dropdown {
                id: pick
                Layout.preferredWidth: 230
                model: ["Run a command", "Open the launcher", "Overview", "Lock the screen", "Screenshot / record bar", "Game overlay", "Close window", "Fullscreen"]
                onActivated: i => {
                    const acts = ["exec ", "shell launcher", "shell overview", "lock", "shell capture", "shell gameoverlay", "close", "fullscreen"];
                    cmd.text = ""; ed.newAction = acts[i];
                }
            }
            Rectangle { Layout.fillWidth: true; implicitHeight: 40; radius: 11; color: Theme.surface3; border.color: Theme.border
                visible: pick.currentIndex === 0
                TextInput { id: cmd; anchors.fill: parent; anchors.leftMargin: 12; verticalAlignment: Text.AlignVCenter; color: Theme.text; font.pixelSize: 13
                    onTextChanged: if (pick.currentIndex === 0) ed.newAction = "exec " + text
                    Text { visible: !cmd.text; anchors.verticalCenter: parent.verticalCenter; text: "Command, e.g. firefox"; color: Theme.text3; font: cmd.font } } }
            Btn { accent: true; text: ed.recording === "+new" ? "Press keys…" : "Set keys"; onClicked: { ed.error = ""; ed.recording = "+new"; catcher.forceActiveFocus() } }
        }
    }

    Repeater {
        model: ed.list.filter(b => !ed.filter || ed.label(b.action).toLowerCase().includes(ed.filter) || b.combo.toLowerCase().includes(ed.filter))
        RowLayout {
            required property var modelData
            Layout.fillWidth: true; spacing: 10
            Text { Layout.fillWidth: true; text: ed.label(modelData.action); color: Theme.text; font.pixelSize: 13.5; elide: Text.ElideRight }
            Rectangle {
                readonly property bool rec: ed.recording === parent.modelData.combo
                implicitHeight: 32; implicitWidth: Math.max(110, kc.implicitWidth + 24); radius: 9
                color: rec ? Theme.accent : kma.containsMouse ? Theme.surface3 : Theme.surface2; border.color: Theme.border
                Text { id: kc; anchors.centerIn: parent; text: parent.rec ? "Press keys…" : parent.parent.modelData.combo.replace(/\+/g, " + ")
                       color: parent.rec ? Theme.onAccent : Theme.text; font.pixelSize: 12.5; font.weight: Font.DemiBold; font.family: Theme.mono }
                MouseArea { id: kma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: { ed.error = ""; ed.recording = parent.parent.modelData.combo; catcher.forceActiveFocus() } }
            }
            ResetButton {
                readonly property var defs: ed.defaultFor(parent.modelData.action)
                active: !parent.modelData.isDefault && defs.length > 0 && !defs.includes(parent.modelData.combo)
                tip: "Back to " + (defs[0] ?? "")
                onClicked: ed.error = Backend.setBinding(parent.modelData.combo, defs[0], parent.modelData.action)
            }
            ResetButton {
                iconName: "x"; tip: "Remove"
                onClicked: Backend.removeBinding(parent.modelData.combo)
            }
        }
    }
}
