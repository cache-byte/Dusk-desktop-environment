import QtQuick
import Nova.Settings
import QtQuick.Layouts

Rectangle {
    id: root
    property int value
    property int step: 1
    property int min: 0
    property int max: 999
    property string suffix: " px"
    signal changed(int value)
    implicitHeight: 40; implicitWidth: row.implicitWidth
    radius: 11; color: Theme.surface3; border.color: Theme.border; clip: true
    RowLayout {
        id: row; anchors.fill: parent; spacing: 0
        Rectangle { implicitWidth: 34; Layout.fillHeight: true; color: Qt.rgba(1, 1, 1, 0.04)
            Icon { anchors.centerIn: parent; name: "minus"; size: 15; color: Theme.text2 }
            MouseArea { anchors.fill: parent; onClicked: { root.value = Math.max(root.min, root.value - root.step); root.changed(root.value) } } }
        Text { Layout.preferredWidth: 70; horizontalAlignment: Text.AlignHCenter; text: root.value + root.suffix; color: Theme.text; font.pixelSize: 13.5 }
        Rectangle { implicitWidth: 34; Layout.fillHeight: true; color: Qt.rgba(1, 1, 1, 0.04)
            Icon { anchors.centerIn: parent; name: "plus"; size: 15; color: Theme.text2 }
            MouseArea { anchors.fill: parent; onClicked: { root.value = Math.min(root.max, root.value + root.step); root.changed(root.value) } } }
    }
}
