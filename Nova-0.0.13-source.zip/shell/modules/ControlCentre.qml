// Control centre. Tiles live on a 4-column grid stored in settings.json
// (ccLayout). Pencil -> edit mode: drag to move (snaps to cells), drag the
// corner to resize, red badge removes, chips at the bottom add tiles.
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Bluetooth
import Quickshell.Io
import Quickshell.Services.UPower
import qs.services
import qs.components

Glass {
    id: root
    width: 400
    height: col.implicitHeight + 36
    padding: 18
    MouseArea { anchors.fill: parent; z: -1 }

    readonly property bool editing: Shell.ccEditing
    readonly property int cols: 6
    readonly property real gapPx: 10
    readonly property real cellW: (width - 36 - gapPx * (cols - 1)) / cols
    readonly property real cellH: 52
    property var layout: JSON.parse(JSON.stringify(Config.s.ccLayout))
    Connections { target: Config.s; function onCcLayoutChanged() { if (!root.editing) root.layout = JSON.parse(JSON.stringify(Config.s.ccLayout)) } }

    // id -> [icon, label, minW, minH, maxW, maxH]
    // id -> [icon, label, minW, minH, maxW, maxH]   (6-column grid)
    readonly property var catalog: ({
        wifi: ["wifi", "Wi-Fi", 2, 1, 6, 1], bluetooth: ["bt", "Bluetooth", 2, 1, 6, 1],
        brightness: ["sun", "Brightness", 1, 2, 6, 5], volume: ["volume", "Volume", 1, 2, 6, 5], micvol: ["mic", "Microphone", 1, 2, 6, 5],
        dnd: ["moon", "Do not disturb", 1, 1, 3, 1], nightlight: ["sunset", "Night light", 1, 1, 3, 1], airplane: ["plane", "Airplane", 1, 1, 3, 1],
        darkmode: ["contrast", "Dark mode", 1, 1, 3, 1], mic: ["mic", "Mic mute", 1, 1, 3, 1], screenshot: ["shot", "Screenshot", 1, 1, 3, 1],
        caffeine: ["coffee", "Keep awake", 1, 1, 3, 1], record: ["record", "Screen record", 1, 1, 3, 1], hotspot: ["hotspot", "Hotspot", 1, 1, 3, 1],
        kbl: ["kbl", "Keyboard light", 1, 1, 3, 1], power: ["gauge", "Power mode", 4, 1, 6, 1]
    })
    // 6 × 10 grid. Only the rows in use are shown; while editing, one empty row below them
    // is shown too, so there's somewhere to drag tiles (never more than 10 rows).
    readonly property int maxRows: 10
    readonly property int rows: Math.min(maxRows, Math.max(1, ...layout.map(t => t.y + t.h)) + (editing ? 1 : 0))

    function save() { Config.s.ccLayout = JSON.parse(JSON.stringify(layout)) }
    function overlaps(a, skip) {
        if (a.x < 0 || a.y < 0 || a.x + a.w > cols || a.y + a.h > maxRows) return true;
        return layout.some((b, i) => i !== skip && a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h);
    }
    function firstFree(w, h) {
        for (let y = 0; y <= maxRows - h; y++) for (let x = 0; x <= cols - w; x++)
            if (!overlaps({ x, y, w, h }, -1)) return { x, y };
        return null;   // grid is full
    }

    // ---- tile state & actions ----
    property bool nightOn: false
    property bool caffeineOn: false
    property bool recordOn: false
    property int kblLevel: 0
    function run(c) { Quickshell.execDetached(["sh", "-c", c]) }
    function isOn(id) {
        switch (id) {
        case "wifi": return Net.wifiEnabled;
        case "bluetooth": return Bluetooth.defaultAdapter?.enabled ?? false;
        case "dnd": return Config.s.dnd;
        case "nightlight": return nightOn;
        case "airplane": return !Net.wifiEnabled && !(Bluetooth.defaultAdapter?.enabled ?? false);
        case "darkmode": return Config.s.mode !== "light";
        case "mic": return !Audio.micMuted;
        case "caffeine": return caffeineOn;
        case "record": return recordOn;
        case "kbl": return kblLevel > 0;
        }
        return false;
    }
    function sub(id) {
        if (id === "wifi") return Net.wired ? "Wired" : Net.ssid || (Net.wifiEnabled ? "Not connected" : "Off");
        if (id === "bluetooth") {
            const n = (Bluetooth.devices?.values ?? []).filter(d => d.connected).length;
            return !(Bluetooth.defaultAdapter?.enabled) ? "Off" : n ? n + " connected" : "On";
        }
        return "";
    }
    function press(id) {
        switch (id) {
        case "wifi": Net.setWifi(!Net.wifiEnabled); break;
        case "bluetooth": if (Bluetooth.defaultAdapter) Bluetooth.defaultAdapter.enabled = !Bluetooth.defaultAdapter.enabled; break;
        case "dnd": Config.s.dnd = !Config.s.dnd; break;
        case "nightlight": nightOn = !nightOn; run(nightOn ? "pkill gammastep; gammastep -O 4200 >/dev/null 2>&1 &" : "pkill gammastep"); break;
        case "airplane": { const on = !isOn("airplane"); Net.setAirplane(on); if (Bluetooth.defaultAdapter) Bluetooth.defaultAdapter.enabled = !on; break }
        case "darkmode": Config.s.mode = Config.s.mode === "light" ? "dark" : "light";
            run("nova-theme " + Config.s.mode); break;
        case "mic": Audio.toggleMic(); break;
        case "screenshot": Shell.close(); run("sleep 0.3; nova-record shot edit"); break;
        case "caffeine": caffeineOn = !caffeineOn; Idle.caffeine = caffeineOn; break;
        case "record": recordOn = !recordOn; Shell.close(); run(recordOn ? "sleep 0.3; nova-record start screen" : "nova-record stop"); break;
        case "hotspot": run("nmcli dev wifi hotspot"); break;
        case "kbl": kblLevel = (kblLevel + 1) % 4; run("brightnessctl -q -d '*kbd_backlight*' set " + Math.round(kblLevel / 3 * 100) + "%"); break;
        }
    }

    ColumnLayout {
        id: col
        anchors.fill: parent
        spacing: 14

        // header (no settings / power buttons by design)
        RowLayout {
            Layout.fillWidth: true
            ColumnLayout {
                spacing: 2
                SystemClock { id: clk; precision: SystemClock.Minutes }
                Text { text: root.editing ? "Drag to move · corner to resize" : Qt.formatDate(clk.date, "dddd"); color: Theme.text2; font.pixelSize: 13 }
                Text { text: root.editing ? "Edit controls" : Qt.formatDate(clk.date, "d MMMM"); color: Theme.text; font.pixelSize: 24; font.weight: Font.DemiBold }
            }
            Item { Layout.fillWidth: true }
            IconButton { visible: !root.editing; icon: "pencil"; iconSize: 17; onClicked: Shell.ccEditing = true }
            Rectangle {
                visible: root.editing
                implicitWidth: 64; implicitHeight: 34; radius: 11; color: Theme.surface3
                Text { anchors.centerIn: parent; text: "Reset"; color: Theme.text; font.pixelSize: 13; font.weight: Font.DemiBold }
                MouseArea { anchors.fill: parent; onClicked: root.layout = JSON.parse(JSON.stringify(Config.defaultCcLayout)) }
            }
            Rectangle {
                visible: root.editing
                implicitWidth: 80; implicitHeight: 34; radius: 11; color: Theme.accent
                RowLayout { anchors.centerIn: parent; spacing: 6
                    Icon { name: "check"; size: 15; color: Theme.onAccent }
                    Text { text: "Done"; color: Theme.onAccent; font.pixelSize: 13; font.weight: Font.DemiBold } }
                MouseArea { anchors.fill: parent; onClicked: { root.save(); Shell.ccEditing = false } }
            }
        }

        // tile grid
        Item {
            id: gridArea
            Layout.fillWidth: true
            implicitHeight: root.rows * root.cellH + (root.rows - 1) * root.gapPx

            // empty cells shown while editing
            Repeater {
                model: root.editing ? root.cols * root.rows : 0
                Rectangle {
                    required property int index
                    readonly property int cx: index % root.cols
                    readonly property int cy: Math.floor(index / root.cols)
                    visible: !root.layout.some(t => cx >= t.x && cx < t.x + t.w && cy >= t.y && cy < t.y + t.h)
                    x: cx * (root.cellW + root.gapPx); y: cy * (root.cellH + root.gapPx)
                    width: root.cellW; height: root.cellH; radius: 16
                    color: "transparent"; border.width: 1.5; border.color: Qt.rgba(1, 1, 1, 0.14)
                    Icon { anchors.centerIn: parent; name: "plus"; size: 18; color: Theme.text3 }
                }
            }
            // snap ghost while dragging
            Rectangle {
                id: ghost
                visible: false
                radius: 16; color: Theme.accentSoft; border.width: 2; border.color: Theme.accent
            }

            Repeater {
                model: root.layout
                delegate: Item {
                    id: tile
                    required property var modelData
                    required property int index
                    readonly property var meta: root.catalog[modelData.id] ?? ["square", modelData.id, 1, 1, 4, 4]
                    readonly property bool on: root.isOn(modelData.id)
                    x: modelData.x * (root.cellW + root.gapPx)
                    y: modelData.y * (root.cellH + root.gapPx)
                    width: modelData.w * root.cellW + (modelData.w - 1) * root.gapPx
                    height: modelData.h * root.cellH + (modelData.h - 1) * root.gapPx
                    z: dragArea.drag.active || resizeArea.pressed ? 10 : 1
                    rotation: dragArea.drag.active ? -2.5 : 0
                    Behavior on x { enabled: !dragArea.drag.active; NumberAnimation { duration: Theme.ms(160); easing.type: Easing.OutCubic } }
                    Behavior on y { enabled: !dragArea.drag.active; NumberAnimation { duration: Theme.ms(160); easing.type: Easing.OutCubic } }

                    // --- content by tile type ---
                    Loader {
                        anchors.fill: parent
                        sourceComponent: ["brightness", "volume", "micvol"].includes(tile.modelData.id) ? vpillC
                                       : tile.modelData.id === "power" ? powerC
                                       : tile.modelData.w >= 2 ? wideC : squareC
                    }
                    Component {
                        id: vpillC
                        VPill {
                            vertical: tile.height >= tile.width
                            interactive: !root.editing
                            icon: tile.modelData.id === "brightness" ? "sun" : tile.modelData.id === "volume" ? (Audio.muted ? "mute" : "volume") : "mic"
                            muted: tile.modelData.id === "volume" && Audio.muted
                            value: tile.modelData.id === "brightness" ? Brightness.value : tile.modelData.id === "volume" ? Audio.volume : Audio.micVolume
                            onMoved: v => {
                                if (tile.modelData.id === "brightness") Brightness.set(v);
                                else if (tile.modelData.id === "volume") Audio.setVolume(v);
                                else if (Audio.source?.audio) Audio.source.audio.volume = v;
                            }
                        }
                    }
                    Component {
                        id: wideC
                        Rectangle {
                            radius: 16; color: Theme.surface2
                            RowLayout {
                                anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 12; spacing: 12
                                Rectangle {
                                    implicitWidth: 36; implicitHeight: 36; radius: 12
                                    color: tile.on ? Theme.accent : Theme.surface3
                                    Icon { anchors.centerIn: parent; name: tile.meta[0]; size: 19; color: tile.on ? Theme.onAccent : Theme.text }
                                }
                                ColumnLayout { Layout.fillWidth: true; spacing: 1
                                    Text { text: tile.meta[1]; color: Theme.text; font.pixelSize: 13.5; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
                                    Text { text: root.sub(tile.modelData.id); visible: text !== ""; color: Theme.text2; font.pixelSize: 12; elide: Text.ElideRight; Layout.fillWidth: true } }
                                Icon { visible: tile.modelData.id === "wifi" || tile.modelData.id === "bluetooth"; name: "chevr"; size: 16; color: Theme.text3
                                    MouseArea { anchors.fill: parent; anchors.margins: -8; enabled: !root.editing
                                        onClicked: { Quickshell.execDetached(["nova-settings", "--page", "Connections"]); Shell.close() } } }
                            }
                            MouseArea { anchors.fill: parent; z: -1; enabled: !root.editing; onClicked: root.press(tile.modelData.id) }
                        }
                    }
                    Component {
                        id: squareC
                        Rectangle {
                            radius: 16; color: tile.on ? Theme.accent : Theme.surface2
                            Icon { anchors.centerIn: parent; name: tile.meta[0]; size: 20; color: tile.on ? Theme.onAccent : Theme.text }
                            MouseArea { anchors.fill: parent; enabled: !root.editing; onClicked: root.press(tile.modelData.id) }
                        }
                    }
                    Component {
                        id: powerC
                        Rectangle {
                            radius: 16; color: Theme.surface2
                            RowLayout {
                                anchors.fill: parent; anchors.margins: 4; spacing: 4
                                Repeater {
                                    model: [[PowerProfile.PowerSaver, "leaf", "Saver"], [PowerProfile.Balanced, "gauge", "Balanced"], [PowerProfile.Performance, "bolt", "Performance"]]
                                    Rectangle {
                                        required property var modelData
                                        readonly property bool sel: PowerProfiles.profile === modelData[0]
                                        visible: modelData[0] !== PowerProfile.Performance || PowerProfiles.hasPerformanceProfile
                                        Layout.fillWidth: true; Layout.fillHeight: true; radius: 12
                                        color: sel ? Theme.accent : "transparent"
                                        RowLayout { anchors.centerIn: parent; spacing: 7
                                            Icon { name: modelData[1]; size: 16; color: parent.parent.sel ? Theme.onAccent : Theme.text2 }
                                            Text { visible: tile.width > 300; text: modelData[2]; font.pixelSize: 12.5; font.weight: parent.parent.sel ? Font.DemiBold : Font.Normal; color: parent.parent.sel ? Theme.onAccent : Theme.text2 } }
                                        MouseArea { anchors.fill: parent; enabled: !root.editing; onClicked: PowerProfiles.profile = modelData[0] }
                                    }
                                }
                            }
                        }
                    }

                    // --- edit chrome ---
                    Rectangle {
                        visible: root.editing; anchors.fill: parent; radius: 16; color: "transparent"
                        border.width: 1.5; border.color: dragArea.drag.active ? Theme.accent : Qt.rgba(1, 1, 1, 0.22)
                    }
                    MouseArea {
                        id: dragArea
                        anchors.fill: parent
                        enabled: root.editing
                        drag.target: root.editing ? tile : null
                        cursorShape: root.editing ? Qt.OpenHandCursor : Qt.ArrowCursor
                        readonly property var cell: ({
                            x: Math.max(0, Math.min(root.cols - tile.modelData.w, Math.round(tile.x / (root.cellW + root.gapPx)))),
                            y: Math.max(0, Math.min(root.maxRows - tile.modelData.h, Math.round(tile.y / (root.cellH + root.gapPx))))
                        })
                        onPositionChanged: if (drag.active) {
                            const t = { x: cell.x, y: cell.y, w: tile.modelData.w, h: tile.modelData.h };
                            ghost.visible = !root.overlaps(t, tile.index);
                            ghost.x = t.x * (root.cellW + root.gapPx); ghost.y = t.y * (root.cellH + root.gapPx);
                            ghost.width = tile.width; ghost.height = tile.height;
                        }
                        onReleased: {
                            ghost.visible = false;
                            const t = Object.assign({}, tile.modelData, cell);
                            const l = root.layout.slice();
                            if (!root.overlaps(t, tile.index)) l[tile.index] = t;
                            root.layout = l;   // re-binds x/y (snaps back if blocked)
                        }
                    }
                    Rectangle {   // remove
                        visible: root.editing
                        x: parent.width - 15; y: -7; width: 22; height: 22; radius: 11; color: Theme.danger
                        Icon { anchors.centerIn: parent; name: "minus"; size: 13; color: "white" }
                        MouseArea { anchors.fill: parent; onClicked: { const l = root.layout.slice(); l.splice(tile.index, 1); root.layout = l } }
                    }
                    Item {        // resize corner
                        visible: root.editing
                        anchors.right: parent.right; anchors.bottom: parent.bottom
                        width: 24; height: 24
                        Icon { anchors.centerIn: parent; name: "resize"; size: 14; color: Theme.accent }
                        MouseArea {
                            id: resizeArea
                            anchors.fill: parent
                            cursorShape: Qt.SizeFDiagCursor
                            property real sx; property real sy
                            onPressed: m => { const p = mapToItem(gridArea, m.x, m.y); sx = p.x; sy = p.y }
                            onReleased: m => {
                                const p = mapToItem(gridArea, m.x, m.y);
                                const mt = tile.meta, d = tile.modelData;
                                const w = Math.max(mt[2], Math.min(mt[4], d.w + Math.round((p.x - sx) / (root.cellW + root.gapPx))));
                                const h = Math.max(mt[3], Math.min(mt[5], d.h + Math.round((p.y - sy) / (root.cellH + root.gapPx))));
                                const t = Object.assign({}, d, { w, h });
                                if (!root.overlaps(t, tile.index)) { const l = root.layout.slice(); l[tile.index] = t; root.layout = l }
                            }
                        }
                    }
                }
            }
        }

        // add-tile drawer
        ColumnLayout {
            visible: root.editing
            Layout.fillWidth: true; spacing: 10
            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.border }
            Text { text: "ADD CONTROLS"; color: Theme.text3; font.pixelSize: 12; font.weight: Font.DemiBold; font.letterSpacing: 0.7 }
            Flow {
                Layout.fillWidth: true; spacing: 8
                Repeater {
                    model: Object.keys(root.catalog).filter(id => !root.layout.some(t => t.id === id))
                    Rectangle {
                        required property string modelData
                        height: 34; width: chipRow.implicitWidth + 24; radius: 17; color: Theme.surface3
                        RowLayout { id: chipRow; anchors.centerIn: parent; spacing: 7
                            Icon { name: root.catalog[modelData][0]; size: 15; color: Theme.text }
                            Text { text: root.catalog[modelData][1]; color: Theme.text; font.pixelSize: 12.5 } }
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                const m = root.catalog[modelData];
                                const pos = root.firstFree(m[2], m[3]);
                                if (pos) root.layout = root.layout.concat([{ id: modelData, x: pos.x, y: pos.y, w: m[2], h: m[3] }]);
                            }
                        }
                    }
                }
            }
        }
    }
}
