// Bottom panel: launcher, pinned + running apps, clipboard, tray, status, clock.
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Services.SystemTray
import Quickshell.Services.UPower
import qs.services
import qs.components

PanelWindow {
    id: panel
    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.namespace: "nova-panel"
    anchors { bottom: true; left: true; right: true }
    implicitHeight: Theme.panelHeight
    exclusiveZone: Theme.panelHeight
    color: Theme.panel

    Rectangle { anchors { top: parent.top; left: parent.left; right: parent.right } height: 1; color: Theme.border }

    // ---------------------------------------------------------------- left
    RowLayout {
        anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
        spacing: 6

        PanelButton {
            active: Shell.popout === "launcher" && Shell.isPopoutScreen(panel.screen)
            onClicked: Shell.toggleOn("launcher", panel.screen)
            Icon { anchors.centerIn: parent; name: "nova"; size: 24; color: Theme.accent }
        }
        Rectangle { width: 1; height: 22; color: Theme.border; Layout.leftMargin: 6; Layout.rightMargin: 6 }

        Repeater {
            // pinned apps first, then running apps that aren't pinned
            model: {
                const pins = Config.s.pinned.map(id => id.toLowerCase());
                const extra = [];
                for (const t of ToplevelManager.toplevels.values) {
                    const id = (t.appId || "").toLowerCase();
                    if (id && !pins.some(p => p === id || p.endsWith("." + id) || id.endsWith("." + p)) && !extra.includes(id)) extra.push(id);
                }
                return Config.s.pinned.concat(extra);
            }
            delegate: PanelButton {
                id: appBtn
                required property string modelData
                readonly property var entry: DesktopEntries.heuristicLookup(modelData)
                readonly property var wins: ToplevelManager.toplevels.values.filter(t => {
                    const a = (t.appId || "").toLowerCase(), m = modelData.toLowerCase();
                    return a === m || m.endsWith("." + a) || a.endsWith("." + m) || (entry && a === (entry.id || "").toLowerCase());
                })
                readonly property bool focused: wins.some(t => t.activated)
                active: focused
                onClicked: {
                    if (wins.length === 0) { entry?.execute(); return }
                    const t = wins.find(w => w.activated);
                    if (t) t.minimized = true;          // click focused app -> minimise
                    else wins[0].activate();
                }
                AppIcon { anchors.centerIn: parent; appId: appBtn.modelData; implicitSize: 30 }
                Rectangle {   // open / focused indicator
                    visible: appBtn.wins.length > 0
                    anchors { bottom: parent.bottom; bottomMargin: 2; horizontalCenter: parent.horizontalCenter }
                    height: 3; radius: 2
                    width: appBtn.focused ? 16 : 5
                    color: appBtn.focused ? Theme.accent : Theme.text3
                    Behavior on width { NumberAnimation { duration: Theme.ms(160) } }
                }
            }
        }
    }

    // --------------------------------------------------------------- right
    RowLayout {
        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
        spacing: 6

        PanelButton {
            active: Shell.popout === "clipboard" && Shell.isPopoutScreen(panel.screen)
            onClicked: Shell.toggleOn("clipboard", panel.screen)
            Icon { anchors.centerIn: parent; name: "clip"; size: 20; color: Theme.text }
        }

        // Caps / Num Lock while on (Settings → Popups & indicators → Show in panel)
        Pill {
            visible: Config.s.lockInPanel && (Nova.capsLock || Nova.numLock)
            highlighted: true
            Icon { visible: Nova.capsLock; name: "caps"; size: 16; color: Theme.accentBright }
            Icon { visible: Nova.numLock; name: "hash"; size: 16; color: Theme.accentBright }
        }

        // app status icons (StatusNotifierItem tray)
        Pill {
            visible: SystemTray.items.values.length > 0
            Repeater {
                model: SystemTray.items
                delegate: AppIcon {
                    required property var modelData
                    source: modelData.icon
                    implicitSize: 18
                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                        onClicked: m => {
                            if (m.button === Qt.RightButton && modelData.hasMenu) {
                                const p = mapToItem(panel.contentItem, 0, 0);
                                modelData.display(panel, p.x, p.y - 8);
                            } else modelData.activate();
                        }
                    }
                }
            }
        }

        // status: network, volume, battery -> control centre
        Pill {
            highlighted: Shell.popout === "controlcentre" && Shell.isPopoutScreen(panel.screen)
            onClicked: Shell.toggleOn("controlcentre", panel.screen)
            Icon { name: Net.wired ? "net" : "wifi"; size: 18; color: Net.ssid || Net.wired ? Theme.text : Theme.text3 }
            Icon { name: Audio.muted ? "mute" : Audio.volume < 0.34 ? "volumelow" : "volume"; size: 18; color: Theme.text }
            Battery {
                visible: UPower.displayDevice?.isLaptopBattery ?? false
                level: UPower.displayDevice?.percentage ?? 0
                charging: !UPower.onBattery
            }
        }

        // clock: hover -> now playing, click -> calendar & notifications
        Pill {
            id: clockPill
            highlighted: (Shell.popout === "notifications" && Shell.isPopoutScreen(panel.screen)) || (Shell.npOpen && Shell.npScreen === panel.screen)
            onClicked: Shell.toggleOn("notifications", panel.screen)
            onHoveredChanged: { Shell.npScreen = panel.screen; Shell.clockHovered = hovered }

            // recording: red pill, click to stop
            Rectangle {
                visible: Shell.recording
                Layout.alignment: Qt.AlignVCenter
                implicitWidth: recRow.implicitWidth + 16; implicitHeight: 24; radius: 12; color: Qt.rgba(0.9, 0.3, 0.3, 0.2)
                RowLayout { id: recRow; anchors.centerIn: parent; spacing: 6
                    Rectangle { implicitWidth: 8; implicitHeight: 8; radius: 4; color: "#e5484d"
                        SequentialAnimation on opacity { running: Shell.recording; loops: Animation.Infinite
                            NumberAnimation { to: 0.3; duration: 600 } NumberAnimation { to: 1; duration: 600 } } }
                    Text { text: "Stop"; color: Theme.text; font.pixelSize: 11.5; font.weight: Font.DemiBold } }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Quickshell.execDetached(["nova-record", "stop"]) }
            }
            // music indicator on the clock pill: live visualizer if chosen in Settings, else the little bars
            MusicBars { visible: Media.playing && !(Config.s.vizPlaces ?? []).includes("clock"); active: Media.playing; Layout.alignment: Qt.AlignVCenter }
            Visualizer {
                visible: Media.playing && (Config.s.vizPlaces ?? []).includes("clock")
                Layout.alignment: Qt.AlignVCenter; implicitWidth: 34; implicitHeight: 16
                style: 1
            }
            SystemClock { id: clock; precision: SystemClock.Minutes }
            Column {
                Text {
                    anchors.right: parent.right
                    text: Qt.formatDateTime(clock.date, Config.s.clock24 ? "HH:mm" : "h:mm AP")
                    color: Theme.text; font.family: Theme.font; font.pixelSize: 14; font.weight: Font.DemiBold
                }
                Text {
                    anchors.right: parent.right
                    text: Qt.formatDateTime(clock.date, "ddd d MMM")
                    color: Theme.text2; font.family: Theme.font; font.pixelSize: 11.5
                }
            }
            Rectangle {
                visible: Notifs.count > 0
                implicitWidth: Math.max(20, badgeText.implicitWidth + 12); implicitHeight: 20; radius: 10
                color: Config.s.dnd ? Theme.surface3 : Theme.accent
                Text { id: badgeText; anchors.centerIn: parent; text: Notifs.count; font.pixelSize: 11; font.weight: Font.Bold; color: Config.s.dnd ? Theme.text2 : Theme.onAccent }
            }
        }
    }

    // ---- local helpers ----
    component PanelButton: Rectangle {
        id: pb
        property bool active: false
        default property alias inner: holder.data
        signal clicked()
        implicitWidth: 42; implicitHeight: 42; radius: 13
        color: active ? Theme.accentSoft : hov.hovered ? Theme.surface3 : "transparent"
        Item { id: holder; anchors.fill: parent }
        HoverHandler { id: hov }
        TapHandler { onTapped: pb.clicked() }
    }
    component Pill: Rectangle {
        id: pl
        property bool highlighted: false
        readonly property bool hovered: hov2.hovered
        default property alias inner: row.data
        signal clicked()
        implicitHeight: 38
        implicitWidth: row.implicitWidth + 26
        radius: 12
        color: highlighted ? Theme.accentSoft : hov2.hovered ? Theme.surface3 : Theme.surface2
        border.width: highlighted ? 1 : 0
        border.color: Theme.accentLine
        RowLayout { id: row; anchors.centerIn: parent; spacing: 11 }
        HoverHandler { id: hov2 }
        TapHandler { onTapped: pl.clicked() }
    }
}
