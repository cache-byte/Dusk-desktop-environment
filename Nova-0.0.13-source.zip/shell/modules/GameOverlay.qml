// Super+G: quick controls while gaming — game mode, FPS overlay, record, instant replay,
// screenshot, power mode, do not disturb, volume and mic. Opens above fullscreen games.
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.services
import qs.components

Glass {
    id: root
    width: 760
    height: col.implicitHeight + 2 * padding
    radius: 24
    padding: 18
    MouseArea { anchors.fill: parent; z: -1 }
    Keys.onEscapePressed: Shell.close()
    onVisibleChanged: if (visible) { forceActiveFocus(); prof.running = true }

    property string profile: ""
    Process { id: prof; command: ["powerprofilesctl", "get"]; stdout: StdioCollector { onStreamFinished: root.profile = text.trim() } }
    function setProfile(p) { Quickshell.execDetached(["powerprofilesctl", "set", p]); profile = p }

    component Tile: Rectangle {
        property string icon
        property string label
        property string sub
        property bool on
        property bool enabledTile: true
        signal hit()
        Layout.fillWidth: true; implicitHeight: 74; radius: 16
        opacity: enabledTile ? 1 : 0.4
        color: on ? Theme.accent : tma.containsMouse ? Theme.surface3 : Theme.surface2
        ColumnLayout { anchors.centerIn: parent; spacing: 4
            Icon { Layout.alignment: Qt.AlignHCenter; name: parent.parent.icon; size: 20; color: parent.parent.on ? Theme.onAccent : Theme.text }
            Text { Layout.alignment: Qt.AlignHCenter; text: parent.parent.label; font.pixelSize: 12.5; font.weight: Font.DemiBold; font.family: Theme.font
                   color: parent.parent.on ? Theme.onAccent : Theme.text }
            Text { visible: parent.parent.sub !== ""; Layout.alignment: Qt.AlignHCenter; text: parent.parent.sub; font.pixelSize: 10.5; font.family: Theme.font
                   color: parent.parent.on ? Theme.onAccent : Theme.text3 } }
        MouseArea { id: tma; anchors.fill: parent; hoverEnabled: true; enabled: parent.enabledTile; cursorShape: Qt.PointingHandCursor; onClicked: parent.hit() }
    }

    ColumnLayout {
        id: col
        anchors.left: parent.left; anchors.right: parent.right
        spacing: 14
        RowLayout {
            Layout.fillWidth: true; spacing: 10
            Icon { name: "game"; size: 20; color: Theme.accent }
            Text { text: "Game mode " + (Gaming.active ? "on" : Nova.fullscreen ? "waiting for the game" : "off"); color: Theme.text; font.pixelSize: 15; font.weight: Font.DemiBold; font.family: Theme.font }
            Item { Layout.fillWidth: true }
            Text { text: "Esc to close"; color: Theme.text3; font.pixelSize: 12; font.family: Theme.font }
        }
        RowLayout {
            Layout.fillWidth: true; spacing: 8
            Tile { icon: "gauge"; label: "FPS overlay"; sub: "next game launch"; on: Config.s.mangohud; onHit: Config.s.mangohud = !Config.s.mangohud }
            Tile { icon: "record"; label: Shell.recording ? "Stop" : "Record"; sub: "whole screen"; on: Shell.recording
                   onHit: { Shell.close(); Quickshell.execDetached(["nova-record", Shell.recording ? "stop" : "start", "screen"]) } }
            Tile { icon: "restart"; label: "Save replay"; sub: Replay.enabled ? "last " + (Config.s.replaySeconds ?? 30) + " s" : "replay is off"
                   enabledTile: Replay.enabled; onHit: Replay.save() }
            Tile { icon: "video"; label: "Instant replay"; sub: Replay.enabled ? "on" : "off"; on: Replay.enabled; onHit: Config.s.replayEnabled = !Config.s.replayEnabled }
            Tile { icon: "shot"; label: "Screenshot"; sub: "whole screen"; onHit: { Shell.close(); Quickshell.execDetached(["sh", "-c", "sleep 0.3; nova-record shot screen"]) } }
            Tile { icon: "moon"; label: "Do not disturb"; sub: Config.s.autoDnd ? "auto in fullscreen" : ""; on: Config.s.dnd; onHit: Config.s.dnd = !Config.s.dnd }
        }
        RowLayout {
            Layout.fillWidth: true; spacing: 6
            Repeater {
                model: [["power-saver", "leaf", "Saver"], ["balanced", "gauge", "Balanced"], ["performance", "bolt", "Performance"]]
                Rectangle {
                    required property var modelData
                    readonly property bool on: root.profile === modelData[0]
                    Layout.fillWidth: true; implicitHeight: 42; radius: 13; color: on ? Theme.accent : Theme.surface2
                    RowLayout { anchors.centerIn: parent; spacing: 7
                        Icon { name: parent.parent.modelData[1]; size: 15; color: parent.parent.on ? Theme.onAccent : Theme.text2 }
                        Text { text: parent.parent.modelData[2]; font.pixelSize: 13; font.family: Theme.font; color: parent.parent.on ? Theme.onAccent : Theme.text2
                               font.weight: parent.parent.on ? Font.DemiBold : Font.Normal } }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.setProfile(parent.modelData[0]) }
                }
            }
        }
        RowLayout {
            Layout.fillWidth: true; spacing: 12
            IconButton { icon: Audio.muted ? "mute" : "volume"; onClicked: Audio.toggleMute() }
            PillSlider { Layout.fillWidth: true; value: Audio.volume / Audio.maxVolume; onMoved: v => Audio.setVolume(v * Audio.maxVolume) }
            Text { text: Math.round(Audio.volume * 100) + "%"; color: Theme.text2; font.pixelSize: 12.5; font.family: Theme.font; Layout.preferredWidth: 40 }
            IconButton { icon: "mic"; iconColor: Audio.micMuted ? Theme.danger : Theme.text; onClicked: Audio.toggleMic() }
        }
    }
}
