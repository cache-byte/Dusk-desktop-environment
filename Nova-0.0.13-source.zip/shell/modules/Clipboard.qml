// Clipboard history (cliphist, fed by `wl-paste --watch cliphist store`).
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.services
import qs.components

Glass {
    id: root
    width: 420
    height: 520
    padding: 16
    MouseArea { anchors.fill: parent; z: -1 }
    property var items: []
    property string filter: ""

    onVisibleChanged: if (visible) { list.running = true; field.text = ""; field.forceActiveFocus() }
    Process {
        id: list
        command: ["cliphist", "list"]
        stdout: StdioCollector { onStreamFinished: root.items = text.split("\n").filter(l => l).slice(0, 100) }
    }
    function body(line) { return line.substring(line.indexOf("\t") + 1) }
    function pick(line) {
        Quickshell.execDetached(["sh", "-c", "printf '%s' \"$1\" | cliphist decode | wl-copy", "sh", line]);
        Shell.close();
    }

    ColumnLayout {
        anchors.fill: parent; spacing: 12
        RowLayout {
            Text { text: "Clipboard"; color: Theme.text; font.pixelSize: 18; font.weight: Font.DemiBold }
            Item { Layout.fillWidth: true }
            Rectangle {
                implicitWidth: 64; implicitHeight: 30; radius: 10; color: Theme.surface3
                Text { anchors.centerIn: parent; text: "Clear"; color: Theme.text; font.pixelSize: 12.5 }
                MouseArea { anchors.fill: parent; onClicked: { Quickshell.execDetached(["cliphist", "wipe"]); root.items = [] } }
            }
        }
        Rectangle {
            Layout.fillWidth: true; implicitHeight: 40; radius: 12; color: Theme.surface2
            RowLayout { anchors.fill: parent; anchors.leftMargin: 12; spacing: 10
                Icon { name: "search"; size: 16; color: Theme.text2 }
                TextInput { id: field; Layout.fillWidth: true; color: Theme.text; font.pixelSize: 13.5
                    onTextChanged: root.filter = text.toLowerCase()
                    Keys.onEscapePressed: Shell.close()
                    Keys.onReturnPressed: { const f = root.items.filter(l => root.body(l).toLowerCase().includes(root.filter)); if (f.length) root.pick(f[0]) } } }
        }
        ListView {
            Layout.fillWidth: true; Layout.fillHeight: true; clip: true; spacing: 4
            model: root.items.filter(l => root.body(l).toLowerCase().includes(root.filter))
            delegate: Rectangle {
                required property string modelData
                width: ListView.view.width; height: 46; radius: 11
                color: ma.containsMouse ? Theme.accentSoft : Theme.surface2
                Text { anchors.fill: parent; anchors.margins: 12; verticalAlignment: Text.AlignVCenter
                    text: root.body(modelData).replace(/\s+/g, " "); elide: Text.ElideRight; color: Theme.text; font.pixelSize: 13 }
                MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; onClicked: root.pick(modelData) }
            }
        }
    }
}
