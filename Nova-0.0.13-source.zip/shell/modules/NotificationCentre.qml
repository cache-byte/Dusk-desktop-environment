// Clock click: calendar + notification history + Do Not Disturb.
import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.services
import qs.components

Glass {
    id: root
    width: 420
    height: Math.min(860, col.implicitHeight + 36)
    padding: 18
    MouseArea { anchors.fill: parent; z: -1 }
    property date month: new Date()

    ColumnLayout {
        id: col
        anchors.fill: parent
        spacing: 14

        RowLayout {
            Text { text: Qt.formatDate(root.month, "MMMM yyyy"); color: Theme.text; font.pixelSize: 18; font.weight: Font.DemiBold }
            Item { Layout.fillWidth: true }
            IconButton { icon: "chevr"; rotation: 180; implicitWidth: 32; implicitHeight: 32; onClicked: root.month = new Date(root.month.getFullYear(), root.month.getMonth() - 1, 1) }
            IconButton { icon: "chevr"; implicitWidth: 32; implicitHeight: 32; onClicked: root.month = new Date(root.month.getFullYear(), root.month.getMonth() + 1, 1) }
        }
        GridLayout {
            Layout.fillWidth: true; columns: 7; rowSpacing: 2; columnSpacing: 2
            Repeater { model: ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
                Text { required property string modelData; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; text: modelData; color: Theme.text3; font.pixelSize: 11.5 } }
            Repeater {
                model: 42
                Rectangle {
                    required property int index
                    readonly property date first: new Date(root.month.getFullYear(), root.month.getMonth(), 1)
                    readonly property date day: new Date(first.getFullYear(), first.getMonth(), 1 - ((first.getDay() + 6) % 7) + index)
                    readonly property bool today: day.toDateString() === new Date().toDateString()
                    Layout.fillWidth: true; implicitHeight: 34; radius: 10
                    color: today ? Theme.accent : "transparent"
                    Text { anchors.centerIn: parent; text: parent.day.getDate()
                        color: parent.today ? Theme.onAccent : parent.day.getMonth() === root.month.getMonth() ? Theme.text : Theme.text3
                        font.pixelSize: 13; font.weight: parent.today ? Font.Bold : Font.Normal }
                }
            }
        }
        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.border }
        RowLayout {
            Text { text: "Notifications"; color: Theme.text; font.pixelSize: 15; font.weight: Font.DemiBold }
            Item { Layout.fillWidth: true }
            Text { text: "Do not disturb"; color: Theme.text2; font.pixelSize: 12.5 }
            Toggle { checked: Config.s.dnd; onToggled: v => Config.s.dnd = v }
        }
        ListView {
            Layout.fillWidth: true
            Layout.preferredHeight: Math.min(contentHeight, 360)
            clip: true; spacing: 8
            model: Notifs.groups
            delegate: ColumnLayout {
                id: grp
                required property var modelData
                property bool open: modelData.items.length <= 2
                width: ListView.view.width
                spacing: 6
                RowLayout {
                    visible: Config.s.groupNotifications && grp.modelData.items.length > 1
                    Layout.fillWidth: true
                    Text { text: grp.modelData.name; color: Theme.text2; font.pixelSize: 12; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: grp.open ? "Show less" : grp.modelData.items.length + " more"; color: Theme.accent; font.pixelSize: 12
                        MouseArea { anchors.fill: parent; onClicked: grp.open = !grp.open } }
                }
                Repeater {
                    model: grp.open ? grp.modelData.items : grp.modelData.items.slice(0, 1)
                    NotificationCard { required property var modelData; notif: modelData; Layout.fillWidth: true }
                }
            }
            Text { visible: Notifs.count === 0; anchors.centerIn: parent; text: "You're all caught up"; color: Theme.text3; font.pixelSize: 13 }
        }
        Rectangle {
            visible: Notifs.count > 0
            Layout.alignment: Qt.AlignRight
            implicitWidth: 86; implicitHeight: 32; radius: 11; color: Theme.surface3
            Text { anchors.centerIn: parent; text: "Clear all"; color: Theme.text; font.pixelSize: 12.5; font.weight: Font.DemiBold }
            MouseArea { anchors.fill: parent; onClicked: Notifs.clearAll() }
        }
    }
}
