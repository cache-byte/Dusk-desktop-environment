// Super+Tab: blurred wallpaper, workspaces along the top (x to close, + to add),
// a window search, and every window on the current workspace as a card
// (app icon bottom-left, close button top-right). Minimised windows on the right.
import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import qs.services
import qs.components

PanelWindow {
    id: win
    visible: Shell.overview && screen === (Shell.popoutScreen ?? Quickshell.screens[0])
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "nova-overview"
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
    exclusionMode: ExclusionMode.Ignore
    anchors { top: true; bottom: true; left: true; right: true }
    margins.bottom: Theme.panelHeight
    color: "transparent"

    property string query: ""
    onVisibleChanged: if (visible) { query = ""; search.text = ""; search.forceActiveFocus(); Nova.refreshWindows() }

    // this monitor's workspaces (each monitor has its own)
    readonly property var ws: Nova.wsFor(screen?.name ?? "")
    readonly property var mine: Nova.windows.filter(w => !w.output || w.output === (screen?.name ?? ""))
    readonly property var wins: (query ? Nova.windows : mine).filter(w => !w.minimized
        && (query ? (w.title + " " + w.app_id).toLowerCase().includes(query.toLowerCase()) : (w.index ?? w.workspace) === ws.active))
    readonly property var minimized: mine.filter(w => w.minimized)
    readonly property var workspaces: {
        const n = Math.max(ws.active, ...(ws.occupied || []), 1);
        return Array.from({ length: n }, (_, i) => i + 1);
    }

    // blurred wallpaper backdrop
    Image {
        id: wp
        anchors.fill: parent
        source: !Theme.wallpaperIsVideo ? Theme.wallpaperUrl : "file://" + Theme.defaultWallpaper
        fillMode: Image.PreserveAspectCrop
        visible: false
    }
    MultiEffect { anchors.fill: parent; source: wp; blurEnabled: true; blur: 1.0; blurMax: 64; brightness: -0.18; saturation: 0.2 }
    MouseArea { anchors.fill: parent; onClicked: Shell.close() }

    Item {
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: Shell.close()

        // workspaces
        Row {
            id: wsRow
            anchors { top: parent.top; topMargin: 34; horizontalCenter: parent.horizontalCenter }
            spacing: 16
            Repeater {
                model: win.workspaces
                Column {
                    required property int modelData
                    spacing: 8
                    Rectangle {
                        width: 220; height: 124; radius: 14; clip: true
                        color: Theme.surface
                        border.width: modelData === win.ws.active ? 2.5 : 1
                        border.color: modelData === win.ws.active ? Theme.accent : Qt.rgba(1, 1, 1, 0.12)
                        Image { anchors.fill: parent; anchors.margins: 2; source: wp.source; fillMode: Image.PreserveAspectCrop; opacity: 0.85 }
                        Text { anchors.centerIn: parent; text: win.mine.filter(w => (w.index ?? w.workspace) === parent.parent.modelData).length + " windows"
                               color: "white"; font.pixelSize: 12; style: Text.Raised; styleColor: "#80000000" }
                        MouseArea { anchors.fill: parent; onClicked: Nova.dispatch("workspace " + parent.parent.modelData) }
                        Rectangle {
                            visible: win.workspaces.length > 1
                            anchors { right: parent.right; top: parent.top; margins: 6 }
                            width: 22; height: 22; radius: 11; color: Theme.danger
                            Icon { anchors.centerIn: parent; name: "x"; size: 12; color: "white" }
                            MouseArea { anchors.fill: parent; onClicked: { Nova.dispatch("close-workspace " + (win.ws.base + parent.parent.parent.modelData - 1)); refresh.restart() } }
                        }
                    }
                    Text { anchors.horizontalCenter: parent.horizontalCenter; text: "Workspace " + modelData
                           color: modelData === win.ws.active ? Theme.accentBright : Theme.text2; font.pixelSize: 12.5
                           font.weight: modelData === win.ws.active ? Font.DemiBold : Font.Normal }
                }
            }
            Rectangle {
                visible: win.workspaces.length < 9
                width: 64; height: 124; radius: 14; color: "transparent"
                border.width: 1.5; border.color: Theme.accentLine
                Icon { anchors.centerIn: parent; name: "plus"; color: Theme.accentBright }
                MouseArea { anchors.fill: parent; onClicked: Nova.dispatch("workspace " + (win.workspaces.length + 1)) }
            }
        }

        // search
        Glass {
            id: searchBox
            anchors { top: wsRow.bottom; topMargin: 10; horizontalCenter: parent.horizontalCenter }
            width: 440; height: 46; radius: 23; padding: 0
            RowLayout {
                anchors.fill: parent; anchors.leftMargin: 18; anchors.rightMargin: 18; spacing: 12
                Icon { name: "search"; color: Theme.text2 }
                TextInput {
                    id: search
                    Layout.fillWidth: true
                    color: Theme.text; font.pixelSize: 14.5
                    cursorDelegate: Rectangle { width: 2; color: Theme.accent }
                    onTextChanged: win.query = text
                    Keys.onReturnPressed: if (win.wins.length) { Nova.dispatch("focus-window " + win.wins[0].id); Shell.close() }
                    Keys.onEscapePressed: Shell.close()
                    Text { visible: !search.text; text: "Search windows"; color: Theme.text3; font: search.font }
                }
            }
        }

        // windows
        Rectangle {
            id: stage
            anchors { top: searchBox.bottom; topMargin: 40; bottom: parent.bottom; bottomMargin: 30; left: parent.left; leftMargin: 150; right: parent.right; rightMargin: 290 }
            radius: 28
            color: Qt.rgba(1, 1, 1, 0.035)
            border.color: Qt.rgba(1, 1, 1, 0.06)

            Flow {
                anchors.centerIn: parent
                width: Math.min(parent.width - 80, implicitWidth)
                spacing: 48
                Repeater {
                    model: win.wins
                    WindowCard { required property var modelData; w: modelData }
                }
            }
            Text { visible: win.wins.length === 0; anchors.centerIn: parent; text: win.query ? "No matching windows" : "No windows on this workspace"; color: Theme.text3; font.pixelSize: 14 }
        }

        // minimised
        Column {
            anchors { top: stage.top; right: parent.right; rightMargin: 52 }
            width: 190; spacing: 12
            visible: win.minimized.length > 0
            Text { text: "MINIMIZED"; color: Theme.text3; font.pixelSize: 12; font.weight: Font.DemiBold; font.letterSpacing: 0.7 }
            Repeater {
                model: win.minimized
                Column {
                    required property var modelData
                    spacing: 6
                    Rectangle {
                        width: 190; height: 118; radius: 14; color: Theme.surface
                        AppIcon { anchors.centerIn: parent; appId: parent.parent.modelData.app_id; implicitSize: 48 }
                        MouseArea { anchors.fill: parent; onClicked: { Nova.dispatch("focus-window " + parent.parent.modelData.id); Shell.close() } }
                    }
                    Text { width: 190; elide: Text.ElideRight; text: parent.modelData.title; color: Theme.text3; font.pixelSize: 12 }
                }
            }
        }
    }
    Timer { id: refresh; interval: 150; onTriggered: Nova.refreshWindows() }

    // Window card. Live thumbnails need toplevel capture (wlroots >= 0.20 /
    // ext-image-copy-capture); until then the card shows the app icon large.
    component WindowCard: Column {
        id: wc
        property var w
        spacing: 14
        Item {
            width: 320; height: 210
            Rectangle {
                anchors.fill: parent; radius: 14
                color: Qt.rgba(0.08, 0.075, 0.105, 0.95)
                border.color: hov.hovered ? Theme.accent : Qt.rgba(1, 1, 1, 0.08)
                border.width: hov.hovered ? 2 : 1
                AppIcon { anchors.centerIn: parent; appId: wc.w.app_id; implicitSize: 72; opacity: 0.9 }
                HoverHandler { id: hov }
                MouseArea { anchors.fill: parent; onClicked: { Nova.dispatch("focus-window " + wc.w.id); Shell.close() } }
            }
            AppIcon { x: -14; y: parent.height - 32; appId: wc.w.app_id; implicitSize: 46 }
            Rectangle {
                x: parent.width - 18; y: -10; width: 28; height: 28; radius: 14; color: Theme.danger
                Icon { anchors.centerIn: parent; name: "x"; size: 14; color: "white" }
                MouseArea { anchors.fill: parent; onClicked: { Nova.dispatch("close-window " + wc.w.id); refresh.restart() } }
            }
        }
        Text { width: 320; horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight; text: wc.w.title || wc.w.app_id; color: Theme.text2; font.pixelSize: 13 }
    }
}
