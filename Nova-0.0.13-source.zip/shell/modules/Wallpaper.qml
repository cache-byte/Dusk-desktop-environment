// Background layer: wallpaper (image or video) + desktop icons from ~/Desktop.
import QtQuick
import QtMultimedia
import Qt.labs.folderlistmodel
import Quickshell
import Quickshell.Wayland
import qs.services
import qs.components

PanelWindow {
    id: win
    WlrLayershell.layer: WlrLayer.Background
    WlrLayershell.namespace: "nova-wallpaper"
    exclusionMode: ExclusionMode.Ignore
    anchors { top: true; bottom: true; left: true; right: true }
    color: "black"

    readonly property string src: Theme.wallpaperPath
    readonly property bool isVideo: /\.(mp4|webm|mkv|mov)$/i.test(src)
    readonly property int fillMode: Config.s.wallpaperFill === "fit" ? Image.PreserveAspectFit
                                  : Config.s.wallpaperFill === "center" ? Image.Pad : Image.PreserveAspectCrop

    Image {
        anchors.fill: parent
        visible: !win.isVideo
        source: win.isVideo ? "" : "file://" + win.src.replace(/^file:\/\//, "")
        fillMode: win.fillMode
        asynchronous: true
        cache: false
    }
    Video {
        anchors.fill: parent
        visible: win.isVideo
        source: win.isVideo ? "file://" + win.src : ""
        loops: MediaPlayer.Infinite
        muted: true
        autoPlay: true
        fillMode: VideoOutput.PreserveAspectCrop
    }

    // ---- desktop icons ----
    property int selected: -1
    FolderListModel {
        id: desk
        folder: "file://" + Quickshell.env("HOME") + "/Desktop"
        showDirsFirst: true
        showHidden: false
    }
    MouseArea { anchors.fill: parent; onClicked: win.selected = -1 }
    Grid {
        visible: Config.s.showDesktopIcons
        x: 28; y: 28
        flow: Grid.TopToBottom
        rows: Math.max(1, Math.floor((win.height - Theme.panelHeight - 56) / 108))
        spacing: 6
        Repeater {
            model: desk
            delegate: Rectangle {
                required property int index
                required property string fileName
                required property string filePath
                required property bool fileIsDir
                width: 96; height: 102; radius: 12
                color: win.selected === index ? Theme.accentSoft : "transparent"
                border.color: win.selected === index ? Theme.accentLine : "transparent"
                Column {
                    anchors.centerIn: parent
                    spacing: 8
                    AppIcon {
                        anchors.horizontalCenter: parent.horizontalCenter
                        implicitSize: 48
                        iconName: fileIsDir ? "folder" : (/\.(png|jpe?g|webp|svg)$/i.test(fileName) ? "image-x-generic"
                                  : /\.desktop$/i.test(fileName) ? "application-x-executable" : "text-x-generic")
                    }
                    Text {
                        width: 90
                        horizontalAlignment: Text.AlignHCenter
                        text: fileName.replace(/\.desktop$/, "")
                        elide: Text.ElideMiddle
                        color: "white"; style: Text.Raised; styleColor: Qt.rgba(0, 0, 0, 0.7)
                        font.family: Theme.font; font.pixelSize: 12.5
                    }
                }
                MouseArea {
                    anchors.fill: parent
                    onClicked: win.selected = index
                    onDoubleClicked: Quickshell.execDetached(["xdg-open", filePath])
                }
            }
        }
    }
}
