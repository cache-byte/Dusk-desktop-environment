# Nova

A calm, dark Wayland desktop for Linux, written from scratch in C++20 on
[wlroots](https://gitlab.freedesktop.org/wlroots/wlroots) 0.20 and
[scenefx](https://github.com/wlrfx/scenefx). Floating windows with snapping
and tiling layouts, panels and a dock, a control centre, an overview with
workspaces, notifications, a lock screen and its own Settings app, all in
one program with no shell toolkit underneath.

Nova 1.0 is the desktop that was called **Dusk** (0.5 – 0.35) and **Floe**
(before that). It also replaces the short-lived Nova preview built on KWin
and Quickshell: the look and the ideas came across, the KWin parts did not.

Runs on **Fedora**, **Arch** and **Debian/Ubuntu** (anything with wlroots 0.20).

## What's new in 1.1.2

- **Nova's taskbar:** the menu button with Nova's burst logo on an accent square, the overview button (four squares) instead of the workspace count, pinned and open apps, then the tray, clipboard, the status pill, notifications and the clock (set once; Edit panels changes it).
- **The status pill** is a soft grey pill, lighter while the quick settings are open (it was lit in the accent).
- **Settings in Nova's colours:** the page #121214, the sidebar darker, cards a step lighter, and always solid (the header bar showed the wallpaper through it).

## What's new in 1.1.1

- **Settings builds again:** 1.1.0 stopped with "run_in_terminal is ambiguous" (the new Users page had a second copy of a helper Settings already had).

## What's new in 1.1.0

- **Settings arranged like Nova's:** the same groups and order (Personalise, Connections, System, Windows, Apps & people, About), each page's name large at the top left, and pages with tabs: Keyboard & touchpad, Apps (default and startup apps), Region & language, Desktop & clipboard (with screenshots and media), Appearance (with animations).
- **New Settings pages:** Wi-Fi & network (networks, hidden networks, saved ones, VPNs, airplane mode), Bluetooth (your devices, finding and pairing new ones), Sound (output, microphone and each app's volume), Users & accounts (your picture, name, password and signing in automatically) and Storage (how full your disks are, emptying the trash and clearing old previews).
- **Nova's app menu:** the pinned apps in a card, every app A to Z under them, and you, Settings, lock and power in a card along the bottom.
- **Nova's buttons and tabs:** rounder buttons and pill-shaped tabs in Settings.

## What's new in 1.0.2

- **Nova's control centre:** tiles are dark cards with hairline borders; a tile that's on gets a soft accent tint and an accent edge (not a solid accent block); small toggles are rounded squares that turn into accent circles; sliders are cards with a tinted fill and an accent edge line; the battery row has Nova's ring battery and the power modes as a segmented control.
- **Notifications on their own:** the clock opens them; the status pill opens the quick settings, sized to what's in it.
- **Nova's panel:** the status icons sit in a soft pill with the ring battery, open apps get a small dot (wider for the one in front) and a quiet grey highlight instead of the accent, and the app menu button is an accent square.
- **The app menu's search field** is tinted with the accent, like Nova's.

## What's new in 1.0.1

- **Builds everywhere:** the wlroots protocol files the installer downloads (where the system has no package for them) are kept where the build can read them. 1.0.0 stopped with "Sandbox violation".

## What's new in 1.0.0

- **Dusk is now Nova:** new name, same desktop. Your settings, pinned apps, wallpapers and shortcuts move across by themselves, and the login screen offers Nova instead of Dusk.
- **Nova's look:** black and near-black surfaces in dark mode, soft greys (never pure white) in light mode, hairline borders, soft shadows, rounder corners (24 px panels and cards, 16 px windows) and round title bar buttons on the right. Settings uses the same colours.
- **One look, done well:** the Windows 11, GNOME and macOS imitations of the panels, app menu and control centre are gone; Nova's own is the only one.
- **Other programs' panels and launchers work:** layer-shell support, so Waybar, rofi, fuzzel, wofi, swaync, mako, swaybg and slurp run on Nova and keep their space free.
- **Screen sharing:** Discord, OBS, Zoom and browsers can share a screen or window through xdg-desktop-portal-wlr (installed for you). With more than one screen, click the one to share.
- **Lock screens from other programs:** swaylock, hyprlock and gtklock work (ext-session-lock). If one crashes, Nova's own lock screen takes over rather than unlocking.
- **Window lists for other programs:** taskbars, docks and switchers from elsewhere see Nova's windows (wlr-foreign-toplevel and ext-foreign-toplevel-list).
- **Screen tools:** wlr-randr, kanshi and wdisplays can set up screens (saved like a change in Settings › Displays), wlopm can turn screens off, and wlsunset or gammastep can set colours (Nova's night light steps aside meanwhile).
- **Typing in other languages:** Fcitx 5 and IBus work in Wayland apps (text-input-v3 and input-method-v2), with the candidate list under the text cursor.
- **Touchscreens and pens:** touch goes straight to apps (a tap is a click on Nova's own panels and menus), and drawing tablets send pressure and tilt to apps like Krita and GIMP.
- **Gaming page in Settings:** variable refresh rate turns on by itself while a game is full screen, Performance power mode while you play, MangoHud overlay, GameMode and the faster graphics card on laptops for games started from Nova.
- **Window rules:** Settings › Windows › Window rules sends an app to a workspace or screen, full screen, maximised, centred, sticky or at a size when it opens.
- **Accessibility page:** sticky keys and bounce keys.
- **Sandboxed apps kept in their box:** Flatpak apps can't use the protocols that read the screen, type for you or cover the screen.

## Install

```sh
unzip Nova-1.1.2-source.zip -d ~/src && cd ~/src/nova && ./install.sh
```

`install.sh` (or double-click it in Files and pick "Run as a program") installs what's missing with your package manager (it asks for
your password), builds Nova, installs it to `/usr/local` and adds **Nova** to
the login screen. Log out and pick Nova.

- `./build.sh build` only compiles; `./build.sh run` opens Nova in a window inside your current desktop, to try it.
- `./uninstall.sh` (or `nova-uninstall`) removes it again.
- **Ctrl+Alt+Backspace** ends the session if anything goes badly wrong.

The first build also downloads scenefx, and on Debian/Ubuntu (which doesn't
package them) the wlroots protocol files.

### Coming from Dusk

Open **Settings › About › Updates** in Dusk and update as usual: Dusk's
repository has one last release, `Dusk-1.1.2-source.zip`, which is Nova 1.0
under the old name. It installs Nova,
moves `~/.config/dusk` to `~/.config/nova`, switches your login session to
Nova and removes Dusk. Log out and back in. From then on, updates come from
Nova's own repository.

### Coming from the KWin/Quickshell Nova preview (0.1.x)

Updating from its Settings downloads this version to `~/src/Nova-1.1.2` and
asks you to run `install.sh` there once (Nova 1.0 installs differently). Or
just install it as above. The installer turns the old services off and removes
the preview's files, its login screen theme (your previous one comes back)
and its Quickshell shell. Your old `settings.json` is kept beside the new
settings as `settings.json.quickshell-nova`.

## Updating

**Settings › About › Updates** checks GitHub, downloads the new version,
builds it and installs it, asking for your password in a window. Or from a
terminal:

```sh
nova-update             # newest version
nova-update --list      # every version
nova-update 1.0.0       # a particular one
nova-update --zip FILE  # a zip you already have
```

Versions are the `Nova-X.Y.Z-source.zip` files in
[cache-byte/Nova-desktop-environment](https://github.com/cache-byte/Nova-desktop-environment).
Set `NOVA_GITHUB=owner/repo` to update from a fork.

## Gaming

A focused full-screen window counts as a game. While one plays:

- nothing of Nova's is drawn over it, so it can go straight to the screen;
- background work (the media wave, wallpaper video, clocks) pauses;
- a game that asks to skip vsync can (tearing control, if allowed);
- variable refresh (FreeSync, G-Sync, Adaptive Sync) turns on if the screen can, and back off afterwards;
- the power mode goes to Performance, and back.

Games and launchers (anything in the *Game* category, or Steam, Lutris,
Heroic, Bottles, itch) started from the app menu, dock or overview go through
`nova-game-run`, which adds MangoHud, GameMode and the dedicated graphics card
on hybrid laptops, as Settings › Gaming says. To use it from Steam for one
game: `nova-game-run %command%` in the game's launch options.

**Super+Escape** takes the keyboard back and redraws everything if a game
leaves the desktop stuck.

## Shortcuts

| Keys | Action |
|---|---|
| Super (tap) | Overview (or the app menu: Settings › Workspaces) |
| Alt+F1 | App menu |
| Super+A or Super+N | Control centre |
| Super+Enter | Terminal |
| Super+I | Nova Settings |
| Super+E | Your files |
| Super+V | Clipboard history |
| Super+K | On-screen keyboard |
| Print | Screenshot tool (area, window or screen) |
| Shift+Print / Alt+Print | All screens / the active window, at once |
| Super+D | Show the desktop |
| Super+F | Full screen |
| Alt+Tab / Alt+Shift+Tab | Switch windows |
| Alt+F4 or Super+Q | Close window |
| Super+Up / Super+Down | Maximise / restore or minimise |
| Super+Left / Super+Right | Snap to half the screen |
| Super+Z | Snap layouts |
| Super+Shift+Left / Right | Move the window to the next screen |
| Super + left / right drag | Move / resize a window from anywhere in it |
| Super+Escape | Unstick (after a game) |
| Ctrl+Alt+Backspace | End the session |

All of them can be changed in Settings › Keyboard.

## Settings

Changes apply at once. They live in `~/.config/nova/nova.conf`, a plain
`key = value` file you can edit by hand (Nova notices when it's saved):

```
theme = dark
accent = #4d8df6
output.HDMI-A-1.mode = 2560x1440@143.912
output.HDMI-A-1.vrr = true
scale.eDP-1 = 1.25
vrr_games = true
mangohud = false
sticky_keys = false
bounce_keys = 0
rule.1 = steam_app_* : workspace 3, fullscreen
rule.2 = title:*Picture-in-Picture* : sticky
```

Window rules are `app : what`, where `app` is the app ID (`*` and `?` match
anything) or `title:` and the window's name; what can happen: `workspace N`,
`maximize`, `fullscreen`, `center`, `sticky`, `size WxH`, `screen NAME`. The
first rule that matches wins.

## Works with

| | |
|---|---|
| Panels, docks, launchers | Waybar, rofi (Wayland), fuzzel, wofi, nwg-dock, swaync, mako |
| Lock screens | Nova's own, swaylock, hyprlock, gtklock |
| Screens | Settings › Displays, wlr-randr, kanshi, wdisplays, wlopm |
| Colour temperature | Nova's night light, wlsunset, gammastep |
| Screen sharing | xdg-desktop-portal-wlr (Discord, OBS, Firefox, Chromium, Zoom) |
| Screenshots | Nova's own, grim + slurp, Flameshot (portal) |
| Input methods | Fcitx 5, IBus |
| Remote control | wayvnc, KDE Connect input, ydotool (virtual keyboard and pointer) |
| Apps | Wayland apps, X11 apps through Xwayland, Flatpaks |

## Planned

Still to come across from the Quickshell version of Nova:

- Get new stuff (wallpapers, icons, cursors and themes from the KDE Store)
- Video wallpapers
- The first-run setup (five steps)
- Special keys (Copilot and laptop keys, with press, double-press and hold)
- Toasts (power mode and other quick notes) and the plug-in charging popup
- The large battery card (cells) in the control centre and Power & battery
- Editing panels by dragging items onto them
- Printers and Privacy & security pages
- Updates & about with rollback, system and Flatpak updates and the health check

Also:

- HDR and wide colour
- VR headsets (DRM leasing)
- Apps surviving a Nova crash (session recovery)
- Screen zoom and colour filters (accessibility)
- Sharp X11 apps on scaled screens (Xwayland scaling)
- Drawing tablet pad buttons and rings

## How it's built

| Part | Where |
|---|---|
| The compositor: windows, input, screens, shortcuts | `src/server.cpp`, `src/view.cpp`, `src/xdg_view.cpp`, `src/xwayland.cpp` |
| Layer-shell, session lock, window lists, screen tools, input methods, touch, pens, rules | `src/extras.cpp` |
| Panels, dock, control centre, app menu, overview | `src/panel.cpp`, `src/ccentre.cpp`, `src/launcher.cpp`, `src/overview.cpp` |
| Notifications, on-screen display, lock screen | `src/notify.cpp`, `src/osd.cpp`, `src/lock.cpp` |
| Colours, fonts and drawing | `src/draw.hpp` (`theme::set_theme`), `src/draw.cpp` |
| Settings app (Qt 6) | `settings/main.cpp` |
| Installer, updater, helpers | `build.sh`, `data/nova-update`, `data/nova-game-run`, `data/nova-apply-theme`, `data/nova-doctor` |

The full history (Floe, Dusk) is in [CHANGELOG.md](CHANGELOG.md).

## Languages

The desktop and Settings are in English. App names and descriptions follow
your language (from the apps' own `.desktop` files), and dates and times use
your region's formats (Settings › Language & region). Translations are welcome.

## Credits

Nova stands on a lot of other people's work:

- [wlroots](https://gitlab.freedesktop.org/wlroots/wlroots): the Wayland compositor library everything is built on
- [scenefx](https://github.com/wlrfx/scenefx) (from SwayFX): blur, shadows and rounded corners
- [Wayland](https://wayland.freedesktop.org/), [wayland-protocols](https://gitlab.freedesktop.org/wayland/wayland-protocols) and [wlr-protocols](https://gitlab.freedesktop.org/wlroots/wlr-protocols)
- [Xwayland](https://gitlab.freedesktop.org/xorg/xserver) for X11 apps
- [cairo](https://www.cairographics.org/) and [Pango](https://pango.gnome.org/) for drawing and text; [gdk-pixbuf](https://gitlab.gnome.org/GNOME/gdk-pixbuf) for pictures
- [libinput](https://gitlab.freedesktop.org/libinput/libinput) and [xkbcommon](https://xkbcommon.org/) for input
- [Qt 6](https://www.qt.io/) for Settings
- [Lucide](https://lucide.dev/) icons (ISC licence)
- [Sway](https://github.com/swaywm/sway), [dwl](https://codeberg.org/dwl/dwl) and [labwc](https://github.com/labwc/labwc), whose code shows how the wlroots protocols fit together
- [xdg-desktop-portal-wlr](https://github.com/emersion/xdg-desktop-portal-wlr) and [xdg-desktop-portal-gtk](https://github.com/flatpak/xdg-desktop-portal-gtk)
- [MangoHud](https://github.com/flightlessmango/MangoHud), [GameMode](https://github.com/FeralInteractive/gamemode) and [power-profiles-daemon](https://gitlab.freedesktop.org/upower/power-profiles-daemon) for the gaming features
- [SongRec](https://github.com/marin-m/SongRec) and [LRCLIB](https://lrclib.net/) for song recognition and lyrics
- [adw-gtk3](https://github.com/lassekongo83/adw-gtk3) so GTK 3 apps match
- GNOME and libadwaita, whose settings Nova keeps in step so apps follow light, dark and the accent colour

## Contributors

- **cache-byte**: creator, design and testing
- **Claude** (Anthropic): wrote much of the code with cache-byte

Issues and pull requests are welcome at
[cache-byte/Nova-desktop-environment](https://github.com/cache-byte/Nova-desktop-environment).

## Licence

Nova is free software under the GNU General Public License, version 3 or
later (see `LICENSE`). The bundled Lucide icons are under the ISC licence;
wlroots and scenefx are under the MIT licence.
